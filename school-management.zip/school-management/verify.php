<?php
require 'config/db.php';
echo 'Total: ' . $pdo->query('SELECT COUNT(*) FROM students')->fetchColumn() . "\n";
echo 'Pending: ' . $pdo->query("SELECT COUNT(*) FROM students WHERE status='Pending'")->fetchColumn() . "\n";
echo 'Approved: ' . $pdo->query("SELECT COUNT(*) FROM students WHERE status='Approved'")->fetchColumn() . "\n";
echo 'Rejected: ' . $pdo->query("SELECT COUNT(*) FROM students WHERE status='Rejected'")->fetchColumn() . "\n";
?>

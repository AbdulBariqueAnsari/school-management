<?php
require_once 'includes/init.php';

// If maintenance mode is off, or user is super admin, redirect to login/dashboard
$stmt = $pdo->query("SELECT setting_value FROM super_admin_settings WHERE setting_key = 'maintenance_mode'");
$maintenance = $stmt->fetchColumn();

if ($maintenance != '1' || (isset($_SESSION['role_id']) && $_SESSION['role_id'] == 1)) {
    redirect(BASE_URL . '/index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Under Maintenance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
        }
        .maintenance-card {
            max-width: 500px;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
            background: white;
        }
        .icon-container {
            font-size: 60px;
            color: #ffc107;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

    <div class="maintenance-card">
        <div class="icon-container">
            <i class="fa-solid fa-person-digging"></i>
        </div>
        <h2 class="fw-bold mb-3">We'll be back soon!</h2>
        <p class="text-muted mb-4">Sorry for the inconvenience but we're performing some maintenance at the moment. We'll be back online shortly!</p>
        <a href="login.php" class="btn btn-outline-primary">Admin Login</a>
    </div>

</body>
</html>

<?php
require_once 'includes/auth.php';

// Master router for initial logins based on roles
switch ($_SESSION['role_id']) {
    case 1:
        redirect(BASE_URL . '/admin/index.php');
        break;
    case 2:
        redirect(BASE_URL . '/principal/index.php');
        break;
    case 3:
        redirect(BASE_URL . '/clerk/index.php');
        break;
    case 4:
    case 5:
    case 8:
        redirect(BASE_URL . '/teacher/dashboard.php');
        break;
    case 6:
        redirect(BASE_URL . '/student/index.php');
        break;
    case 7:
        redirect(BASE_URL . '/parent/index.php');
        break;
    default:
        echo "Valid role not found for dashboard redirect.";
        exit();
}
?>

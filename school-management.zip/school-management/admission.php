<?php
require_once 'includes/init.php';

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_admission'])) {
    // Collect basics
    $full_name = trim($_POST['full_name']);
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $blood_group = $_POST['blood_group'] ?? null;
    $aadhaar_number = $_POST['aadhaar_number'] ?? null;

    // Contact
    $present_address = trim($_POST['present_address']);
    $mobile_number = trim($_POST['mobile_number']);

    // Health
    $has_med = $_POST['has_medical_condition'] == 'Yes' ? 1 : 0;
    $med_desc = $_POST['medical_condition_desc'] ?? null;
    $has_dis = $_POST['has_disability'] == 'Yes' ? 1 : 0;
    $dis_desc = $_POST['disability_desc'] ?? null;
    $has_alg = $_POST['has_allergies'] == 'Yes' ? 1 : 0;
    $alg_desc = $_POST['allergies_desc'] ?? null;

    // Identity
    $religion = $_POST['religion'] ?? null;
    $caste = $_POST['caste_category'] ?? 'General';
    $mother_tongue = $_POST['mother_tongue'] ?? null;

    // Parent
    $father_name = trim($_POST['father_name']);
    $father_mobile = trim($_POST['father_mobile']);
    $mother_name = trim($_POST['mother_name']);
    $mother_mobile = trim($_POST['mother_mobile']);
    $parents_address = trim($_POST['parents_address']);

    $guardian_name = trim($_POST['guardian_name'] ?? '');
    $relation = trim($_POST['relation'] ?? '');
    $guardian_mobile = trim($_POST['guardian_mobile'] ?? '');
    $guardian_address = trim($_POST['guardian_address'] ?? '');

    // Academic
    $prev_status = $_POST['previous_schooling_status'];
    $class_applying = $_POST['class_applying_for'];
    $prev_class = $_POST['previous_class'] ?? null;
    $prev_school = $_POST['previous_school_name'] ?? null;
    $prev_board = $_POST['previous_board'] ?? null;
    $pass_year = $_POST['year_of_passing'] ?? null;

    // Portal
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $hash = password_hash($password, PASSWORD_BCRYPT);

    try {
        $pdo->beginTransaction();

        // Handle Photo Upload (Save to disk)
        $photoName = null;
        if (isset($_FILES['student_photo']) && $_FILES['student_photo']['error'] == 0) {
            $ext = strtolower(pathinfo($_FILES['student_photo']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png']) && $_FILES['student_photo']['size'] <= 1048576) {
                $uploadDir = 'uploads/students/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                $photoName = 'stu_' . time() . '.' . $ext;
                if (!move_uploaded_file($_FILES['student_photo']['tmp_name'], $uploadDir . $photoName)) {
                    throw new Exception("Failed to save uploaded photo.");
                }
            }
            else {
                throw new Exception("Invalid photo format or size (Max 1MB).");
            }
        }

        // Insert exactly into admission_requests as expected by the consolidated system
        $stmtApp = $pdo->prepare("INSERT INTO admission_requests 
            (student_name, dob, gender, blood_group, address, previous_school, aadhaar_number, 
            parent_name, parent_phone, parent_email, class_applied, status,
            student_photo, mobile_number, religion, caste_category, mother_tongue,
            father_name, father_mobile, mother_name, mother_mobile, parents_address,
            guardian_name, relation, guardian_mobile, guardian_address,
            has_medical_condition, medical_condition_desc, has_disability, disability_desc,
            has_allergies, allergies_desc, previous_schooling_status, previous_class,
            previous_board, year_of_passing) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending',
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmtApp->execute([
            $full_name, $dob, $gender, $blood_group, $present_address, $prev_school, $aadhaar_number,
            $father_name, $father_mobile, $email, $class_applying,
            $photoName, $mobile_number, $religion, $caste, $mother_tongue,
            $father_name, $father_mobile, $mother_name, $mother_mobile, $parents_address,
            $guardian_name, $relation, $guardian_mobile, $guardian_address,
            $has_med, $med_desc, $has_dis, $dis_desc,
            $has_alg, $alg_desc, $prev_status, $prev_class,
            $prev_board, $pass_year
        ]);

        $application_id = $pdo->lastInsertId();

        $admission_no = 'ADM-' . date('Y') . '-' . str_pad($application_id, 4, '0', STR_PAD_LEFT);
        $pdo->prepare("UPDATE admission_requests SET admission_no = ? WHERE id = ?")->execute([$admission_no, $application_id]);

        $pdo->commit();
        redirect(BASE_URL . '/admission_success.php?uid=' . $application_id);

    }
    catch (Exception $e) {
        $pdo->rollBack();
        $err = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admission Form | School Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/admission.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<div class="container">
    <div class="wizard-container">
        <div class="wizard-header text-center">
            <h2 class="fw-bold" style="color: #000080; text-shadow: 2px 2px 4px #aaa; text-transform: uppercase;"><i class="fa fa-user-graduate"></i> REGISTRATION FORM</h2>
            <p class="mb-0">Please fill out all details accurately. Mismatched info during verification will reject your application.</p>
        </div>

        <div class="wizard-content">
            <?php if ($msg): ?>
                <div class="alert alert-success text-center pb-5 pt-5 border-0 bg-light-success">
                    <i class="fa fa-check-circle fa-4x text-success mb-3"></i>
                    <h4>Success!</h4>
                    <p><?php echo $msg; ?></p>
                    <a href="dashboard.php" class="btn btn-primary mt-3">Return to Home</a>
                </div>
            <?php
else: ?>
                <?php if ($err): ?><div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> <?php echo $err; ?></div><?php
    endif; ?>

                <div class="progress mb-4">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" id="progressBar" role="progressbar" style="width: 14%;"></div>
                </div>

                <div class="step-indicator mb-5">
                    <div class="step-item active" data-step="1">1</div>
                    <div class="step-item" data-step="2">2</div>
                    <div class="step-item" data-step="3">3</div>
                    <div class="step-item" data-step="4">4</div>
                    <div class="step-item" data-step="5">5</div>
                    <div class="step-item" data-step="6">6</div>
                    <div class="step-item" data-step="7"><i class="fa fa-lock"></i></div>
                </div>

                <form method="POST" enctype="multipart/form-data" id="admissionForm">

                    <!-- STEP 1 -->
                    <div class="step-content active" id="step1">
                        <div class="mb-4 pb-2" style="border-bottom: 2px solid #000080;">
                            <h4 class="text-uppercase fw-bold mb-0" style="color: #000080; text-shadow: 1px 1px 2px #ccc;"><i class="fa fa-id-card"></i> STUDENT DETAILS</h4>
                            <h6 class="text-secondary mt-1">(BASIC IDENTITY)</h6>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Full Name</label>
                                <input type="text" name="full_name" class="form-control" placeholder="As per Birth Certificate" required>
                                <div class="form-text">Exact name matching official records.</div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Gender</label>
                                <select name="gender" class="form-select" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label required-star">Date of Birth</label>
                                <input type="date" name="dob" id="dobInput" class="form-control" required>
                            </div>
                            <div class="col-md-2 mb-3">
                                <label class="form-label">Age</label>
                                <input type="text" id="ageDisplay" class="form-control bg-light" readonly>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Class Applying For</label>
                                <select name="class_applying_for" class="form-select" required>
                                    <option value="">Select Class</option>
                                    <?php
    $clsStmt = $pdo->query("SELECT id, name FROM classes ORDER BY id");
    while ($clRow = $clsStmt->fetch()) {
        echo "<option value=\"{$clRow['id']}\">{$clRow['name']}</option>";
    }
?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Blood Group</label>
                                <select name="blood_group" class="form-select">
                                    <option value="">Select</option>
                                    <option value="A+">A+</option><option value="A-">A-</option>
                                    <option value="B+">B+</option><option value="B-">B-</option>
                                    <option value="O+">O+</option><option value="O-">O-</option>
                                    <option value="AB+">AB+</option><option value="AB-">AB-</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Aadhaar Number (Optional)</label>
                                <input type="text" name="aadhaar_number" class="form-control" placeholder="12 Digit No.">
                            </div>
                            <div class="col-md-12 mb-3">
                                <label class="form-label required-star">Student Photo Upload</label>
                                <input type="file" name="student_photo" class="form-control" accept="image/jpeg, image/png" required>
                                <div class="form-text text-danger">Max size: 1MB. JPG/PNG only.</div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end mt-4"><button type="button" class="btn btn-primary btn-next" onclick="nextStep(1)">Next &rarr;</button></div>
                    </div>

                    <!-- STEP 2 -->
                    <div class="step-content" id="step2">
                        <div class="mb-4 pb-2" style="border-bottom: 2px solid #000080;">
                            <h4 class="text-uppercase fw-bold mb-0" style="color: #000080; text-shadow: 1px 1px 2px #ccc;"><i class="fa fa-address-book"></i> CONTACT DETAILS</h4>
                            <h6 class="text-secondary mt-1">(ADDRESS & PHONE)</h6>
                        </div>
                        <div class="mb-3">
                            <label class="form-label required-star">Present Address</label>
                            <textarea name="present_address" class="form-control" rows="3" placeholder="Full residential address" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Student Mobile Number</label>
                            <div class="input-group">
                                <span class="input-group-text">🇮🇳 +91</span>
                                <input type="text" name="mobile_number" class="form-control" placeholder="Optional">
                            </div>
                        </div>
                        <div class="d-flex justify-content-between mt-4">
                            <button type="button" class="btn btn-secondary btn-prev" onclick="prevStep(2)">&larr; Previous</button>
                            <button type="button" class="btn btn-primary btn-next" onclick="nextStep(2)">Next &rarr;</button>
                        </div>
                    </div>

                    <!-- STEP 3 -->
                    <div class="step-content" id="step3">
                        <div class="mb-4 pb-2" style="border-bottom: 2px solid #000080;">
                            <h4 class="text-uppercase fw-bold mb-0" style="color: #000080; text-shadow: 1px 1px 2px #ccc;"><i class="fa fa-heartbeat"></i> HEALTH INFORMATION</h4>
                            <h6 class="text-secondary mt-1">(MEDICAL HISTORY)</h6>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label required-star">Any Medical Condition?</label>
                            <select name="has_medical_condition" class="form-select trigger-show" data-target="med_desc" required>
                                <option value="No">No</option>
                                <option value="Yes">Yes</option>
                            </select>
                        </div>
                        <div class="mb-3 hidden-section" id="med_desc">
                            <label class="form-label required-star">Specify Medical Condition</label>
                            <textarea name="medical_condition_desc" class="form-control" rows="2"></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label required-star">Disability?</label>
                            <select name="has_disability" class="form-select trigger-show" data-target="dis_desc" required>
                                <option value="No">No</option>
                                <option value="Yes">Yes</option>
                            </select>
                        </div>
                        <div class="mb-3 hidden-section" id="dis_desc">
                            <label class="form-label required-star">Explain Disability</label>
                            <textarea name="disability_desc" class="form-control" rows="2"></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label required-star">Allergies?</label>
                            <select name="has_allergies" class="form-select trigger-show" data-target="alg_desc" required>
                                <option value="No">No</option>
                                <option value="Yes">Yes</option>
                            </select>
                        </div>
                        <div class="mb-3 hidden-section" id="alg_desc">
                            <label class="form-label required-star">Specify Allergy</label>
                            <textarea name="allergies_desc" class="form-control" rows="2"></textarea>
                        </div>

                        <div class="d-flex justify-content-between mt-4">
                            <button type="button" class="btn btn-secondary btn-prev" onclick="prevStep(3)">&larr; Previous</button>
                            <button type="button" class="btn btn-primary btn-next" onclick="nextStep(3)">Next &rarr;</button>
                        </div>
                    </div>

                    <!-- STEP 4 -->
                    <div class="step-content" id="step4">
                        <div class="mb-4 pb-2" style="border-bottom: 2px solid #000080;">
                            <h4 class="text-uppercase fw-bold mb-0" style="color: #000080; text-shadow: 1px 1px 2px #ccc;"><i class="fa fa-fingerprint"></i> IDENTITY & CATEGORY</h4>
                            <h6 class="text-secondary mt-1">(SOCIAL BACKGROUND)</h6>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Religion</label>
                                <select name="religion" class="form-select" required>
                                    <option value="">Select Religion</option>
                                    <option value="Hindu">Hindu</option>
                                    <option value="Islam">Islam</option>
                                    <option value="Christian">Christian</option>
                                    <option value="Buddhist">Buddhist</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Caste Category</label>
                                <select name="caste_category" class="form-select" required>
                                    <option value="General">General</option>
                                    <option value="OBC-A">OBC-A</option>
                                    <option value="OBC-B">OBC-B</option>
                                    <option value="SC">SC</option>
                                    <option value="ST">ST</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Mother Tongue</label>
                                <input type="text" name="mother_tongue" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Previous Schooling Status</label>
                                <select name="previous_schooling_status" id="academicTrigger" class="form-select" required>
                                    <option value="">Select Status</option>
                                    <option value="Passed from Previous School">Passed from Previous School</option>
                                    <option value="Currently Studying">Currently Studying</option>
                                    <option value="Transfer Certificate">Transfer Certificate</option>
                                    <option value="Left School">Left School</option>
                                    <option value="Never Attended School">Never Attended School</option>
                                </select>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between mt-4">
                            <button type="button" class="btn btn-secondary btn-prev" onclick="prevStep(4)">&larr; Previous</button>
                            <button type="button" class="btn btn-primary btn-next" onclick="nextStep(4)">Next &rarr;</button>
                        </div>
                    </div>

                    <!-- STEP 5 -->
                    <div class="step-content" id="step5">
                        <div class="mb-4 pb-2" style="border-bottom: 2px solid #000080;">
                            <h4 class="text-uppercase fw-bold mb-0" style="color: #000080; text-shadow: 1px 1px 2px #ccc;"><i class="fa fa-users"></i> PARENT/GUARDIAN DETAILS</h4>
                            <h6 class="text-secondary mt-1">(CONTACT & PROFILES)</h6>
                        </div>
                        <div class="row bg-light p-3 rounded mb-3 border">
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Father's Name</label>
                                <input type="text" name="father_name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Father's Mobile</label>
                                <input type="text" name="father_mobile" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Mother's Name</label>
                                <input type="text" name="mother_name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Mother's Mobile</label>
                                <input type="text" name="mother_mobile" class="form-control" required>
                            </div>
                            <div class="col-md-12">
                                <label class="form-label required-star">Parents Address</label>
                                <textarea name="parents_address" class="form-control" rows="2" required></textarea>
                            </div>
                        </div>

                        <h5 class="mt-4 border-bottom pb-2 text-secondary">Local Guardian Details</h5>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Guardian Name</label>
                                <input type="text" name="guardian_name" id="gName" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3 hidden-section g-field">
                                <label class="form-label">Relation with Student</label>
                                <input type="text" name="relation" class="form-control req-guard">
                            </div>
                            <div class="col-md-6 mb-3 hidden-section g-field">
                                <label class="form-label">Guardian Mobile</label>
                                <input type="text" name="guardian_mobile" class="form-control req-guard">
                            </div>
                            <div class="col-md-12 mb-3 hidden-section g-field">
                                <label class="form-label">Guardian Address</label>
                                <textarea name="guardian_address" class="form-control req-guard" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between mt-4">
                            <button type="button" class="btn btn-secondary btn-prev" onclick="prevStep(5)">&larr; Previous</button>
                            <button type="button" class="btn btn-primary btn-next" onclick="nextStep(5)">Next &rarr;</button>
                        </div>
                    </div>

                    <!-- STEP 6 -->
                    <div class="step-content" id="step6">
                        <div class="mb-4 pb-2" style="border-bottom: 2px solid #000080;">
                            <h4 class="text-uppercase fw-bold mb-0" style="color: #000080; text-shadow: 1px 1px 2px #ccc;"><i class="fa fa-book"></i> ACADEMIC DETAILS</h4>
                            <h6 class="text-secondary mt-1">(PREVIOUS SCHOOLING)</h6>
                        </div>
                        <div class="alert alert-info" id="noAcademicAlert" style="display:none;">
                            You selected "Never Attended School". This section is not required. Click Next to continue.
                        </div>
                        <div class="row" id="academicFields">
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Previous Class</label>
                                <input type="text" name="previous_class" class="form-control req-acad">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Previous School Name</label>
                                <input type="text" name="previous_school_name" class="form-control req-acad">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Previous Board</label>
                                <input type="text" name="previous_board" class="form-control req-acad">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Year of Passing</label>
                                <input type="number" name="year_of_passing" class="form-control req-acad" min="2000" max="2030">
                            </div>
                        </div>
                        <div class="d-flex justify-content-between mt-4">
                            <button type="button" class="btn btn-secondary btn-prev" onclick="prevStep(6)">&larr; Previous</button>
                            <button type="button" class="btn btn-primary btn-next" onclick="nextStep(6)">Next &rarr;</button>
                        </div>
                    </div>

                    <!-- STEP 7 -->
                    <div class="step-content" id="step7">
                        <div class="mb-4 pb-2" style="border-bottom: 2px solid #000080;">
                            <h4 class="text-uppercase fw-bold mb-0" style="color: #000080; text-shadow: 1px 1px 2px #ccc;"><i class="fa fa-lock"></i> PORTAL LOGIN DETAILS</h4>
                            <h6 class="text-secondary mt-1">(ACCOUNT SETUP)</h6>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Desired Username</label>
                                <input type="text" name="username" class="form-control" required pattern="[a-zA-Z0-9_]{5,20}" title="5-20 characters, no spaces">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Email Address</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Password</label>
                                <input type="password" name="password" id="pass" class="form-control" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
                                <div class="form-text">Min 8 chars, 1 uppercase, 1 number, 1 special char.</div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label required-star">Confirm Password</label>
                                <input type="password" id="cpass" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-check mt-3 mb-4">
                            <input class="form-check-input" type="checkbox" id="declaration" required>
                            <label class="form-check-label" for="declaration" style="font-size: 0.9em; text-align: justify;">
                                I hereby declare that the information provided in this Admission-cum-Registration Form is true, complete, and accurate to the best of my knowledge. I understand that any false or misleading information may result in cancellation of admission.<br><br>I agree to abide by all the rules, regulations, and policies of the school as amended from time to time.<br><br>I also give my consent to the school to use the student’s information for academic records, administrative purposes, communication, and official school activities.<br><br>I accept full responsibility for ensuring timely submission of required documents and payment of fees.
                            </label>
                        </div>
                        <div class="d-flex justify-content-between mt-4 border-top pt-4">
                            <button type="button" class="btn btn-secondary btn-prev" onclick="prevStep(7)">&larr; Previous</button>
                            <button type="submit" name="submit_admission" class="btn btn-success btn-submit fw-bold"><i class="fa fa-paper-plane me-2"></i> Submit Application</button>
                        </div>
                    </div>

                </form>
            <?php
endif; ?>
        </div>
    </div>
</div>

<script src="assets/js/admission.js?v=2"></script>
</body>
</html>

<?php
require 'config/db.php';
$stmt = $pdo->query("SELECT class_applied, gender, COUNT(*) as c FROM students WHERE username LIKE 'student_%' GROUP BY class_applied, gender");
$res = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($res as $r) {
    echo $r['class_applied'] . " - " . $r['gender'] . ": " . $r['c'] . "\n";
}

$stmt2 = $pdo->query("SELECT status, COUNT(*) as c FROM students WHERE username LIKE 'student_%' GROUP BY status");
$res2 = $stmt2->fetchAll(PDO::FETCH_ASSOC);
foreach($res2 as $r) {
    echo $r['status'] . ": " . $r['c'] . "\n";
}

$stmt3 = $pdo->query("SELECT COUNT(DISTINCT email) as unique_emails, COUNT(DISTINCT username) as unique_users, COUNT(*) as total FROM students WHERE username LIKE 'student_%'");
$res3 = $stmt3->fetch(PDO::FETCH_ASSOC);
print_r($res3);

<?php
require 'config/db.php';

// 1. Temporarily rename all student emails and usernames to avoid unique conflicts.
echo "Phase 1: Renaming existing student emails and usernames temporarily...\n";
$pdo->exec("UPDATE users SET email = CONCAT('temp_', id, '_', email), username = CONCAT('temp_', username) WHERE role_id = 6");

// 2. Realign credentials by student record and repair missing student-user links.
echo "Phase 2: Realigning credentials with Student IDs...\n";

$updateUserStmt = $pdo->prepare("UPDATE users SET email = ?, username = ?, password = ? WHERE id = ?");
$insertUserStmt = $pdo->prepare("INSERT INTO users (name, username, email, password, role_id, is_active) VALUES (?, ?, ?, ?, 6, 1)");
$linkStudentStmt = $pdo->prepare("UPDATE students SET user_id = ? WHERE id = ?");

$passHash = password_hash('Password123', PASSWORD_BCRYPT);
$students = $pdo->query("SELECT s.id AS student_id, s.student_name, s.user_id, u.id AS linked_user_id FROM students s LEFT JOIN users u ON s.user_id = u.id")->fetchAll(PDO::FETCH_ASSOC);

$updated = 0;
$created = 0;
foreach ($students as $student) {
    $studentId = (int)$student['student_id'];
    $expectedEmail = "student{$studentId}@school.com";
    $expectedUsername = "student_{$studentId}";
    $name = $student['student_name'] ?: "Student {$studentId}";

    if (!$student['user_id'] || !$student['linked_user_id']) {
        // Create a new user account for unlinked/missing student records.
        $tempUsername = "temp_student_{$studentId}";
        $tempEmail = "temp_student_{$studentId}@school.com";

        $insertUserStmt->execute([$name, $tempUsername, $tempEmail, $passHash]);
        $newUserId = $pdo->lastInsertId();

        $updateUserStmt->execute([$expectedEmail, $expectedUsername, $passHash, $newUserId]);
        $linkStudentStmt->execute([$newUserId, $studentId]);
        $created++;
        continue;
    }

    $updateUserStmt->execute([$expectedEmail, $expectedUsername, $passHash, $student['user_id']]);
    $updated++;
}

echo "Updated $updated existing student user accounts.\n";
echo "Created and linked $created missing student user accounts.\n";

// 3. Cleanup orphaned student user accounts that are no longer linked to any student.
echo "Phase 3: Cleanup orphaned student user accounts...\n";
$deleted = $pdo->exec("DELETE FROM users WHERE role_id = 6 AND id NOT IN (SELECT user_id FROM students WHERE user_id IS NOT NULL)");
echo "Deleted $deleted orphaned student user accounts.\n";

// 4. Optional verification sample.
echo "\nVerification sample for Student #6:\n";
$stmt = $pdo->prepare("SELECT u.email, u.username, u.id, s.user_id FROM users u JOIN students s ON u.id = s.user_id WHERE s.id = 6");
$stmt->execute();
print_r($stmt->fetch(PDO::FETCH_ASSOC));

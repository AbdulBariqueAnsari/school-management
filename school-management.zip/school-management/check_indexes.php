<?php
require_once 'config/db.php';
echo "STUDENTS INDEXES:\n";
$stmt = $pdo->query("SHOW INDEX FROM students");
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "Table: " . $row['Table'] . " | Non_unique: " . $row['Non_unique'] . " | Key_name: " . $row['Key_name'] . " | Column_name: " . $row['Column_name'] . "\n";
}
echo "---\nUSERS INDEXES:\n";
$stmt = $pdo->query("SHOW INDEX FROM users");
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "Table: " . $row['Table'] . " | Non_unique: " . $row['Non_unique'] . " | Key_name: " . $row['Key_name'] . " | Column_name: " . $row['Column_name'] . "\n";
}

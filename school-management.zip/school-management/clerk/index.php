<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 3) {
    redirect(BASE_URL . '/dashboard.php');
}

$received = role_count("SELECT COALESCE(SUM(amount_paid),0) FROM payments WHERE status='Completed'");
$pending = role_count("SELECT COALESCE(SUM(amount_paid),0) FROM payments WHERE status='Pending'");
$cards = [
    ['Fee Heads', role_count("SELECT COUNT(*) FROM fees")],
    ['Payments', role_count("SELECT COUNT(*) FROM payments")],
    ['Received', role_money($received)],
    ['Pending', role_money($pending)],
];

$payments = role_rows("SELECT student_id, fee_id, amount_paid, payment_method, status, payment_date FROM payments ORDER BY payment_date DESC", [], 10);
$students = role_rows("SELECT admission_no, student_name, class_applied, parent_name, status FROM students ORDER BY student_name", [], 10);

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php role_page_hero('Clerk & Accounts Dashboard', 'Fees, payments, student account support and daily collection tracking.', 'fa-calculator'); ?>
    <div class="row g-3 mb-4"><?php role_render_cards($cards); ?></div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3 d-flex justify-content-between">
                    <h2 class="h5 fw-bold mb-0">Recent Payments</h2>
                    <a href="module.php?type=payments" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <?php role_render_table(['Student ID', 'Fee ID', 'Paid', 'Method', 'Status', 'Date'], $payments); ?>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3"><h2 class="h5 fw-bold mb-0">Quick Actions</h2></div>
                <div class="list-group list-group-flush">
                    <a href="notices.php" class="list-group-item list-group-item-action"><i class="fa fa-bullhorn me-2 text-warning"></i> School Notice Board</a>
                    <a href="module.php?type=fees" class="list-group-item list-group-item-action"><i class="fa fa-file-invoice-dollar me-2 text-primary"></i> Fee Heads</a>
                    <a href="module.php?type=payments" class="list-group-item list-group-item-action"><i class="fa fa-money-check-dollar me-2 text-success"></i> Payments</a>
                    <a href="module.php?type=students" class="list-group-item list-group-item-action"><i class="fa fa-user-graduate me-2 text-info"></i> Student Accounts</a>
                    <a href="module.php?type=admissions" class="list-group-item list-group-item-action"><i class="fa fa-user-plus me-2 text-warning"></i> Admission Support</a>
                    <a href="exam_verify.php" class="list-group-item list-group-item-action"><i class="fa fa-clipboard-check me-2" style="color: #0ea5e9;"></i> Verify Exam Forms</a>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3"><h2 class="h5 fw-bold mb-0">Student Account Snapshot</h2></div>
                <?php role_render_table(['Admission No', 'Student', 'Class', 'Parent', 'Status'], $students); ?>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

<?php
require_once '../includes/auth.php';

if ($_SESSION['role_id'] != 3) {
    redirect(BASE_URL . '/login.php');
}

$portal_title = 'Clerk Profile & Settings';
require_once '../includes/shared_profile.php';
?>

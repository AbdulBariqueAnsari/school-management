<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

// Verify authentication
if (!isset($_SESSION['role_id'])) {
    redirect(BASE_URL . '/login.php');
}

$role_id = (int)$_SESSION['role_id'];

// Fetch announcements matching the current user's role or general notices
$stmt = $pdo->prepare("
    SELECT a.*, r.name as target_role_name, u.name as creator_name
    FROM announcements a
    LEFT JOIN roles r ON a.target_role_id = r.id
    LEFT JOIN users u ON a.created_by = u.id
    WHERE a.target_role_id = ? OR a.target_role_id IS NULL
    ORDER BY a.created_at DESC
");
$stmt->execute([$role_id]);
$notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="main-content">
    <?php role_page_hero('Official Notice Board', 'View school-wide notices, announcements, attachments, and updates published by the Principal.', 'fa-bullhorn'); ?>

    <!-- Real-time Filter Bar -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 16px; background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(10px);">
        <div class="card-body p-3">
            <div class="row g-2 align-items-center">
                <div class="col-md-8 position-relative">
                    <i class="fa fa-magnifying-glass position-absolute text-muted" style="left: 20px; top: 50%; transform: translateY(-50%);"></i>
                    <input type="text" id="noticeSearch" class="form-control bg-light border-0 ps-5 py-2.5" placeholder="Search notices by title, keywords, or content..." onkeyup="filterNotices();">
                </div>
                <div class="col-md-4">
                    <select id="noticeFilter" class="form-select bg-light border-0 py-2.5" onchange="filterNotices();">
                        <option value="all">All Notice Types</option>
                        <option value="general">General Announcements Only</option>
                        <option value="portal">Role Specific Notices</option>
                        <option value="attachment">Notices with Attachments</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Notices Grid -->
    <div class="row g-4" id="noticesContainer">
        <?php if (!$notices): ?>
            <div class="col-12 text-center py-5">
                <div class="card border-0 shadow-sm py-5" style="border-radius: 16px;">
                    <div class="card-body">
                        <i class="fa fa-bell-slash fa-4x text-muted opacity-25 mb-3"></i>
                        <h4 class="fw-bold text-dark">Notice Board is Empty</h4>
                        <p class="text-secondary mb-0">There are no notices published for your account type at the moment.</p>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($notices as $row): ?>
                <?php 
                $has_attachment = !empty($row['attachment_path']) ? 'yes' : 'no';
                $notice_type = empty($row['target_role_id']) ? 'general' : 'portal';
                ?>
                <div class="col-md-6 col-xl-4 notice-card-wrapper" data-attachment="<?php echo $has_attachment; ?>" data-type="<?php echo $notice_type; ?>">
                    <div class="card border-0 shadow-sm h-100 transition-all dashboard-card-hover" style="border-radius: 16px; overflow: hidden; background: #ffffff;">
                        <div class="card-header border-0 bg-light-subtle pt-4 px-4 pb-2 d-flex justify-content-between align-items-center">
                            <?php if (empty($row['target_role_name'])): ?>
                                <span class="badge bg-primary-subtle text-primary fw-semibold px-2.5 py-1.5 rounded-pill"><i class="fa-solid fa-users me-1"></i> General Announcement</span>
                            <?php else: ?>
                                <span class="badge bg-warning-subtle text-warning-emphasis fw-semibold px-2.5 py-1.5 rounded-pill"><i class="fa-solid fa-user-lock me-1"></i> <?php echo htmlspecialchars($row['target_role_name']); ?> Special</span>
                            <?php endif; ?>
                            
                            <small class="text-muted"><i class="fa-regular fa-clock me-1"></i><?php echo date('d M', strtotime($row['created_at'])); ?></small>
                        </div>
                        <div class="card-body px-4 pt-2 pb-3">
                            <h5 class="card-title fw-bold text-dark mb-2 notice-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                            <p class="card-text text-secondary small notice-content" style="line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 4; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis; white-space: normal;">
                                <?php echo htmlspecialchars($row['content']); ?>
                            </p>
                        </div>
                        <div class="card-footer border-0 bg-white px-4 pb-4 pt-0">
                            <!-- Attachments -->
                            <?php if (!empty($row['attachment_path'])): ?>
                                <div class="p-2.5 border rounded-3 bg-light d-flex align-items-center justify-content-between mb-3">
                                    <div class="d-flex align-items-center gap-2">
                                        <?php if ($row['attachment_type'] === 'pdf'): ?>
                                            <i class="fa-solid fa-file-pdf text-danger fs-4"></i>
                                            <div class="lh-sm">
                                                <span class="d-block text-dark fw-bold text-truncate small" style="max-width: 130px;">Document.pdf</span>
                                                <small class="text-muted" style="font-size:0.7rem;">PDF Document</small>
                                            </div>
                                        <?php else: ?>
                                            <i class="fa-solid fa-image text-primary fs-4"></i>
                                            <div class="lh-sm">
                                                <span class="d-block text-dark fw-bold text-truncate small" style="max-width: 130px;">Image_Attachment</span>
                                                <small class="text-muted" style="font-size:0.7rem;">Notice Image</small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <?php if ($row['attachment_type'] === 'pdf'): ?>
                                            <a href="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" target="_blank" class="btn btn-xs btn-danger fw-bold py-1 px-2.5 shadow-none" style="font-size: 0.72rem;">
                                                <i class="fa-solid fa-arrow-up-right-from-square me-1"></i>Open
                                            </a>
                                        <?php else: ?>
                                            <button class="btn btn-xs btn-primary fw-bold py-1 px-2.5 shadow-none" style="font-size: 0.72rem;" data-bs-toggle="modal" data-bs-target="#viewImageModal<?php echo $row['id']; ?>">
                                                <i class="fa-solid fa-eye me-1"></i>View
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="d-flex justify-content-between align-items-center pt-2 border-top border-light">
                                <small class="text-muted">Posted by: <strong><?php echo htmlspecialchars($row['creator_name'] ?? 'Principal'); ?></strong></small>
                                <button class="btn btn-sm btn-outline-primary px-3 rounded-pill" data-bs-toggle="modal" data-bs-target="#viewNoticeModal<?php echo $row['id']; ?>"><i class="fa fa-expand me-1"></i> Read Details</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Dialogs for Detailed View & Lightbox -->
<?php if ($notices): ?>
    <?php foreach ($notices as $row): ?>
        <!-- Notice Detail Modal -->
        <div class="modal fade" id="viewNoticeModal<?php echo $row['id']; ?>" tabindex="-1" data-bs-backdrop="false" style="background: rgba(15,23,42,0.5); backdrop-filter: blur(8px);">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden; background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px);">
                    <div class="modal-header border-0 bg-light p-4">
                        <div>
                            <span class="badge bg-primary mb-2">Notice ID: #<?php echo $row['id']; ?></span>
                            <h4 class="modal-title fw-bold text-dark mb-0"><?php echo htmlspecialchars($row['title']); ?></h4>
                            <small class="text-muted">Published on: <?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></small>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body p-4">
                        <div class="mb-4">
                            <span class="text-muted small d-block mb-1">Target Audience:</span>
                            <?php if (empty($row['target_role_name'])): ?>
                                <span class="badge bg-primary-subtle text-primary fw-semibold"><i class="fa-solid fa-users me-1"></i> All Users</span>
                            <?php else: ?>
                                <span class="badge bg-secondary-subtle text-secondary fw-semibold"><i class="fa-solid fa-user me-1"></i> <?php echo htmlspecialchars($row['target_role_name']); ?> Only</span>
                            <?php endif; ?>
                        </div>

                        <div class="mb-4">
                            <span class="text-muted small d-block mb-2">Notice Content:</span>
                            <div class="p-3 bg-light rounded-3 text-secondary" style="white-space: pre-wrap; line-height: 1.6; font-size: 0.95rem; border-left: 4px solid #2563eb;">
                                <?php echo htmlspecialchars($row['content']); ?>
                            </div>
                        </div>

                        <?php if (!empty($row['attachment_path'])): ?>
                            <h6 class="fw-bold text-dark mb-3"><i class="fa fa-paperclip me-2 text-primary"></i>Attachment Attachment</h6>
                            <?php if ($row['attachment_type'] === 'pdf'): ?>
                                <div class="ratio ratio-16x9 border rounded-3 bg-white mb-2 overflow-hidden shadow-sm">
                                    <iframe src="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" frameborder="0"></iframe>
                                </div>
                                <div class="text-center mt-2">
                                    <a href="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" target="_blank" class="btn btn-outline-danger btn-sm fw-bold">
                                        <i class="fa fa-up-right-from-square me-2"></i>Open PDF in New Window
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="text-center border rounded-3 bg-white p-3 shadow-sm">
                                    <img src="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" class="img-fluid rounded-2 max-height-300" style="max-height: 400px; object-fit: contain;">
                                    <div class="mt-3">
                                        <a href="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" target="_blank" class="btn btn-outline-primary btn-sm fw-bold">
                                            <i class="fa fa-download me-2"></i>Download Image
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer border-0 bg-light p-3">
                        <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Image Lightbox Modal if the notice has an image -->
        <?php if (!empty($row['attachment_path']) && $row['attachment_type'] === 'image'): ?>
            <div class="modal fade" id="viewImageModal<?php echo $row['id']; ?>" tabindex="-1" data-bs-backdrop="false" style="background: rgba(15,23,42,0.7); backdrop-filter: blur(10px);">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content border-0 bg-transparent text-center">
                        <div class="text-end mb-2">
                            <button type="button" class="btn-close btn-close-white fs-4" data-bs-dismiss="modal"></button>
                        </div>
                        <img src="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" class="img-fluid rounded shadow-lg" style="max-height: 80vh; object-fit: contain;">
                        <div class="text-white mt-3 fw-bold fs-5"><?php echo htmlspecialchars($row['title']); ?></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
<?php endif; ?>

<script>
function filterNotices() {
    const searchVal = document.getElementById('noticeSearch').value.toLowerCase();
    const filterVal = document.getElementById('noticeFilter').value;
    const cards = document.querySelectorAll('.notice-card-wrapper');

    cards.forEach(card => {
        const title = card.querySelector('.notice-title').textContent.toLowerCase();
        const content = card.querySelector('.notice-content').textContent.toLowerCase();
        const hasAttachment = card.getAttribute('data-attachment');
        const type = card.getAttribute('data-type');

        // Search match
        const matchesSearch = title.includes(searchVal) || content.includes(searchVal);
        
        // Filter match
        let matchesFilter = true;
        if (filterVal === 'general') {
            matchesFilter = (type === 'general');
        } else if (filterVal === 'portal') {
            matchesFilter = (type === 'portal');
        } else if (filterVal === 'attachment') {
            matchesFilter = (hasAttachment === 'yes');
        }

        if (matchesSearch && matchesFilter) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}
</script>

<?php require_once '../includes/footer.php'; ?>

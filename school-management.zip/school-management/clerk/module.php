<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 3) {
    redirect(BASE_URL . '/dashboard.php');
}

$type = $_GET['type'] ?? 'payments';
$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if ($_POST['action'] === 'create_fee' && role_can('manage_fees')) {
            $title = trim($_POST['title'] ?? '');
            $classId = (int)($_POST['class_id'] ?? 0);
            $amount = (float)($_POST['amount'] ?? 0);
            $dueDate = trim($_POST['due_date'] ?? '');
            if (!$title || !$classId || $amount <= 0 || !$dueDate) {
                throw new Exception('Fee title, class, amount and due date are required.');
            }
            $stmt = $pdo->prepare("INSERT INTO fees (class_id, title, amount, due_date) VALUES (?, ?, ?, ?)");
            $stmt->execute([$classId, $title, $amount, $dueDate]);
            logActivity("Clerk created fee head: " . $title);
            $notice = 'Fee head created successfully.';
        }

        if ($_POST['action'] === 'record_payment' && role_can('record_payments')) {
            $studentId = (int)($_POST['student_id'] ?? 0);
            $feeId = (int)($_POST['fee_id'] ?? 0);
            $amount = (float)($_POST['amount_paid'] ?? 0);
            $method = trim($_POST['payment_method'] ?? 'Cash');
            $status = trim($_POST['status'] ?? 'Completed');
            if (!$studentId || !$feeId || $amount <= 0) {
                throw new Exception('Student, fee and amount are required.');
            }
            $stmt = $pdo->prepare("INSERT INTO payments (student_id, fee_id, amount_paid, payment_method, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$studentId, $feeId, $amount, $method, $status]);
            logActivity("Clerk recorded payment for student ID " . $studentId);
            $notice = 'Payment recorded successfully.';
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$classes = role_rows("SELECT id, name FROM classes ORDER BY id", [], 100);
$studentsList = role_rows("SELECT id, admission_no, student_name, class_applied FROM students WHERE status='Approved' ORDER BY student_name", [], 500);
$feesList = role_rows("SELECT id, title, amount FROM fees ORDER BY due_date DESC", [], 500);

$title = 'Accounts Module';
$icon = 'fa-calculator';
$cards = [];
$columns = [];
$rows = [];

switch ($type) {
    case 'fees':
        $title = 'Fee Heads';
        $icon = 'fa-file-invoice-dollar';
        $cards = [['Fee Heads', role_count("SELECT COUNT(*) FROM fees")]];
        $columns = ['ID', 'Title', 'Class ID', 'Amount', 'Due Date', 'Academic Year'];
        $rows = role_rows("SELECT id, title, class_id, amount, due_date, academic_year_id FROM fees ORDER BY due_date DESC", [], 200);
        break;
    case 'students':
        $title = 'Student Accounts';
        $icon = 'fa-user-graduate';
        $cards = [['Students', role_count("SELECT COUNT(*) FROM students")], ['Approved', role_count("SELECT COUNT(*) FROM students WHERE status='Approved'")]];
        $columns = ['ID', 'Admission No', 'Student', 'Class', 'Parent', 'Status'];
        $rows = role_rows("SELECT id, admission_no, student_name, class_applied, parent_name, status FROM students ORDER BY student_name", [], 200);
        break;
    case 'admissions':
        $title = 'Admission Support';
        $icon = 'fa-user-plus';
        $cards = [['Pending', role_count("SELECT COUNT(*) FROM students WHERE status='Pending'")], ['Approved', role_count("SELECT COUNT(*) FROM students WHERE status='Approved'")]];
        $columns = ['Admission No', 'Student', 'Class', 'Parent', 'Status'];
        $rows = role_rows("SELECT admission_no, student_name, class_applied, parent_name, status FROM students ORDER BY created_at DESC", [], 200);
        break;
    default:
        $title = 'Payments';
        $icon = 'fa-money-check-dollar';
        $cards = [['Payments', role_count("SELECT COUNT(*) FROM payments")], ['Received', role_money(role_count("SELECT COALESCE(SUM(amount_paid),0) FROM payments WHERE status='Completed'"))]];
        $columns = ['ID', 'Student ID', 'Fee ID', 'Paid', 'Method', 'Status', 'Date'];
        $rows = role_rows("SELECT id, student_id, fee_id, amount_paid, payment_method, status, payment_date FROM payments ORDER BY payment_date DESC", [], 200);
}

require_once '../includes/header.php';
?>
<div class="container-fluid py-4">
    <?php role_page_hero($title, 'Clerk/accountant data entry and operational view.', $icon); ?>
    <?php if ($notice) echo role_alert($notice); ?>
    <?php if ($error) echo role_alert($error, 'danger'); ?>
    <div class="row g-3 mb-4"><?php role_render_cards($cards); ?></div>

    <?php if ($type === 'fees' && role_can('manage_fees')): ?>
    <div class="card border-0 shadow-sm mb-4" style="border-radius:14px;"><div class="card-body">
        <h2 class="h5 fw-bold mb-3">Create Fee Head</h2>
        <form method="POST" class="row g-3">
            <input type="hidden" name="action" value="create_fee">
            <div class="col-md-4"><input name="title" class="form-control" placeholder="Fee title" required></div>
            <div class="col-md-3"><select name="class_id" class="form-select" required><option value="">Class</option><?php foreach ($classes as $c): ?><option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['name']); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-2"><input type="number" step="0.01" name="amount" class="form-control" placeholder="Amount" required></div>
            <div class="col-md-2"><input type="date" name="due_date" class="form-control" required></div>
            <div class="col-md-1"><button class="btn btn-primary w-100">Save</button></div>
        </form>
    </div></div>
    <?php endif; ?>

    <?php if ($type === 'payments' && role_can('record_payments')): ?>
    <div class="card border-0 shadow-sm mb-4" style="border-radius:14px;"><div class="card-body">
        <h2 class="h5 fw-bold mb-3">Record Payment</h2>
        <form method="POST" class="row g-3">
            <input type="hidden" name="action" value="record_payment">
            <div class="col-md-3"><select name="student_id" class="form-select" required><option value="">Student</option><?php foreach ($studentsList as $s): ?><option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['student_name'] . ' - ' . $s['admission_no']); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-3"><select name="fee_id" class="form-select" required><option value="">Fee</option><?php foreach ($feesList as $f): ?><option value="<?php echo $f['id']; ?>"><?php echo htmlspecialchars($f['title'] . ' (' . $f['amount'] . ')'); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-2"><input type="number" step="0.01" name="amount_paid" class="form-control" placeholder="Paid" required></div>
            <div class="col-md-2"><select name="payment_method" class="form-select"><option>Cash</option><option>UPI</option><option>Bank Transfer</option><option>Cheque</option></select></div>
            <div class="col-md-1"><select name="status" class="form-select"><option>Completed</option><option>Pending</option><option>Failed</option></select></div>
            <div class="col-md-1"><button class="btn btn-primary w-100">Save</button></div>
        </form>
    </div></div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
        <div class="card-header bg-white py-3 d-flex justify-content-between"><h2 class="h5 fw-bold mb-0">Records</h2><a href="index.php" class="btn btn-sm btn-outline-secondary">Back</a></div>
        <?php role_render_table($columns, $rows); ?>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

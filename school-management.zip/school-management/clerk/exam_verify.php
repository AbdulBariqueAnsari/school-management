<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 3) {
    redirect(BASE_URL . '/dashboard.php');
}

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['submission_id'])) {
    $submission_id = (int)$_POST['submission_id'];
    $remarks = $_POST['remarks'] ?? '';
    $action = $_POST['action'];
    $payment_ref = trim($_POST['payment_ref'] ?? '');

    if ($action === 'Verify') {
        $status = 'Verified';
    } elseif ($action === 'Reject') {
        $status = 'Rejected';
    } else {
        $status = 'Pending';
    }

    try {
        $pdo->beginTransaction();

        // Decode, update the reference inside form_data, and re-save
        if ($action === 'Verify' && $payment_ref !== '') {
            $get_form = $pdo->prepare("SELECT form_data FROM exam_form_submissions WHERE id = ? FOR UPDATE");
            $get_form->execute([$submission_id]);
            $form_json = $get_form->fetchColumn();
            if ($form_json) {
                $data = json_decode($form_json, true) ?: [];
                $data['Payment Reference/Receipt'] = $payment_ref;
                $data['Payment Reference'] = $payment_ref;
                
                $updated_json = json_encode($data);
                $upd_form = $pdo->prepare("UPDATE exam_form_submissions SET form_data = ? WHERE id = ?");
                $upd_form->execute([$updated_json, $submission_id]);
            }
        }

        $stmt = $pdo->prepare("UPDATE exam_form_submissions SET status = ?, clerk_id = ?, remarks = ? WHERE id = ?");
        $stmt->execute([$status, $_SESSION['user_id'], $remarks, $submission_id]);
        
        $pdo->commit();
        $success_msg = "Submission updated and payment cleared successfully.";
    } catch(Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error_msg = "Error updating submission: " . $e->getMessage();
    }
}

// Fetch pending and verified submissions
$submissions = $pdo->query("
    SELECT s.id, s.status, s.form_data, s.remarks, s.submitted_at, s.application_sl_no,
           st.student_name, st.admission_no, COALESCE(c.name, st.class_applied) as class_name, e.name as exam_name
    FROM exam_form_submissions s
    JOIN students st ON s.student_id = st.id
    JOIN exams e ON s.exam_id = e.id
    LEFT JOIN classes c ON c.id = COALESCE(NULLIF(st.class_id, 0), (SELECT id FROM classes WHERE name = st.class_applied LIMIT 1))
    ORDER BY CASE s.status WHEN 'Pending' THEN 1 WHEN 'Verified' THEN 2 ELSE 3 END, s.submitted_at ASC
")->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php role_page_hero('Exam Form Verification', 'Review and verify student exam applications & payment before Principal approval.', 'fa-clipboard-check'); ?>

    <?php if ($success_msg): ?>
        <div class="alert alert-success"><i class="fa fa-check-circle me-2"></i><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="alert alert-danger"><i class="fa fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
        <div class="card-header bg-white py-3">
            <h2 class="h5 fw-bold mb-0">Student Submissions</h2>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Application Sl No</th>
                        <th>Student</th>
                        <th>Class / Exam</th>
                        <th>Payment Info</th>
                        <th>Submitted At</th>
                        <th>Status</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$submissions): ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">No submissions found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($submissions as $sub): ?>
                            <tr>
                                <td class="ps-4 fw-semibold text-primary"><?php echo htmlspecialchars($sub['application_sl_no'] ?? 'N/A'); ?></td>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo htmlspecialchars($sub['student_name']); ?></div>
                                    <small class="text-muted">Adm No: <?php echo htmlspecialchars($sub['admission_no']); ?></small>
                                </td>
                                <td>
                                    <div class="fw-bold text-secondary"><?php echo htmlspecialchars($sub['exam_name']); ?></div>
                                    <small class="text-muted"><?php echo htmlspecialchars($sub['class_name']); ?></small>
                                </td>
                                <td>
                                    <?php 
                                    $data = json_decode($sub['form_data'], true); 
                                    $pay_mode = $data['Payment Mode'] ?? 'Cash at Counter';
                                    $pay_ref = $data['Payment Reference/Receipt'] ?? $data['Payment Reference'] ?? 'N/A';
                                    ?>
                                    <span class="badge bg-light text-dark border small mb-1"><?php echo htmlspecialchars($pay_mode); ?></span><br>
                                    <small class="text-muted">Ref: <strong class="text-primary"><?php echo htmlspecialchars($pay_ref); ?></strong></small>
                                </td>
                                <td>
                                    <small class="text-dark"><?php echo date('d M Y h:i A', strtotime($sub['submitted_at'])); ?></small>
                                </td>
                                <td>
                                    <?php
                                    $badge = 'bg-warning text-dark';
                                    if ($sub['status'] === 'Verified') $badge = 'bg-info text-dark';
                                    if ($sub['status'] === 'Approved') $badge = 'bg-success';
                                    if ($sub['status'] === 'Rejected') $badge = 'bg-danger';
                                    ?>
                                    <span class="badge <?php echo $badge; ?>"><?php echo htmlspecialchars($sub['status']); ?></span>
                                </td>
                                <td class="text-end pe-4">
                                    <?php if ($sub['status'] === 'Pending' || $sub['status'] === 'Rejected'): ?>
                                        <button class="btn btn-sm btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#verifyModal<?php echo $sub['id']; ?>"><i class="fa fa-edit me-1"></i> Verify</button>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#verifyModal<?php echo $sub['id']; ?>"><i class="fa fa-eye me-1"></i> View Details</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal definition block shifted OUTSIDE table container to resolve web overflow clipping -->
<?php if ($submissions): ?>
    <?php foreach ($submissions as $sub): ?>
        <?php 
        $data = json_decode($sub['form_data'], true); 
        $pay_mode = $data['Payment Mode'] ?? 'Cash at Counter';
        $pay_ref = $data['Payment Reference/Receipt'] ?? $data['Payment Reference'] ?? 'N/A';
        ?>
        <!-- Verify Modal -->
        <div class="modal fade" id="verifyModal<?php echo $sub['id']; ?>" tabindex="-1" data-bs-backdrop="false" style="background: rgba(15,23,42,0.45); backdrop-filter: blur(4px);">
          <div class="modal-dialog modal-lg text-start">
            <form method="POST" class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
              <div class="modal-header border-0 pb-0 bg-light rounded-top p-4">
                <div>
                    <h5 class="modal-title fw-bold text-dark"><i class="fa fa-clipboard-check text-primary me-2"></i>Verify Exam Form &amp; Biodata</h5>
                    <small class="text-muted">Review submitted details and payment status</small>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body p-4" style="max-height:75vh; overflow-y:auto;">
                <input type="hidden" name="submission_id" value="<?php echo $sub['id']; ?>">
                
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <span class="text-muted small d-block">Student Name</span>
                        <strong class="text-dark fs-5"><?php echo htmlspecialchars($sub['student_name']); ?></strong>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <span class="text-muted small d-block">Application Serial No</span>
                        <span class="badge bg-primary fs-6 py-2 px-3"><?php echo htmlspecialchars($sub['application_sl_no'] ?? 'N/A'); ?></span>
                    </div>
                </div>

                <div class="alert bg-primary-subtle text-primary border-0 rounded-3 p-3 mb-4">
                    <h6 class="fw-bold mb-2"><i class="fa fa-file-invoice-dollar me-2"></i>Payment Collection &amp; Clearance</h6>
                    <div class="row g-3 align-items-end">
                        <div class="col-md-4">
                            <small class="text-muted d-block mb-1">Declared Payment Mode</small>
                            <span class="badge bg-primary px-3 py-2 fs-6 rounded-pill"><?php echo htmlspecialchars($pay_mode); ?></span>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label fw-bold text-dark mb-1">
                                <?php if ($pay_mode === 'Cash at Counter'): ?>
                                    <i class="fa fa-receipt text-success me-1"></i> Clear Cash Payment &amp; Issue Receipt No
                                <?php else: ?>
                                    <i class="fa fa-credit-card text-indigo me-1"></i> Verify / Update UPI Transaction Ref No
                                <?php endif; ?>
                            </label>
                            <input type="text" name="payment_ref" class="form-control bg-white" placeholder="Enter Reference / Receipt No to clear payment" value="<?php echo htmlspecialchars($pay_ref === 'N/A' ? '' : $pay_ref); ?>" required>
                            <small class="form-text text-muted">Entering a value here updates the student's official receipt reference.</small>
                        </div>
                    </div>
                </div>

                <h6 class="fw-bold text-secondary border-bottom pb-2 mb-3"><i class="fa fa-id-card me-2"></i>Full Submitted Biodata</h6>
                <div class="row g-3 mb-4">
                    <?php if ($data): ?>
                        <?php foreach ($data as $k => $v): ?>
                            <?php if ($k !== 'Payment Mode' && $k !== 'Payment Reference/Receipt' && $k !== 'Payment Reference'): ?>
                                <div class="col-md-6 col-lg-4">
                                    <small class="text-muted d-block mb-0"><?php echo htmlspecialchars($k); ?></small>
                                    <span class="text-dark fw-semibold"><?php echo htmlspecialchars($v ?: 'N/A'); ?></span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12 text-muted">No form details found.</div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 mt-4">
                    <label class="form-label fw-bold text-dark">Clerk Verification Remarks</label>
                    <textarea name="remarks" class="form-control" rows="2" placeholder="e.g., Cash payment received, verified Aadhaar & roll, forwarded." required><?php echo htmlspecialchars($sub['remarks'] ?? ''); ?></textarea>
                </div>
              </div>
              <div class="modal-footer border-0 bg-light rounded-bottom p-4">
                <?php if ($sub['status'] === 'Pending' || $sub['status'] === 'Rejected'): ?>
                    <button type="submit" name="action" value="Reject" class="btn btn-danger px-4 fw-bold">Reject Application</button>
                    <button type="submit" name="action" value="Verify" class="btn btn-success px-4 fw-bold shadow-sm"><i class="fa fa-check me-2"></i>Verify &amp; Forward</button>
                <?php else: ?>
                    <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Close</button>
                <?php endif; ?>
              </div>
            </form>
          </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>

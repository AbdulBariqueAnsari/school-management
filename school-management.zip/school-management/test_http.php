<?php
// fake auth for testing locally
session_id(md5("test"));
session_start();
$_SESSION['role_id'] = 1;
$_SESSION['user_id'] = 1;
session_write_close();

$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"Cookie: PHPSESSID=" . md5("test") . "\r\n"
  )
);
$context = stream_context_create($opts);

$html = file_get_contents('http://localhost/school-management/admin/approved_students.php', false, $context);
echo "HTML Length: " . strlen($html) . "\n";
echo "Number of Table Rows: " . substr_count($html, '<tr class="sp-row"');

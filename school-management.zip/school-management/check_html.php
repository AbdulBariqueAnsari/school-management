<?php
session_start();
$_SESSION['role_id'] = 1;

ob_start();
chdir('admin');
include 'approved_students.php';
$html = ob_get_clean();

echo "Length of HTML: " . strlen($html) . "\n";
if (strpos($html, 'Aakanksha Chatterjee') !== false) {
    echo "Found student in HTML!\n";
} else {
    echo "Student NOT FOUND in HTML!\n";
}
// check if there's any fatal error returned
if (error_get_last()) {
    print_r(error_get_last());
}

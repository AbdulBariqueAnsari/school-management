<?php
require_once 'config/db.php';

echo "Setting up environment...\n";

// Backup
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS students_backup AS SELECT * FROM students");
}
catch (Exception $e) {
}

// Clear tables
$pdo->exec("SET FOREIGN_KEY_CHECKS=0");
$pdo->exec("TRUNCATE TABLE students");
try {
    $pdo->exec("TRUNCATE TABLE admission_requests");
}
catch (Exception $e) {
}
$pdo->exec("DELETE FROM users WHERE email LIKE 'student%@test.com'");
$pdo->exec("SET FOREIGN_KEY_CHECKS=1");

$password_hash = password_hash('password123', PASSWORD_DEFAULT);

$readme_content = "\n\n## Test Student Accounts\n\nApproved Students.\n";

for ($i = 1; $i <= 10; $i++) {
    $status = ($i <= 5) ? 'Approved' : 'Pending';
    $username = "student{$i}";
    $email = "student{$i}@test.com";

    // Insert to users table
    $stmt_user = $pdo->prepare("INSERT INTO users (name, email, password, role_id, is_active) VALUES (?, ?, ?, 6, 1)");
    $stmt_user->execute(["Student {$i}", $email, $password_hash]);

    $admission_no = ($status === 'Approved') ? 'ADM-' . date('Y') . '-' . str_pad($i, 4, '0', STR_PAD_LEFT) : null;
    $admission_date = ($status === 'Approved') ? date('Y-m-d') : null;

    $data = [
        'admission_no' => $admission_no,
        'student_name' => "Student {$i} Full Name",
        'gender' => ($i % 2 == 0) ? 'Female' : 'Male',
        'dob' => date('Y-m-d', strtotime('-' . (5 + ($i % 5)) . ' years')),
        'blood_group' => 'O+',
        'aadhaar_number' => '1234567890' . str_pad($i, 2, '0', STR_PAD_LEFT),
        'student_photo' => 'default_student.png',
        'address' => "12{$i} Main St, Present City",
        'mobile_number' => '988877700' . ($i % 10),
        'has_medical_condition' => 1,
        'medical_condition_desc' => 'Minor Asthma',
        'has_disability' => 0,
        'disability_desc' => '',
        'has_allergies' => 1,
        'allergies_desc' => 'Peanuts',
        'religion' => 'Hindu',
        'caste_category' => 'General',
        'mother_tongue' => 'English',
        'previous_schooling_status' => 'Yes',
        'father_name' => "Father Name {$i}",
        'father_mobile' => '999888770' . ($i % 10),
        'mother_name' => "Mother Name {$i}",
        'mother_mobile' => '999888660' . ($i % 10),
        'parents_address' => "12{$i} Main St, Parent City",
        'guardian_name' => "Guardian Name {$i}",
        'relation' => 'Uncle', // maps to guardian_relation form field concept
        'guardian_mobile' => '999888550' . ($i % 10),
        'guardian_address' => "12{$i} Main St, Guardian City",
        'class_applied' => '' . (($i % 10) + 1), // Class 1 to 10
        'previous_class' => '' . (($i % 10)),
        'previous_school_name' => "Previous School {$i}",
        'previous_board' => 'CBSE',
        'year_of_passing' => '2025',
        'status' => $status,
        'created_at' => date('Y-m-d H:i:s'),
        'class' => '' . (($i % 10) + 1), // Standard duplicate
        'parent_name' => "Father Name {$i}",
        'parent_email' => $email,
        'admission_date' => $admission_date
    ];

    $cols = array_keys($data);
    $placeholders = array_fill(0, count($cols), '?');
    $vals = array_values($data);

    $sql = "INSERT INTO students (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $placeholders) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($vals);

    if ($i == 6) {
        $readme_content .= "\nPending Students.\n";
    }
    $readme_content .= "{$username} / password123\n";
}

echo "Seeded 10 fully filled student records.\n";
file_put_contents('test_logins.txt', $readme_content);
?>

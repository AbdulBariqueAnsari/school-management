<?php
require_once 'c:/xampp/htdocs/school-management/config/db.php';

echo "Starting database consolidation...\n";

// 1. Ensure columns exist in admission_requests
$req_cols = [
    "blood_group VARCHAR(10)",
    "aadhaar_number VARCHAR(20)",
    "mobile_number VARCHAR(20)",
    "address TEXT",
    "guardian_details TEXT",
    "student_photo VARCHAR(255)",
    "admission_no VARCHAR(20)",
    "father_name VARCHAR(150)",
    "father_mobile VARCHAR(20)",
    "mother_name VARCHAR(150)",
    "mother_mobile VARCHAR(20)",
    "parents_address TEXT",
    "guardian_name VARCHAR(150)",
    "relation VARCHAR(100)",
    "guardian_mobile VARCHAR(20)",
    "guardian_address TEXT",
    "religion VARCHAR(50)",
    "caste_category VARCHAR(50)",
    "mother_tongue VARCHAR(100)",
    "has_medical_condition TINYINT DEFAULT 0",
    "medical_condition_desc TEXT",
    "has_disability TINYINT DEFAULT 0",
    "disability_desc TEXT",
    "has_allergies TINYINT DEFAULT 0",
    "allergies_desc TEXT",
    "previous_schooling_status VARCHAR(100)",
    "previous_class VARCHAR(50)",
    "previous_school_name VARCHAR(150)",
    "previous_board VARCHAR(100)",
    "year_of_passing INT",
    "previous_school VARCHAR(150)",
    "class_applied VARCHAR(50)"
];

foreach ($req_cols as $col_def) {
    $col_name = explode(' ', $col_def)[0];
    try {
        $pdo->exec("ALTER TABLE admission_requests ADD COLUMN $col_def");
        echo "  Added column to admission_requests: $col_name\n";
    }
    catch (PDOException $e) {
    }
}

// 2. Add class_applied and admission_no to admission_requests if they were named differently elsewhere
// (Done in step above)

// 3. Migrate data from admission_applications if it exists
$stmt = $pdo->query("SHOW TABLES LIKE 'admission_applications'");
if ($stmt->fetch()) {
    echo "Migrating data from admission_applications...\n";

    // Simple migration: insert records that don't exist
    // We'll move based on student_name and dob as a rough unique key
    $pdo->exec("INSERT INTO admission_requests (student_name, dob, gender, blood_group, address, previous_school, aadhaar_number, parent_name, parent_phone, parent_email, class_applied, status, student_photo, mobile_number, religion, caste_category, mother_tongue, father_name, father_mobile, mother_name, mother_mobile, parents_address, guardian_name, relation, guardian_mobile, guardian_address, admission_no)
                SELECT student_name, dob, gender, blood_group, address, previous_school, aadhaar_number, parent_name, parent_phone, parent_email, class_applying_for, status, student_photo, mobile_number, religion, caste_category, mother_tongue, father_name, father_mobile, mother_name, mother_mobile, parents_address, guardian_name, relation, guardian_mobile, guardian_address, admission_number 
                FROM admission_applications
                WHERE (student_name, dob) NOT IN (SELECT student_name, dob FROM admission_requests)");

    $count = $pdo->query("SELECT COUNT(*) FROM admission_applications")->fetchColumn();
    echo "  Migrated entries from admission_applications.\n";

    // Note: Delaying drop until verified manually or via further steps
    echo "  Old table 'admission_applications' preserved for safety.\n";
}

echo "Done.\n";

# Complete School Management System (ERP)

A modern Role-Based School Management system built using Core PHP, MySQL, Bootstrap 5, and JavaScript.

## Features Included
- **7 Roles**: Super Admin, Principal, Clerk, Class Teacher, Subject Teacher, Student, Parent
- **Modern UI**: Glassmorphism cards, Neumorphic buttons, and animated SaaS footer.
- **Class Teacher System**: Dedicated dashboards for class management and teacher assignments.
- **Student Module**: Multi-step admission form and comprehensive student record management.

## Setup Instructions

1. **Upload Files**: Upload the entire directory to `htdocs/` (XAMPP).
2. **Database Import**:
   - Create a database named `school_management` in phpMyAdmin.
   - Import `database/install.sql`.
3. **Configuration**:
   - Update `config/db.php` with your database details.
   - Update `config/mail.php` with your SMTP settings.


## 🔑 Login Credentials (STANDARDIZED)

All user accounts follow a logical naming convention. Password for Super Admin is `SuperPassword123!`. All other accounts use `Password123`.

### 🛡️ Administrative & Staff Summary
| Role | Email | Username | Password |
| :--- | :--- | :--- | :--- |
| **Super Admin** | `superadmin@school.com` | `superadmin` | `SuperPassword123!` |
| **Principal** | `principal@school.com` | `principal` | `Password123` |
| **Clerk** | `clerk@school.com` | `clerk` | `Password123` |

### 👨‍🏫 Role Patterns
- **Teachers:** `teacher{user_id}@school.com` / `teacher_{user_id}` / `Password123`
- **Students:** `student{user_id}@school.com` / `student_{user_id}` / `Password123`
- **Guardians:** `parent{user_id}@school.com` / `parent_{user_id}` / `Password123`

<details>
<summary><b>Click to expand full list of all 369 Users</b></summary>

| ID | Role | Name | Email | Username |
| :--- | :--- | :--- | :--- | :--- |
| 1 | Super Admin | Super Admin | `superadmin@school.com` | `superadmin` |
| 2 | Principal | Principal | `principal@school.com` | `principal` |
| 3 | Clerk | Clerk | `clerk@school.com` | `clerk` |
| 4 | Class Teacher | Class Teacher | `teacher4@school.com` | `teacher_4` |
| 5 | Subject Teacher | Subject Teacher | `teacher5@school.com` | `teacher_5` |
| 6 | Student | Student | `student6@school.com` | `student_6` |
| 9 | Student | TALIV ANSARI | `student9@school.com` | `student_9` |
| 11 | Student | John Doe | `student11@school.com` | `student_11` |
| 13 | Student | Test Student | `student13@school.com` | `student_13` |
| 15 | Student | SHEHNAWAZ | `student15@school.com` | `student_15` |
| 16 | Student | Stanley Hudson | `student16@school.com` | `student_16` |
| 17 | Student | Phyllis Vance | `student17@school.com` | `student_17` |
| 18 | Student | Kevin Malone | `student18@school.com` | `student_18` |
| 19 | Student | Oscar Martinez | `student19@school.com` | `student_19` |
| 20 | Student | Kelly Kapoor | `student20@school.com` | `student_20` |
| 21 | Student | Michael Scott | `student21@school.com` | `student_21` |
| 22 | Student | Pam Beesly | `student22@school.com` | `student_22` |
| 23 | Student | Jim Halpert | `student23@school.com` | `student_23` |
| 24 | Student | Dwight Schrute | `student24@school.com` | `student_24` |
| 25 | Student | Angela Martin | `student25@school.com` | `student_25` |
| 26 | Student | Stanley Hudson | `student26@school.com` | `student_26` |
| 27 | Student | Phyllis Vance | `student27@school.com` | `student_27` |
| 28 | Student | Kevin Malone | `student28@school.com` | `student_28` |
| 29 | Student | Oscar Martinez | `student29@school.com` | `student_29` |
| 30 | Student | Kelly Kapoor | `student30@school.com` | `student_30` |
| 51 | Student | Student 1 | `student51@school.com` | `student_51` |
| 52 | Student | Student 2 | `student52@school.com` | `student_52` |
| 53 | Student | Student 3 | `student53@school.com` | `student_53` |
| 54 | Student | Student 4 | `student54@school.com` | `student_54` |
| 55 | Student | Student 5 | `student55@school.com` | `student_55` |
| 56 | Student | Student 6 | `student56@school.com` | `student_56` |
| 57 | Student | Student 7 | `student57@school.com` | `student_57` |
| 58 | Student | Student 8 | `student58@school.com` | `student_58` |
| 59 | Student | Student 9 | `student59@school.com` | `student_59` |
| 60 | Student | Student 10 | `student60@school.com` | `student_60` |
| 95 | Student | Priya Menon | `student95@school.com` | `student_95` |
| 96 | Student | Vihaan Sharma | `student96@school.com` | `student_96` |
| 97 | Student | Saanvi Mishra | `student97@school.com` | `student_97` |
| 98 | Student | Sanjay Sen | `student98@school.com` | `student_98` |
| 99 | Student | Pooja Kumar | `student99@school.com` | `student_99` |
| 100 | Student | Vanya Singh | `student100@school.com` | `student_100` |
| 101 | Student | Vikram Kapoor | `student101@school.com` | `student_101` |
| 102 | Student | Sanjay Kumar | `student102@school.com` | `student_102` |
| 103 | Student | Sai Reddy | `student103@school.com` | `student_103` |
| 104 | Student | Aditya Bansal | `student104@school.com` | `student_104` |
| 105 | Student | Arjun Singh | `student105@school.com` | `student_105` |
| 106 | Student | Sai Khan | `student106@school.com` | `student_106` |
| 107 | Student | Amara Garg | `student107@school.com` | `student_107` |
| 108 | Student | Anita Mishra | `student108@school.com` | `student_108` |
| 109 | Student | Anita Mishra | `student109@school.com` | `student_109` |
| 110 | Student | Akash Bansal | `student110@school.com` | `student_110` |
| 111 | Student | Vikram Nair | `student111@school.com` | `student_111` |
| 112 | Student | Riya Malhotra | `student112@school.com` | `student_112` |
| 113 | Student | Amit Menon | `student113@school.com` | `student_113` |
| 114 | Student | Aarav Chatterjee | `student114@school.com` | `student_114` |
| 115 | Student | Rajesh Pillai | `student115@school.com` | `student_115` |
| 116 | Student | Suresh Gupta | `student116@school.com` | `student_116` |
| 117 | Student | Vishal Mukherjee | `student117@school.com` | `student_117` |
| 118 | Student | Sumit Reddy | `student118@school.com` | `student_118` |
| 119 | Student | Sanjay Verma | `student119@school.com` | `student_119` |
| 120 | Student | Manish Patil | `student120@school.com` | `student_120` |
| 121 | Student | Aditya Sen | `student121@school.com` | `student_121` |
| 122 | Student | Karan Mishra | `student122@school.com` | `student_122` |
| 123 | Student | Deepak Patel | `student123@school.com` | `student_123` |
| 124 | Student | Nidhi Banerjee | `student124@school.com` | `student_124` |
| 125 | Student | Sneha Banerjee | `student125@school.com` | `student_125` |
| 126 | Student | Kavita Yadav | `student126@school.com` | `student_126` |
| 127 | Student | Simran Banerjee | `student127@school.com` | `student_127` |
| 128 | Student | Sita Banerjee | `student128@school.com` | `student_128` |
| 129 | Student | Zainab Mishra | `student129@school.com` | `student_129` |
| 130 | Student | Ayesha Kumar | `student130@school.com` | `student_130` |
| 131 | Student | Sonia Chatterjee | `student131@school.com` | `student_131` |
| 132 | Student | Sonia Pandey | `student132@school.com` | `student_132` |
| 133 | Student | Nidhi Sharma | `student133@school.com` | `student_133` |
| 134 | Student | Vikas Bose | `student134@school.com` | `student_134` |
| 135 | Student | Akash Mukherjee | `student135@school.com` | `student_135` |
| 136 | Student | Sunil Menon | `student136@school.com` | `student_136` |
| 137 | Student | Rajesh Patel | `student137@school.com` | `student_137` |
| 138 | Student | Ramesh Gupta | `student138@school.com` | `student_138` |
| 139 | Student | Karan Chatterjee | `student139@school.com` | `student_139` |
| 140 | Student | Vikas Mukherjee | `student140@school.com` | `student_140` |
| 141 | Student | Sumit Verma | `student141@school.com` | `student_141` |
| 142 | Student | Ravi Gupta | `student142@school.com` | `student_142` |
| 143 | Student | Kunal Sharma | `student143@school.com` | `student_143` |
| 144 | Student | Swati Chatterjee | `student144@school.com` | `student_144` |
| 145 | Student | Sneha Gupta | `student145@school.com` | `student_145` |
| 146 | Student | Kavya Verma | `student146@school.com` | `student_146` |
| 147 | Student | Kiran Bhat | `student147@school.com` | `student_147` |
| 148 | Student | Kavya Kumar | `student148@school.com` | `student_148` |
| 149 | Student | Kavita Tiwari | `student149@school.com` | `student_149` |
| 150 | Student | Neha Sen | `student150@school.com` | `student_150` |
| 151 | Student | Aakanksha Yadav | `student151@school.com` | `student_151` |
| 152 | Student | Sonia Patil | `student152@school.com` | `student_152` |
| 153 | Student | Rekha Sen | `student153@school.com` | `student_153` |
| 154 | Student | Ramesh Sen | `student154@school.com` | `student_154` |
| 155 | Student | Ravi Sen | `student155@school.com` | `student_155` |
| 156 | Student | Ramesh Yadav | `student156@school.com` | `student_156` |
| 157 | Student | Akash Sharma | `student157@school.com` | `student_157` |
| 158 | Student | Vishal Bose | `student158@school.com` | `student_158` |
| 159 | Student | Rohan Bose | `student159@school.com` | `student_159` |
| 160 | Student | Arjun Dubey | `student160@school.com` | `student_160` |
| 161 | Student | Sanjay Sharma | `student161@school.com` | `student_161` |
| 162 | Student | Ramesh Menon | `student162@school.com` | `student_162` |
| 163 | Student | Ramesh Dubey | `student163@school.com` | `student_163` |
| 164 | Student | Priya Pillai | `student164@school.com` | `student_164` |
| 165 | Student | Preeti Patel | `student165@school.com` | `student_165` |
| 166 | Student | Simran Iyer | `student166@school.com` | `student_166` |
| 167 | Student | Geeta Tiwari | `student167@school.com` | `student_167` |
| 168 | Student | Anita Singh | `student168@school.com` | `student_168` |
| 169 | Student | Aakanksha Nair | `student169@school.com` | `student_169` |
| 170 | Student | Geeta Nair | `student170@school.com` | `student_170` |
| 171 | Student | Zainab Chauhan | `student171@school.com` | `student_171` |
| 172 | Student | Rekha Mishra | `student172@school.com` | `student_172` |
| 173 | Student | Swati Yadav | `student173@school.com` | `student_173` |
| 174 | Student | Krishna Patil | `student174@school.com` | `student_174` |
| 175 | Student | Vikrant Joshi | `student175@school.com` | `student_175` |
| 176 | Student | Amit Mukherjee | `student176@school.com` | `student_176` |
| 177 | Student | Vijay Chauhan | `student177@school.com` | `student_177` |
| 178 | Student | Vijay Sharma | `student178@school.com` | `student_178` |
| 179 | Student | Rahul Menon | `student179@school.com` | `student_179` |
| 180 | Student | Vijay Bose | `student180@school.com` | `student_180` |
| 181 | Student | Rahul Patil | `student181@school.com` | `student_181` |
| 182 | Student | Sanjay Banerjee | `student182@school.com` | `student_182` |
| 183 | Student | Rahul Bose | `student183@school.com` | `student_183` |
| 184 | Student | Sunita Das | `student184@school.com` | `student_184` |
| 185 | Student | Shruti Bose | `student185@school.com` | `student_185` |
| 186 | Student | Diya Reddy | `student186@school.com` | `student_186` |
| 187 | Student | Diya Pandey | `student187@school.com` | `student_187` |
| 188 | Student | Kiran Banerjee | `student188@school.com` | `student_188` |
| 189 | Student | Nidhi Kulkarni | `student189@school.com` | `student_189` |
| 190 | Student | Ananya Gupta | `student190@school.com` | `student_190` |
| 191 | Student | Kiran Dubey | `student191@school.com` | `student_191` |
| 192 | Student | Sita Iyer | `student192@school.com` | `student_192` |
| 193 | Student | Simran Yadav | `student193@school.com` | `student_193` |
| 194 | Student | Ramesh Das | `student194@school.com` | `student_194` |
| 195 | Student | Rahul Tiwari | `student195@school.com` | `student_195` |
| 196 | Student | Vivaan Reddy | `student196@school.com` | `student_196` |
| 197 | Student | Kunal Deshmukh | `student197@school.com` | `student_197` |
| 198 | Student | Vikram Reddy | `student198@school.com` | `student_198` |
| 199 | Student | Anil Bose | `student199@school.com` | `student_199` |
| 200 | Student | Vikrant Kumar | `student200@school.com` | `student_200` |
| 201 | Student | Karan Sharma | `student201@school.com` | `student_201` |
| 202 | Student | Vijay Mistry | `student202@school.com` | `student_202` |
| 203 | Student | Vikrant Chauhan | `student203@school.com` | `student_203` |
| 204 | Student | Sunita Chauhan | `student204@school.com` | `student_204` |
| 205 | Student | Preeti Pandey | `student205@school.com` | `student_205` |
| 206 | Student | Ishita Bose | `student206@school.com` | `student_206` |
| 207 | Student | Ishita Joshi | `student207@school.com` | `student_207` |
| 208 | Student | Swati Sen | `student208@school.com` | `student_208` |
| 209 | Student | Simran Menon | `student209@school.com` | `student_209` |
| 210 | Student | Sneha Iyer | `student210@school.com` | `student_210` |
| 211 | Student | Swati Chauhan | `student211@school.com` | `student_211` |
| 212 | Student | Nidhi Menon | `student212@school.com` | `student_212` |
| 213 | Student | Kavya Joshi | `student213@school.com` | `student_213` |
| 214 | Student | Kunal Yadav | `student214@school.com` | `student_214` |
| 215 | Student | Ravi Pillai | `student215@school.com` | `student_215` |
| 216 | Student | Kunal Pillai | `student216@school.com` | `student_216` |
| 217 | Student | Kunal Mishra | `student217@school.com` | `student_217` |
| 218 | Student | Akash Nair | `student218@school.com` | `student_218` |
| 219 | Student | Aditya Singh | `student219@school.com` | `student_219` |
| 220 | Student | Rahul Chauhan | `student220@school.com` | `student_220` |
| 221 | Student | Vishal Mishra | `student221@school.com` | `student_221` |
| 222 | Student | Ravi Patel | `student222@school.com` | `student_222` |
| 223 | Student | Vikram Gupta | `student223@school.com` | `student_223` |
| 224 | Student | Preeti Das | `student224@school.com` | `student_224` |
| 225 | Student | Riya Chowdhury | `student225@school.com` | `student_225` |
| 226 | Student | Ishita Pillai | `student226@school.com` | `student_226` |
| 227 | Student | Shweta Tiwari | `student227@school.com` | `student_227` |
| 228 | Student | Diya Mishra | `student228@school.com` | `student_228` |
| 229 | Student | Aakanksha Kulkarni | `student229@school.com` | `student_229` |
| 230 | Student | Priya Sharma | `student230@school.com` | `student_230` |
| 231 | Student | Pooja Tiwari | `student231@school.com` | `student_231` |
| 232 | Student | Sita Nair | `student232@school.com` | `student_232` |
| 233 | Student | Zainab Nair | `student233@school.com` | `student_233` |
| 234 | Student | Neeraj Gupta | `student234@school.com` | `student_234` |
| 235 | Student | Sumit Chowdhury | `student235@school.com` | `student_235` |
| 236 | Student | Rohan Deshmukh | `student236@school.com` | `student_236` |
| 237 | Student | Vivaan Chowdhury | `student237@school.com` | `student_237` |
| 238 | Student | Manoj Joshi | `student238@school.com` | `student_238` |
| 239 | Student | Krishna Pandey | `student239@school.com` | `student_239` |
| 240 | Student | Sunil Chowdhury | `student240@school.com` | `student_240` |
| 241 | Student | Deepak Banerjee | `student241@school.com` | `student_241` |
| 242 | Student | Sunil Das | `student242@school.com` | `student_242` |
| 243 | Student | Akash Chowdhury | `student243@school.com` | `student_243` |
| 244 | Student | Simran Patel | `student244@school.com` | `student_244` |
| 245 | Student | Anita Deshmukh | `student245@school.com` | `student_245` |
| 246 | Student | Diya Chatterjee | `student246@school.com` | `student_246` |
| 247 | Student | Sneha Chauhan | `student247@school.com` | `student_247` |
| 248 | Student | Fatima Mukherjee | `student248@school.com` | `student_248` |
| 249 | Student | Shruti Gupta | `student249@school.com` | `student_249` |
| 250 | Student | Neha Das | `student250@school.com` | `student_250` |
| 251 | Student | Riya Iyer | `student251@school.com` | `student_251` |
| 252 | Student | Geeta Patel | `student252@school.com` | `student_252` |
| 253 | Student | Neha Banerjee | `student253@school.com` | `student_253` |
| 254 | Student | Arjun Joshi | `student254@school.com` | `student_254` |
| 255 | Student | Aarav Banerjee | `student255@school.com` | `student_255` |
| 256 | Student | Manish Iyer | `student256@school.com` | `student_256` |
| 257 | Student | Vikrant Menon | `student257@school.com` | `student_257` |
| 258 | Student | Sunil Pandey | `student258@school.com` | `student_258` |
| 259 | Student | Rajesh Sharma | `student259@school.com` | `student_259` |
| 260 | Student | Akash Kulkarni | `student260@school.com` | `student_260` |
| 261 | Student | Nitin Patil | `student261@school.com` | `student_261` |
| 262 | Student | Amit Chauhan | `student262@school.com` | `student_262` |
| 263 | Student | Akash Chauhan | `student263@school.com` | `student_263` |
| 264 | Student | Ayesha Singh | `student264@school.com` | `student_264` |
| 265 | Student | Kavita Joshi | `student265@school.com` | `student_265` |
| 266 | Student | Kiran Sharma | `student266@school.com` | `student_266` |
| 267 | Student | Aakanksha Deshmukh | `student267@school.com` | `student_267` |
| 268 | Student | Riya Chatterjee | `student268@school.com` | `student_268` |
| 269 | Student | Aakanksha Sen | `student269@school.com` | `student_269` |
| 270 | Student | Pooja Joshi | `student270@school.com` | `student_270` |
| 271 | Student | Fatima Patil | `student271@school.com` | `student_271` |
| 272 | Student | Kavya Sen | `student272@school.com` | `student_272` |
| 273 | Student | Shweta Patil | `student273@school.com` | `student_273` |
| 274 | Student | Neeraj Kulkarni | `student274@school.com` | `student_274` |
| 275 | Student | Deepak Das | `student275@school.com` | `student_275` |
| 276 | Student | Rohan Iyer | `student276@school.com` | `student_276` |
| 277 | Student | Aditya Kulkarni | `student277@school.com` | `student_277` |
| 278 | Student | Sanjay Mukherjee | `student278@school.com` | `student_278` |
| 279 | Student | Arjun Chatterjee | `student279@school.com` | `student_279` |
| 280 | Student | Nitin Nair | `student280@school.com` | `student_280` |
| 281 | Student | Vikas Kulkarni | `student281@school.com` | `student_281` |
| 282 | Student | Vikram Sen | `student282@school.com` | `student_282` |
| 283 | Student | Ravi Mistry | `student283@school.com` | `student_283` |
| 284 | Student | Anita Tiwari | `student284@school.com` | `student_284` |
| 285 | Student | Pooja Banerjee | `student285@school.com` | `student_285` |
| 286 | Student | Shweta Yadav | `student286@school.com` | `student_286` |
| 287 | Student | Neha Gupta | `student287@school.com` | `student_287` |
| 288 | Student | Neha Bhat | `student288@school.com` | `student_288` |
| 289 | Student | Geeta Sen | `student289@school.com` | `student_289` |
| 290 | Student | Pooja Mistry | `student290@school.com` | `student_290` |
| 291 | Student | Nisha Chauhan | `student291@school.com` | `student_291` |
| 292 | Student | Shweta Menon | `student292@school.com` | `student_292` |
| 293 | Student | Nidhi Kumar | `student293@school.com` | `student_293` |
| 294 | Student | Amit Das | `student294@school.com` | `student_294` |
| 295 | Student | Anil Chowdhury | `student295@school.com` | `student_295` |
| 296 | Student | Rajesh Kulkarni | `student296@school.com` | `student_296` |
| 297 | Student | Akash Verma | `student297@school.com` | `student_297` |
| 298 | Student | Aditya Pandey | `student298@school.com` | `student_298` |
| 299 | Student | Suresh Kulkarni | `student299@school.com` | `student_299` |
| 300 | Student | Sumit Kumar | `student300@school.com` | `student_300` |
| 301 | Student | Aarav Patel | `student301@school.com` | `student_301` |
| 302 | Student | Sunil Yadav | `student302@school.com` | `student_302` |
| 303 | Student | Nitin Iyer | `student303@school.com` | `student_303` |
| 304 | Student | Sonia Nair | `student304@school.com` | `student_304` |
| 305 | Student | Sneha Singh | `student305@school.com` | `student_305` |
| 306 | Student | Rekha Joshi | `student306@school.com` | `student_306` |
| 307 | Student | Swati Reddy | `student307@school.com` | `student_307` |
| 308 | Student | Ayesha Verma | `student308@school.com` | `student_308` |
| 309 | Student | Kavita Pillai | `student309@school.com` | `student_309` |
| 310 | Student | Nisha Gupta | `student310@school.com` | `student_310` |
| 311 | Student | Meena Kulkarni | `student311@school.com` | `student_311` |
| 312 | Student | Shruti Yadav | `student312@school.com` | `student_312` |
| 313 | Student | Kavya Banerjee | `student313@school.com` | `student_313` |
| 314 | Student | Vikrant Chowdhury | `student314@school.com` | `student_314` |
| 315 | Student | Sunil Mishra | `student315@school.com` | `student_315` |
| 316 | Student | Nitin Chowdhury | `student316@school.com` | `student_316` |
| 317 | Student | Ravi Patil | `student317@school.com` | `student_317` |
| 318 | Student | Amit Mistry | `student318@school.com` | `student_318` |
| 319 | Student | Anil Kumar | `student319@school.com` | `student_319` |
| 320 | Student | Vikrant Singh | `student320@school.com` | `student_320` |
| 321 | Student | Neeraj Patel | `student321@school.com` | `student_321` |
| 322 | Student | Akash Pandey | `student322@school.com` | `student_322` |
| 323 | Student | Abhishek Chauhan | `student323@school.com` | `student_323` |
| 324 | Student | Divya Pillai | `student324@school.com` | `student_324` |
| 325 | Student | Sunita Chatterjee | `student325@school.com` | `student_325` |
| 326 | Student | Kavita Sen | `student326@school.com` | `student_326` |
| 327 | Student | Aakanksha Pandey | `student327@school.com` | `student_327` |
| 328 | Student | Zainab Deshmukh | `student328@school.com` | `student_328` |
| 329 | Student | Sneha Reddy | `student329@school.com` | `student_329` |
| 330 | Student | Ishita Patil | `student330@school.com` | `student_330` |
| 331 | Student | Shweta Verma | `student331@school.com` | `student_331` |
| 332 | Student | Ayesha Mistry | `student332@school.com` | `student_332` |
| 333 | Student | Sonia Mukherjee | `student333@school.com` | `student_333` |
| 334 | Student | Ravi Yadav | `student334@school.com` | `student_334` |
| 335 | Student | Manoj Reddy | `student335@school.com` | `student_335` |
| 336 | Student | Rajesh Nair | `student336@school.com` | `student_336` |
| 337 | Student | Vikas Iyer | `student337@school.com` | `student_337` |
| 338 | Student | Nitin Yadav | `student338@school.com` | `student_338` |
| 339 | Student | Rohan Kulkarni | `student339@school.com` | `student_339` |
| 340 | Student | Rajesh Joshi | `student340@school.com` | `student_340` |
| 341 | Student | Karan Gupta | `student341@school.com` | `student_341` |
| 342 | Student | Sunil Gupta | `student342@school.com` | `student_342` |
| 343 | Student | Abhishek Mukherjee | `student343@school.com` | `student_343` |
| 344 | Student | Simran Chowdhury | `student344@school.com` | `student_344` |
| 345 | Student | Rekha Mistry | `student345@school.com` | `student_345` |
| 346 | Student | Priya Joshi | `student346@school.com` | `student_346` |
| 347 | Student | Fatima Dubey | `student347@school.com` | `student_347` |
| 348 | Student | Kiran Chauhan | `student348@school.com` | `student_348` |
| 349 | Student | Rekha Banerjee | `student349@school.com` | `student_349` |
| 350 | Student | Pooja Yadav | `student350@school.com` | `student_350` |
| 351 | Student | Sneha Pillai | `student351@school.com` | `student_351` |
| 352 | Student | Riya Reddy | `student352@school.com` | `student_352` |
| 353 | Student | Riya Mistry | `student353@school.com` | `student_353` |
| 354 | Student | Suresh Das | `student354@school.com` | `student_354` |
| 355 | Student | Sanjay Menon | `student355@school.com` | `student_355` |
| 356 | Student | Krishna Tiwari | `student356@school.com` | `student_356` |
| 357 | Student | Nitin Patel | `student357@school.com` | `student_357` |
| 358 | Student | Krishna Mukherjee | `student358@school.com` | `student_358` |
| 359 | Student | Manish Nair | `student359@school.com` | `student_359` |
| 360 | Student | Rohan Dubey | `student360@school.com` | `student_360` |
| 361 | Student | Sumit Yadav | `student361@school.com` | `student_361` |
| 362 | Student | Amit Joshi | `student362@school.com` | `student_362` |
| 363 | Student | Sanjay Bhat | `student363@school.com` | `student_363` |
| 364 | Student | Rekha Pandey | `student364@school.com` | `student_364` |
| 365 | Student | Sunita Dubey | `student365@school.com` | `student_365` |
| 366 | Student | Pooja Iyer | `student366@school.com` | `student_366` |
| 367 | Student | Geeta Kumar | `student367@school.com` | `student_367` |
| 368 | Student | Ananya Menon | `student368@school.com` | `student_368` |
| 369 | Student | Priya Chauhan | `student369@school.com` | `student_369` |
| 370 | Student | Preeti Kumar | `student370@school.com` | `student_370` |
| 371 | Student | Divya Verma | `student371@school.com` | `student_371` |
| 372 | Student | Pooja Pillai | `student372@school.com` | `student_372` |
| 373 | Student | Kavya Pandey | `student373@school.com` | `student_373` |
| 374 | Student | Ravi Sharma | `student374@school.com` | `student_374` |
| 375 | Student | Akash Joshi | `student375@school.com` | `student_375` |
| 376 | Student | Ravi Verma | `student376@school.com` | `student_376` |
| 377 | Student | Manish Dubey | `student377@school.com` | `student_377` |
| 378 | Student | Suresh Nair | `student378@school.com` | `student_378` |
| 379 | Student | Arjun Menon | `student379@school.com` | `student_379` |
| 380 | Student | Ravi Chatterjee | `student380@school.com` | `student_380` |
| 381 | Student | Manish Kulkarni | `student381@school.com` | `student_381` |
| 382 | Student | Rohan Das | `student382@school.com` | `student_382` |
| 383 | Student | Arjun Tiwari | `student383@school.com` | `student_383` |
| 384 | Student | Meena Banerjee | `student384@school.com` | `student_384` |
| 385 | Student | Aakanksha Chauhan | `student385@school.com` | `student_385` |
| 386 | Student | Riya Chauhan | `student386@school.com` | `student_386` |
| 387 | Student | Riya Pandey | `student387@school.com` | `student_387` |
| 388 | Student | Aakanksha Chatterjee | `student388@school.com` | `student_388` |
| 389 | Student | Simran Bhat | `student389@school.com` | `student_389` |
| 390 | Student | Sonia Pillai | `student390@school.com` | `student_390` |
| 391 | Student | Swati Tiwari | `student391@school.com` | `student_391` |
| 392 | Student | Anita Verma | `student392@school.com` | `student_392` |
| 393 | Student | Ananya Das | `student393@school.com` | `student_393` |
| 394 | Student | Manoj Yadav | `student394@school.com` | `student_394` |
| 395 | Student | Krishna Chauhan | `student395@school.com` | `student_395` |
| 396 | Student | Vikrant Mishra | `student396@school.com` | `student_396` |
| 397 | Student | Rahul Singh | `student397@school.com` | `student_397` |
| 398 | Student | Neeraj Mistry | `student398@school.com` | `student_398` |
| 399 | Student | Krishna Bose | `student399@school.com` | `student_399` |
| 400 | Student | Vijay Tiwari | `student400@school.com` | `student_400` |
| 401 | Student | Manoj Bhat | `student401@school.com` | `student_401` |
| 402 | Student | Vivaan Singh | `student402@school.com` | `student_402` |
| 403 | Student | Aarav Deshmukh | `student403@school.com` | `student_403` |
| 404 | Student | Riya Tiwari | `student404@school.com` | `student_404` |
| 405 | Student | Preeti Gupta | `student405@school.com` | `student_405` |
| 406 | Student | Preeti Bhat | `student406@school.com` | `student_406` |
| 407 | Student | Sunita Bose | `student407@school.com` | `student_407` |
| 408 | Student | Neha Mistry | `student408@school.com` | `student_408` |
| 409 | Student | Priya Chatterjee | `student409@school.com` | `student_409` |
| 410 | Student | Divya Sen | `student410@school.com` | `student_410` |
| 411 | Student | Sonia Menon | `student411@school.com` | `student_411` |
| 412 | Student | Ananya Yadav | `student412@school.com` | `student_412` |
| 413 | Student | Ishita Chowdhury | `student413@school.com` | `student_413` |
| 414 | Student | Neeraj Pandey | `student414@school.com` | `student_414` |
| 415 | Student | Amit Tiwari | `student415@school.com` | `student_415` |
| 416 | Student | Vijay Banerjee | `student416@school.com` | `student_416` |
| 417 | Student | Manoj Menon | `student417@school.com` | `student_417` |
| 418 | Student | Sanjay Kulkarni | `student418@school.com` | `student_418` |
| 419 | Student | Anil Bhat | `student419@school.com` | `student_419` |
| 420 | Student | Rajesh Tiwari | `student420@school.com` | `student_420` |
| 421 | Student | Ravi Das | `student421@school.com` | `student_421` |
| 422 | Student | Rajesh Gupta | `student422@school.com` | `student_422` |
| 423 | Student | Deepak Dubey | `student423@school.com` | `student_423` |
| 424 | Student | Shweta Mukherjee | `student424@school.com` | `student_424` |
| 425 | Student | Shweta Patel | `student425@school.com` | `student_425` |
| 426 | Student | Rekha Pillai | `student426@school.com` | `student_426` |
| 427 | Student | Meena Singh | `student427@school.com` | `student_427` |
| 428 | Student | Meena Gupta | `student428@school.com` | `student_428` |
| 429 | Student | Fatima Chowdhury | `student429@school.com` | `student_429` |
| 430 | Student | Riya Menon | `student430@school.com` | `student_430` |
| 431 | Student | Swati Iyer | `student431@school.com` | `student_431` |
| 432 | Student | Pooja Gupta | `student432@school.com` | `student_432` |
| 433 | Student | Ishita Pandey | `student433@school.com` | `student_433` |
| 7 | Parent | Parent | `parent7@school.com` | `parent_7` |
| 8 | Parent | TALIVAAN | `parent8@school.com` | `parent_8` |
| 10 | Parent | Jane Doe | `parent10@school.com` | `parent_10` |
| 12 | Parent | Test Parent | `parent12@school.com` | `parent_12` |
| 14 | Parent | RAJU | `parent14@school.com` | `parent_14` |
| 62 | Teacher | Kiara Yadav | `teacher62@school.com` | `teacher_62` |
| 63 | Teacher | Meera Das | `teacher63@school.com` | `teacher_63` |
| 65 | Teacher | Ishaan Yadav | `teacher65@school.com` | `teacher_65` |
| 66 | Teacher | Krishna Kapoor | `teacher66@school.com` | `teacher_66` |
| 67 | Teacher | Rahul Khan | `teacher67@school.com` | `teacher_67` |
| 68 | Teacher | Nitin Chauhan | `teacher68@school.com` | `teacher_68` |
| 69 | Teacher | Sunil Trivedi | `teacher69@school.com` | `teacher_69` |
| 70 | Teacher | Rajesh Verma | `teacher70@school.com` | `teacher_70` |
| 71 | Teacher | Karan Kapoor | `teacher71@school.com` | `teacher_71` |
| 72 | Teacher | Aavya Yadav | `teacher72@school.com` | `teacher_72` |
| 73 | Teacher | Ayaat Sharma | `teacher73@school.com` | `teacher_73` |
| 74 | Teacher | Saanvi Sharma | `teacher74@school.com` | `teacher_74` |
| 75 | Teacher | Vikram Garg | `teacher75@school.com` | `teacher_75` |
| 76 | Teacher | Amit Reddy | `teacher76@school.com` | `teacher_76` |
| 77 | Teacher | Karan Garg | `teacher77@school.com` | `teacher_77` |
| 79 | Teacher | Ishani Menon | `teacher79@school.com` | `teacher_79` |
| 80 | Teacher | Ishaan Deshmukh | `teacher80@school.com` | `teacher_80` |
| 81 | Teacher | Sanjay Das | `teacher81@school.com` | `teacher_81` |
| 82 | Teacher | Sai Iyer | `teacher82@school.com` | `teacher_82` |
| 83 | Teacher | Divya Gupta | `teacher83@school.com` | `teacher_83` |
| 84 | Teacher | Advika Mehta | `teacher84@school.com` | `teacher_84` |
| 85 | Teacher | Advika Bhat | `teacher85@school.com` | `teacher_85` |
| 86 | Teacher | Diya Yadav | `teacher86@school.com` | `teacher_86` |
| 87 | Teacher | Arjun Garg | `teacher87@school.com` | `teacher_87` |
| 88 | Teacher | Ishani Joshi | `teacher88@school.com` | `teacher_88` |
| 89 | Teacher | Vikram Mehta | `teacher89@school.com` | `teacher_89` |
| 90 | Teacher | Arjun Gupta | `teacher90@school.com` | `teacher_90` |
| 91 | Teacher | Rajesh Bhat | `teacher91@school.com` | `teacher_91` |
| 92 | Teacher | Krishna Menon | `teacher92@school.com` | `teacher_92` |
| 93 | Teacher | Akash Singh | `teacher93@school.com` | `teacher_93` |
| 94 | Teacher | Akash Mehta | `teacher94@school.com` | `teacher_94` |

</details>

---
*Designed and maintained by WebNoor*
<?php
require_once 'includes/init.php';

// Fetch School Logo from system_settings
$school_logo = 'assets/logo/school.png'; // Fallback
try {
    $stmt = $pdo->query("SELECT school_logo FROM system_settings LIMIT 1");
    $logo_db = $stmt->fetchColumn();
    if ($logo_db) {
        $school_logo = $logo_db;
    }
}
catch (Exception $e) {
// If table doesn't exist or other error, fallback to default
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found | School Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            /* Slightly more saturated but still very light colors for visibility */
            --soft-blue: #d6e9ff;
            --soft-purple: #f0e4ff;
            --soft-cyan: #e0fffb;
            --dark-grey: #333333;
            --text-muted: #555555;
            --btn-blue: #007bff;
            --btn-hover: #0056b3;
            --footer-grey: #888888;
        }

        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow: hidden;
            background: linear-gradient(135deg, var(--soft-blue) 0%, var(--soft-purple) 50%, var(--soft-cyan) 100%);
            background-attachment: fixed;
        }

        /* Light rays effect spreading from bottom left */
        body::before {
            content: "";
            position: fixed;
            bottom: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            /* Using a semi-transparent white for rays to make them pop against the gradient */
            background: radial-gradient(circle at bottom left, rgba(255, 255, 255, 0.6) 0%, transparent 60%);
            animation: rotateRays 30s linear infinite;
            pointer-events: none;
            z-index: 0;
        }

        @keyframes rotateRays {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .container-wrapper {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            padding: 20px;
            text-align: center;
            z-index: 1; /* Ensure content is above rays */
        }

        .school-logo {
            width: 120px;
            margin-bottom: 30px;
            transition: transform 0.3s ease;
        }

        .school-logo:hover {
            transform: scale(1.05);
        }

        .error-code {
            font-size: 80px;
            font-weight: bold;
            color: var(--dark-grey);
            margin: 0;
            line-height: 1;
        }

        .error-title {
            font-size: 28px;
            color: var(--dark-grey);
            margin-bottom: 20px;
        }

        .error-message {
            font-size: 16px;
            color: var(--text-muted);
            max-width: 500px;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .btn-home {
            background-color: var(--btn-blue);
            color: white;
            padding: 12px 30px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.3);
            border: none;
        }

        .btn-home:hover {
            background-color: var(--btn-hover);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 123, 255, 0.4);
        }

        .footer {
            position: absolute;
            bottom: 30px;
            width: 100%;
            text-align: center;
            font-size: 12px;
            color: var(--footer-grey);
        }

        .footer a {
            color: var(--footer-grey);
            text-decoration: none;
            font-weight: bold;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .highlight-webnoor {
            background-color: #ffd700;
            padding: 2px 6px;
            border-radius: 4px;
            color: #333;
            font-weight: bold;
        }

        /* Responsive Adjustments */
        @media (max-width: 576px) {
            .error-code { font-size: 60px; }
            .error-title { font-size: 24px; }
            .error-message { font-size: 14px; }
            .school-logo { width: 100px; }
        }
    </style>
</head>
<body>
    <div class="container-wrapper">
        <div class="top-section">
            <img src="<?php echo htmlspecialchars($school_logo); ?>" alt="School Logo" class="school-logo" onerror="this.src='assets/logo/school.png';">
        </div>

        <div class="middle-section">
            <h1 class="error-code">404</h1>
            <h2 class="error-title">Page Not Found</h2>
            <p class="error-message">
                The page you are trying to access does not exist or the link may be broken. 
                Please check the URL or return to the homepage to continue using the system.
            </p>
            <a href="login.php" class="btn-home">Return to Login Page</a>
        </div>

        <div class="footer">
            Designed and developed by <a href="https://webnoor.in/" target="_blank"><span class="highlight-webnoor">webnoor</span></a>
        </div>
    </div>
</body>
</html>

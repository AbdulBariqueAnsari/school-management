-- Extra tables for Exam Form Fill-up functionality
-- These should be imported after the main database tables (exams, classes, students) have been created.

-- Table for Principal to manage which classes have exam forms open
CREATE TABLE IF NOT EXISTS `exam_form_settings` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `exam_id` int(11) NOT NULL,
    `class_id` int(11) NOT NULL,
    `is_open` tinyint(1) DEFAULT 0,
    `fee_amount` decimal(10,2) DEFAULT 0.00,
    `deadline` date DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `exam_class` (`exam_id`, `class_id`),
    CONSTRAINT `fk_exam_settings` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_class_settings` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table to store student submissions for exam forms
CREATE TABLE IF NOT EXISTS `exam_form_submissions` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `student_id` int(11) NOT NULL,
    `exam_id` int(11) NOT NULL,
    `form_data` text DEFAULT NULL,
    `status` enum('Pending','Verified','Approved','Rejected') DEFAULT 'Pending',
    `clerk_id` int(11) DEFAULT NULL,
    `remarks` text DEFAULT NULL,
    `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `student_exam` (`student_id`, `exam_id`),
    CONSTRAINT `fk_student_submission` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_exam_submission` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert common exams if they don't exist
INSERT IGNORE INTO `exams` (`name`, `start_date`, `end_date`) VALUES
('Annual Exam', '2026-03-01', '2026-03-15'),
('Half Yearly Exam', '2025-09-01', '2025-09-15'),
('Quarterly Exam', '2025-06-01', '2025-06-10'),
('Unit Test', '2025-05-01', '2025-05-05');

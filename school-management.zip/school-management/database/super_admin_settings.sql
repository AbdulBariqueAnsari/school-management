-- Update users table with profile information parameters
ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR(50) NULL UNIQUE AFTER name;
ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_photo VARCHAR(255) NULL AFTER username;
ALTER TABLE users ADD COLUMN IF NOT EXISTS address TEXT NULL AFTER phone;
ALTER TABLE users ADD COLUMN IF NOT EXISTS dob DATE NULL AFTER address;
ALTER TABLE users ADD COLUMN IF NOT EXISTS gender ENUM('Male', 'Female', 'Other') NULL AFTER dob;

-- Create settings table
CREATE TABLE IF NOT EXISTS super_admin_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default rows if not exists
INSERT IGNORE INTO super_admin_settings (setting_key, setting_value) VALUES 
('school_logo', ''),
('school_favicon', ''),
('school_name', 'My School'),
('school_tagline', 'Excellence in Education'),
('school_code', 'SCH-001'),
('school_board', 'ICSE'),
('school_registration_number', '123456789'),
('school_email', 'talivsir@gmail.com'),
('school_phone', '+1234567890'),
('school_website', 'www.school.com'),
('school_address', '123 Main St, City, Country'),
('academic_year', '2023-2024'),
('academic_start_date', '2023-04-01'),
('academic_end_date', '2024-03-31'),
('grade_system', 'Percentage'),
('passing_percentage', '40'),
('attendance_type', 'Daily'),
('timezone', 'UTC'),
('currency', 'USD'),
('date_format', 'Y-m-d'),
('language', 'English'),
('theme', 'Light'),
('maintenance_mode', '0'),
('two_factor_auth', '0'),
('session_timeout', '120');

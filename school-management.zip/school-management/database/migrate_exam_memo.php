<?php
require_once __DIR__ . '/../config/db.php';

try {
    // Check if memo_no exists in exam_form_settings
    $stmt = $pdo->query("SHOW COLUMNS FROM exam_form_settings LIKE 'memo_no'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE exam_form_settings ADD COLUMN memo_no VARCHAR(50) NULL UNIQUE");
        echo "Added memo_no to exam_form_settings successfully.\n";
    } else {
        echo "memo_no already exists in exam_form_settings.\n";
    }
    
    // Check if application_sl_no exists in exam_form_submissions
    $stmt = $pdo->query("SHOW COLUMNS FROM exam_form_submissions LIKE 'application_sl_no'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE exam_form_submissions ADD COLUMN application_sl_no VARCHAR(50) NULL UNIQUE");
        echo "Added application_sl_no to exam_form_submissions successfully.\n";
    } else {
        echo "application_sl_no already exists in exam_form_submissions.\n";
    }
    
    // Ensure the status enum supports 'Verified'
    $pdo->exec("ALTER TABLE exam_form_submissions MODIFY COLUMN status ENUM('Pending','Verified','Approved','Rejected') DEFAULT 'Pending'");
    echo "Exam status enum verified and configured successfully.\n";

} catch (Exception $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
}
?>

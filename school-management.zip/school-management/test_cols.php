<?php
require_once 'config/db.php';
$stmt = $pdo->query("DESCRIBE students");
$cols = $stmt->fetchAll(PDO::FETCH_COLUMN);
echo implode("\n", $cols);

<?php
require 'includes/init.php';
try {
    $pdo->exec("ALTER TABLE admission_applications 
        ADD COLUMN student_photo VARCHAR(255) NULL,
        ADD COLUMN mobile_number VARCHAR(20) NULL,
        ADD COLUMN religion VARCHAR(50) NULL,
        ADD COLUMN caste_category VARCHAR(50) NULL,
        ADD COLUMN mother_tongue VARCHAR(50) NULL,
        ADD COLUMN father_name VARCHAR(100) NULL,
        ADD COLUMN father_mobile VARCHAR(20) NULL,
        ADD COLUMN mother_name VARCHAR(100) NULL,
        ADD COLUMN mother_mobile VARCHAR(20) NULL,
        ADD COLUMN parents_address TEXT NULL,
        ADD COLUMN guardian_name VARCHAR(100) NULL,
        ADD COLUMN relation VARCHAR(50) NULL,
        ADD COLUMN guardian_mobile VARCHAR(20) NULL,
        ADD COLUMN guardian_address TEXT NULL,
        ADD COLUMN has_medical_condition VARCHAR(10) NULL,
        ADD COLUMN medical_condition_desc TEXT NULL,
        ADD COLUMN has_disability VARCHAR(10) NULL,
        ADD COLUMN disability_desc TEXT NULL,
        ADD COLUMN has_allergies VARCHAR(10) NULL,
        ADD COLUMN allergies_desc TEXT NULL,
        ADD COLUMN previous_schooling_status VARCHAR(50) NULL,
        ADD COLUMN previous_class VARCHAR(50) NULL,
        ADD COLUMN previous_board VARCHAR(100) NULL,
        ADD COLUMN year_of_passing VARCHAR(10) NULL
    ");
    echo "Columns added to admission_applications successfully.";
}
catch (Exception $e) {
    if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
        echo "Columns already exist.";
    }
    else {
        echo "Error: " . $e->getMessage();
    }
}

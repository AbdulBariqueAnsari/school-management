<?php
require_once 'includes/init.php';

// If already logged in, redirect them
if (isLoggedIn()) {
    redirect(BASE_URL . '/dashboard.php');
}

$type = $_GET['type'] ?? 'staff';
$backUrl = ($type == 'student') ? 'student/login.php' : 'login.php';

$message = '';
$messageType = '';
$resetLink = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);

    try {
        // Ensure reset_token column exists
        $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token VARCHAR(100) NULL AFTER password");
        $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_expires DATETIME NULL AFTER reset_token");
    } catch (Exception $e) {}

    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ? AND is_active = 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

        $updateStmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?");
        $updateStmt->execute([$token, $expires, $user['id']]);

        $link = BASE_URL . "/reset_password.php?token=" . $token . "&type=" . $type;
        
        $subject = "Password Reset Request";
        $body = "Hello " . htmlspecialchars($user['name']) . ",\n\n";
        $body .= "Click the following link to reset your password:\n$link\n\n";
        if (sendTemplateEmail($email, $subject, $body)) {
            $message = "A password reset link has been sent to your email address.";
            $messageType = "success";
        } else {
            $message = "Local Development Mode: Secure link generated.";
            $messageType = "info";
            $resetLink = $link; // Fallback to show link on screen
        }
    } else {
        $message = "If that email is registered, a reset link has been sent to it.";
        $messageType = "info";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Exemplar School Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-wrapper {
            width: 100%;
            max-width: 420px;
            padding: 15px;
        }
        .login-card { 
            padding: 40px 30px; 
            border-radius: 15px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.15); 
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.5);
        }
        .form-floating .form-control { border-radius: 10px; border: 1px solid #ced4da; transition: all 0.3s; }
        .form-floating .form-control:focus { box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.15); border-color: #80bdff; }
        .btn-login {
            border-radius: 10px; padding: 12px; font-weight: 600; letter-spacing: 0.5px;
            background: linear-gradient(to right, #0052D4, #4364F7, #6FB1FC); border: none;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 123, 255, 0.4); }
        .utility-links a { color: #495057; text-decoration: none; font-size: 0.9em; transition: color 0.2s; font-weight: bold; }
        .utility-links a:hover { color: #007bff; text-decoration: underline; }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-card">
            <div class="text-center mb-4">
                <i class="fa fa-envelope-open-text fa-4x text-primary mb-3"></i>
                <h4 class="fw-bold" style="color: #2c3e50;">Password Recovery</h4>
                <p class="text-muted small">Enter your registered email address to receive a secure password reset link.</p>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?> py-2 shadow-sm text-center" style="font-size:0.9em;">
                    <i class="fa <?php echo $messageType == 'success' ? 'fa-check-circle' : 'fa-info-circle'; ?> me-1"></i> <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if ($resetLink): ?>
                <div class="alert alert-warning py-3 text-center shadow-sm">
                    <strong>Local Environment Notice:</strong> Since email cannot be sent, please <a href="<?php echo htmlspecialchars($resetLink); ?>" class="fw-bold text-dark text-decoration-underline">click here to reset your password</a> directly.
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-floating mb-4 mt-3">
                    <input type="email" name="email" class="form-control" id="floatingEmail" placeholder="name@example.com" required>
                    <label for="floatingEmail"><i class="fa fa-envelope text-muted me-2"></i>Registered Email</label>
                </div>
                
                <button type="submit" class="btn btn-primary w-100 btn-login text-white mb-3 shadow-none">
                    Send Reset Link <i class="fa fa-paper-plane ms-2"></i>
                </button>
            </form>

            <div class="utility-links text-center mt-4 border-top pt-3">
                <a href="<?php echo htmlspecialchars($backUrl); ?>" class="text-secondary"><i class="fa fa-arrow-left me-1"></i> Back to Login</a>
            </div>
        </div>
    </div>
</body>
</html>

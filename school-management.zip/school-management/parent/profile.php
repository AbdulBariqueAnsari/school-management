<?php
require_once '../includes/auth.php';

if ($_SESSION['role_id'] != 7) {
    redirect(BASE_URL . '/login.php');
}

$portal_title = 'Parent Profile & Settings';
require_once '../includes/shared_profile.php';
?>

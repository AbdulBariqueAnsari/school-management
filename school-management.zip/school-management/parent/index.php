<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 7) {
    redirect(BASE_URL . '/dashboard.php');
}

$user_id = (int)$_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$parentUser = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
$email = $parentUser['email'] ?? '';
$phone = $parentUser['phone'] ?? '';

$children = role_rows(
    "SELECT id, admission_no, student_name, class_applied, status, father_mobile, mother_mobile, parent_email, parent_id
     FROM students
     WHERE parent_id = ? OR parent_email = ? OR father_mobile = ? OR mother_mobile = ?
     ORDER BY student_name",
    [$user_id, $email, $phone, $phone],
    20
);

$childIds = array_map(function ($row) { return (int)$row['id']; }, $children);
$childCount = count($children);
$attendanceRows = 0;
$paymentRows = 0;
$marksRows = 0;
if ($childIds) {
    $placeholders = implode(',', array_fill(0, count($childIds), '?'));
    $attendanceRows = role_count("SELECT COUNT(*) FROM attendance WHERE student_id IN ($placeholders)", $childIds);
    $paymentRows = role_count("SELECT COUNT(*) FROM payments WHERE student_id IN ($placeholders)", $childIds);
    $marksRows = role_count("SELECT COUNT(*) FROM marks WHERE student_id IN ($placeholders)", $childIds);
}

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php role_page_hero('Parent / Guardian Portal', 'Monitor child profile, attendance, fees, results and school communication.', 'fa-people-roof'); ?>
    <div class="row g-3 mb-4">
        <?php role_render_cards([['Linked Children', $childCount], ['Attendance Rows', $attendanceRows], ['Payment Rows', $paymentRows], ['Result Rows', $marksRows]]); ?>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3"><h2 class="h5 fw-bold mb-0">My Children</h2></div>
                <?php role_render_table(['ID', 'Admission No', 'Student', 'Class', 'Status', 'Father Mobile', 'Mother Mobile', 'Parent Email', 'Parent ID'], $children, 'No linked child records found. Ask admin to connect your parent account.'); ?>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3"><h2 class="h5 fw-bold mb-0">Quick Actions</h2></div>
                <div class="list-group list-group-flush">
                    <a href="notices.php" class="list-group-item list-group-item-action"><i class="fa fa-bullhorn me-2 text-warning"></i> School Notice Board</a>
                    <a href="module.php?type=attendance" class="list-group-item list-group-item-action"><i class="fa fa-calendar-check me-2 text-success"></i> Attendance</a>
                    <a href="module.php?type=fees" class="list-group-item list-group-item-action"><i class="fa fa-file-invoice-dollar me-2 text-warning"></i> Fees</a>
                    <a href="module.php?type=results" class="list-group-item list-group-item-action"><i class="fa fa-chart-line me-2 text-info"></i> Results</a>
                    <a href="module.php?type=messages" class="list-group-item list-group-item-action"><i class="fa fa-envelope me-2 text-primary"></i> Messages</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

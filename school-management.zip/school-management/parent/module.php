<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 7) {
    redirect(BASE_URL . '/dashboard.php');
}

$user_id = (int)$_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$parentUser = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
$email = $parentUser['email'] ?? '';
$phone = $parentUser['phone'] ?? '';
$children = role_rows("SELECT id FROM students WHERE parent_id = ? OR parent_email = ? OR father_mobile = ? OR mother_mobile = ?", [$user_id, $email, $phone, $phone], 50);
$childIds = array_map(function ($row) { return (int)$row['id']; }, $children);
$where = $childIds ? implode(',', array_fill(0, count($childIds), '?')) : '0';

$type = $_GET['type'] ?? 'attendance';
$title = 'Parent View';
$icon = 'fa-people-roof';
$cards = [['Linked Children', count($childIds)]];
$columns = [];
$rows = [];

switch ($type) {
    case 'fees':
        $title = 'Child Fee Records';
        $icon = 'fa-file-invoice-dollar';
        $columns = ['Student ID', 'Fee ID', 'Paid', 'Method', 'Status', 'Date'];
        $rows = $childIds ? role_rows("SELECT student_id, fee_id, amount_paid, payment_method, status, payment_date FROM payments WHERE student_id IN ($where) ORDER BY payment_date DESC", $childIds, 200) : [];
        break;
    case 'results':
        $title = 'Child Results';
        $icon = 'fa-chart-line';
        $columns = ['Exam ID', 'Student ID', 'Subject ID', 'Marks', 'Grade'];
        $rows = $childIds ? role_rows("SELECT exam_id, student_id, subject_id, CONCAT(marks_obtained, '/', total_marks) AS marks, grade FROM marks WHERE student_id IN ($where) ORDER BY id DESC", $childIds, 200) : [];
        break;
    case 'messages':
        $title = 'Child Messages';
        $icon = 'fa-envelope';
        $columns = ['Sender', 'Receiver', 'Message', 'Role', 'Created'];
        $rows = $childIds ? role_rows("SELECT sender_id, receiver_id, message, sender_role, created_at FROM messages WHERE sender_id IN ($where) OR receiver_id IN ($where) ORDER BY created_at DESC", array_merge($childIds, $childIds), 200) : [];
        break;
    default:
        $title = 'Child Attendance';
        $icon = 'fa-calendar-check';
        $columns = ['Date', 'Student ID', 'Status', 'Marked By'];
        $rows = $childIds ? role_rows("SELECT date, student_id, status, marked_by FROM attendance WHERE student_id IN ($where) ORDER BY date DESC", $childIds, 200) : [];
}

require_once '../includes/header.php';
?>
<div class="container-fluid py-4">
    <?php role_page_hero($title, 'Parent/guardian read-only child record view.', $icon); ?>
    <div class="row g-3 mb-4"><?php role_render_cards($cards); ?></div>
    <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
        <div class="card-header bg-white py-3 d-flex justify-content-between"><h2 class="h5 fw-bold mb-0">Records</h2><a href="index.php" class="btn btn-sm btn-outline-secondary">Back</a></div>
        <?php role_render_table($columns, $rows, 'No linked records found yet.'); ?>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

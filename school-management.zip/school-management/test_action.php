<?php
require 'c:/xampp/htdocs/school-management/config/db.php';
session_start();
// mock super admin login
$_SESSION['role_id'] = 1;
$_SESSION['user_id'] = 1;

$_GET['id'] = 4; // testing with a pending teacher id=4

ob_start();

try {
    require 'c:/xampp/htdocs/school-management/admin/actions/approve_teacher.php';
}
catch (Throwable $e) {
    echo "CAUGHT ERROR: " . $e->getMessage() . "\n" . $e->getTraceAsString();
}

echo "SESSION DUMP:\n";
print_r($_SESSION);
$output = ob_get_clean();
file_put_contents('c:/xampp/htdocs/school-management/test_action_output.txt', $output);
echo "Done";

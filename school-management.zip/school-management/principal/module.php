<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 2) {
    redirect(BASE_URL . '/dashboard.php');
}

$type = $_GET['type'] ?? 'students';
$title = 'Academic Overview';
$icon = 'fa-school';
$columns = [];
$rows = [];
$cards = [];

switch ($type) {
    case 'teachers':
        $title = 'Teacher Directory';
        $icon = 'fa-chalkboard-user';
        $cards = [['Approved', role_count("SELECT COUNT(*) FROM teachers WHERE status='Approved'")], ['Pending', role_count("SELECT COUNT(*) FROM teachers WHERE status='Pending'")]];
        $columns = ['Teacher', 'Subject', 'Class', 'Designation', 'Status'];
        $rows = role_rows("SELECT full_name, assigned_subject, assigned_class, designation, status FROM teachers ORDER BY status, full_name", [], 200);
        break;
    case 'admissions':
        $title = 'Admission Pipeline';
        $icon = 'fa-user-plus';
        $cards = [['Pending', role_count("SELECT COUNT(*) FROM students WHERE status='Pending'")], ['Approved', role_count("SELECT COUNT(*) FROM students WHERE status='Approved'")], ['Rejected', role_count("SELECT COUNT(*) FROM students WHERE status='Rejected'")]];
        $columns = ['Admission No', 'Student', 'Class', 'Parent', 'Status'];
        $rows = role_rows("SELECT admission_no, student_name, class_applied, parent_name, status FROM students ORDER BY created_at DESC", [], 200);
        break;
    case 'attendance':
        $title = 'Attendance Overview';
        $icon = 'fa-calendar-check';
        $cards = [['Attendance Rows', role_count("SELECT COUNT(*) FROM attendance")], ['Present', role_count("SELECT COUNT(*) FROM attendance WHERE status='Present'")], ['Absent', role_count("SELECT COUNT(*) FROM attendance WHERE status='Absent'")]];
        $columns = ['Date', 'Student ID', 'Status', 'Marked By'];
        $rows = role_rows("SELECT date, student_id, status, marked_by FROM attendance ORDER BY date DESC", [], 200);
        break;
    case 'results':
        $title = 'Results Overview';
        $icon = 'fa-chart-line';
        $cards = [['Exams', role_count("SELECT COUNT(*) FROM exams")], ['Marks Rows', role_count("SELECT COUNT(*) FROM marks")]];
        $columns = ['Exam ID', 'Student ID', 'Subject ID', 'Marks', 'Grade'];
        $rows = role_rows("SELECT exam_id, student_id, subject_id, CONCAT(marks_obtained, '/', total_marks) AS marks, grade FROM marks ORDER BY id DESC", [], 200);
        break;
    default:
        $title = 'Students Overview';
        $icon = 'fa-user-graduate';
        $cards = [['Students', role_count("SELECT COUNT(*) FROM students")], ['Approved', role_count("SELECT COUNT(*) FROM students WHERE status='Approved'")]];
        $columns = ['Admission No', 'Student', 'Class', 'Parent', 'Status'];
        $rows = role_rows("SELECT admission_no, student_name, class_applied, parent_name, status FROM students ORDER BY student_name", [], 200);
}

require_once '../includes/header.php';
?>
<div class="container-fluid py-4">
    <?php role_page_hero($title, 'Principal read-only operational view.', $icon); ?>
    <div class="row g-3 mb-4"><?php role_render_cards($cards); ?></div>
    <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
        <div class="card-header bg-white py-3 d-flex justify-content-between"><h2 class="h5 fw-bold mb-0">Records</h2><a href="index.php" class="btn btn-sm btn-outline-secondary">Back</a></div>
        <?php role_render_table($columns, $rows); ?>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>

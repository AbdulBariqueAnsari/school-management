<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 2) {
    redirect(BASE_URL . '/dashboard.php');
}

$success_msg = '';
$error_msg = '';

// Handle Actions (Approve / Delete / Create)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'approve' && isset($_POST['notice_id'])) {
            $notice_id = (int)$_POST['notice_id'];
            try {
                $stmt = $pdo->prepare("UPDATE exam_schedule_notices SET status = 'Approved' WHERE id = ?");
                $stmt->execute([$notice_id]);
                $success_msg = "Exam schedule approved successfully and is now active for students!";
            } catch (Exception $e) {
                $error_msg = "Failed to approve schedule: " . $e->getMessage();
            }
        } elseif ($_POST['action'] === 'delete' && isset($_POST['notice_id'])) {
            $notice_id = (int)$_POST['notice_id'];
            try {
                $stmt = $pdo->prepare("DELETE FROM exam_schedule_notices WHERE id = ?");
                $stmt->execute([$notice_id]);
                $success_msg = "Exam schedule notice deleted successfully.";
            } catch (Exception $e) {
                $error_msg = "Failed to delete schedule: " . $e->getMessage();
            }
        } elseif ($_POST['action'] === 'create') {
            $exam_id = (int)($_POST['exam_id'] ?? 0);
            $class_id = (int)($_POST['class_id'] ?? 0);
            $schedule_json = $_POST['schedule_json'] ?? '';
            
            if (!$exam_id || !$class_id || empty($schedule_json) || $schedule_json === '[]') {
                $error_msg = "Please select an exam, class, and add at least one subject to the schedule.";
            } else {
                try {
                    // Generate Unique Notice Number
                    $stmt_count = $pdo->query("SELECT IFNULL(MAX(id), 0) + 1 FROM exam_schedule_notices");
                    $next_id = $stmt_count->fetchColumn();
                    $notice_no = "EXAM-SCH-" . date('Y') . "-" . str_pad($next_id, 4, '0', STR_PAD_LEFT);
                    
                    // Insert into DB
                    $stmt = $pdo->prepare("
                        INSERT INTO exam_schedule_notices (notice_no, exam_id, class_id, schedule_data, created_by, status)
                        VALUES (?, ?, ?, ?, ?, 'Approved')
                    ");
                    $stmt->execute([$notice_no, $exam_id, $class_id, $schedule_json, $_SESSION['user_id']]);
                    $success_msg = "Exam schedule created and published successfully under Notice No: $notice_no";
                } catch (Exception $e) {
                    $error_msg = "Failed to create schedule: " . $e->getMessage();
                }
            }
        }
    }
}

// Fetch lists for forms
$exams = $pdo->query("SELECT id, name FROM exams ORDER BY start_date DESC")->fetchAll(PDO::FETCH_ASSOC);
$classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all schedule notices
$notices = $pdo->query("
    SELECT n.*, e.name as exam_name, c.name as class_name, u.name as creator_name
    FROM exam_schedule_notices n
    JOIN exams e ON n.exam_id = e.id
    JOIN classes c ON n.class_id = c.id
    LEFT JOIN users u ON n.created_by = u.id
    ORDER BY n.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="main-content">
    <?php role_page_hero('Exam Dates & Notices', 'Create, manage, and authorize official exam datesheets and subject-wise schedules.', 'fa-calendar-days'); ?>

    <?php if ($success_msg): ?>
        <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-circle-check me-2"></i><?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Creation Column -->
        <div class="col-xl-5">
            <div class="card border-0 shadow-sm" style="border-radius: 16px;">
                <div class="card-header bg-white border-0 pt-4 px-4 pb-2">
                    <h5 class="fw-bold text-dark mb-0"><i class="fa fa-circle-plus text-primary me-2"></i>Create New Datesheet Notice</h5>
                    <small class="text-muted">Generate a subject-wise schedule notice for any class.</small>
                </div>
                <div class="card-body p-4">
                    <form method="POST" id="datesheetForm" onsubmit="return handleFormSubmit(event);">
                        <input type="hidden" name="action" value="create">
                        <input type="hidden" name="schedule_json" id="scheduleJsonInput">

                        <div class="mb-3">
                            <label class="form-label fw-semibold text-secondary">Select Examination</label>
                            <select name="exam_id" class="form-select bg-light" required>
                                <option value="" disabled selected>-- Choose Exam --</option>
                                <?php foreach ($exams as $exam): ?>
                                    <option value="<?php echo $exam['id']; ?>"><?php echo htmlspecialchars($exam['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-semibold text-secondary">Target Class</label>
                            <select name="class_id" class="form-select bg-light" required>
                                <option value="" disabled selected>-- Choose Class --</option>
                                <?php foreach ($classes as $cls): ?>
                                    <option value="<?php echo $cls['id']; ?>"><?php echo htmlspecialchars($cls['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Scheduler Block -->
                        <div class="border rounded-3 p-3 bg-light mb-4">
                            <h6 class="fw-bold text-dark mb-3"><i class="fa fa-list-check text-primary me-2"></i>Add Subject Schedule Row</h6>
                            
                            <div class="mb-2">
                                <label class="form-label small fw-bold text-secondary mb-1">Subject Name</label>
                                <input type="text" id="sched_subject" class="form-control form-control-sm bg-white" placeholder="e.g. Mathematics, Science">
                            </div>
                            
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <label class="form-label small fw-bold text-secondary mb-1">Exam Date</label>
                                    <input type="date" id="sched_date" class="form-control form-control-sm bg-white">
                                </div>
                                <div class="col-6">
                                    <label class="form-label small fw-bold text-secondary mb-1">Full Marks</label>
                                    <input type="number" id="sched_marks" class="form-control form-control-sm bg-white" placeholder="100" min="1">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-bold text-secondary mb-1">Timings</label>
                                <input type="text" id="sched_time" class="form-control form-control-sm bg-white" placeholder="e.g. 10:00 AM - 01:00 PM">
                            </div>

                            <button type="button" onclick="addSubjectRow();" class="btn btn-sm btn-outline-primary w-100 fw-bold"><i class="fa fa-plus me-1"></i> Add Subject Row to List</button>
                        </div>

                        <!-- Table preview inside builder -->
                        <div class="mb-4">
                            <label class="form-label fw-bold text-dark d-block">Schedule Summary Rows</label>
                            <div class="table-responsive border rounded-3 bg-white" style="max-height: 200px; overflow-y:auto;">
                                <table class="table table-sm table-hover align-middle mb-0" id="builderTable">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Subject</th>
                                            <th>Date</th>
                                            <th>Marks</th>
                                            <th class="text-end">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="builderBody">
                                        <tr id="emptyRowPlaceholder"><td colspan="4" class="text-center text-muted small py-3">No subjects added to schedule yet.</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 fw-bold shadow-sm"><i class="fa fa-bullhorn me-2"></i>Publish Datesheet Notice</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Management List Column -->
        <div class="col-xl-7">
            <div class="card border-0 shadow-sm" style="border-radius: 16px;">
                <div class="card-header bg-white border-0 pt-4 px-4 pb-2">
                    <h5 class="fw-bold text-dark mb-0"><i class="fa fa-list text-primary me-2"></i>Published Schedules &amp; Approvals</h5>
                    <small class="text-muted">Authorized and pending Clerk-submitted schedule notices.</small>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Notice Details</th>
                                    <th>Target Class</th>
                                    <th>Creator</th>
                                    <th>Status</th>
                                    <th class="text-end pe-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$notices): ?>
                                    <tr><td colspan="5" class="text-center py-4 text-muted">No schedule notices have been created yet.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($notices as $row): ?>
                                        <?php 
                                        $badge = $row['status'] === 'Approved' ? 'bg-success' : 'bg-warning text-dark';
                                        ?>
                                        <tr>
                                            <td class="ps-4">
                                                <strong class="text-primary d-block"><?php echo htmlspecialchars($row['notice_no']); ?></strong>
                                                <small class="text-dark fw-bold"><?php echo htmlspecialchars($row['exam_name']); ?></small><br>
                                                <small class="text-muted"><?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></small>
                                            </td>
                                            <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($row['class_name']); ?></span></td>
                                            <td><small class="fw-semibold text-secondary"><?php echo htmlspecialchars($row['creator_name'] ?: 'System'); ?></small></td>
                                            <td><span class="badge <?php echo $badge; ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                                            <td class="text-end pe-4">
                                                <button class="btn btn-sm btn-outline-info me-1" data-bs-toggle="modal" data-bs-target="#viewNoticeModal<?php echo $row['id']; ?>"><i class="fa fa-eye"></i></button>
                                                
                                                <?php if ($row['status'] === 'Pending'): ?>
                                                    <form method="POST" style="display:inline;">
                                                        <input type="hidden" name="action" value="approve">
                                                        <input type="hidden" name="notice_id" value="<?php echo $row['id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-success me-1" title="Approve Notice"><i class="fa fa-check"></i> Approve</button>
                                                    </form>
                                                <?php endif; ?>

                                                <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this exam schedule?');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="notice_id" value="<?php echo $row['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete Notice"><i class="fa fa-trash-can"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal definition block shifted OUTSIDE table container to resolve web overflow clipping & backdrop freezes -->
<?php if ($notices): ?>
    <?php foreach ($notices as $row): ?>
        <?php 
        $sch_data = json_decode($row['schedule_data'], true) ?: [];
        ?>
        <!-- View Schedule Modal -->
        <div class="modal fade" id="viewNoticeModal<?php echo $row['id']; ?>" tabindex="-1" data-bs-backdrop="false" style="background: rgba(15,23,42,0.45); backdrop-filter: blur(4px);">
          <div class="modal-dialog modal-lg text-start">
            <div class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
              <div class="modal-header border-0 pb-0 bg-light rounded-top p-4">
                <div>
                    <h5 class="modal-title fw-bold text-dark"><i class="fa fa-calendar-days text-primary me-2"></i>Exam Schedule Details</h5>
                    <small class="text-muted"><?php echo htmlspecialchars($row['notice_no']); ?> | <?php echo htmlspecialchars($row['exam_name']); ?></small>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body p-4">
                <div class="row g-3 mb-4 bg-light rounded-3 p-3">
                    <div class="col-md-4">
                        <span class="text-muted small d-block">Target Class</span>
                        <strong class="text-dark"><?php echo htmlspecialchars($row['class_name']); ?></strong>
                    </div>
                    <div class="col-md-4">
                        <span class="text-muted small d-block">Status</span>
                        <span class="badge <?php echo $row['status'] === 'Approved' ? 'bg-success' : 'bg-warning text-dark'; ?>"><?php echo htmlspecialchars($row['status']); ?></span>
                    </div>
                    <div class="col-md-4">
                        <span class="text-muted small d-block">Published Date</span>
                        <strong class="text-dark"><?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></strong>
                    </div>
                </div>

                <h6 class="fw-bold text-secondary border-bottom pb-2 mb-3"><i class="fa fa-list-check me-2"></i>Subject-Wise Datesheet</h6>
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th>Subject</th>
                                <th>Exam Date</th>
                                <th>Timings</th>
                                <th class="text-end">Full Marks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$sch_data): ?>
                                <tr><td colspan="4" class="text-center py-3 text-muted">No details found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($sch_data as $sub): ?>
                                    <tr>
                                        <td><strong class="text-dark"><?php echo htmlspecialchars($sub['subject'] ?? 'N/A'); ?></strong></td>
                                        <td><span class="badge bg-light text-dark border"><i class="fa fa-calendar me-1 text-primary"></i><?php echo !empty($sub['date']) ? date('d M Y', strtotime($sub['date'])) : 'N/A'; ?></span></td>
                                        <td><small class="fw-semibold text-secondary"><?php echo htmlspecialchars($sub['time'] ?? 'N/A'); ?></small></td>
                                        <td class="text-end fw-bold text-primary"><?php echo htmlspecialchars($sub['full_marks'] ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
              </div>
              <div class="modal-footer border-0 bg-light rounded-bottom p-4">
                <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<script>
let scheduleItems = [];

function addSubjectRow() {
    const subject = document.getElementById('sched_subject').value.trim();
    const date = document.getElementById('sched_date').value;
    const marks = document.getElementById('sched_marks').value;
    const time = document.getElementById('sched_time').value.trim();

    if (!subject || !date || !marks || !time) {
        alert("Please enter subject name, exam date, full marks, and timing values.");
        return;
    }

    const item = {
        subject: subject,
        date: date,
        full_marks: parseInt(marks),
        time: time
    };

    scheduleItems.push(item);
    renderBuilderTable();

    // Clear builder inputs
    document.getElementById('sched_subject').value = '';
    document.getElementById('sched_date').value = '';
    document.getElementById('sched_marks').value = '';
    document.getElementById('sched_time').value = '';
}

function removeSubjectRow(index) {
    scheduleItems.splice(index, 1);
    renderBuilderTable();
}

function renderBuilderTable() {
    const body = document.getElementById('builderBody');
    body.innerHTML = '';

    if (scheduleItems.length === 0) {
        body.innerHTML = '<tr id="emptyRowPlaceholder"><td colspan="4" class="text-center text-muted small py-3">No subjects added to schedule yet.</td></tr>';
        return;
    }

    scheduleItems.forEach((item, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><strong>${escapeHtml(item.subject)}</strong></td>
            <td><small class="text-muted">${item.date}</small></td>
            <td><span class="badge bg-primary">${item.full_marks}</span></td>
            <td class="text-end">
                <button type="button" onclick="removeSubjectRow(${index});" class="btn btn-sm btn-outline-danger py-0 px-2"><i class="fa fa-times small"></i></button>
            </td>
        `;
        body.appendChild(row);
    });
}

function handleFormSubmit(e) {
    if (scheduleItems.length === 0) {
        alert("Please add at least one subject to your exam schedule list.");
        return false;
    }
    document.getElementById('scheduleJsonInput').value = JSON.stringify(scheduleItems);
    return true;
}

function escapeHtml(text) {
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
</script>

<?php require_once '../includes/footer.php'; ?>

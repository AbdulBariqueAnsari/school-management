<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 2) {
    redirect(BASE_URL . '/dashboard.php');
}

$cards = [
    ['Approved Students', role_count("SELECT COUNT(*) FROM students WHERE status='Approved'")],
    ['Teachers', role_count("SELECT COUNT(*) FROM teachers WHERE status='Approved'")],
    ['Pending Admissions', role_count("SELECT COUNT(*) FROM students WHERE status='Pending'")],
    ['Exams', role_count("SELECT COUNT(*) FROM exams")],
];

$recentAdmissions = role_rows("SELECT admission_no, student_name, class_applied, parent_name, status FROM students ORDER BY created_at DESC", [], 8);
$teacherLoad = role_rows("SELECT full_name, assigned_subject, assigned_class, role, status FROM teachers WHERE status='Approved' ORDER BY assigned_class, full_name", [], 8);

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php role_page_hero('Principal Dashboard', 'Academic leadership overview for admissions, teachers, classes and performance.', 'fa-user-tie'); ?>

    <div class="row g-3 mb-4"><?php role_render_cards($cards); ?></div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h2 class="h5 fw-bold mb-0">Recent Student Records</h2>
                    <a href="<?php echo BASE_URL; ?>/admin/students.php" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <?php role_render_table(['Admission No', 'Student', 'Class', 'Parent', 'Status'], $recentAdmissions); ?>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3">
                    <h2 class="h5 fw-bold mb-0">Quick Actions</h2>
                </div>
                <div class="list-group list-group-flush">
                    <a href="<?php echo BASE_URL; ?>/admin/teachers.php" class="list-group-item list-group-item-action"><i class="fa fa-chalkboard-user me-2 text-primary"></i> Teacher Directory</a>
                    <a href="<?php echo BASE_URL; ?>/admin/admissions.php" class="list-group-item list-group-item-action"><i class="fa fa-user-plus me-2 text-warning"></i> Admission Pipeline</a>
                    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=results" class="list-group-item list-group-item-action"><i class="fa fa-chart-line me-2 text-info"></i> Results Overview</a>
                    <a href="<?php echo BASE_URL; ?>/principal/exam_forms.php" class="list-group-item list-group-item-action"><i class="fa fa-clipboard-list me-2" style="color: #8b5cf6;"></i> Exam Form Manager</a>
                    <a href="<?php echo BASE_URL; ?>/principal/exam_approvals.php" class="list-group-item list-group-item-action"><i class="fa fa-gavel me-2 text-danger"></i> Exam Approvals</a>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3"><h2 class="h5 fw-bold mb-0">Teacher Assignments</h2></div>
                <?php role_render_table(['Teacher', 'Subject', 'Class', 'Assignment Role', 'Status'], $teacherLoad); ?>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 2) {
    redirect(BASE_URL . '/dashboard.php');
}

$success_msg = '';
$error_msg = '';

// Handle Actions (Create / Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'delete' && isset($_POST['notice_id'])) {
            $notice_id = (int)$_POST['notice_id'];
            try {
                // Fetch the notice first to delete the file from disk if it exists
                $stmt_fetch = $pdo->prepare("SELECT attachment_path FROM announcements WHERE id = ?");
                $stmt_fetch->execute([$notice_id]);
                $notice = $stmt_fetch->fetch();
                
                if ($notice && !empty($notice['attachment_path'])) {
                    $file_path = '../' . $notice['attachment_path'];
                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }
                }

                $stmt = $pdo->prepare("DELETE FROM announcements WHERE id = ?");
                $stmt->execute([$notice_id]);
                $success_msg = "Notice deleted successfully.";
            } catch (Exception $e) {
                $error_msg = "Failed to delete notice: " . $e->getMessage();
            }
        } elseif ($_POST['action'] === 'create') {
            $title = trim($_POST['title'] ?? '');
            $content = trim($_POST['content'] ?? '');
            $target_role_id = $_POST['target_role_id'] === 'all' ? null : (int)$_POST['target_role_id'];
            
            if (empty($title) || empty($content)) {
                $error_msg = "Title and Content are required fields.";
            } else {
                try {
                    $attachment_path = null;
                    $attachment_type = null;

                    // Handle file upload if present
                    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                        $file_tmp = $_FILES['attachment']['tmp_name'];
                        $file_name = $_FILES['attachment']['name'];
                        $file_size = $_FILES['attachment']['size'];
                        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

                        $allowed_exts = ['pdf', 'jpg', 'jpeg', 'png', 'gif', 'webp'];
                        
                        if (!in_array($file_ext, $allowed_exts)) {
                            $error_msg = "Only PDF and Image files (jpg, jpeg, png, gif, webp) are allowed.";
                        } elseif ($file_size > 10 * 1024 * 1024) { // 10MB Limit
                            $error_msg = "Attachment size must be under 10MB.";
                        } else {
                            // Ensure upload directory exists
                            $upload_dir = '../uploads/notices/';
                            if (!is_dir($upload_dir)) {
                                mkdir($upload_dir, 0777, true);
                            }

                            // Generate a unique filename
                            $new_file_name = time() . '_' . bin2hex(random_bytes(8)) . '.' . $file_ext;
                            $dest_path = $upload_dir . $new_file_name;

                            if (move_uploaded_file($file_tmp, $dest_path)) {
                                $attachment_path = 'uploads/notices/' . $new_file_name;
                                $attachment_type = ($file_ext === 'pdf') ? 'pdf' : 'image';
                            } else {
                                $error_msg = "Failed to save uploaded file.";
                            }
                        }
                    }

                    if (empty($error_msg)) {
                        // Insert into database
                        $stmt = $pdo->prepare("
                            INSERT INTO announcements (title, content, target_role_id, created_by, attachment_path, attachment_type)
                            VALUES (?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$title, $content, $target_role_id, $_SESSION['user_id'], $attachment_path, $attachment_type]);
                        $success_msg = "Notice published successfully to the designated audience!";
                    }
                } catch (Exception $e) {
                    $error_msg = "Failed to publish notice: " . $e->getMessage();
                }
            }
        }
    }
}

// Fetch roles for target audience selection
$roles = $pdo->query("SELECT id, name FROM roles WHERE id != 2 ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all announcements created by any admin/principal
$notices = $pdo->query("
    SELECT a.*, r.name as target_role_name, u.name as creator_name
    FROM announcements a
    LEFT JOIN roles r ON a.target_role_id = r.id
    LEFT JOIN users u ON a.created_by = u.id
    ORDER BY a.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="main-content">
    <?php role_page_hero('School Notice Board Manager', 'Broadcast announcements, event notices, files, and rules directly to specific user roles.', 'fa-bullhorn'); ?>

    <?php if ($success_msg): ?>
        <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-circle-check me-2"></i><?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Publish New Notice -->
        <div class="col-xl-4">
            <div class="card border-0 shadow-sm" style="border-radius: 16px;">
                <div class="card-header bg-white border-0 pt-4 px-4 pb-2">
                    <h5 class="fw-bold text-dark mb-0"><i class="fa fa-paper-plane text-primary me-2"></i>Publish New Notice</h5>
                    <small class="text-muted">Draft a general text broadcast or attach standard PDF documents & images.</small>
                </div>
                <div class="card-body p-4">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="create">

                        <div class="mb-3">
                            <label class="form-label fw-semibold text-secondary">Notice Title</label>
                            <input type="text" name="title" class="form-control bg-light border-0 py-2" placeholder="e.g. Annual Sports Meet 2026" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold text-secondary">Target Audience</label>
                            <select name="target_role_id" class="form-select bg-light border-0 py-2" required>
                                <option value="all">All Users (Students, Teachers, Clerks, Parents)</option>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?php echo $role['id']; ?>"><?php echo htmlspecialchars($role['name']); ?> Portal Only</option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold text-secondary">Notice Content</label>
                            <textarea name="content" rows="6" class="form-control bg-light border-0" placeholder="Type detailed notice details here..." required></textarea>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-semibold text-secondary">File Attachment <small class="text-muted fw-normal">(Optional - PDF or Image)</small></label>
                            <input type="file" name="attachment" class="form-control bg-light border-0" accept=".pdf,image/*">
                            <div class="form-text small text-muted">Supports high-res PNG, JPG, JPEG, GIF, and PDF up to 10MB.</div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 fw-bold shadow-sm py-2"><i class="fa fa-bullhorn me-2"></i>Publish Notice</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Notices Board History -->
        <div class="col-xl-8">
            <div class="card border-0 shadow-sm" style="border-radius: 16px;">
                <div class="card-header bg-white border-0 pt-4 px-4 pb-2 d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="fw-bold text-dark mb-0"><i class="fa fa-clock-rotate-left text-primary me-2"></i>Broadcast History</h5>
                        <small class="text-muted">Review, inspect, or delete notices previously broadcasted.</small>
                    </div>
                    <span class="badge bg-light text-dark border fw-bold px-3 py-2 rounded-pill"><?php echo count($notices); ?> Total Notices</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Notice Details</th>
                                    <th>Target Audience</th>
                                    <th>Attachments</th>
                                    <th>Creator</th>
                                    <th class="text-end pe-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$notices): ?>
                                    <tr><td colspan="5" class="text-center py-5 text-muted">No notices have been published yet.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($notices as $row): ?>
                                        <tr>
                                            <td class="ps-4 py-3" style="max-width: 300px;">
                                                <strong class="text-dark d-block fs-6 mb-1"><?php echo htmlspecialchars($row['title']); ?></strong>
                                                <p class="text-secondary mb-1 text-truncate small" style="max-width: 280px;"><?php echo htmlspecialchars($row['content']); ?></p>
                                                <small class="text-muted"><i class="fa-regular fa-clock me-1"></i><?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></small>
                                            </td>
                                            <td>
                                                <?php if (empty($row['target_role_name'])): ?>
                                                    <span class="badge bg-primary-subtle text-primary fw-semibold px-2.5 py-1.5 rounded-pill"><i class="fa-solid fa-users me-1"></i> All Users</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary-subtle text-secondary fw-semibold px-2.5 py-1.5 rounded-pill"><i class="fa-solid fa-user me-1"></i> <?php echo htmlspecialchars($row['target_role_name']); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (!empty($row['attachment_path'])): ?>
                                                    <?php if ($row['attachment_type'] === 'pdf'): ?>
                                                        <a href="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" target="_blank" class="btn btn-sm btn-outline-danger fw-bold border-0 shadow-none">
                                                            <i class="fa-solid fa-file-pdf me-1 fs-5"></i> PDF
                                                        </a>
                                                    <?php else: ?>
                                                        <button class="btn btn-sm btn-outline-info fw-bold border-0 shadow-none" data-bs-toggle="modal" data-bs-target="#viewImageModal<?php echo $row['id']; ?>">
                                                            <i class="fa-solid fa-image me-1 fs-5"></i> Image
                                                        </button>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="text-muted small">None</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><small class="fw-semibold text-secondary"><?php echo htmlspecialchars($row['creator_name'] ?: 'System'); ?></small></td>
                                            <td class="text-end pe-4">
                                                <button class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#viewNoticeModal<?php echo $row['id']; ?>"><i class="fa fa-eye"></i> View</button>
                                                
                                                <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to permanently delete this notice? This will also delete any attached file from the server.');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="notice_id" value="<?php echo $row['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete Notice"><i class="fa fa-trash-can"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modals Block for Notice Previews -->
<?php if ($notices): ?>
    <?php foreach ($notices as $row): ?>
        <!-- Full Notice View Modal -->
        <div class="modal fade" id="viewNoticeModal<?php echo $row['id']; ?>" tabindex="-1" data-bs-backdrop="false" style="background: rgba(15,23,42,0.5); backdrop-filter: blur(8px);">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden; background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px);">
                    <div class="modal-header border-0 bg-light p-4">
                        <div>
                            <span class="badge bg-primary mb-2">Notice ID: #<?php echo $row['id']; ?></span>
                            <h4 class="modal-title fw-bold text-dark mb-0"><?php echo htmlspecialchars($row['title']); ?></h4>
                            <small class="text-muted">Published on: <?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></small>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body p-4">
                        <div class="mb-4">
                            <span class="text-muted small d-block mb-1">Target Audience:</span>
                            <?php if (empty($row['target_role_name'])): ?>
                                <span class="badge bg-primary-subtle text-primary fw-semibold"><i class="fa-solid fa-users me-1"></i> All Users</span>
                            <?php else: ?>
                                <span class="badge bg-secondary-subtle text-secondary fw-semibold"><i class="fa-solid fa-user me-1"></i> <?php echo htmlspecialchars($row['target_role_name']); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="mb-4">
                            <span class="text-muted small d-block mb-2">Notice Body:</span>
                            <div class="p-3 bg-light rounded-3 text-secondary" style="white-space: pre-wrap; line-height: 1.6; font-size: 0.95rem; border-left: 4px solid #2563eb;">
                                <?php echo htmlspecialchars($row['content']); ?>
                            </div>
                        </div>

                        <?php if (!empty($row['attachment_path'])): ?>
                            <h6 class="fw-bold text-dark mb-3"><i class="fa fa-paperclip me-2 text-primary"></i>Attachment Attachment</h6>
                            <?php if ($row['attachment_type'] === 'pdf'): ?>
                                <div class="ratio ratio-16x9 border rounded-3 bg-white mb-2 overflow-hidden shadow-sm">
                                    <iframe src="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" frameborder="0"></iframe>
                                </div>
                                <div class="text-center mt-2">
                                    <a href="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" target="_blank" class="btn btn-outline-danger btn-sm fw-bold">
                                        <i class="fa fa-up-right-from-square me-2"></i>Open PDF in New Window
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="text-center border rounded-3 bg-white p-3 shadow-sm">
                                    <img src="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" class="img-fluid rounded-2 max-height-300" style="max-height: 400px; object-fit: contain;">
                                    <div class="mt-3">
                                        <a href="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" target="_blank" class="btn btn-outline-primary btn-sm fw-bold">
                                            <i class="fa fa-download me-2"></i>Download Image
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer border-0 bg-light p-3">
                        <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Image Lightbox Modal if the notice has an image -->
        <?php if (!empty($row['attachment_path']) && $row['attachment_type'] === 'image'): ?>
            <div class="modal fade" id="viewImageModal<?php echo $row['id']; ?>" tabindex="-1" data-bs-backdrop="false" style="background: rgba(15,23,42,0.7); backdrop-filter: blur(10px);">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content border-0 bg-transparent">
                        <div class="text-end mb-2">
                            <button type="button" class="btn-close btn-close-white fs-4" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="text-center">
                            <img src="<?php echo BASE_URL . '/' . htmlspecialchars($row['attachment_path']); ?>" class="img-fluid rounded shadow-lg" style="max-height: 80vh; object-fit: contain;">
                            <div class="text-white mt-3 fw-bold fs-5"><?php echo htmlspecialchars($row['title']); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>

<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 2) {
    redirect(BASE_URL . '/dashboard.php');
}

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['submission_id'])) {
    $submission_id = (int)$_POST['submission_id'];
    $remarks = $_POST['remarks'] ?? '';
    $action = $_POST['action'];

    if ($action === 'Approve') {
        $status = 'Approved';
    } elseif ($action === 'Reject') {
        $status = 'Rejected';
    } else {
        $status = 'Verified';
    }

    try {
        $stmt = $pdo->prepare("UPDATE exam_form_submissions SET status = ?, remarks = CONCAT(COALESCE(remarks, ''), '\nPrin. Remarks: ', ?) WHERE id = ?");
        $stmt->execute([$status, $remarks, $submission_id]);
        $success_msg = "Exam form $status successfully.";
    } catch(Exception $e) {
        $error_msg = "Error processing approval.";
    }
}

// Fetch submissions that are verified by clerk
$submissions = $pdo->query("
    SELECT s.id, s.status, s.form_data, s.remarks, s.submitted_at, s.clerk_id, s.application_sl_no,
           st.student_name, st.admission_no, COALESCE(c.name, st.class_applied) as class_name, e.name as exam_name
    FROM exam_form_submissions s
    JOIN students st ON s.student_id = st.id
    JOIN exams e ON s.exam_id = e.id
    LEFT JOIN classes c ON c.id = COALESCE(NULLIF(st.class_id, 0), (SELECT id FROM classes WHERE name = st.class_applied LIMIT 1))
    ORDER BY CASE s.status WHEN 'Verified' THEN 1 WHEN 'Pending' THEN 2 ELSE 3 END, s.submitted_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php role_page_hero('Final Exam Approvals', 'Approve or reject student exam forms. Forms verified by clerks appear first.', 'fa-gavel'); ?>

    <?php if ($success_msg): ?>
        <div class="alert alert-success"><i class="fa fa-check-circle me-2"></i><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="alert alert-danger"><i class="fa fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
        <div class="card-header bg-white py-3">
            <h2 class="h5 fw-bold mb-0">Exam Form Submissions</h2>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Application Sl No</th>
                        <th>Student</th>
                        <th>Class / Exam</th>
                        <th>Verification</th>
                        <th>Status</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$submissions): ?>
                        <tr><td colspan="6" class="text-center py-4 text-muted">No submissions found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($submissions as $sub): ?>
                            <tr>
                                <td class="ps-4 fw-semibold text-primary"><?php echo htmlspecialchars($sub['application_sl_no'] ?? 'N/A'); ?></td>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo htmlspecialchars($sub['student_name']); ?></div>
                                    <small class="text-muted">Adm No: <?php echo htmlspecialchars($sub['admission_no']); ?></small>
                                </td>
                                <td>
                                    <div class="fw-bold text-secondary"><?php echo htmlspecialchars($sub['exam_name']); ?></div>
                                    <small class="text-muted"><?php echo htmlspecialchars($sub['class_name']); ?></small>
                                </td>
                                <td>
                                    <?php if ($sub['clerk_id']): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle"><i class="fa fa-check-circle me-1"></i> Verified by Clerk</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle"><i class="fa fa-clock me-1"></i> Not Verified</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $badge = 'bg-secondary';
                                    if ($sub['status'] === 'Verified') $badge = 'bg-info text-dark';
                                    if ($sub['status'] === 'Approved') $badge = 'bg-success';
                                    if ($sub['status'] === 'Rejected') $badge = 'bg-danger';
                                    if ($sub['status'] === 'Pending') $badge = 'bg-warning text-dark';
                                    ?>
                                    <span class="badge <?php echo $badge; ?>"><?php echo htmlspecialchars($sub['status']); ?></span>
                                </td>
                                 <td class="text-end pe-4">
                                     <?php if ($sub['status'] === 'Verified' || $sub['status'] === 'Pending'): ?>
                                         <button class="btn btn-sm btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#approveModal<?php echo $sub['id']; ?>"><i class="fa fa-gavel me-1"></i> Process</button>
                                     <?php else: ?>
                                         <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#approveModal<?php echo $sub['id']; ?>"><i class="fa fa-eye me-1"></i> Details</button>
                                     <?php endif; ?>
                                 </td>
                             </tr>
                         <?php endforeach; ?>
                     <?php endif; ?>
                 </tbody>
             </table>
         </div>
     </div>
 </div>

<!-- Modal block shifted OUTSIDE table container to resolve web overflow clipping & backdrop freezes -->
<?php if ($submissions): ?>
    <?php foreach ($submissions as $sub): ?>
        <!-- Approve Modal -->
        <div class="modal fade" id="approveModal<?php echo $sub['id']; ?>" tabindex="-1" data-bs-backdrop="false" style="background: rgba(15,23,42,0.45); backdrop-filter: blur(4px);">
          <div class="modal-dialog modal-lg text-start">
            <form method="POST" class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
              <div class="modal-header border-0 pb-0 bg-light rounded-top p-4">
                <div>
                    <h5 class="modal-title fw-bold text-dark"><i class="fa fa-gavel text-primary me-2"></i>Final Exam Form Approval</h5>
                    <small class="text-muted">Review and provide ultimate approval for this form</small>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body p-4" style="max-height: 75vh; overflow-y: auto;">
                <input type="hidden" name="submission_id" value="<?php echo $sub['id']; ?>">
                
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <span class="text-muted small d-block">Student Name</span>
                        <strong class="text-dark fs-5"><?php echo htmlspecialchars($sub['student_name']); ?></strong>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <span class="text-muted small d-block">Application Serial No</span>
                        <span class="badge bg-primary fs-6 py-2 px-3"><?php echo htmlspecialchars($sub['application_sl_no'] ?? 'N/A'); ?></span>
                    </div>
                </div>

                <div class="alert bg-primary-subtle text-primary border-0 rounded-3 p-3 mb-4">
                    <h6 class="fw-bold mb-2"><i class="fa fa-clipboard-check me-2"></i>Clerk Verification &amp; Remarks</h6>
                    <div class="small">
                        <strong>Clerk Verification Status:</strong> 
                        <?php if ($sub['clerk_id']): ?>
                            <span class="badge bg-success">Verified</span>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark">Pending Clerk Review</span>
                        <?php endif; ?>
                        <br>
                        <strong>Clerk Remarks:</strong> <span class="text-dark font-monospace"><?php echo htmlspecialchars($sub['remarks'] ?? 'No remarks provided.'); ?></span>
                    </div>
                </div>

                <h6 class="fw-bold text-secondary border-bottom pb-2 mb-3"><i class="fa fa-id-card me-2"></i>Full Submitted Biodata</h6>
                <div class="row g-3 mb-4">
                    <?php 
                    $data = json_decode($sub['form_data'], true); 
                    if ($data): 
                        foreach ($data as $k => $v): 
                    ?>
                        <div class="col-md-6 col-lg-4">
                            <small class="text-muted d-block mb-0"><?php echo htmlspecialchars($k); ?></small>
                            <span class="text-dark fw-semibold"><?php echo htmlspecialchars($v ?: 'N/A'); ?></span>
                        </div>
                    <?php 
                        endforeach; 
                    else: 
                    ?>
                        <div class="col-12 text-muted">No details found.</div>
                    <?php endif; ?>
                </div>

                <div class="mb-3 mt-4">
                    <label class="form-label fw-bold text-dark">Principal Final Remarks (Optional)</label>
                    <textarea name="remarks" class="form-control" rows="2" placeholder="e.g. Approved, record matches."></textarea>
                </div>
              </div>
              <div class="modal-footer border-0 bg-light rounded-bottom p-4">
                <?php if ($sub['status'] === 'Verified' || $sub['status'] === 'Pending'): ?>
                    <button type="submit" name="action" value="Reject" class="btn btn-danger px-4 fw-bold">Reject</button>
                    <button type="submit" name="action" value="Approve" class="btn btn-success px-4 fw-bold shadow-sm"><i class="fa fa-check me-2"></i>Approve Final</button>
                <?php else: ?>
                    <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Close</button>
                <?php endif; ?>
              </div>
            </form>
          </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>

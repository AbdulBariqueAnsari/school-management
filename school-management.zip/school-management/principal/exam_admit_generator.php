<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 2) {
    redirect(BASE_URL . '/dashboard.php');
}

$success_msg = '';
$error_msg = '';

$salt = "SECURE_SCHOOL_ERP_SALT_2026_!@#";

// Handle Bulk Generation POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'generate') {
            $memo_no = isset($_POST['memo_no']) ? trim($_POST['memo_no']) : '';
            $academic_year = isset($_POST['academic_year']) ? trim($_POST['academic_year']) : '';
            
            if (empty($memo_no) || empty($academic_year)) {
                $error_msg = "Please select both an Exam Window Memo No and the Academic Year/Session.";
            } else {
                try {
                    // Fetch exam_id and class_id linked to the selected memo_no
                    $stmt_memo = $pdo->prepare("SELECT exam_id, class_id FROM exam_form_settings WHERE memo_no = ?");
                    $stmt_memo->execute([$memo_no]);
                    $memo_data = $stmt_memo->fetch(PDO::FETCH_ASSOC);

                    if (!$memo_data) {
                        $error_msg = "Selected Exam Window Memo No does not exist or has been removed.";
                    } else {
                        $exam_id = (int)$memo_data['exam_id'];
                        $class_id = (int)$memo_data['class_id'];

                        // Fetch the class name and class number to handle all DB representations of students
                        $stmt_class_info = $pdo->prepare("SELECT name FROM classes WHERE id = ?");
                        $stmt_class_info->execute([$class_id]);
                        $class_name_str = $stmt_class_info->fetchColumn() ?: '';
                        
                        // Extract number from class name (e.g. "Class 10" -> "10")
                        $class_number_str = preg_replace('/[^0-9]/', '', $class_name_str);

                        // Fetch all active students matching any format of the selected class
                        $stmt_students = $pdo->prepare("
                            SELECT s.id, u.name as student_name, s.admission_date
                            FROM students s
                            JOIN users u ON s.user_id = u.id
                            WHERE u.is_active = 1 AND (
                                s.class_id = :class_id 
                                OR s.class = :class_id
                                OR s.class_applied = :class_id
                                OR s.class = :class_name
                                OR s.class_applied = :class_name
                                OR (:class_number != '' AND s.class = :class_number)
                                OR (:class_number != '' AND s.class_applied = :class_number)
                            )
                        ");
                        $stmt_students->execute([
                            'class_id' => $class_id,
                            'class_name' => $class_name_str,
                            'class_number' => $class_number_str
                        ]);
                        $students_list = $stmt_students->fetchAll(PDO::FETCH_ASSOC);

                        if (!$students_list) {
                            $error_msg = "No active students found in the target class: " . htmlspecialchars($class_name_str);
                        } else {
                            $generated_count = 0;
                            $skipped_count = 0;
                            $unapplied_count = 0;
                            
                            foreach ($students_list as $st) {
                                $student_id = (int)$st['id'];

                                // Check if student has applied for this exam in exam_form_submissions
                                $stmt_sub = $pdo->prepare("SELECT status FROM exam_form_submissions WHERE student_id = ? AND exam_id = ?");
                                $stmt_sub->execute([$student_id, $exam_id]);
                                $sub_status = $stmt_sub->fetchColumn();

                                if (!$sub_status) {
                                    // Skip students who have not applied for the examination form at all!
                                    $unapplied_count++;
                                    continue;
                                }
                                
                                // Check if admit card already exists for this student & exam
                                $stmt_check = $pdo->prepare("SELECT id FROM exam_admit_cards WHERE student_id = ? AND exam_id = ?");
                                $stmt_check->execute([$student_id, $exam_id]);
                                if ($stmt_check->fetch()) {
                                    $skipped_count++;
                                    continue;
                                }

                                // Generate Roll Number
                                $roll_no = "ROLL-" . date('Y') . "-" . str_pad($student_id, 4, '0', STR_PAD_LEFT);
                                // Generate Unique Admit Card Serial Code
                                $admit_no = "ADM-" . date('Y') . "-" . str_pad($student_id, 3, '0', STR_PAD_LEFT) . "-" . rand(1000, 9999);
                                
                                // Generate SECURE Cryptographic Signature Hash to prevent forging & spoofing
                                $signature_payload = $student_id . '-' . $exam_id . '-' . $class_id . '-' . $admit_no;
                                $security_hash = hash_hmac('sha256', $signature_payload, $salt);

                                // Insert Admit Card with academic_year and memo_no
                                $stmt_ins = $pdo->prepare("
                                    INSERT INTO exam_admit_cards (student_id, exam_id, class_id, academic_year, memo_no, roll_number, admit_card_no, security_hash)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                                ");
                                $stmt_ins->execute([$student_id, $exam_id, $class_id, $academic_year, $memo_no, $roll_no, $admit_no, $security_hash]);
                                $generated_count++;
                            }
                            
                            $success_msg = "Bulk generation complete! Created $generated_count new secure Admit Card(s). " . 
                                ($skipped_count > 0 ? "($skipped_count cards already existed). " : "") .
                                ($unapplied_count > 0 ? "($unapplied_count students skipped because they did not fill out the exam form)." : "");
                        }
                    }
                } catch (Exception $e) {
                    $error_msg = "Generation failed: " . $e->getMessage();
                }
            }
        } elseif ($_POST['action'] === 'delete' && isset($_POST['card_id'])) {
            $card_id = (int)$_POST['card_id'];
            try {
                $stmt = $pdo->prepare("DELETE FROM exam_admit_cards WHERE id = ?");
                $stmt->execute([$card_id]);
                $success_msg = "Admit card revoked successfully.";
            } catch (Exception $e) {
                $error_msg = "Failed to revoke admit card: " . $e->getMessage();
            }
        }
    }
}

// Fetch dynamic Memo list from opened Exam Forms
$memos = $pdo->query("
    SELECT s.memo_no, e.name as exam_name, c.name as class_name, s.exam_id, s.class_id
    FROM exam_form_settings s
    JOIN exams e ON s.exam_id = e.id
    JOIN classes c ON s.class_id = c.id
    ORDER BY s.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch generated admit cards list with matching exam form status
$cards_list = $pdo->query("
    SELECT c.*, u.name as student_name, e.name as exam_name, cl.name as class_name,
           sub.status as form_status
    FROM exam_admit_cards c
    JOIN students s ON c.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN exams e ON c.exam_id = e.id
    JOIN classes cl ON c.class_id = cl.id
    LEFT JOIN exam_form_submissions sub ON (c.student_id = sub.student_id AND c.exam_id = sub.exam_id)
    ORDER BY c.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="main-content">
    <?php role_page_hero('Secure Admit Card Generator', 'Bulk generate and cryptographically seal official admit cards for examinations.', 'fa-id-card'); ?>

    <?php if ($success_msg): ?>
        <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-circle-check me-2"></i><?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Generator Form Column -->
        <div class="col-xl-4">
            <div class="card border-0 shadow-sm" style="border-radius: 16px;">
                <div class="card-header bg-white border-0 pt-4 px-4 pb-2">
                    <h5 class="fw-bold text-dark mb-0"><i class="fa fa-gears text-primary me-2"></i>Generate Bulk Admit Cards</h5>
                    <small class="text-muted">Initiate bulk compilation for an exam window.</small>
                </div>
                <div class="card-body p-4">
                    <div class="alert bg-info-subtle text-info border-0 rounded-3 small p-3 mb-4">
                        <i class="fa fa-shield-halved me-2"></i><strong>Approval Lock Active:</strong> Admit cards are only compiled for students who filled the exam form. Cards will remain locked/pending for students whose forms are not approved.
                    </div>
                    <form method="POST">
                        <input type="hidden" name="action" value="generate">

                        <div class="mb-3">
                            <label class="form-label fw-semibold text-secondary">Select Exam Window Memo</label>
                            <select name="memo_no" class="form-select bg-light" required>
                                <option value="" disabled selected>-- Select Memo (Exam &amp; Class) --</option>
                                <?php foreach ($memos as $m): ?>
                                    <option value="<?php echo htmlspecialchars($m['memo_no']); ?>">
                                        <?php echo htmlspecialchars($m['memo_no']); ?> - <?php echo htmlspecialchars($m['exam_name']); ?> (<?php echo htmlspecialchars($m['class_name']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-semibold text-secondary">Select Session / Year</label>
                            <select name="academic_year" class="form-select bg-light" required>
                                <option value="" disabled selected>-- Select Academic Year --</option>
                                <option value="2025-2026">2025-2026</option>
                                <option value="2026-2027">2026-2027</option>
                                <option value="2027-2028">2027-2028</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 fw-bold shadow-sm" onclick="return confirm('Are you sure you want to generate admit cards for this exam window?');">
                            <i class="fa fa-id-card-clip me-2"></i>Generate &amp; Seal Admit Cards
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Generated List Column -->
        <div class="col-xl-8">
            <div class="card border-0 shadow-sm" style="border-radius: 16px;">
                <div class="card-header bg-white border-0 pt-4 px-4 pb-2">
                    <h5 class="fw-bold text-dark mb-0"><i class="fa fa-clipboard-check text-primary me-2"></i>Sealed Admit Cards Register</h5>
                    <small class="text-muted">Register of cryptographically signed student timetables.</small>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Student Details</th>
                                    <th>Class &amp; Exam</th>
                                    <th>Session &amp; Memo</th>
                                    <th>Admit Card No / Roll</th>
                                    <th>Status (Form)</th>
                                    <th class="text-end pe-4">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$cards_list): ?>
                                    <tr><td colspan="6" class="text-center py-4 text-muted">No admit cards generated yet.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($cards_list as $row): ?>
                                        <?php 
                                        $is_approved = ($row['form_status'] === 'Approved');
                                        $status_badge = $is_approved ? 'bg-success' : 'bg-warning text-dark';
                                        $status_text = $is_approved ? 'Active (Approved)' : 'Pending Form Approval';
                                        ?>
                                        <tr>
                                            <td class="ps-4">
                                                <strong class="text-dark d-block"><?php echo htmlspecialchars($row['student_name']); ?></strong>
                                                <small class="text-muted">ID: <?php echo $row['student_id']; ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-light text-dark border mb-1"><?php echo htmlspecialchars($row['class_name']); ?></span><br>
                                                <small class="text-dark fw-semibold"><?php echo htmlspecialchars($row['exam_name']); ?></small>
                                            </td>
                                            <td>
                                                <strong class="text-secondary small d-block">Session: <?php echo htmlspecialchars($row['academic_year'] ?: 'N/A'); ?></strong>
                                                <code class="text-indigo small">Memo: <?php echo htmlspecialchars($row['memo_no'] ?: 'N/A'); ?></code>
                                            </td>
                                            <td>
                                                <strong class="text-primary"><?php echo htmlspecialchars($row['admit_card_no']); ?></strong><br>
                                                <small class="text-muted">Roll: <?php echo htmlspecialchars($row['roll_number']); ?></small>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo $status_badge; ?>"><?php echo $status_text; ?></span>
                                            </td>
                                            <td class="text-end pe-4">
                                                <?php if ($is_approved): ?>
                                                    <a href="../student/download-admit-pdf.php?id=<?php echo $row['id']; ?>&hash=<?php echo $row['security_hash']; ?>" target="_blank" class="btn btn-sm btn-outline-info me-1" title="View PDF"><i class="fa fa-file-pdf"></i></a>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-outline-secondary me-1" disabled title="Form Pending Verification"><i class="fa fa-lock"></i></button>
                                                <?php endif; ?>
                                                <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to revoke this admit card?');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="card_id" value="<?php echo $row['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-danger" title="Revoke Admit Card"><i class="fa fa-trash-can"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

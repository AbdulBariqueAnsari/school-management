<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 2) {
    redirect(BASE_URL . '/dashboard.php');
}

$success_msg = '';
$error_msg = '';

// Handle POST actions for approval or rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $exam_id = (int)($_POST['exam_id'] ?? 0);
    $class_id = (int)($_POST['class_id'] ?? 0);
    $subject_id = (int)($_POST['subject_id'] ?? 0);
    $action = $_POST['action']; // 'Approve' or 'Reject'
    $remarks = trim($_POST['remarks'] ?? '');

    if (!$exam_id || !$class_id || !$subject_id) {
        $error_msg = "Invalid parameters for exam results processing.";
    } else {
        try {
            if ($action === 'Approve') {
                $stmt = $pdo->prepare("
                    UPDATE exam_results 
                    SET status = 'Approved' 
                    WHERE exam_id = ? AND class_id = ? AND subject_id = ?
                ");
                $stmt->execute([$exam_id, $class_id, $subject_id]);

                // Auto Notice publishing
                try {
                    $stmt_info = $pdo->prepare("
                        SELECT e.name as exam_name, c.name as class_name, s.name as subject_name 
                        FROM exams e, classes c, subjects s 
                        WHERE e.id = ? AND c.id = ? AND s.id = ?
                    ");
                    $stmt_info->execute([$exam_id, $class_id, $subject_id]);
                    $info = $stmt_info->fetch(PDO::FETCH_ASSOC);
                    
                    if ($info) {
                        $notice_title = "Official Results Released: " . $info['exam_name'] . " (" . $info['class_name'] . ")";
                        $notice_content = "We are pleased to announce that the official examination results for target subject: \"" . $info['subject_name'] . "\" under \"" . $info['exam_name'] . "\" have been officially verified, approved, and published by the Principal. \n\nStudents in " . $info['class_name'] . " are hereby advised to log into their Student Portal to view and print their updated digital scorecards.";
                        
                        $stmt_not = $pdo->prepare("
                            INSERT INTO announcements (title, content, target_role_id, created_by, attachment_path, attachment_type)
                            VALUES (?, ?, 6, ?, NULL, NULL)
                        ");
                        $stmt_not->execute([$notice_title, $notice_content, $_SESSION['user_id']]);
                    }
                } catch (Exception $e_notice) {
                    // Fail silently so it doesn't interrupt flow
                }

                $success_msg = "Marksheet successfully approved and published! Students can now view their scorecards.";
            } elseif ($action === 'Reject') {
                $stmt = $pdo->prepare("
                    UPDATE exam_results 
                    SET status = 'Draft', remarks = ? 
                    WHERE exam_id = ? AND class_id = ? AND subject_id = ?
                ");
                $stmt->execute([$remarks ?: 'Returned by Principal for review.', $exam_id, $class_id, $subject_id]);
                $success_msg = "Marksheet successfully rejected and returned to the compilation teacher for revision.";
            }
        } catch (Exception $e) {
            $error_msg = "Database error: " . $e->getMessage();
        }
    }
}

// Fetch filters from GET parameters
$filter_exam = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;
$filter_class = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$filter_subject = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;
$filter_status = isset($_GET['status']) ? trim($_GET['status']) : '';

// Fetch dynamic dropdowns for filtering
$exams = $pdo->query("SELECT id, name FROM exams ORDER BY start_date DESC")->fetchAll(PDO::FETCH_ASSOC);
$classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$subjects = $pdo->query("SELECT id, name FROM subjects ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Compile filters WHERE clause
$where_clauses = [];
$params = [];

if ($filter_exam) {
    $where_clauses[] = "r.exam_id = ?";
    $params[] = $filter_exam;
}
if ($filter_class) {
    $where_clauses[] = "r.class_id = ?";
    $params[] = $filter_class;
}
if ($filter_subject) {
    $where_clauses[] = "r.subject_id = ?";
    $params[] = $filter_subject;
}
if ($filter_status !== '') {
    $where_clauses[] = "r.status = ?";
    $params[] = $filter_status;
}

$where_sql = $where_clauses ? "WHERE " . implode(" AND ", $where_clauses) : "";

// Fetch aggregated exam marksheets list (grouped by exam, class, subject, status, teacher)
$query = "
    SELECT r.exam_id, r.class_id, r.subject_id, r.status, r.teacher_id,
           e.name as exam_name, c.name as class_name, sub.name as subject_name, u.name as teacher_name,
           COUNT(r.id) as total_students,
           SUM(r.is_absent) as total_absent,
           SUM(CASE WHEN r.is_absent = 0 AND r.marks_obtained >= r.passing_marks THEN 1 ELSE 0 END) as total_passed,
           SUM(CASE WHEN r.is_absent = 0 AND r.marks_obtained < r.passing_marks THEN 1 ELSE 0 END) as total_failed
    FROM exam_results r
    JOIN exams e ON r.exam_id = e.id
    JOIN classes c ON r.class_id = c.id
    JOIN subjects sub ON r.subject_id = sub.id
    JOIN users u ON r.teacher_id = u.id
    $where_sql
    GROUP BY r.exam_id, r.class_id, r.subject_id, r.status, r.teacher_id
    ORDER BY CASE r.status WHEN 'Submitted' THEN 1 WHEN 'Draft' THEN 2 ELSE 3 END, e.name ASC, c.name ASC
";
$stmt_compiled = $pdo->prepare($query);
$stmt_compiled->execute($params);
$marksheets = $stmt_compiled->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php role_page_hero('Final Exam Results Approvals', 'Review exam marks compiled by teachers, enforce thresholds, and authorize publishing.', 'fa-clipboard-check'); ?>

    <?php if ($success_msg): ?>
        <div class="alert alert-success border-0 shadow-sm"><i class="fa fa-circle-check me-2"></i><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="alert alert-danger border-0 shadow-sm"><i class="fa fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>

    <!-- Comprehensive Filter Panel -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 16px;">
        <div class="card-body p-4">
            <h5 class="fw-bold mb-3 text-secondary"><i class="fa fa-filter me-2"></i>Search and Filter Results Sheets</h5>
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label small fw-semibold text-muted">Examination</label>
                    <select name="exam_id" class="form-select bg-light">
                        <option value="">-- All Exams --</option>
                        <?php foreach ($exams as $e): ?>
                            <option value="<?php echo $e['id']; ?>" <?php echo ($filter_exam == $e['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($e['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-semibold text-muted">Class</label>
                    <select name="class_id" class="form-select bg-light">
                        <option value="">-- All Classes --</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?php echo $c['id']; ?>" <?php echo ($filter_class == $c['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label small fw-semibold text-muted">Subject</label>
                    <select name="subject_id" class="form-select bg-light">
                        <option value="">-- All Subjects --</option>
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?php echo $s['id']; ?>" <?php echo ($filter_subject == $s['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($s['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label small fw-semibold text-muted">Status</label>
                    <select name="status" class="form-select bg-light">
                        <option value="">-- All Status --</option>
                        <option value="Draft" <?php echo ($filter_status === 'Draft') ? 'selected' : ''; ?>>Draft</option>
                        <option value="Submitted" <?php echo ($filter_status === 'Submitted') ? 'selected' : ''; ?>>Submitted (Pending Approval)</option>
                        <option value="Approved" <?php echo ($filter_status === 'Approved') ? 'selected' : ''; ?>>Approved (Published)</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100 fw-bold"><i class="fa fa-magnifying-glass me-2"></i>Filter</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Grouped Marksheets Table -->
    <div class="card border-0 shadow-sm" style="border-radius: 16px; overflow: hidden;">
        <div class="card-header bg-white py-3 border-0 px-4">
            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-list me-2"></i>Compiled Result Sheets Queue</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Examination</th>
                        <th>Class &amp; Subject</th>
                        <th>Compiled By</th>
                        <th class="text-center">Students (Pass/Fail)</th>
                        <th class="text-center">Absent Count</th>
                        <th>Approval Status</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$marksheets): ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">No marks sheets found matching filter criteria.</td></tr>
                    <?php else: ?>
                        <?php foreach ($marksheets as $sheet): ?>
                            <tr>
                                <td class="ps-4">
                                    <strong class="text-dark d-block"><?php echo htmlspecialchars($sheet['exam_name']); ?></strong>
                                </td>
                                <td>
                                    <strong class="text-secondary"><?php echo htmlspecialchars($sheet['class_name']); ?></strong>
                                    <div class="small text-muted"><?php echo htmlspecialchars($sheet['subject_name']); ?></div>
                                </td>
                                <td>
                                    <div class="fw-semibold text-dark"><?php echo htmlspecialchars($sheet['teacher_name']); ?></div>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-light text-dark border"><?php echo $sheet['total_students']; ?> Total</span>
                                    <span class="badge bg-success-subtle text-success ms-1"><?php echo $sheet['total_passed']; ?> Passed</span>
                                    <span class="badge bg-danger-subtle text-danger ms-1"><?php echo $sheet['total_failed']; ?> Failed</span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-warning-subtle text-warning fw-bold"><?php echo $sheet['total_absent']; ?> Absent</span>
                                </td>
                                <td>
                                    <?php
                                    $badge = 'bg-secondary';
                                    if ($sheet['status'] === 'Draft') $badge = 'bg-light text-muted border';
                                    if ($sheet['status'] === 'Submitted') $badge = 'bg-warning text-dark';
                                    if ($sheet['status'] === 'Approved') $badge = 'bg-success';
                                    ?>
                                    <span class="badge <?php echo $badge; ?>">
                                        <?php echo ($sheet['status'] === 'Submitted') ? 'Submitted (Pending Approval)' : htmlspecialchars($sheet['status']); ?>
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <button class="btn btn-sm <?php echo ($sheet['status'] === 'Submitted') ? 'btn-primary shadow-sm' : 'btn-outline-secondary'; ?>" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#reviewModal_<?php echo $sheet['exam_id'].'_'.$sheet['class_id'].'_'.$sheet['subject_id']; ?>">
                                        <i class="fa <?php echo ($sheet['status'] === 'Submitted') ? 'fa-gavel' : 'fa-eye'; ?> me-1"></i>
                                        <?php echo ($sheet['status'] === 'Submitted') ? 'Process Review' : 'View sheet'; ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Dialogs Shipped Safely Outside Layout Conts -->
<?php if ($marksheets): ?>
    <?php foreach ($marksheets as $sheet): ?>
        <?php
        // Fetch detailed results for this specific exam, class, subject
        $stmt_details = $pdo->prepare("
            SELECT r.*, u.name as student_name, s.admission_no
            FROM exam_results r
            JOIN students s ON r.student_id = s.id
            JOIN users u ON s.user_id = u.id
            WHERE r.exam_id = ? AND r.class_id = ? AND r.subject_id = ?
            ORDER BY u.name ASC
        ");
        $stmt_details->execute([$sheet['exam_id'], $sheet['class_id'], $sheet['subject_id']]);
        $details = $stmt_details->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <div class="modal fade" id="reviewModal_<?php echo $sheet['exam_id'].'_'.$sheet['class_id'].'_'.$sheet['subject_id']; ?>" tabindex="-1" data-bs-backdrop="false" style="background: rgba(15,23,42,0.45); backdrop-filter: blur(4px);">
            <div class="modal-dialog modal-xl text-start">
                <form method="POST" class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
                    <input type="hidden" name="exam_id" value="<?php echo $sheet['exam_id']; ?>">
                    <input type="hidden" name="class_id" value="<?php echo $sheet['class_id']; ?>">
                    <input type="hidden" name="subject_id" value="<?php echo $sheet['subject_id']; ?>">

                    <div class="modal-header border-0 pb-0 bg-light rounded-top p-4">
                        <div>
                            <h5 class="modal-title fw-bold text-dark"><i class="fa fa-clipboard-check text-primary me-2"></i>Review Marksheet Details</h5>
                            <small class="text-muted">Compiled by: <?php echo htmlspecialchars($sheet['teacher_name']); ?></small>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body p-4" style="max-height: 70vh; overflow-y: auto;">
                        <!-- Information Banner -->
                        <div class="row g-3 mb-4">
                            <div class="col-md-3">
                                <small class="text-muted d-block">Examination Name</small>
                                <strong class="text-dark"><?php echo htmlspecialchars($sheet['exam_name']); ?></strong>
                            </div>
                            <div class="col-md-3">
                                <small class="text-muted d-block">Class</small>
                                <strong class="text-dark"><?php echo htmlspecialchars($sheet['class_name']); ?></strong>
                            </div>
                            <div class="col-md-3">
                                <small class="text-muted d-block">Subject</small>
                                <strong class="text-dark"><?php echo htmlspecialchars($sheet['subject_name']); ?></strong>
                            </div>
                            <div class="col-md-3 text-md-end">
                                <small class="text-muted d-block">Overall Sheet Status</small>
                                <span class="badge <?php echo ($sheet['status'] === 'Approved') ? 'bg-success' : 'bg-warning text-dark'; ?> fs-6">
                                    <?php echo htmlspecialchars($sheet['status']); ?>
                                </span>
                            </div>
                        </div>

                        <!-- Candidates Sheet Grid -->
                        <div class="table-responsive border rounded-3 mb-4">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-3">Student Name / Adm No</th>
                                        <th class="text-center">Absence Status</th>
                                        <th class="text-center">Obtained / Total Marks</th>
                                        <th class="text-center">Passing Marks</th>
                                        <th class="text-center">Result Outcome</th>
                                        <th class="pe-3">Remarks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($details as $det): ?>
                                        <?php 
                                        $is_fail = (!$det['is_absent'] && $det['marks_obtained'] < $det['passing_marks']);
                                        ?>
                                        <tr>
                                            <td class="ps-3">
                                                <strong class="text-dark d-block"><?php echo htmlspecialchars($det['student_name']); ?></strong>
                                                <small class="text-muted">Adm: <?php echo htmlspecialchars($det['admission_no']); ?></small>
                                            </td>
                                            <td class="text-center">
                                                <?php if ($det['is_absent']): ?>
                                                    <span class="badge bg-danger-subtle text-danger"><i class="fa fa-circle-exclamation me-1"></i> ABSENT</span>
                                                <?php else: ?>
                                                    <span class="badge bg-success-subtle text-success">Present</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if ($det['is_absent']): ?>
                                                    <span class="text-muted">-- / <?php echo (float)$det['marks_total']; ?></span>
                                                <?php else: ?>
                                                    <strong class="<?php echo $is_fail ? 'text-danger fw-bold' : 'text-primary'; ?>">
                                                        <?php echo (float)$det['marks_obtained']; ?>
                                                    </strong> 
                                                    <span class="text-muted">/ <?php echo (float)$det['marks_total']; ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <span class="text-muted fw-semibold"><?php echo (float)$det['passing_marks']; ?></span>
                                            </td>
                                            <td class="text-center">
                                                <?php if ($det['is_absent']): ?>
                                                    <span class="badge bg-warning-subtle text-warning">ABSENT IN RESULT</span>
                                                <?php elseif ($is_fail): ?>
                                                    <span class="badge bg-danger-subtle text-danger"><i class="fa fa-circle-xmark me-1"></i> FAILED</span>
                                                <?php else: ?>
                                                    <span class="badge bg-success-subtle text-success"><i class="fa fa-circle-check me-1"></i> PASSED</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="pe-3 text-muted small"><?php echo htmlspecialchars($det['remarks'] ?: 'No notes'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Action Remarks Block -->
                        <?php if ($sheet['status'] === 'Submitted'): ?>
                            <div class="mb-3">
                                <label class="form-label fw-bold text-dark">Principal Review Remarks (Optional)</label>
                                <textarea name="remarks" class="form-control" rows="2" placeholder="Provide notes if rejecting/returning this marksheet back to the teacher..."></textarea>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="modal-footer border-0 bg-light rounded-bottom p-4">
                        <?php if ($sheet['status'] === 'Submitted'): ?>
                            <button type="submit" name="action" value="Reject" class="btn btn-danger px-4 fw-bold">Reject &amp; Roll Back</button>
                            <button type="submit" name="action" value="Approve" class="btn btn-success px-4 fw-bold shadow-sm"><i class="fa fa-check me-2"></i>Approve &amp; Publish</button>
                        <?php else: ?>
                            <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Close</button>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>

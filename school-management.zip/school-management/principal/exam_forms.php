<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if ($_SESSION['role_id'] != 2) {
    redirect(BASE_URL . '/dashboard.php');
}

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $setting_id = (int)($_POST['setting_id'] ?? 0);
        if ($setting_id) {
            try {
                $stmt = $pdo->prepare("DELETE FROM exam_form_settings WHERE id = ?");
                $stmt->execute([$setting_id]);
                $success_msg = "Exam form window removed successfully.";
            } catch (Exception $e) {
                $error_msg = "Database error: " . $e->getMessage();
            }
        } else {
            $error_msg = "Invalid settings ID.";
        }
    } else {
        $exam_id = (int)($_POST['exam_id'] ?? 0);
        $class_id = (int)($_POST['class_id'] ?? 0);
        $is_open = isset($_POST['is_open']) ? 1 : 0;
        $fee_amount = (float)($_POST['fee_amount'] ?? 0);
        $deadline = $_POST['deadline'] ?? null;

        if ($exam_id && $class_id) {
            try {
                // Check if setting already exists
                $stmt_check = $pdo->prepare("SELECT id, memo_no FROM exam_form_settings WHERE exam_id = ? AND class_id = ?");
                $stmt_check->execute([$exam_id, $class_id]);
                $existing = $stmt_check->fetch(PDO::FETCH_ASSOC);
                
                if ($existing) {
                    $memo_no = $existing['memo_no'];
                    if (empty($memo_no)) {
                        $memo_no = "MEMO/EXAM/" . date('Y') . "/" . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
                    }
                    $stmt = $pdo->prepare("
                        UPDATE exam_form_settings 
                        SET is_open = ?, fee_amount = ?, deadline = ?, memo_no = ?
                        WHERE exam_id = ? AND class_id = ?
                    ");
                    $stmt->execute([$is_open, $fee_amount, $deadline, $memo_no, $exam_id, $class_id]);
                } else {
                    $memo_no = "MEMO/EXAM/" . date('Y') . "/" . str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
                    $stmt = $pdo->prepare("
                        INSERT INTO exam_form_settings (exam_id, class_id, is_open, fee_amount, deadline, memo_no)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$exam_id, $class_id, $is_open, $fee_amount, $deadline, $memo_no]);
                }

                // Add automatic notice if opened
                if ($is_open) {
                    $exam_name = $pdo->query("SELECT name FROM exams WHERE id = " . $exam_id)->fetchColumn();
                    $class_name = $pdo->query("SELECT name FROM classes WHERE id = " . $class_id)->fetchColumn();
                    
                    $title_text = "Exam Form Fill-up: " . $exam_name . " (" . $class_name . ")";
                    
                    $check_notice = $pdo->prepare("SELECT id FROM announcements WHERE title = ? AND created_by = ?");
                    $check_notice->execute([$title_text, $_SESSION['user_id']]);
                    if (!$check_notice->fetch()) {
                        $content_text = "Dear students of " . $class_name . ",\n\nThe exam form fill-up window for " . $exam_name . " is now open under Memo No: " . $memo_no . ". The form fee is ₹" . number_format($fee_amount, 2) . ". Please submit the application form through your dashboard before the deadline: " . ($deadline ? date('d M Y', strtotime($deadline)) : 'N/A') . ".";
                        
                        $ins_notice = $pdo->prepare("INSERT INTO announcements (title, content, target_role_id, created_by) VALUES (?, ?, 6, ?)");
                        $ins_notice->execute([$title_text, $content_text, $_SESSION['user_id']]);
                    }
                }

                $success_msg = "Exam form settings updated successfully with Memo No: " . $memo_no;
            } catch (Exception $e) {
                $error_msg = "Database error: " . $e->getMessage();
            }
        } else {
            $error_msg = "Please select an Exam and a Class.";
        }
    }
}

// Fetch all classes and exams for the dropdowns
$classes = $pdo->query("SELECT id, name FROM classes ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$exams = $pdo->query("SELECT id, name FROM exams ORDER BY start_date DESC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch current active/inactive form settings
$settings = $pdo->query("
    SELECT s.id, e.name as exam_name, c.name as class_name, s.is_open, s.fee_amount, s.deadline, s.memo_no
    FROM exam_form_settings s
    JOIN exams e ON s.exam_id = e.id
    JOIN classes c ON s.class_id = c.id
    ORDER BY s.deadline DESC, e.start_date DESC
")->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php role_page_hero('Exam Forms Manager', 'Open or close exam fill-up windows for students based on their class.', 'fa-clipboard-list'); ?>

    <?php if ($success_msg): ?>
        <div class="alert alert-success"><i class="fa fa-check-circle me-2"></i><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="alert alert-danger"><i class="fa fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Add/Edit Settings Form -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3">
                    <h2 class="h5 fw-bold mb-0">Configure Exam Form</h2>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Select Exam</label>
                            <select name="exam_id" class="form-select" required>
                                <option value="">-- Choose Exam --</option>
                                <?php foreach ($exams as $exam): ?>
                                    <option value="<?php echo $exam['id']; ?>"><?php echo htmlspecialchars($exam['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Select Class</label>
                            <select name="class_id" class="form-select" required>
                                <option value="">-- Choose Class --</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?php echo $class['id']; ?>"><?php echo htmlspecialchars($class['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Form Fee (₹)</label>
                            <input type="number" step="0.01" name="fee_amount" class="form-control" placeholder="0.00" value="0.00" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Deadline Date</label>
                            <input type="date" name="deadline" class="form-control" required>
                        </div>
                        <div class="mb-3 form-check form-switch mt-4">
                            <input class="form-check-input" type="checkbox" role="switch" id="isOpenSwitch" name="is_open" checked>
                            <label class="form-check-label fw-bold" for="isOpenSwitch">Enable Form Fillup</label>
                            <div class="form-text">If enabled, students in this class will see the form in their portal.</div>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 fw-bold mt-2"><i class="fa fa-save me-2"></i> Save Settings</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Current Form Settings List -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3">
                    <h2 class="h5 fw-bold mb-0">Active / Inactive Exam Windows</h2>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Memo No</th>
                                <th>Exam Name</th>
                                <th>Class</th>
                                <th>Fee</th>
                                <th>Deadline</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$settings): ?>
                                <tr><td colspan="7" class="text-center py-4 text-muted">No exam form windows configured yet.</td></tr>
                            <?php else: ?>
                                <?php foreach ($settings as $row): ?>
                                    <tr>
                                        <td class="ps-4 text-muted small fw-semibold"><?php echo htmlspecialchars($row['memo_no'] ?? 'N/A'); ?></td>
                                        <td class="fw-semibold text-primary"><?php echo htmlspecialchars($row['exam_name']); ?></td>
                                        <td class="fw-bold"><?php echo htmlspecialchars($row['class_name']); ?></td>
                                        <td>₹<?php echo number_format($row['fee_amount'], 2); ?></td>
                                        <td class="<?php echo (!empty($row['deadline']) && strtotime($row['deadline']) < time()) ? 'text-danger' : 'text-success'; ?>">
                                            <?php echo !empty($row['deadline']) ? date('d M Y', strtotime($row['deadline'])) : 'N/A'; ?>
                                        </td>
                                        <td>
                                            <?php if ($row['is_open']): ?>
                                                <span class="badge bg-success"><i class="fa fa-door-open me-1"></i> Open</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><i class="fa fa-door-closed me-1"></i> Closed</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end pe-4">
                                            <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to remove this exam form window? Students will no longer be able to apply.');">
                                                <input type="hidden" name="setting_id" value="<?php echo $row['id']; ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Remove Window">
                                                    <i class="fa fa-trash-alt me-1"></i> Remove
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

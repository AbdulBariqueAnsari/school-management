<?php
// principal/footer.php
// Premium footer for Principal with mobile responsive toggle scripts
?>
        </div> <!-- End Main Content -->
    </div> <!-- End d-flex wrapper -->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <?php if (file_exists(BASE_PATH . '/assets/js/scripts.js')): ?>
        <script src="<?php echo BASE_URL; ?>/assets/js/scripts.js"></script>
    <?php endif; ?>

    <style>
        @keyframes gradientWave {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            margin: 0;
        }

        body > div.d-flex {
            flex: 1;
        }

        .modern-footer {
            width: 100%;
            margin-top: auto;
            background: linear-gradient(135deg, #1e1b4b, #312e81, #1e1b4b);
            background-size: 400% 400%;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .footer-content {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 14px 20px;
            color: #c7d2fe;
            font-family: 'Segoe UI', Roboto, sans-serif;
            font-weight: 600;
            font-size: 14px;
        }

        .webnoor-link {
            color: #818cf8;
            font-weight: 700;
            margin-left: 5px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .webnoor-link:hover {
            color: #a5b4fc;
            text-shadow: 0 0 8px rgba(129, 140, 248, 0.6);
        }

        @media (max-width: 768px) {
            .footer-content {
                font-size: 12px;
                padding: 10px;
            }
        }
    </style>
    
    <footer class="modern-footer no-print">
        <div class="footer-content">
            Principal Portal &copy; <?php echo date('Y'); ?> | Designed by 
            <a href="https://webnoor.in" target="_blank" class="webnoor-link">
                WebNoor
            </a>
        </div>
    </footer>

    <script>
        // Clock implementation
        function updateClock() {
            const now = new Date();
            const options = { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
            const clockEl = document.getElementById('liveClock');
            if(clockEl) {
                clockEl.textContent = now.toLocaleDateString('en-US', options);
            }
        }
        setInterval(updateClock, 1000);
        updateClock();

        // Responsive sidebar logic
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggle = document.getElementById('sidebarToggle');
            const sidebar = document.getElementById('sidebar');
            
            let overlay = document.querySelector('.sidebar-overlay');
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.className = 'sidebar-overlay';
                document.body.appendChild(overlay);
            }
            
            if (sidebarToggle && sidebar) {
                sidebarToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (window.innerWidth < 992) {
                        sidebar.classList.toggle('show-mobile-sidebar');
                        overlay.classList.toggle('show');
                    } else {
                        sidebar.classList.toggle('sidebar-collapsed');
                    }
                });
                
                overlay.addEventListener('click', function() {
                    sidebar.classList.remove('show-mobile-sidebar');
                    overlay.classList.remove('show');
                });
            }
        });
    </script>
</body>
</html>

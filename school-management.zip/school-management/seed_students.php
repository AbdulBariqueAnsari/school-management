<?php
require_once 'config/db.php';
require_once 'config/database_init.php';

echo "Cleaning up databases...\n";
// Clear students and admission_requests
$pdo->exec("SET FOREIGN_KEY_CHECKS=0; TRUNCATE TABLE students; TRUNCATE TABLE admission_requests; SET FOREIGN_KEY_CHECKS=1;");

$records = [
    // 5 Pending
    ['name' => 'Michael Scott', 'gender' => 'Male', 'class' => '1', 'parent' => 'Marnie Scott', 'status' => 'Pending'],
    ['name' => 'Pam Beesly', 'gender' => 'Female', 'class' => '2', 'parent' => 'William Beesly', 'status' => 'Pending'],
    ['name' => 'Jim Halpert', 'gender' => 'Male', 'class' => '3', 'parent' => 'Gerald Halpert', 'status' => 'Pending'],
    ['name' => 'Dwight Schrute', 'gender' => 'Male', 'class' => '4', 'parent' => 'Ira Schrute', 'status' => 'Pending'],
    ['name' => 'Angela Martin', 'gender' => 'Female', 'class' => '5', 'parent' => 'Charles Martin', 'status' => 'Pending'],
    // 5 Approved
    ['name' => 'Stanley Hudson', 'gender' => 'Male', 'class' => '6', 'parent' => 'Cynthia Hudson', 'status' => 'Approved'],
    ['name' => 'Phyllis Vance', 'gender' => 'Female', 'class' => '7', 'parent' => 'Bob Vance', 'status' => 'Approved'],
    ['name' => 'Kevin Malone', 'gender' => 'Male', 'class' => '8', 'parent' => 'Stacy Malone', 'status' => 'Approved'],
    ['name' => 'Oscar Martinez', 'gender' => 'Male', 'class' => '9', 'parent' => 'Gil Martinez', 'status' => 'Approved'],
    ['name' => 'Kelly Kapoor', 'gender' => 'Female', 'class' => '10', 'parent' => 'Ravi Kapoor', 'status' => 'Approved']
];

$password = password_hash('password123', PASSWORD_DEFAULT);
$credentials = "\n\n## Demo Login Credentials (Updated)\n\n| Student Name | Username/Email | Password | Status | Class |\n|---|---|---|---|---|\n";

foreach ($records as $index => $r) {
    // Generate full data to ensure no blank fields as requested
    $email = strtolower(explode(' ', $r['name'])[0]) . rand(10, 99) . '@school.com';
    $parent_email = strtolower(explode(' ', $r['parent'])[0]) . rand(10, 99) . '@parent.com';
    $phone = '9876543' . str_pad($index, 3, '0', STR_PAD_LEFT);
    $dob = date('Y-m-d', strtotime('-' . (5 + $index) . ' years'));
    $address = 'Dunder Mifflin Lane, Scranton PA 18504';
    $guardian = $r['parent'] . ' (Primary Guardian)';

    $admission_no = ($r['status'] === 'Approved') ? 'ADM-' . date('Y') . '-' . str_pad($index + 1, 4, '0', STR_PAD_LEFT) : null;
    $admission_date = ($r['status'] === 'Approved') ? date('Y-m-d') : null;

    // Full insert into unified students table
    $stmt = $pdo->prepare("INSERT INTO students (
        admission_no, student_name, gender, dob, class_applied, 
        father_name, mother_name, parent_email, parent_phone, 
        student_photo, status, created_at, address, guardian_details, class, admission_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?)");

    $stmt->execute([
        $admission_no,
        $r['name'],
        $r['gender'],
        $dob,
        $r['class'],
        $r['parent'], // father
        $r['parent'] . ' Mother', // mother
        $parent_email,
        $phone,
        'default_student.png',
        $r['status'],
        $address,
        $guardian,
        $r['class'], // class (same as class_applied for simplicity)
        $admission_date
    ]);

    // Create user account for all (or just approved, user requested user id and passwords, so let's do all or approved)
    // The user instruction: "Add user id and password also and update the readme file"
    $stmt_user = $pdo->prepare("INSERT INTO users (name, email, password, role_id, is_active) VALUES (?, ?, ?, 6, 1)");
    $stmt_user->execute([$r['name'], $email, $password]);
    $user_id = $pdo->lastInsertId();

    $credentials .= "| {$r['name']} | {$email} | password123 | {$r['status']} | {$r['class']} |\n";
}

// Update README
file_put_contents('README.md', $credentials, FILE_APPEND);
echo "10 fully populated students generated (5 Approved, 5 Pending). Credentials added to README.md.\n";
?>

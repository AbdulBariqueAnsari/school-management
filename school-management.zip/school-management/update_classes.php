<?php
require 'includes/init.php';

try {
    $classes = [
        'Pre-Nursery', 'Nursery', 'LKG', 'UKG',
        'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5', 'Class 6',
        'Class 7', 'Class 8', 'Class 9', 'Class 10', 'Class 11', 'Class 12'
    ];

    $stmt = $pdo->prepare("SELECT name FROM classes");
    $stmt->execute();
    $existing = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $insert = $pdo->prepare("INSERT INTO classes (name) VALUES (?)");

    foreach ($classes as $cName) {
        if (!in_array($cName, $existing)) {
            $insert->execute([$cName]);
        }
    }

    echo "Classes updated successfully!";
}
catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

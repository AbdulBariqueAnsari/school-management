<?php
require 'config/db.php';
$stmt = $pdo->query("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 10");
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Recent Audit Logs:\n";
print_r($logs);

$count = $pdo->query("SELECT COUNT(*) FROM audit_logs")->fetchColumn();
echo "Total logs: $count\n";

<?php
require_once 'includes/init.php';

// If already logged in, redirect them
if (isLoggedIn()) {
    redirect(BASE_URL . '/dashboard.php');
}

$token = $_GET['token'] ?? '';
$type = $_GET['type'] ?? 'staff';
$loginUrl = ($type == 'student') ? 'student/login.php' : 'login.php';

$message = '';
$messageType = '';
$validToken = false;
$userId = null;

if (empty($token)) {
    $message = "Invalid or missing password reset token.";
    $messageType = "danger";
} else {
    // Validate token
    $stmt = $pdo->prepare("SELECT id, reset_expires FROM users WHERE reset_token = ?");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if ($user) {
        if (strtotime($user['reset_expires']) > time()) {
            $validToken = true;
            $userId = $user['id'];
        } else {
            $message = "This password reset link has expired. Please request a new one.";
            $messageType = "danger";
        }
    } else {
        $message = "Invalid password reset token.";
        $messageType = "danger";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $validToken) {
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (empty($newPassword) || empty($confirmPassword)) {
        $message = "Please fill in all fields.";
        $messageType = "warning";
    } elseif ($newPassword !== $confirmPassword) {
        $message = "Passwords do not match.";
        $messageType = "warning";
    } elseif (strlen($newPassword) < 6) {
        $message = "Password must be at least 6 characters long.";
        $messageType = "warning";
    } else {
        $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
        
        $updateStmt = $pdo->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?");
        if ($updateStmt->execute([$newHash, $userId])) {
            $message = "Your password has been successfully updated!";
            $messageType = "success";
            $validToken = false; // Hide form
        } else {
            $message = "Failed to update password. Please try again later.";
            $messageType = "danger";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Exemplar School Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); 
            display: flex; align-items: center; justify-content: center; 
            min-height: 100vh; margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-wrapper { width: 100%; max-width: 420px; padding: 15px; }
        .login-card { 
            padding: 40px 30px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); 
            background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.5);
        }
        .form-floating .form-control { border-radius: 10px; border: 1px solid #ced4da; transition: all 0.3s; }
        .form-floating .form-control:focus { box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.15); border-color: #80bdff; }
        .btn-login {
            border-radius: 10px; padding: 12px; font-weight: 600; letter-spacing: 0.5px;
            background: linear-gradient(to right, #0052D4, #4364F7, #6FB1FC); border: none;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 123, 255, 0.4); }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-card">
            <div class="text-center mb-4">
                <i class="fa fa-key fa-4x text-primary mb-3"></i>
                <h4 class="fw-bold" style="color: #2c3e50;">Set New Password</h4>
                <?php if ($validToken): ?>
                    <p class="text-muted small">Please enter your new password below.</p>
                <?php endif; ?>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?> py-2 shadow-sm text-center" style="font-size:0.9em;">
                    <i class="fa <?php echo $messageType == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> me-1"></i> <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if ($validToken): ?>
                <form method="POST" action="">
                    <div class="form-floating mb-3">
                        <input type="password" name="new_password" class="form-control" id="floatingNewPassword" placeholder="New Password" required>
                        <label for="floatingNewPassword"><i class="fa fa-lock text-muted me-2"></i>New Password</label>
                    </div>
                    <div class="form-floating mb-4">
                        <input type="password" name="confirm_password" class="form-control" id="floatingConfirmPassword" placeholder="Confirm Password" required>
                        <label for="floatingConfirmPassword"><i class="fa fa-lock text-muted me-2"></i>Confirm Password</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100 btn-login text-white mb-3 shadow-none">
                        Update Password <i class="fa fa-arrow-right ms-2"></i>
                    </button>
                </form>
            <?php endif; ?>

            <div class="text-center mt-4 border-top pt-3">
                <a href="<?php echo htmlspecialchars($loginUrl); ?>" class="text-decoration-none fw-bold text-primary">
                    <i class="fa fa-arrow-left me-1"></i> Proceed to Login
                </a>
            </div>

        </div>
    </div>
</body>
</html>

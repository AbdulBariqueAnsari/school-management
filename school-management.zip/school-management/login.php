<?php
require_once 'includes/init.php';

// If already logged in, redirect them
if (isLoggedIn()) {
    redirect(BASE_URL . '/dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1 AND role_id != 6");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['role_id'] = $user['role_id'];

        // Lookup Role Name
        $roleStmt = $pdo->prepare("SELECT name FROM roles WHERE id = ?");
        $roleStmt->execute([$user['role_id']]);
        $_SESSION['role_name'] = $roleStmt->fetchColumn();
        logActivity("Logged into staff/admin portal");
        redirect(BASE_URL . '/dashboard.php');
    }
    else {
        $error = "Invalid email or password, or account disabled.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Exemplar School Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            min-height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-wrapper {
            width: 100%;
            max-width: 420px;
            padding: 15px;
        }
        .login-card { 
            padding: 40px 30px; 
            border-radius: 15px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.15); 
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.5);
        }
        
        /* Shining Logo Animation */
        .school-logo-container {
            width: 120px;
            height: 120px;
            margin: 0 auto 25px auto;
            position: relative;
            border-radius: 50%;
            padding: 5px;
            /* Create the colorful rotating border effect */
            background: linear-gradient(90deg, #007bff, #00ff88, #007bff);
            background-size: 200% auto;
            animation: shineLoop 3s linear infinite;
        }
        .school-logo-inner {
            width: 100%;
            height: 100%;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            box-shadow: inset 0 0 10px rgba(0,0,0,0.1);
        }
        .school-logo-inner img {
            max-width: 80%;
            max-height: 80%;
            object-fit: contain;
        }
        @keyframes shineLoop {
            to { background-position: 200% center; }
        }

        /* Modern Form Elements */
        .form-floating .form-control {
            border-radius: 10px;
            border: 1px solid #ced4da;
            transition: all 0.3s;
        }
        .form-floating .form-control:focus {
            box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.15);
            border-color: #80bdff;
        }
        .btn-login {
            border-radius: 10px;
            padding: 12px;
            font-weight: 600;
            letter-spacing: 0.5px;
            background: linear-gradient(to right, #0052D4, #4364F7, #6FB1FC);
            border: none;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 123, 255, 0.4);
        }
        
        .utility-links a {
            color: #495057;
            text-decoration: none;
            font-size: 0.9em;
            transition: color 0.2s;
        }
        .utility-links a:hover {
            color: #007bff;
            text-decoration: underline;
        }
        
        /* Developer Tagline Highlight */
        .dev-footer {
            margin-top: 30px;
            text-align: center;
            font-size: 0.85em;
        }
        .dev-footer span {
            background-color: #ffd700;
            padding: 2px 8px;
            border-radius: 4px;
            color: #333;
            font-weight: 600;
        }
        .dev-footer a {
            color: #000;
            text-decoration: none;
            font-weight: bold;
        }
        .dev-footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-card">
            
            <div class="school-logo-container">
                <div class="school-logo-inner">
                    <!-- Pointing exactly to the requested path C:\xampp\htdocs\school-management\assets\logo\school.png via native web path -->
                    <img src="assets/logo/school.png" alt="School Logo" onerror="this.src='https://via.placeholder.com/80?text=LOGO'">
                </div>
            </div>

            <h4 class="text-center mb-4 fw-bold" style="color: #2c3e50;">Portal Login</h4>
            
            <?php if ($error): ?>
                <div class="alert alert-danger py-2 border-0 shadow-sm" style="font-size:0.9em;">
                    <i class="fa fa-exclamation-circle me-1"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php
endif; ?>

            <?php
$default_email = '';
try {
    $stmtSettings = $pdo->query("SELECT setting_value FROM super_admin_settings WHERE setting_key = 'school_email'");
    $setting_email = $stmtSettings->fetchColumn();
    if ($setting_email) {
        $default_email = $setting_email;
    }
}
catch (Exception $e) {
}
?>

            <form method="POST" action="">
                <div class="form-floating mb-3">
                    <input type="email" name="email" class="form-control" id="floatingEmail" placeholder="name@example.com" required value="<?php echo htmlspecialchars($default_email); ?>">
                    <label for="floatingEmail"><i class="fa fa-envelope text-muted me-2"></i>Email Address</label>
                </div>
                <div class="form-floating mb-4">
                    <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password" required>
                    <label for="floatingPassword"><i class="fa fa-lock text-muted me-2"></i>Password</label>
                </div>
                
                <button type="submit" class="btn btn-primary w-100 btn-login text-white mb-3">
                    Sign In <i class="fa fa-arrow-right ms-2"></i>
                </button>
            </form>

            <div class="utility-links text-center mt-3">
                <div class="mb-2">
                    <a href="inquiry.php" class="me-3"><i class="fa fa-envelope-open-text me-1"></i> Public Inquiry</a>
                    <a href="appointment.php"><i class="fa fa-calendar-check me-1"></i> Book Appointment</a>
                </div>
                <div class="mb-2 mt-3 pt-2 border-top">
                    <a href="forgot_password.php?type=staff" class="text-muted"><i class="fa fa-key me-1"></i> Staff Forgot Password?</a>
                </div>
            </div>

        </div>

        <div class="dev-footer">
            <span>Designed and developed by <a href="https://webnoor.in/" target="_blank">webnoor</a></span>
        </div>
    </div>
</body>
</html>

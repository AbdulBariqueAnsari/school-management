<?php
http_response_code(403);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 Forbidden | Access Denied</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            font-family: 'Inter', 'Segoe UI', sans-serif;
            color: #f8fafc;
            overflow: hidden;
        }

        /* Animated Background Elements */
        .bg-shape {
            position: absolute;
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(37, 99, 235, 0.1));
            filter: blur(80px);
            border-radius: 50%;
            z-index: 0;
        }
        .shape-1 { width: 400px; height: 400px; top: -100px; left: -100px; animation: float 10s infinite; }
        .shape-2 { width: 500px; height: 500px; bottom: -150px; right: -150px; animation: float 14s infinite alternate; background: linear-gradient(135deg, rgba(239, 68, 68, 0.15), rgba(220, 38, 38, 0.05)); }

        @keyframes float {
            0% { transform: translateY(0) scale(1); }
            50% { transform: translateY(-40px) scale(1.05); }
            100% { transform: translateY(0) scale(1); }
        }

        .error-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 24px;
            padding: 3rem 2.5rem;
            max-width: 500px;
            width: 90%;
            text-align: center;
            position: relative;
            z-index: 10;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            animation: slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .icon-container {
            width: 90px;
            height: 90px;
            background: rgba(239, 68, 68, 0.15);
            color: #ef4444;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            margin: 0 auto 1.5rem auto;
            position: relative;
            box-shadow: 0 0 0 8px rgba(239, 68, 68, 0.05);
        }

        .icon-container::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            border: 2px solid rgba(239, 68, 68, 0.5);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); opacity: 1; }
            100% { transform: scale(1.4); opacity: 0; }
        }

        .error-code {
            font-size: 5rem;
            font-weight: 800;
            line-height: 1;
            margin-bottom: 0.5rem;
            background: linear-gradient(to right, #ffffff, #94a3b8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: -2px;
        }

        .error-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: #e2e8f0;
        }

        .error-desc {
            color: #94a3b8;
            font-size: 1rem;
            line-height: 1.6;
            margin-bottom: 2rem;
        }

        .btn-return {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white;
            border: none;
            padding: 0.8rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.4);
        }

        .btn-return:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.5);
            color: white;
        }

        .shield-icon {
            animation: lockShake 4s ease infinite;
        }

        @keyframes lockShake {
            0%, 90% { transform: rotate(0); }
            92% { transform: rotate(10deg); }
            94% { transform: rotate(-10deg); }
            96% { transform: rotate(5deg); }
            98% { transform: rotate(-5deg); }
            100% { transform: rotate(0); }
        }
    </style>
</head>
<body>

    <!-- Background Decoration -->
    <div class="bg-shape shape-1"></div>
    <div class="bg-shape shape-2"></div>

    <div class="error-card">
        <div class="icon-container">
            <i class="fa fa-shield-halved shield-icon"></i>
        </div>
        
        <div class="error-code">403</div>
        <div class="error-title">Access Forbidden</div>
        
        <div class="error-desc">
            You don't have permission to navigate this directory or view this resource. The area is highly protected.
        </div>
        
        <a href="/school-management/login.php" class="btn-return">
            <i class="fa fa-arrow-left"></i> Return to Safety
        </a>
    </div>

</body>
</html>

<?php
require 'config/db.php';
$stmt = $pdo->prepare("SELECT id, email, username FROM users WHERE id = 99");
$stmt->execute();
print_r($stmt->fetch(PDO::FETCH_ASSOC));

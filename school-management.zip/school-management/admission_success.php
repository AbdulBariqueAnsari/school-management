<?php
require_once 'includes/init.php';

if (!isset($_GET['uid'])) {
    redirect(BASE_URL . '/index.php');
}

$uid = (int)$_GET['uid'];
$stmt = $pdo->prepare("SELECT * FROM admission_applications WHERE id = ?");
$stmt->execute([$uid]);
$student = $stmt->fetch();

if (!$student) {
    redirect(BASE_URL . '/index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admission Success & Download | School Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f6f9; }
        .print-only { display: none; }
        @media print {
            body { background: white; }
            .no-print { display: none !important; }
            .print-only { display: block; }
            .container { max-width: 100%; border: 0; box-shadow: none; }
        }
    </style>
</head>
<body>
    <div class="container mt-5 mb-5 p-4 bg-white shadow-sm rounded">
        <div class="no-print text-center">
            <div class="mb-4">
                <i class="fa fa-check-circle fa-5x text-success"></i>
            </div>
            <h2 class="fw-bold text-success">Application Submitted Successfully!</h2>
            <p class="lead text-muted">Your application is now under review. Please read the important instructions below.</p>
            <div class="alert alert-warning text-start mx-auto" style="max-width: 700px;">
                <h5 class="alert-heading"><strong>Important Instructions:</strong></h5>
                <hr>
                <ul>
                    <li>Any mistakes or mismatch in the form fill-up will result in immediate rejection of the application.</li>
                    <li>Your account will be activated once all offline documents are physically verified by the school administration.</li>
                    <li>Please download/print this form and bring it to the school during your offline verification step.</li>
                </ul>
            </div>
            <button class="btn btn-primary mt-3" onclick="window.print()"><i class="fa fa-file-pdf"></i> Download / Print Application</button>
            <a href="index.php" class="btn btn-secondary mt-3">Return Home</a>
        </div>

        <!-- Print View Content -->
        <div class="print-only" style="font-size: 0.95em;">
            <div class="text-center mb-3 border-bottom pb-2">
                <img src="assets/images/logo.png" alt="School Logo" style="height: 70px; margin-bottom: 5px;" onerror="this.style.display='none'">
                <h1 style="color: #000080; font-size: 1.8rem;" class="fw-bold mb-1">EXEMPLAR HIGH SCHOOL</h1>
                <p class="mb-1 small">123 Academic Avenue, Knowledge City, 10001</p>
                <p class="mb-1 small">Email: info@exemplarschool.com | Contact: +1 800 555 1234</p>
                <p class="mb-0 small"><a href="https://exemplarschool.com" class="text-decoration-none">www.exemplarschool.com</a></p>
            </div>
            
            <h4 class="text-center bg-light py-2 border mb-3 fw-bold">ADMISSION REGISTRATION FORM</h4>

            <div class="mb-3">
                <table class="table table-bordered mb-0 border-dark">
                    <tr>
                        <th width="25%" class="bg-light">Admission No.</th>
                        <td width="25%" class="fw-bold fs-5 text-primary"><?php echo htmlspecialchars($student['admission_number'] ?? 'PENDING'); ?></td>
                        <th width="25%" class="bg-light">Class Applied For</th>
                        <td width="25%" class="fw-bold"><?php
$cStmt = $pdo->prepare("SELECT name FROM classes WHERE id = ?");
$cStmt->execute([$student['class_applying_for']]);
echo htmlspecialchars($cStmt->fetchColumn() ?: $student['class_applying_for']);
?></td>
                    </tr>
                </table>
            </div>

            <!-- Student Details -->
            <h6 class="bg-secondary text-white p-2 mb-0 fw-bold">1. STUDENT DETAILS</h6>
            <table class="table table-bordered mb-2 border-dark table-sm">
                <tr><th width="25%">Full Name</th><td width="25%"><?php echo htmlspecialchars($student['student_name']); ?></td><th width="25%">Date of Birth</th><td width="25%"><?php echo htmlspecialchars($student['dob']); ?></td></tr>
                <tr><th>Gender</th><td><?php echo htmlspecialchars($student['gender']); ?></td><th>Blood Group</th><td><?php echo htmlspecialchars($student['blood_group'] ?: '-'); ?></td></tr>
                <tr><th>Religion</th><td><?php echo htmlspecialchars($student['religion'] ?: '-'); ?></td><th>Caste Category</th><td><?php echo htmlspecialchars($student['caste_category'] ?: '-'); ?></td></tr>
                <tr><th>Mother Tongue</th><td><?php echo htmlspecialchars($student['mother_tongue'] ?: '-'); ?></td><th>Aadhaar Number</th><td><?php echo htmlspecialchars($student['aadhaar_number'] ?: '-'); ?></td></tr>
                <tr><th>Mobile Number</th><td><?php echo htmlspecialchars($student['mobile_number'] ?: '-'); ?></td><th>Present Address</th><td colspan="3"><?php echo htmlspecialchars($student['address']); ?></td></tr>
            </table>

            <!-- Parent Details -->
            <h6 class="bg-secondary text-white p-2 mb-0 fw-bold mt-2">2. PARENT / GUARDIAN DETAILS</h6>
            <table class="table table-bordered mb-2 border-dark table-sm">
                <tr><th width="25%">Father's Name</th><td width="25%"><?php echo htmlspecialchars($student['father_name'] ?: '-'); ?></td><th width="25%">Father's Mobile</th><td width="25%"><?php echo htmlspecialchars($student['father_mobile'] ?: '-'); ?></td></tr>
                <tr><th>Mother's Name</th><td><?php echo htmlspecialchars($student['mother_name'] ?: '-'); ?></td><th>Mother's Mobile</th><td><?php echo htmlspecialchars($student['mother_mobile'] ?: '-'); ?></td></tr>
                <tr><th>Primary Email</th><td colspan="3"><?php echo htmlspecialchars($student['parent_email']); ?></td></tr>
                <tr><th>Parents' Address</th><td colspan="3"><?php echo htmlspecialchars($student['parents_address'] ?: '-'); ?></td></tr>
                <tr><th>Guardian Name</th><td><?php echo htmlspecialchars($student['guardian_name'] ?: '-'); ?></td><th>Relation / Mobile</th><td><?php echo htmlspecialchars(($student['relation'] ?: '-') . ' / ' . ($student['guardian_mobile'] ?: '-')); ?></td></tr>
                <tr><th>Guardian Address</th><td colspan="3"><?php echo htmlspecialchars($student['guardian_address'] ?: '-'); ?></td></tr>
            </table>

            <!-- Health Details -->
            <h6 class="bg-secondary text-white p-2 mb-0 fw-bold mt-2">3. HEALTH INFORMATION</h6>
            <table class="table table-bordered mb-2 border-dark table-sm">
                <tr><th width="25%">Medical Condition?</th><td width="25%"><?php echo htmlspecialchars($student['has_medical_condition'] ?: 'No'); ?></td><th>Details</th><td><?php echo htmlspecialchars($student['medical_condition_desc'] ?: '-'); ?></td></tr>
                <tr><th>Disability?</th><td><?php echo htmlspecialchars($student['has_disability'] ?: 'No'); ?></td><th>Details</th><td><?php echo htmlspecialchars($student['disability_desc'] ?: '-'); ?></td></tr>
                <tr><th>Allergies?</th><td><?php echo htmlspecialchars($student['has_allergies'] ?: 'No'); ?></td><th>Details</th><td><?php echo htmlspecialchars($student['allergies_desc'] ?: '-'); ?></td></tr>
            </table>

            <!-- Academic Details -->
            <h6 class="bg-secondary text-white p-2 mb-0 fw-bold mt-2">4. PREVIOUS ACADEMIC DETAILS</h6>
            <table class="table table-bordered mb-3 border-dark table-sm">
                <tr><th width="25%">Schooling Status</th><td colspan="3"><?php echo htmlspecialchars($student['previous_schooling_status'] ?: '-'); ?></td></tr>
                <tr><th>School Name</th><td><?php echo htmlspecialchars($student['previous_school'] ?: '-'); ?></td><th>Class & Year</th><td><?php echo htmlspecialchars(($student['previous_class'] ?: '-') . ' | ' . ($student['year_of_passing'] ?: '-')); ?></td></tr>
                <tr><th>Board</th><td colspan="3"><?php echo htmlspecialchars($student['previous_board'] ?: '-'); ?></td></tr>
            </table>

            <!-- Declarations & Signatures -->
            <div class="border border-dark p-2 mt-2 bg-light" style="font-size: 0.85em; text-align: justify;">
                <strong>Declaration:</strong> I hereby declare that the information provided in this Admission-cum-Registration Form is true, complete, and accurate. I understand that any false or misleading information may result in cancellation of admission. I agree to abide by all the rules, regulations, and policies of the school.
            </div>

            <div class="row mt-4 pt-2">
                <div class="col-6">
                    <p class="mb-4 text-start"><strong>Date:</strong> ______________________</p>
                    <p class="text-start"><strong>Place:</strong> _____________________</p>
                    <p class="mt-4 border-top border-dark pt-2 d-inline-block fw-bold">Signature of Parent / Guardian</p>
                </div>
                <div class="col-6 text-end">
                    <div class="p-2 border border-dark d-inline-block text-center mb-3" style="min-width: 130px; min-height: 70px;">
                        <span class="text-muted small">School Stamp</span>
                    </div>
                    <div class="clearfix"></div>
                    <p class="mt-2 border-top border-dark pt-2 d-inline-block fw-bold">Checked by School Office (Signature)</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center mt-5 mb-3 no-print">
        <p class="text-muted small">Designed and developed by <a href="https://webnoor.in/" target="_blank">Webnoor</a></p>
    </div>
</body>
</html>

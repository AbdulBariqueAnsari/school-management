<?php
require_once 'config/db.php';
$stmt = $pdo->query("SHOW TRIGGERS");
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "Table: " . $row['Table'] . " | Event: " . $row['Event'] . " | Timing: " . $row['Timing'] . "\n";
    echo "Statement: " . $row['Statement'] . "\n---\n";
}

<?php
require_once 'config/db.php';

$sql = "
CREATE TABLE IF NOT EXISTS `exam_admit_cards` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `student_id` int(11) NOT NULL,
    `exam_id` int(11) NOT NULL,
    `class_id` int(11) NOT NULL,
    `roll_number` varchar(50) DEFAULT NULL,
    `admit_card_no` varchar(100) NOT NULL UNIQUE,
    `security_hash` varchar(64) NOT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `student_exam_admit` (`student_id`, `exam_id`),
    CONSTRAINT `fk_admit_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_admit_exam` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_admit_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

try {
    $pdo->exec($sql);
    echo "Exam Admit Cards migration successful!";
} catch (PDOException $e) {
    echo "Migration failed: " . $e->getMessage();
}
?>

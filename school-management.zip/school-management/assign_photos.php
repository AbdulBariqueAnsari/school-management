<?php
require_once __DIR__ . '/config/db.php';

$source_dir = __DIR__ . '/student photos';
$uploads_dir = __DIR__ . '/uploads';
$uploads_students_dir = __DIR__ . '/uploads/students';

if (!is_dir($uploads_students_dir)) {
    mkdir($uploads_students_dir, 0777, true);
}

// Get all valid images
$files = scandir($source_dir);
$images = [];
foreach ($files as $file) {
    if ($file !== '.' && $file !== '..') {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
            $images[] = $file;
        }
    }
}

if (empty($images)) {
    echo "No images found in $source_dir\n";
    exit;
}

// Get all students
$stmt = $pdo->query("SELECT id, user_id FROM students");
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($students)) {
    echo "No students found in DB.\n";
    exit;
}

$image_count = count($images);
$updates = 0;

foreach ($students as $index => $student) {
    // Round robin assign images to students
    $image_name = $images[$index % $image_count];
    $source_path = $source_dir . '/' . $image_name;

    // Create a unique name to avoid conflicts if same image assigned multiple times
    $new_filename = time() . '_' . $student['id'] . '_' . preg_replace('/[^a-zA-Z0-9\._-]/', '', $image_name);

    $dest_path_1 = $uploads_students_dir . '/' . $new_filename;

    // Copy the file
    copy($source_path, $dest_path_1);

    // Also copy directly to uploads/ to cover some other legacy views
    copy($source_path, $uploads_dir . '/' . $new_filename);

    // Update students table ('photo' and potentially 'student_photo')
    $relative_path = 'students/' . $new_filename;

    try {
        $pdo->prepare("UPDATE students SET photo = ? WHERE id = ?")->execute([$relative_path, $student['id']]);
    }
    catch (Exception $e) {
    }

    try {
        $pdo->prepare("UPDATE students SET student_photo = ? WHERE id = ?")->execute([$relative_path, $student['id']]);
    }
    catch (Exception $e) {
    }

    // Update users table ('profile_photo') - user holds the raw filename without 'students/' prefix
    if (!empty($student['user_id'])) {
        try {
            $pdo->prepare("UPDATE users SET profile_photo = ? WHERE id = ?")->execute([$new_filename, $student['user_id']]);
        }
        catch (Exception $e) {
        }
    }

    $updates++;
}

echo "Successfully copied and assigned photos to $updates students.\n";

<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=school_management', 'root', '');

    echo "--- students ---\n";
    $stmt = $pdo->query('SELECT id, student_name, status FROM students');
    print_r($stmt->fetchAll(PDO::FETCH_ASSOC));

    echo "\n--- admission_requests ---\n";
    try {
        $stmt = $pdo->query('SELECT id, student_name, status FROM admission_requests');
        print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    catch (Exception $e) {
    }

    echo "\n--- admission_applications ---\n";
    try {
        $stmt = $pdo->query('SELECT id, student_name, status FROM admission_applications');
        print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    catch (Exception $e) {
    }

}
catch (Exception $e) {
    echo 'DB_ERROR: ' . $e->getMessage();
}

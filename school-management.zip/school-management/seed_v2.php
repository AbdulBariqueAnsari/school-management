<?php
require_once 'config/db.php';

echo "Step 1: Creating backup table...\n";
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS students_backup AS SELECT * FROM students");
}
catch (Exception $e) {
    echo "Backup table already exists or error: " . $e->getMessage() . "\n";
}

echo "Step 2: Clearing existing data...\n";
$pdo->exec("SET FOREIGN_KEY_CHECKS=0");
$pdo->exec("TRUNCATE TABLE students");
try {
    $pdo->exec("TRUNCATE TABLE admission_requests");
}
catch (Exception $e) {
}

$pdo->exec("DELETE FROM users WHERE email LIKE 'student%@test.com'");
$pdo->exec("SET FOREIGN_KEY_CHECKS=1");

$stmt = $pdo->query("DESCRIBE students");
$columns = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo "Available columns in students table: " . implode(", ", $columns) . "\n";

echo "Step 3: Inserting 10 test records...\n";
$password_hash = password_hash('password123', PASSWORD_DEFAULT);

$pdo->beginTransaction(); // Start transaction AFTER DDL

try {
    for ($i = 1; $i <= 10; $i++) {
        $status = ($i <= 5) ? 'Approved' : 'Pending';
        $username = "student{$i}";
        $email = "student{$i}@test.com";

        $stmt_user = $pdo->prepare("INSERT INTO users (name, email, password, role_id, is_active) VALUES (?, ?, ?, 6, 1)");
        $stmt_user->execute(["Test Student {$i}", $email, $password_hash]);
        $user_id = $pdo->lastInsertId();

        $admission_no = ($status === 'Approved') ? 'ADM-' . date('Y') . '-' . str_pad($i, 4, '0', STR_PAD_LEFT) : null;
        $admission_date = ($status === 'Approved') ? date('Y-m-d') : null;

        $data = [
            'application_id' => $i,
            'admission_no' => $admission_no,
            'student_name' => "Test Student {$i}",
            'gender' => ($i % 2 == 0) ? 'Female' : 'Male',
            'dob' => date('Y-m-d', strtotime('-' . (5 + ($i % 5)) . ' years')),
            'age' => 5 + ($i % 5),
            'blood_group' => 'O+',
            'aadhaar' => '1234567890' . str_pad($i, 2, '0', STR_PAD_LEFT),
            'student_photo' => 'default_photo.png',
            'present_address' => "12{$i} Main St, Springfield",
            'student_mobile' => '987654321' . ($i % 10),
            'medical_condition' => 'No',
            'medical_details' => '',
            'disability' => 'No',
            'disability_details' => '',
            'allergies' => 'No',
            'allergy_details' => '',
            'religion' => 'Hindu',
            'caste_category' => 'General',
            'mother_tongue' => 'English',
            'previous_school_status' => 'Yes',
            'father_name' => "Father {$i}",
            'father_mobile' => '987654000' . ($i % 10),
            'mother_name' => "Mother {$i}",
            'mother_mobile' => '987654111' . ($i % 10),
            'parent_address' => "12{$i} Main St, Springfield",
            'parent_email' => "parent{$i}@test.com",
            'parent_phone' => '987654000' . ($i % 10),
            'guardian_name' => "Guardian {$i}",
            'guardian_relation' => 'Uncle',
            'guardian_mobile' => '987654222' . ($i % 10),
            'guardian_address' => "12{$i} Main St, Springfield",
            'class_applied' => '' . (($i % 10) + 1),
            'class' => '' . (($i % 10) + 1),
            'previous_class' => '' . (($i % 10)),
            'previous_school_name' => "Old School {$i}",
            'previous_board' => 'CBSE',
            'year_of_passing' => date('Y', strtotime('-1 year')),
            'username' => $username,
            'email' => $email,
            'password' => $password_hash,
            'status' => $status,
            'created_at' => date('Y-m-d H:i:s'),
            'admission_date' => $admission_date
        ];

        $insert_cols = [];
        $insert_vals = [];
        $insert_placeholders = [];

        foreach ($data as $key => $val) {
            if (in_array($key, $columns)) {
                $insert_cols[] = $key;
                $insert_vals[] = $val;
                $insert_placeholders[] = '?';
            }
        }

        $sql = "INSERT INTO students (" . implode(', ', $insert_cols) . ") VALUES (" . implode(', ', $insert_placeholders) . ")";
        $stmt_stu = $pdo->prepare($sql);
        $stmt_stu->execute($insert_vals);
    }

    $pdo->commit();
    echo "Successfully seeded 10 complete records.\n";

}
catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "Error: " . $e->getMessage() . "\n";
}
?>

<?php
session_id('test1234');
session_start();
$_SESSION['role_id'] = 1;
$_SESSION['user_id'] = 1;
session_write_close();

$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"Cookie: PHPSESSID=test1234\r\n"
  )
);
$context = stream_context_create($opts);
$html = file_get_contents('http://localhost/school-management/admin/approved_students.php', false, $context);
echo "DataTable count: " . substr_count($html, 'DataTable') . "\n";
echo "Table count: " . substr_count($html, '<table') . "\n";
echo "sp-row count: " . substr_count($html, 'class="sp-row"') . "\n";

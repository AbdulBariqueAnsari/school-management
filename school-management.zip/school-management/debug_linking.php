<?php
require 'config/db.php';
$student_count = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$user_student_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role_id = 6")->fetchColumn();
$linked_count = $pdo->query("SELECT COUNT(*) FROM students WHERE user_id IS NOT NULL AND user_id IN (SELECT id FROM users)")->fetchColumn();

echo "Total Students: $student_count\n";
echo "Total Users (Role 6): $user_student_count\n";
echo "Correctly Linked: $linked_count\n";

if ($student_count > $linked_count) {
    echo "MISMATCH DETECTED: some students are not linked or linked to non-existent users.\n";
}

// Check a sample mismatch
$mismatch = $pdo->query("SELECT id, student_name, user_id FROM students WHERE user_id IS NULL OR user_id NOT IN (SELECT id FROM users)")->fetchAll(PDO::FETCH_ASSOC);
echo "Samples of Unlinked Students:\n";
print_r(array_slice($mismatch, 0, 5));

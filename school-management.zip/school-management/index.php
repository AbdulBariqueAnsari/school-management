<?php
require_once 'includes/init.php';
redirect(BASE_URL . '/login.php');
?>

<?php
require_once 'includes/init.php';

$role_id = $_SESSION['role_id'] ?? null;

session_destroy();

if ($role_id == 6) {
    redirect(BASE_URL . '/student/login.php');
} else {
    redirect(BASE_URL . '/login.php');
}
?>

<?php
require 'config/db.php';
$stmt = $pdo->query("SELECT * FROM students WHERE status='Approved' ORDER BY student_name ASC");
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Total: " . count($students) . "\n";
foreach($students as $s) {
    echo htmlspecialchars($s['student_name']) . " - " . htmlspecialchars($s['class_applied'] ?? 'N/A') . "\n";
    if (empty($s['student_name'])) {
        echo "EMPTY NAME!\n";
    }
}

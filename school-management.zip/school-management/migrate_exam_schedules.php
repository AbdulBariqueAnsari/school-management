<?php
require_once 'config/db.php';

$sql = "
CREATE TABLE IF NOT EXISTS `exam_schedule_notices` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `notice_no` varchar(50) NOT NULL UNIQUE,
    `exam_id` int(11) NOT NULL,
    `class_id` int(11) NOT NULL,
    `schedule_data` text NOT NULL,
    `created_by` int(11) NOT NULL,
    `status` enum('Pending','Approved') DEFAULT 'Pending',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    CONSTRAINT `fk_schedule_exam` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_schedule_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_schedule_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

try {
    $pdo->exec($sql);
    echo "Exam schedule notices migration successful!";
} catch (PDOException $e) {
    echo "Migration failed: " . $e->getMessage();
}
?>

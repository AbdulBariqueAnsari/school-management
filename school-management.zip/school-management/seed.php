<?php
require_once 'config/db.php';
require_once 'config/database_init.php';

// Clear existing tables for a clean slate, to match "I want at least 10 students" 
// (or just append, the instructions say "Total 10 students I need"). 
// To make sure there are exactly 10, I will truncate the tables.
$pdo->exec("SET FOREIGN_KEY_CHECKS=0; TRUNCATE TABLE admission_requests; TRUNCATE TABLE students; SET FOREIGN_KEY_CHECKS=1;");

$students = [
    // 5 Pending
    ['name' => 'Michael Scott', 'gender' => 'Male', 'class' => '1', 'parent' => 'Marnie Scott', 'status' => 'Pending'],
    ['name' => 'Pam Beesly', 'gender' => 'Female', 'class' => '2', 'parent' => 'William Beesly', 'status' => 'Pending'],
    ['name' => 'Jim Halpert', 'gender' => 'Male', 'class' => '3', 'parent' => 'Gerald Halpert', 'status' => 'Pending'],
    ['name' => 'Dwight Schrute', 'gender' => 'Male', 'class' => '4', 'parent' => 'Ira Schrute', 'status' => 'Pending'],
    ['name' => 'Angela Martin', 'gender' => 'Female', 'class' => '5', 'parent' => 'Charles Martin', 'status' => 'Pending'],
    // 5 Approved
    ['name' => 'Stanley Hudson', 'gender' => 'Male', 'class' => '6', 'parent' => 'Cynthia Hudson', 'status' => 'Approved'],
    ['name' => 'Phyllis Vance', 'gender' => 'Female', 'class' => '7', 'parent' => 'Bob Vance', 'status' => 'Approved'],
    ['name' => 'Kevin Malone', 'gender' => 'Male', 'class' => '8', 'parent' => 'Stacy Malone', 'status' => 'Approved'],
    ['name' => 'Oscar Martinez', 'gender' => 'Male', 'class' => '9', 'parent' => 'Gil Martinez', 'status' => 'Approved'],
    ['name' => 'Kelly Kapoor', 'gender' => 'Female', 'class' => '10', 'parent' => 'Ravi Kapoor', 'status' => 'Approved']
];

$password = password_hash('password123', PASSWORD_DEFAULT);
$credentials = "\n\n## Demo Student Login Credentials\n\n| Name | Email / Username | Password | Status | Class |\n|---|---|---|---|---|\n";

foreach ($students as $index => $s) {
    $email = strtolower(explode(' ', $s['name'])[0]) . rand(10, 99) . '@school.com';
    $parent_email = strtolower(explode(' ', $s['parent'])[0]) . rand(10, 99) . '@parent.com';
    $phone = '9876543' . str_pad($index, 3, '0', STR_PAD_LEFT);
    $dob = date('Y-m-d', strtotime('-' . (5 + $index) . ' years'));
    $address = 'Dunder Mifflin Lane, Scranton';
    $guardian = 'Same as parent';

    // Insert to admission_requests
    $stmt = $pdo->prepare("INSERT INTO admission_requests (student_name, gender, dob, class_applied, parent_name, parent_email, parent_phone, address, guardian_details, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$s['name'], $s['gender'], $dob, $s['class'], $s['parent'], $parent_email, $phone, $address, $guardian, $s['status']]);

    if ($s['status'] === 'Approved') {
        // Create user account for login
        $stmt_user = $pdo->prepare("INSERT INTO users (name, email, password, role_id, is_active) VALUES (?, ?, ?, 6, 1)");
        $stmt_user->execute([$s['name'], $email, $password]);
        $user_id = $pdo->lastInsertId();

        // Add to students
        $admission_no = 'ADM-' . date('Y') . '-' . str_pad($index + 1, 4, '0', STR_PAD_LEFT);
        $stmt_stu = $pdo->prepare("INSERT INTO students (admission_no, student_name, gender, dob, class, parent_name, parent_email, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt_stu->execute([$admission_no, $s['name'], $s['gender'], $dob, $s['class'], $s['parent'], $parent_email]);

        $credentials .= "| {$s['name']} | {$email} | password123 | {$s['status']} | {$s['class']} |\n";
    }
    else {
        $credentials .= "| {$s['name']} | (Application ID tracking) | N/A (Pending) | {$s['status']} | {$s['class']} |\n";
    }
}

file_put_contents('README.md', $credentials, FILE_APPEND);
echo "Seed successful. 10 students generated. Credentials written to README.md.\n";
?>

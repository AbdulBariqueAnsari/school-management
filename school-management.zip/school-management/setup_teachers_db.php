<?php
// setup_teachers_db.php
require_once 'config/db.php';

try {
    // 1. Create the new exact teachers table
    $pdo->exec("DROP TABLE IF EXISTS teachers;");
    $pdo->exec("CREATE TABLE teachers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        teacher_id VARCHAR(50),
        full_name VARCHAR(150),
        gender VARCHAR(10),
        dob DATE,
        age INT,
        blood_group VARCHAR(10),
        aadhaar VARCHAR(20),
        phone VARCHAR(20),
        email VARCHAR(150),
        present_address TEXT,
        permanent_address TEXT,
        photo VARCHAR(255),
        qualification VARCHAR(255),
        specialization VARCHAR(255),
        experience_years INT,
        previous_school VARCHAR(255),
        year_of_joining YEAR,
        designation VARCHAR(100),
        employment_type VARCHAR(50),
        assigned_subject VARCHAR(100),
        assigned_class VARCHAR(50),
        username VARCHAR(100),
        password VARCHAR(255),
        status VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );");

    // 2. Ensure Teacher Role (8) exists
    $stmt = $pdo->prepare("SELECT id FROM roles WHERE id = 8");
    $stmt->execute();
    if (!$stmt->fetch()) {
        $pdo->exec("INSERT INTO roles (id, name) VALUES (8, 'Teacher')");
    }

    // 3. Clear existing teacher data (role 8 or 4/5 if mapped previously)
    // Be careful, only clear new 'Teacher' role (8) to avoid touching old Class/Subject Teacher roles unless asked.
    // The prompt says: "Delete all existing teachers data id and passwords, and add dummy teachers for all subjects, and other teachers."
    // It's safer to only delete role 8 users mapped to the new teachers table.
    $pdo->exec("DELETE FROM users WHERE role_id = 8;");
    $pdo->exec("TRUNCATE TABLE teachers;");

    // 4. Dummy Data for CBSE Subjects
    $subjects = [
        ['name' => 'English', 'class' => 'Class 1'],
        ['name' => 'Hindi', 'class' => 'Class 2'],
        ['name' => 'Mathematics', 'class' => 'Class 3'],
        ['name' => 'EVS', 'class' => 'Class 4'],
        ['name' => 'Science', 'class' => 'Class 5'],
        ['name' => 'Social Science', 'class' => 'Class 6'],
        ['name' => 'Computer Science', 'class' => 'Class 7'],
        ['name' => 'General Knowledge', 'class' => 'Class 8'],
        ['name' => 'Moral Science', 'class' => 'Class 9'],
        ['name' => 'Drawing', 'class' => 'LKG'],
        ['name' => 'Music', 'class' => 'UKG'],
        ['name' => 'Physical Education', 'class' => 'Class 10'],
        ['name' => 'Physics', 'class' => 'Class 11'],
        ['name' => 'Chemistry', 'class' => 'Class 12'],
        ['name' => 'Biology', 'class' => 'Class 11'],
        ['name' => 'Economics', 'class' => 'Class 12']
    ];

    $password_plain = 'password123';
    $password_hashed = password_hash($password_plain, PASSWORD_DEFAULT);

    $dummy_credentials = "\n\n### 🎓 Teacher Portal Credentials\n\n| Name | Subject | Class | Email / Username | Password | Status |\n|---|---|---|---|---|---|\n";

    $count = 1;
    foreach ($subjects as $sub) {
        $first_name = "Teacher" . $count;
        $last_name = preg_replace('/[^a-zA-Z]/', '', $sub['name']);
        $full_name = $first_name . " " . $last_name;
        $username = strtolower($first_name . "_" . $last_name);
        $email = $username . "@school.com";
        $teacher_id = "TCH-" . date('Y') . "-" . str_pad($count, 3, "0", STR_PAD_LEFT);

        // Insert into Users (Role 8)
        $stmt_user = $pdo->prepare("INSERT INTO users (name, email, password, role_id, phone, is_active) VALUES (?, ?, ?, 8, ?, 1)");
        $phone = '98765' . str_pad($count, 5, '0', STR_PAD_LEFT);
        $stmt_user->execute([$full_name, $email, $password_hashed, $phone]);

        // Insert into new teachers table
        $stmt_teacher = $pdo->prepare("INSERT INTO teachers (
            teacher_id, full_name, gender, dob, age, blood_group, aadhaar, phone, email, 
            present_address, permanent_address, photo, qualification, specialization, 
            experience_years, previous_school, year_of_joining, designation, employment_type, 
            assigned_subject, assigned_class, username, password, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Approved')");

        $stmt_teacher->execute([
            $teacher_id, $full_name, 'Female', '1990-01-01', 35, 'O+', '123412341234', $phone, $email,
            '123 School Avenue', '123 School Avenue', 'default-teacher.png', 'M.Ed', $sub['name'],
            5, 'Previous High School', 2020, 'Subject Teacher', 'Full Time',
            $sub['name'], $sub['class'], $username, $password_hashed
        ]);

        $dummy_credentials .= "| {$full_name} | {$sub['name']} | {$sub['class']} | `{$username}` | `{$password_plain}` | Approved |\n";
        $count++;
    }

    echo "Teacher database setup successful.\n";
    echo "Summary of Credentials:\n";
    echo $dummy_credentials;

    // Save to a file to inject into README
    file_put_contents('teacher_creds.txt', $dummy_credentials);

}
catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

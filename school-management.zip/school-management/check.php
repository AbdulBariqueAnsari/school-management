<?php
require 'config/db.php';
$stmt = $pdo->query("SELECT status, COUNT(*) as c FROM students GROUP BY status");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));

<?php
require_once 'includes/init.php';

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_inquiry'])) {
    $visitor_name = trim($_POST['visitor_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $student_name = trim($_POST['student_name'] ?? '');
    $inquiry_type = trim($_POST['inquiry_type'] ?? '');
    $inquiry_message = trim($_POST['message'] ?? '');

    if($visitor_name && $phone && $inquiry_type) {
        $inquiries_file = 'data/inquiries.json';
        $inquiries = [];
        if(file_exists($inquiries_file)) {
            $inquiries = json_decode(file_get_contents($inquiries_file), true);
            if(!is_array($inquiries)) $inquiries = [];
        }

        $inquiries[] = [
            'visitor_name' => $visitor_name,
            'phone' => $phone,
            'email' => $email,
            'student_name' => $student_name,
            'inquiry_type' => $inquiry_type,
            'message' => $inquiry_message,
            'status' => 'New',
            'created_at' => date('Y-m-d H:i:s')
        ];

        if(file_put_contents($inquiries_file, json_encode($inquiries, JSON_PRETTY_PRINT))) {
            $msg = "Inquiry submitted successfully!";
        } else {
            $err = "Failed to save inquiry. Please check file permissions.";
        }
    } else {
        $err = "Please fill in all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enquiry | <?php echo htmlspecialchars($school_name ?? 'School'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fafbfc;
            background-image: 
              linear-gradient(rgba(0,0,0,0.03) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0,0,0,0.03) 1px, transparent 1px);
            background-size: 30px 30px;
            font-family: 'Outfit', sans-serif;
            color: #495057;
            margin-bottom: 60px;
        }
        .brand-header { text-align: center; margin-top: 50px; margin-bottom: 30px; }
        .brand-header img { width: 90px; height: 90px; border-radius: 50%; box-shadow: 0 4px 10px rgba(0,0,0,0.1); margin-bottom: 15px; background: #fff; padding: 4px; object-fit: contain; }
        .brand-header h1 { font-weight: 800; color: #d9580d; font-size: 2.8rem; letter-spacing: -0.5px; margin-bottom: 5px; }
        .brand-header .subtext { font-size: 0.9rem; letter-spacing: 3px; color: #6c757d; text-transform: uppercase; margin-bottom: 20px; font-weight: 600; }
        .brand-header .pill { display: inline-block; background: #c2410c; color: #fff; padding: 8px 24px; border-radius: 30px; font-size: 0.9rem; font-weight: 800; letter-spacing: 1px; box-shadow: 0 4px 15px rgba(194, 65, 12, 0.3); text-transform: uppercase; }

        .form-wrapper { max-width: 820px; margin: 0 auto; background: #fff; border-radius: 16px; box-shadow: 0 20px 40px rgba(0,0,0,0.05); overflow: hidden; position: relative; }
        .form-top-line { height: 6px; background: linear-gradient(90deg, #d9580d 0%, #d9580d 50%, #0d6efd 50%, #0d6efd 100%); }

        .stepper-container { padding: 40px 80px 10px; position: relative; }
        .stepper-line { position: absolute; top: 56px; left: 120px; right: 120px; height: 3px; background: #e9ecef; z-index: 1; }
        .stepper-line-active { position: absolute; top: 56px; left: 120px; width: 0%; height: 3px; background: #c2410c; z-index: 2; transition: width 0.4s ease; }
        .step-item { position: relative; z-index: 3; text-align: center; flex: 1; }
        .step-circle { width: 36px; height: 36px; background: #e9ecef; color: #adb5bd; border-radius: 50%; margin: 0 auto 10px; display: flex; align-items: center; justify-content: center; font-weight: 800; border: 4px solid #fff; transition: 0.3s; font-size: 0.9rem; margin-top:2px; box-shadow: 0 0 0 1px #fff; }
        .step-item.active .step-circle { background: #c2410c; color: #fff; box-shadow: 0 0 0 6px rgba(194, 65, 12, 0.2), 0 0 0 1px #fff; }
        .step-item.completed .step-circle { background: #c2410c; color: #fff; box-shadow: 0 0 0 1px #fff; }
        .step-label { font-size: 0.75rem; font-weight: 800; color: #adb5bd; text-transform: uppercase; letter-spacing: 1px; }
        .step-item.active .step-label { color: #c2410c; }

        .section-header { display: flex; align-items: center; margin: 30px 40px; }
        .section-icon { width: 44px; height: 44px; background: rgba(194, 65, 12, 0.1); color: #c2410c; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; margin-right: 15px; }
        .section-title { margin: 0; font-weight: 800; color: #212529; font-size: 1.5rem; letter-spacing: -0.3px; }
        .section-desc { margin: 0; color: #6c757d; font-size: 0.95rem; font-weight: 400; mt-1; }

        .info-alert { margin: 0 40px 25px; background: #f0f7ff; border: 1px solid #cce3fd; color: #0056b3; padding: 12px 20px; border-radius: 8px; font-size: 0.9rem; font-weight: 600; display: flex; align-items: center; }
        .info-alert i { margin-right: 10px; font-size: 1.1rem; }

        .form-body { padding: 0 40px 20px; }
        .form-label { font-size: 0.8rem; font-weight: 800; color: #495057; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
        .form-label span.req { color: #c2410c; }
        
        .input-group-custom { position: relative; }
        .custom-input { background: #fdfdfd; border: 1px solid #e9ecef; border-radius: 10px; padding: 14px 15px 14px 45px; font-weight: 600; color: #495057; transition: 0.3s; box-shadow: none; font-size: 0.95rem; width: 100%; }
        .custom-input:focus { background: #fff; border-color: #cce3fd; box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1); outline: none; }
        .input-icon { position: absolute; top: 15px; left: 16px; color: #adb5bd; font-size: 1.1rem; z-index: 5; }
        textarea.custom-input { padding-left: 15px; } /* no icon for textarea usually, or adjust */

        .bottom-actions { background: #fcfcfc; padding: 25px 40px; border-top: 1px solid #f1f3f5; display: flex; justify-content: space-between; align-items: center; }
        .step-progress-text { color: #adb5bd; font-weight: 800; font-size: 0.9rem; letter-spacing: 0.5px; }
        
        .btn-continue { background: #c2410c; color: #fff; border: none; padding: 14px 30px; border-radius: 30px; font-weight: 800; font-size: 1.05rem; transition: 0.3s; min-width: 220px; box-shadow: 0 8px 20px rgba(194, 65, 12, 0.2); cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; }
        .btn-continue:hover { background: #9a330a; transform: translateY(-2px); box-shadow: 0 12px 25px rgba(194, 65, 12, 0.3); color:#fff; }
        
        .btn-back { background: transparent; color: #6c757d; border: 1px solid #dee2e6; padding: 14px 30px; border-radius: 30px; font-weight: 800; font-size: 1.05rem; transition: 0.3s; cursor: pointer; }
        .btn-back:hover { background: #f8f9fa; color: #212529; }

        .bottom-cards { display: flex; gap: 20px; max-width: 820px; margin: 30px auto 0; padding:0 15px; flex-wrap: wrap; }
        .b-card { background: #fff; border-radius: 12px; padding: 20px; flex: 1; display: flex; align-items: center; box-shadow: 0 10px 30px rgba(0,0,0,0.03); min-width: 200px; }
        .b-card-icon { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; margin-right: 15px; flex-shrink: 0; }
        .b-card-icon.orange { background: rgba(194, 65, 12, 0.1); color: #c2410c; }
        .b-card-icon.blue { background: rgba(13, 110, 253, 0.1); color: #0d6efd; }
        .b-card-icon.green { background: rgba(25, 135, 84, 0.1); color: #198754; }
        .b-card-title { font-weight: 800; color: #212529; font-size: 0.95rem; margin-bottom: 2px; }
        .b-card-desc { font-size: 0.8rem; color: #6c757d; line-height: 1.3; margin:0; }

        /* Stepper logic */
        .step-pane { display: none; animation: fadeIn 0.4s; }
        .step-pane.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
        .step-pane.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }

        @keyframes cardEntrance { 
            0% { opacity: 0; transform: translateY(30px) scale(0.98); } 
            100% { opacity: 1; transform: translateY(0) scale(1); } 
        }

        @keyframes staggerFade { 
            0% { opacity: 0; transform: translateY(10px); } 
            100% { opacity: 1; transform: translateY(0); } 
        }

        .brand-header { animation: fadeIn 0.8s ease-out; }
        .form-wrapper { animation: cardEntrance 0.8s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; }
        .bottom-cards .b-card { 
            opacity: 0; 
            animation: staggerFade 0.6s ease-out forwards; 
        }
        .bottom-cards .b-card:nth-child(1) { animation-delay: 0.3s; }
        .bottom-cards .b-card:nth-child(2) { animation-delay: 0.45s; }
        .bottom-cards .b-card:nth-child(3) { animation-delay: 0.6s; }

        @media (max-width: 768px) {
            .stepper-container { padding: 30px 20px 10px; }
            .stepper-line { left: 50px; right: 50px; }
            .section-header { margin: 25px; flex-direction: column; align-items: flex-start; }
            .form-body { padding: 0 25px 20px; }
            .bottom-actions { padding: 20px 25px; flex-direction: column; gap: 15px; }
            .btn-continue, .btn-back { width: 100%; }
            .brand-header h1 { font-size: 2.2rem; }
            .brand-header .subtext { font-size: 0.75rem; letter-spacing: 1px; }
        }
    </style>
</head>
<body>

<div class="brand-header">
    <?php if (!empty($logo) && file_exists('uploads/branding/' . $logo)): ?>
        <img src="uploads/branding/<?php echo htmlspecialchars($logo); ?>" alt="Logo">
    <?php else: ?>
        <img src="assets/logo/school.png" onerror="this.src='https://via.placeholder.com/80?text=LOGO'" alt="Logo">
    <?php endif; ?>
    <h1><?php echo htmlspecialchars($school_name ?? 'Orange Lake School'); ?></h1>
    <div class="subtext">EXCELLENCE &bull; CHARACTER &bull; COMMUNITY</div>
    <div class="pill"><i class="fa fa-layer-group me-2"></i> GENERAL ENQUIRY 2025-26</div>
</div>

<div class="form-wrapper">
    <div class="form-top-line"></div>
    
    <?php if ($msg): ?>
        <div class="p-5 text-center my-5">
            <i class="fa fa-check-circle fa-4x mb-4" style="color: #198754;"></i>
            <h2 class="fw-bold text-dark mb-3">Enquiry Submitted!</h2>
            <p class="text-muted" style="font-size: 1.1rem;"><?php echo $msg; ?></p>
            <a href="index.php" class="btn-continue mx-auto mt-4" style="text-decoration:none; width: fit-content;">Return to Home</a>
        </div>
    <?php else: ?>

    <div class="stepper-container d-flex justify-content-between">
        <div class="stepper-line"></div>
        <div class="stepper-line-active" id="sLine"></div>
        
        <div class="step-item active" id="si-1">
            <div class="step-circle">1</div>
            <div class="step-label">VISITOR</div>
        </div>
        <div class="step-item" id="si-2">
            <div class="step-circle">2</div>
            <div class="step-label">STUDENT</div>
        </div>
        <div class="step-item" id="si-3">
            <div class="step-circle">3</div>
            <div class="step-label">DETAILS</div>
        </div>
    </div>

    <form method="POST" id="customForm">
        <?php if ($err): ?><div class="alert alert-danger mx-5 mt-4"><i class="fa fa-exclamation-triangle"></i> <?php echo $err; ?></div><?php endif; ?>
        
        <!-- STEP 1 -->
        <div class="step-pane active" id="sp-1">
            <div class="section-header">
                <div class="section-icon"><i class="fa fa-user"></i></div>
                <div>
                    <h3 class="section-title">Visitor Information</h3>
                    <p class="section-desc">Tell us your basic details to help us contact you.</p>
                </div>
            </div>
            
            <div class="info-alert">
                <i class="fa fa-info-circle"></i> <span>Fields marked with <span style="color:#c2410c; margin: 0 2px;">*</span> are required.</span>
            </div>

            <div class="form-body row g-4">
                <div class="col-md-12">
                    <label class="form-label">FULL NAME <span class="req">*</span></label>
                    <div class="input-group-custom">
                        <i class="fa fa-user input-icon"></i>
                        <input type="text" name="visitor_name" class="custom-input" placeholder="e.g. Aarav Sharma" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">PHONE NUMBER <span class="req">*</span></label>
                    <div class="input-group-custom">
                        <i class="fa fa-phone input-icon"></i>
                        <input type="text" name="phone" class="custom-input" placeholder="e.g. +91 9876543210" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">EMAIL ADDRESS</label>
                    <div class="input-group-custom">
                        <i class="fa fa-envelope input-icon"></i>
                        <input type="email" name="email" class="custom-input" placeholder="e.g. email@example.com">
                    </div>
                </div>
            </div>
            
            <div class="bottom-actions">
                <span class="step-progress-text">Step 1 of 3</span>
                <button type="button" class="btn-continue" onclick="valAndNext(1, 2)">Continue <i class="fa fa-arrow-right"></i></button>
            </div>
        </div>

        <!-- STEP 2 -->
        <div class="step-pane" id="sp-2">
            <div class="section-header">
                <div class="section-icon" style="background: rgba(13, 110, 253, 0.1); color: #0d6efd;"><i class="fa fa-user-graduate"></i></div>
                <div>
                    <h3 class="section-title">Student Details</h3>
                    <p class="section-desc">If applicable, provide details of the student.</p>
                </div>
            </div>

            <div class="form-body row g-4">
                <div class="col-md-12">
                    <label class="form-label">STUDENT NAME</label>
                    <div class="input-group-custom">
                        <i class="fa fa-child input-icon"></i>
                        <input type="text" name="student_name" class="custom-input" placeholder="e.g. Vivaan Sharma">
                    </div>
                    <div class="mt-2 text-muted" style="font-size:0.85rem;"><i class="fa fa-info-circle me-1"></i> Optional if inquiry is general.</div>
                </div>
            </div>
            
            <div class="bottom-actions" style="justify-content: flex-start; gap: 15px;">
                <button type="button" class="btn-back" onclick="goPrev(2, 1)">Back</button>
                <div style="flex-grow:1; text-align:center;"><span class="step-progress-text d-none d-md-inline">Step 2 of 3</span></div>
                <button type="button" class="btn-continue" style="min-width: 180px;" onclick="valAndNext(2, 3)">Continue <i class="fa fa-arrow-right"></i></button>
            </div>
        </div>

        <!-- STEP 3 -->
        <div class="step-pane" id="sp-3">
            <div class="section-header">
                <div class="section-icon" style="background: rgba(25, 135, 84, 0.1); color: #198754;"><i class="fa fa-paper-plane"></i></div>
                <div>
                    <h3 class="section-title">Message Details</h3>
                    <p class="section-desc">What is this inquiry about?</p>
                </div>
            </div>

            <div class="info-alert">
                <i class="fa fa-info-circle"></i> <span>Fields marked with <span style="color:#c2410c; margin: 0 2px;">*</span> are required.</span>
            </div>

            <div class="form-body row g-4">
                <div class="col-md-12">
                    <label class="form-label">INQUIRY TYPE <span class="req">*</span></label>
                    <div class="input-group-custom">
                        <i class="fa fa-list input-icon"></i>
                        <select name="inquiry_type" class="custom-input" required>
                            <option value="">Select Category</option>
                            <option value="Admission">Admission Enquiry</option>
                            <option value="Fees/Finance">Fees & Finance</option>
                            <option value="Complaints">Feedback / Complaints</option>
                            <option value="General">General Enquiry</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-12">
                    <label class="form-label">MESSAGE / DETAILS <span class="req">*</span></label>
                    <div class="input-group-custom">
                        <textarea name="message" class="custom-input" rows="4" placeholder="Enter your detailed message here..." required style="padding-left:15px;"></textarea>
                    </div>
                </div>
            </div>
            
            <div class="bottom-actions" style="justify-content: flex-start; gap: 15px;">
                <button type="button" class="btn-back" onclick="goPrev(3, 2)">Back</button>
                <div style="flex-grow:1; text-align:center;"><span class="step-progress-text d-none d-md-inline">Step 3 of 3</span></div>
                <button type="submit" name="submit_inquiry" class="btn-continue" style="background: #198754; box-shadow: 0 10px 20px rgba(25,135,84,0.2);">Submit Enquiry <i class="fa fa-check"></i></button>
            </div>
        </div>
    </form>
    <?php endif; ?>
</div>

<!-- Bottom Info Cards -->
<?php if (!$msg): ?>
<div class="bottom-cards pb-5">
    <div class="b-card">
        <div class="b-card-icon orange"><i class="fa fa-graduation-cap"></i></div>
        <div>
            <div class="b-card-title">ICSE Affiliated</div>
            <div class="b-card-desc">Nationally recognized curriculum with holistic approach</div>
        </div>
    </div>
    <div class="b-card">
        <div class="b-card-icon blue"><i class="fa fa-users"></i></div>
        <div>
            <div class="b-card-title">Expert Faculty</div>
            <div class="b-card-desc">Qualified, experienced & dedicated teaching staff</div>
        </div>
    </div>
    <div class="b-card">
        <div class="b-card-icon green"><i class="fa fa-check"></i></div>
        <div>
            <div class="b-card-title">Admissions Open</div>
            <div class="b-card-desc">2025-26 session — limited seats available</div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
function valAndNext(current, next) {
    let pane = document.getElementById('sp-' + current);
    let inputs = pane.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(inp => {
        if (!inp.value.trim()) {
            isValid = false;
            inp.style.borderColor = '#dc3545';
        } else {
            inp.style.borderColor = '#e9ecef';
        }
    });

    if (isValid) {
        document.getElementById('sp-' + current).classList.remove('active');
        document.getElementById('sp-' + next).classList.add('active');
        updateUI(next);
    }
}

function goPrev(current, prev) {
    document.getElementById('sp-' + current).classList.remove('active');
    document.getElementById('sp-' + prev).classList.add('active');
    updateUI(prev);
}

function updateUI(step) {
    // line
    const p = step === 1 ? 0 : (step === 2 ? 50 : 100);
    document.getElementById('sLine').style.width = p + '%';
    
    // circles
    for(let i=1; i<=3; i++) {
        let si = document.getElementById('si-' + i);
        si.classList.remove('active', 'completed');
        if(i < step) si.classList.add('completed');
        if(i === step) si.classList.add('active');
    }
}
</script>

</body>
</html>

function nextStep(currentStep) {
    let stepContent = document.getElementById('step' + currentStep);
    let inputs = stepContent.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;

    inputs.forEach(input => {
        if (input.offsetParent !== null && !input.value) {
            isValid = false;
            input.classList.add('is-invalid');
        } else {
            input.classList.remove('is-invalid');
        }
    });

    if (currentStep === 7) {
        let pass = document.getElementById('pass').value;
        let cpass = document.getElementById('cpass').value;
        if (pass !== cpass) {
            alert('Passwords do not match!');
            return;
        }
    }

    if (isValid) {
        let next = currentStep + 1;
        let nContent = document.getElementById('step' + next);
        if (nContent) {
            stepContent.classList.remove('active');
            stepContent.style.display = 'none';

            nContent.classList.add('active');
            nContent.style.display = 'block';

            document.querySelectorAll('.step-item').forEach(i => i.classList.remove('active'));
            for (let i = 1; i <= next; i++) document.querySelector('.step-item[data-step="' + i + '"]').classList.add('active');

            document.getElementById('progressBar').style.width = ((next / 7) * 100) + '%';
        }
    } else alert('Please fill all required valid fields.');
}

function prevStep(currentStep) {
    let prev = currentStep - 1;
    let pContent = document.getElementById('step' + prev);
    if (pContent) {
        let stepContent = document.getElementById('step' + currentStep);
        stepContent.classList.remove('active');
        stepContent.style.display = 'none';

        pContent.classList.add('active');
        pContent.style.display = 'block';

        document.querySelectorAll('.step-item').forEach(i => i.classList.remove('active'));
        for (let i = 1; i <= prev; i++) document.querySelector('.step-item[data-step="' + i + '"]').classList.add('active');

        document.getElementById('progressBar').style.width = ((prev / 7) * 100) + '%';
    }
}

document.getElementById('dobInput')?.addEventListener('change', function () {
    let dob = new Date(this.value);
    let today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    let m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
    document.getElementById('ageDisplay').value = age > 0 ? age + ' yrs' : '0 yrs';
});

document.querySelectorAll('.trigger-show').forEach(el => {
    el.addEventListener('change', function () {
        let target = document.getElementById(this.getAttribute('data-target'));
        if (this.value === 'Yes') {
            target.style.display = 'block';
            target.querySelector('textarea, input').setAttribute('required', 'required');
        } else {
            target.style.display = 'none';
            target.querySelector('textarea, input').removeAttribute('required');
            target.querySelector('textarea, input').value = '';
        }
    });
});

document.querySelectorAll('input[required], select[required], textarea[required]').forEach(el => {
    let div = document.createElement('div');
    div.className = 'invalid-feedback fw-bold';
    div.innerHTML = '<i class="fa fa-warning"></i> This field cannot be left blank.';
    el.parentNode.insertBefore(div, el.nextSibling);
});

document.getElementById('academicTrigger')?.addEventListener('change', function () {
    let fields = document.getElementById('academicFields');
    let alertBox = document.getElementById('noAcademicAlert');
    if (this.value === 'Never Attended School') {
        fields.style.display = 'none';
        alertBox.style.display = 'block';
        fields.querySelectorAll('.req-acad').forEach(i => {
            i.removeAttribute('required');
            i.value = '';
        });
    } else {
        fields.style.display = 'flex';
        alertBox.style.display = 'none';
        fields.querySelectorAll('.req-acad').forEach(i => i.setAttribute('required', 'required'));
    }
});

document.getElementById('gName')?.addEventListener('input', function () {
    let guards = document.querySelectorAll('.g-field');
    if (this.value.trim().length > 0) {
        guards.forEach(g => {
            g.style.display = 'block';
            g.querySelector('.req-guard').setAttribute('required', 'required');
        });
    } else {
        guards.forEach(g => {
            g.style.display = 'none';
            let el = g.querySelector('.req-guard');
            el.removeAttribute('required');
            el.value = '';
        });
    }
});

function saveDraft() {
    let data = {};
    document.querySelectorAll('#admissionForm input, #admissionForm select, #admissionForm textarea').forEach(el => {
        if (el.name && el.type !== 'file' && el.type !== 'password') {
            if (el.type === 'checkbox') {
                data[el.name] = el.checked;
            } else if (el.type === 'radio') {
                if (el.checked) data[el.name] = el.value;
            } else {
                data[el.name] = el.value;
            }
        }
    });
    localStorage.setItem('admission_draft', JSON.stringify(data));
    alert('Form saved as draft successfully! You can resume from this browser later.');
}

function loadDraft() {
    let draft = localStorage.getItem('admission_draft');
    if (draft) {
        let data = JSON.parse(draft);
        document.querySelectorAll('#admissionForm input, #admissionForm select, #admissionForm textarea').forEach(el => {
            if (el.name && data[el.name] !== undefined) {
                if (el.type === 'checkbox') {
                    el.checked = data[el.name];
                } else if (el.type === 'radio') {
                    if (el.value === data[el.name]) el.checked = true;
                } else {
                    el.value = data[el.name];
                }
            }
        });
    }
}

document.addEventListener('DOMContentLoaded', function () {
    loadDraft();

    document.querySelectorAll('.step-content').forEach(s => {
        if (!s.classList.contains('active')) s.style.display = 'none';
    });
    document.querySelectorAll('.hidden-section').forEach(s => s.style.display = 'none');
    document.getElementById('academicFields').style.display = 'flex';
    document.getElementById('progressBar').style.width = '14%';
});

/**
 * Shared Age Calculation Logic
 * Calculates age based on DOB and current date, considering month and day.
 */
function calculateAge(dobString) {
    if (!dobString) return "";
    const dob = new Date(dobString);
    if (isNaN(dob.getTime())) return "";
    
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
        age--;
    }
    
    return age >= 0 ? age : 0;
}

// Function to attach listener to a DOB field and update an Age field
function attachAgeCalculator(dobId, ageId) {
    const dobEl = document.getElementById(dobId);
    const ageEl = document.getElementById(ageId);
    
    if (dobEl && ageEl) {
        dobEl.addEventListener('change', function() {
            const age = calculateAge(this.value);
            ageEl.value = age;
        });
        
        // Initial calculation if DOB is already set
        if (dobEl.value) {
            ageEl.value = calculateAge(dobEl.value);
        }
    }
}

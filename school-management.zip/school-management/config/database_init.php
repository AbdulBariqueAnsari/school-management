<?php
// config/database_init.php
// Ensures required tables for admissions exist

$pdo->exec("CREATE TABLE IF NOT EXISTS admission_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(150),
    gender VARCHAR(10),
    dob DATE,
    blood_group VARCHAR(10),
    aadhaar_number VARCHAR(20),
    class_applied VARCHAR(50),
    mobile_number VARCHAR(20),
    address TEXT,
    parent_name VARCHAR(150),
    parent_email VARCHAR(150),
    parent_phone VARCHAR(20),
    father_name VARCHAR(150),
    father_mobile VARCHAR(20),
    mother_name VARCHAR(150),
    mother_mobile VARCHAR(20),
    parents_address TEXT,
    guardian_name VARCHAR(150),
    relation VARCHAR(100),
    guardian_mobile VARCHAR(20),
    guardian_address TEXT,
    religion VARCHAR(50),
    caste_category VARCHAR(50),
    mother_tongue VARCHAR(100),
    has_medical_condition TINYINT DEFAULT 0,
    medical_condition_desc TEXT,
    has_disability TINYINT DEFAULT 0,
    disability_desc TEXT,
    has_allergies TINYINT DEFAULT 0,
    allergies_desc TEXT,
    previous_schooling_status VARCHAR(100),
    previous_class VARCHAR(50),
    previous_school_name VARCHAR(150),
    previous_board VARCHAR(100),
    year_of_passing INT,
    previous_school VARCHAR(150),
    guardian_details TEXT,
    student_photo VARCHAR(255),
    admission_no VARCHAR(20),
    status VARCHAR(20) DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) engine=InnoDB;");

// Defensive: add any missing columns to existing admission_requests tables
$admission_extra_cols = [
    "blood_group VARCHAR(10)",
    "aadhaar_number VARCHAR(20)",
    "mobile_number VARCHAR(20)",
    "father_name VARCHAR(150)",
    "father_mobile VARCHAR(20)",
    "mother_name VARCHAR(150)",
    "mother_mobile VARCHAR(20)",
    "parents_address TEXT",
    "guardian_name VARCHAR(150)",
    "relation VARCHAR(100)",
    "guardian_mobile VARCHAR(20)",
    "guardian_address TEXT",
    "religion VARCHAR(50)",
    "caste_category VARCHAR(50)",
    "mother_tongue VARCHAR(100)",
    "has_medical_condition TINYINT DEFAULT 0",
    "medical_condition_desc TEXT",
    "has_disability TINYINT DEFAULT 0",
    "disability_desc TEXT",
    "has_allergies TINYINT DEFAULT 0",
    "allergies_desc TEXT",
    "previous_schooling_status VARCHAR(100)",
    "previous_class VARCHAR(50)",
    "previous_school_name VARCHAR(150)",
    "previous_board VARCHAR(100)",
    "year_of_passing INT",
    "previous_school VARCHAR(150)",
    "admission_no VARCHAR(20)",
];
foreach ($admission_extra_cols as $col_def) {
    $col_name = explode(' ', $col_def)[0];
    try {
        $pdo->exec("ALTER TABLE admission_requests ADD COLUMN $col_def");
    }
    catch (Exception $e) {
    }
}


$pdo->exec("CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admission_no VARCHAR(50),
    student_name VARCHAR(100),
    gender VARCHAR(10),
    dob DATE,
    class VARCHAR(50),
    parent_name VARCHAR(100),
    parent_email VARCHAR(150),
    photo VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

$pdo->exec("CREATE TABLE IF NOT EXISTS parents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    father_name VARCHAR(150),
    father_mobile VARCHAR(20),
    mother_name VARCHAR(150),
    mother_mobile VARCHAR(20),
    parents_address TEXT
)");

$pdo->exec("CREATE TABLE IF NOT EXISTS health_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    has_medical_condition TINYINT,
    medical_condition_desc TEXT,
    has_disability TINYINT,
    disability_desc TEXT,
    has_allergies TINYINT,
    allergies_desc TEXT
)");

$pdo->exec("CREATE TABLE IF NOT EXISTS academic_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    previous_schooling_status VARCHAR(100),
    previous_class VARCHAR(50),
    previous_school_name VARCHAR(150),
    previous_board VARCHAR(100),
    year_of_passing INT
)");

// system_settings: stores school branding for PDF exports and headers
$pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    school_name VARCHAR(150) DEFAULT 'School Management System',
    school_logo VARCHAR(255) DEFAULT NULL,
    school_address TEXT DEFAULT NULL,
    school_phone VARCHAR(50) DEFAULT NULL,
    school_email VARCHAR(150) DEFAULT NULL
)");

// Ensure at least one default settings row exists
$pdo->exec("INSERT INTO system_settings (id, school_name)
    SELECT 1, 'School Management System'
    WHERE NOT EXISTS (SELECT 1 FROM system_settings WHERE id = 1)");

// Defensive columns for students table — skip if column already exists
$student_extra_cols = [
    "application_id INT DEFAULT NULL",
    "parent_phone VARCHAR(20) DEFAULT NULL",
    "is_active TINYINT DEFAULT 1",
    "blood_group VARCHAR(10) DEFAULT NULL",
    "aadhaar_number VARCHAR(20) DEFAULT NULL",
    "mobile_number VARCHAR(20) DEFAULT NULL",
    "address TEXT DEFAULT NULL",
    "father_name VARCHAR(150) DEFAULT NULL",
    "father_mobile VARCHAR(20) DEFAULT NULL",
    "mother_name VARCHAR(150) DEFAULT NULL",
    "mother_mobile VARCHAR(20) DEFAULT NULL",
    "parents_address TEXT DEFAULT NULL",
    "guardian_name VARCHAR(150) DEFAULT NULL",
    "relation VARCHAR(100) DEFAULT NULL",
    "guardian_mobile VARCHAR(20) DEFAULT NULL",
    "guardian_address TEXT DEFAULT NULL",
    "religion VARCHAR(50) DEFAULT NULL",
    "caste_category VARCHAR(50) DEFAULT NULL",
    "mother_tongue VARCHAR(100) DEFAULT NULL",
    "has_medical_condition TINYINT DEFAULT 0",
    "medical_condition_desc TEXT DEFAULT NULL",
    "has_disability TINYINT DEFAULT 0",
    "disability_desc TEXT DEFAULT NULL",
    "has_allergies TINYINT DEFAULT 0",
    "allergies_desc TEXT DEFAULT NULL",
    "previous_schooling_status VARCHAR(100) DEFAULT NULL",
    "previous_class VARCHAR(50) DEFAULT NULL",
    "previous_school_name VARCHAR(150) DEFAULT NULL",
    "previous_board VARCHAR(100) DEFAULT NULL",
    "year_of_passing INT DEFAULT NULL",
    "previous_school VARCHAR(150) DEFAULT NULL",
    "guardian_details TEXT DEFAULT NULL",
    "admission_date DATE DEFAULT NULL"
];

foreach ($student_extra_cols as $col_def) {
    $col_name = explode(' ', $col_def)[0];
    try {
        $pdo->exec("ALTER TABLE students ADD COLUMN $col_def");
    }
    catch (Exception $e) {
// ... (rest omitted, replacing just the end)
    }
}

$pdo->exec("CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT,
    receiver_id INT,
    message TEXT,
    sender_role VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

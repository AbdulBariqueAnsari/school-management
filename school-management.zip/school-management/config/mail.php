<?php
// config/mail.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer classes
require_once BASE_PATH . '/includes/PHPMailer/Exception.php';
require_once BASE_PATH . '/includes/PHPMailer/PHPMailer.php';
require_once BASE_PATH . '/includes/PHPMailer/SMTP.php';

// Update these with actual SMTP credentials to send live emails
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com'); 
define('SMTP_PASS', 'your-app-password'); 
define('SMTP_FROM_EMAIL', 'no-reply@school.com');
define('SMTP_FROM_NAME', 'School Management System');

/**
 * Send an email using PHPMailer
 * @param string $to Recipient email address
 * @param string $subject Email subject
 * @param string $message Email body (HTML supported)
 * @return bool True on success, false on failure
 */
function sendTemplateEmail($to, $subject, $message)
{
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;

        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        
        // Wrap message in a basic HTML template
        $htmlMsg = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 10px; background-color: #f8fafc;'>
            <h2 style='color: #2563eb; margin-top: 0;'>" . SMTP_FROM_NAME . "</h2>
            <div style='background-color: #ffffff; padding: 20px; border-radius: 8px; font-size: 16px; color: #334155; line-height: 1.5;'>
                " . nl2br($message) . "
            </div>
            <div style='margin-top: 20px; font-size: 12px; color: #94a3b8; text-align: center;'>
                This is an automated message from the School ERP system. Please do not reply.
            </div>
        </div>
        ";
        
        $mail->Body = $htmlMsg;
        $mail->AltBody = strip_tags($message);

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Mail Error: {$mail->ErrorInfo}");
        return false;
    }
}
?>

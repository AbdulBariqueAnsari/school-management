<?php
require 'includes/init.php';
try {
    $pdo->exec("ALTER TABLE admission_applications ADD COLUMN admission_number VARCHAR(20) NULL UNIQUE");
    $pdo->exec("ALTER TABLE students ADD COLUMN admission_number VARCHAR(20) NULL UNIQUE");
    echo "Columns correctly added.";
}
catch (Exception $e) {
    if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
        echo "Columns already exist.";
    }
    else {
        echo "Error: " . $e->getMessage();
    }
}

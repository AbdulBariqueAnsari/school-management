<?php
require 'config/db.php';

try {
    $pdo->beginTransaction();

    // 1. Update all existing users
    echo "Updating existing users...\n";
    $users = $pdo->query("SELECT id, role_id FROM users")->fetchAll();
    $updateUserStmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");

    $updatedExistingCount = 0;
    foreach ($users as $user) {
        $id = $user['id'];
        $role = $user['role_id'];
        $password = password_hash('Password123', PASSWORD_BCRYPT);
        
        if ($role == 1) { // Super Admin
            $username = 'superadmin';
            $email = 'superadmin@school.com';
            $password = password_hash('SuperPassword123!', PASSWORD_BCRYPT);
        } elseif ($role == 2) { // Principal
            $username = 'principal';
            $email = 'principal@school.com';
        } elseif ($role == 3) { // Clerk
            $username = 'clerk';
            $email = 'clerk@school.com';
        } elseif (in_array($role, [4, 5, 8])) { // Teacher
            $username = 'teacher_' . $id;
            $email = 'teacher' . $id . '@school.com';
        } elseif ($role == 6) { // Student
            $username = 'student_' . $id;
            $email = 'student' . $id . '@school.com';
        } elseif ($role == 7) { // Parent
            $username = 'parent_' . $id;
            $email = 'parent' . $id . '@school.com';
        } else {
            $username = 'user_' . $id;
            $email = 'user' . $id . '@school.com';
        }

        $updateUserStmt->execute([$username, $email, $password, $id]);
        $updatedExistingCount++;
    }
    echo "Updated $updatedExistingCount existing users.\n";

    // 2. Sync missing students
    echo "Syncing missing students...\n";
    $missingStudents = $pdo->query("
        SELECT id, student_name FROM students 
        WHERE user_id IS NULL OR user_id NOT IN (SELECT id FROM users)
    ")->fetchAll();

    $insertUserStmt = $pdo->prepare("INSERT INTO users (name, username, email, password, role_id, is_active) VALUES (?, ?, ?, ?, 6, 1)");
    $linkStudentStmt = $pdo->prepare("UPDATE students SET user_id = ? WHERE id = ?");

    $syncedStudents = 0;
    foreach ($missingStudents as $student) {
        $tempEmail = 'temp_s' . $student['id'] . '@school.com';
        $tempUser = 'temp_s' . $student['id'];
        $passHash = password_hash('Password123', PASSWORD_BCRYPT);
        
        $name = $student['student_name'] ?: 'Student ' . $student['id'];
        $insertUserStmt->execute([$name, $tempUser, $tempEmail, $passHash]);
        $newUserId = $pdo->lastInsertId();
        
        // Finalize username/email for the new user
        $finalUser = 'student_' . $newUserId;
        $finalEmail = 'student' . $newUserId . '@school.com';
        $updateUserStmt->execute([$finalUser, $finalEmail, $passHash, $newUserId]);
        
        // Link students table
        $linkStudentStmt->execute([$newUserId, $student['id']]);
        $syncedStudents++;
    }
    echo "Synced $syncedStudents missing student user accounts.\n";

    // 3. Sync missing teachers (if any)
    // Check if teachers table exists and has user_id
    $syncTeachers = 0;
    try {
        $missingTeachers = $pdo->query("
            SELECT id, name FROM teachers 
            WHERE user_id IS NULL OR user_id NOT IN (SELECT id FROM users)
        ")->fetchAll();

        $insertTeacherUserStmt = $pdo->prepare("INSERT INTO users (name, username, email, password, role_id, is_active) VALUES (?, ?, ?, ?, 8, 1)");
        $linkTeacherStmt = $pdo->prepare("UPDATE teachers SET user_id = ? WHERE id = ?");

        foreach ($missingTeachers as $teacher) {
            $tempEmail = 'temp_t' . $teacher['id'] . '@school.com';
            $tempUser = 'temp_t' . $teacher['id'];
            $passHash = password_hash('Password123', PASSWORD_BCRYPT);
            
            $name = $teacher['name'] ?: 'Teacher ' . $teacher['id'];
            $insertTeacherUserStmt->execute([$name, $tempUser, $tempEmail, $passHash]);
            $newUserId = $pdo->lastInsertId();
            
            $finalUser = 'teacher_' . $newUserId;
            $finalEmail = 'teacher' . $newUserId . '@school.com';
            $updateUserStmt->execute([$finalUser, $finalEmail, $passHash, $newUserId]);
            
            $linkTeacherStmt->execute([$newUserId, $teacher['id']]);
            $syncTeachers++;
        }
    } catch (Exception $e) { /* teachers table might not have user_id or exist */ }
    echo "Synced $syncTeachers missing teacher user accounts.\n";

    $pdo->commit();
    echo "SUCCESS: Database updated and synced.\n";

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo "FATAL ERROR: " . $e->getMessage() . "\n";
}

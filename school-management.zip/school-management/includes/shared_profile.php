<?php
// includes/shared_profile.php
// A premium, universal profile viewer & password manager for staff and parents.

require_once __DIR__ . '/auth.php';

$user_id = (int)$_SESSION['user_id'];
$message = '';

// Fetch user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'update_personal') {
            $name = trim($_POST['name'] ?? '');
            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $dob = $_POST['dob'] ?? null;
            $gender = $_POST['gender'] ?? null;
            $address = trim($_POST['address'] ?? '');

            if (empty($name) || empty($email)) {
                throw new Exception('Name and Email are required.');
            }

            // Check username uniqueness if modified
            if (!empty($username) && $username !== ($user['username'] ?? '')) {
                $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND id != ?");
                $check->execute([$username, $user_id]);
                if ($check->fetchColumn() > 0) {
                    throw new Exception('Username already taken.');
                }
            }

            $photo_query = "";
            $params = [
                ':name' => $name,
                ':username' => !empty($username) ? $username : null,
                ':email' => $email,
                ':phone' => !empty($phone) ? $phone : null,
                ':dob' => !empty($dob) ? $dob : null,
                ':gender' => !empty($gender) ? $gender : null,
                ':address' => !empty($address) ? $address : null,
                ':id' => $user_id
            ];

            if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] == UPLOAD_ERR_OK) {
                $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
                if (!in_array($_FILES['profile_photo']['type'], $allowed_types)) {
                    throw new Exception('Invalid image format. Only JPG, PNG, and GIF allowed.');
                }
                if ($_FILES['profile_photo']['size'] > 2 * 1024 * 1024) {
                    throw new Exception('Image size cannot exceed 2MB.');
                }

                $ext = pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION);
                $filename = uniqid('profile_') . '.' . $ext;
                $upload_dir = __DIR__ . '/../uploads/profile/';

                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }

                if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $upload_dir . $filename)) {
                    $photo_query = ", profile_photo = :photo";
                    $params[':photo'] = $filename;
                }
            }

            $sql = "UPDATE users SET name = :name, username = :username, email = :email, phone = :phone, dob = :dob, gender = :gender, address = :address $photo_query WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            $_SESSION['user_name'] = $name; // Update active session
            logActivity('Updated personal profile information');
            
            $message = '<div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" style="border-radius:12px;"><i class="fa-solid fa-circle-check me-2"></i>Profile updated successfully!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';

            // Refresh user variable
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

        } elseif ($action === 'update_password') {
            $new_pass = $_POST['new_password'] ?? '';
            $confirm_pass = $_POST['confirm_password'] ?? '';

            if (strlen($new_pass) < 6) {
                throw new Exception('Password must be at least 6 characters long.');
            }

            if ($new_pass !== $confirm_pass) {
                throw new Exception('Passwords do not match.');
            }

            $hash = password_hash($new_pass, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hash, $user_id]);

            logActivity('Successfully changed profile password');
            $message = '<div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" style="border-radius:12px;"><i class="fa-solid fa-lock me-2"></i>Password successfully updated!<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        }
    } catch (Exception $e) {
        $message = '<div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm" style="border-radius:12px;"><i class="fa-solid fa-triangle-exclamation me-2"></i>' . htmlspecialchars($e->getMessage()) . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}

require_once __DIR__ . '/header.php';
?>

<style>
/* ============================================================
   PREMIUM GLASSMORPHIC PROFILE CONTAINER
   ============================================================ */
.profile-hub-header {
    background: linear-gradient(135deg, #1e1e38 0%, #151528 100%);
    border-radius: 20px;
    padding: 35px;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}
.profile-hub-header::before {
    content:''; position:absolute; top:-50px; right:-50px;
    width:180px; height:180px; background:rgba(255,255,255,0.04); border-radius:50%;
}
.profile-hub-header h2 { color:#fff; font-weight:800; }
.profile-hub-header p { color:rgba(255,255,255,0.6); margin:0; }

.profile-card {
    background: rgba(255, 255, 255, 0.7);
    backdrop-filter: blur(15px);
    -webkit-backdrop-filter: blur(15px);
    border: 1px solid rgba(255, 255, 255, 0.5);
    border-radius: 20px;
    box-shadow: 0 12px 40px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
}

.profile-pill-button {
    border-radius: 12px;
    font-weight: 600;
    text-align: left;
    padding: 12px 18px;
    margin-bottom: 8px;
    transition: all 0.25s ease;
    border: none;
    background: transparent;
    color: #4b5563;
}
.profile-pill-button.active {
    background: #0d6efd !important;
    color: #fff !important;
    box-shadow: 0 8px 20px rgba(13, 110, 253, 0.25);
}
.profile-pill-button:hover:not(.active) {
    background: rgba(13, 110, 253, 0.08);
    color: #0d6efd;
}
</style>

<div class="container-fluid py-4">
    
    <!-- Header Block -->
    <div class="profile-hub-header d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h2><i class="fa fa-user-circle me-2 text-primary"></i> <?php echo htmlspecialchars($portal_title ?? 'My Profile'); ?></h2>
            <p>Update your personal information, manage security configurations, and customize your profile photo.</p>
        </div>
        <a href="dashboard.php" class="btn btn-outline-light border-0 px-4 py-2" style="background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-radius: 12px;">
            <i class="fa fa-arrow-left me-2"></i> Dashboard
        </a>
    </div>

    <!-- Alert Messaging -->
    <div id="shared-alert-container">
        <?php echo $message; ?>
    </div>

    <div class="row g-4">
        <!-- Navigation Sidebar Tabs -->
        <div class="col-lg-3">
            <div class="profile-card p-3">
                <div class="d-flex flex-column nav-pills" id="profile-tab" role="tablist">
                    <button class="profile-pill-button active" id="pill-personal-tab" data-bs-toggle="pill" data-bs-target="#pill-personal" type="button" role="tab"><i class="fa-solid fa-id-card me-2"></i> Personal Details</button>
                    <button class="profile-pill-button" id="pill-security-tab" data-bs-toggle="pill" data-bs-target="#pill-security" type="button" role="tab"><i class="fa-solid fa-lock me-2"></i> Security Settings</button>
                </div>
            </div>
        </div>

        <!-- Forms Content Panel -->
        <div class="col-lg-9">
            <div class="profile-card p-4 p-md-5">
                <div class="tab-content" id="profile-tabContent">
                    
                    <!-- TAB A: Personal Information -->
                    <div class="tab-pane fade show active" id="pill-personal" role="tabpanel">
                        <h4 class="fw-bold mb-4 text-dark border-bottom pb-2">Personal Details</h4>
                        
                        <form method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="update_personal">
                            
                            <!-- Profile Photo -->
                            <div class="row align-items-center mb-4">
                                <div class="col-auto">
                                    <?php 
                                    $photo = $user['profile_photo'] ?? '';
                                    $avatar = $photo ? BASE_URL . '/uploads/profile/' . htmlspecialchars($photo) : BASE_URL . '/assets/images/default-avatar.png';
                                    ?>
                                    <img src="<?php echo $avatar; ?>" class="rounded-circle border" width="100" height="100" style="object-fit: cover;" id="profile_pic_preview" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($user['name']); ?>&background=0D8ABC&color=fff';">
                                </div>
                                <div class="col">
                                    <label class="form-label fw-bold text-secondary mb-1">Profile Avatar</label>
                                    <input class="form-control" type="file" name="profile_photo" accept="image/jpeg,image/png,image/gif" onchange="previewAvatar(this)">
                                    <small class="text-muted d-block mt-1">Accepted: JPG, PNG, GIF. Max size: 2MB.</small>
                                </div>
                            </div>

                            <!-- Basic Fields -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-secondary">Full Name</label>
                                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required style="border-radius: 10px;">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-secondary">Username</label>
                                    <input type="text" name="username" class="form-control" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" style="border-radius: 10px;">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-secondary">Email Address</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required style="border-radius: 10px;">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-secondary">Contact Number</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" style="border-radius: 10px;">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-secondary">Date of Birth</label>
                                    <input type="date" name="dob" class="form-control" value="<?php echo htmlspecialchars($user['dob'] ?? ''); ?>" style="border-radius: 10px;">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-secondary">Gender</label>
                                    <select name="gender" class="form-select" style="border-radius: 10px;">
                                        <option value="">Select Gender</option>
                                        <option value="Male" <?php echo (($user['gender'] ?? '') === 'Male') ? 'selected' : ''; ?>>Male</option>
                                        <option value="Female" <?php echo (($user['gender'] ?? '') === 'Female') ? 'selected' : ''; ?>>Female</option>
                                        <option value="Other" <?php echo (($user['gender'] ?? '') === 'Other') ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold text-secondary">Address Description</label>
                                <textarea name="address" class="form-control" rows="3" style="border-radius: 10px;"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary px-4 py-2" style="border-radius: 10px;">
                                <i class="fa fa-save me-2"></i> Save Profile Details
                            </button>
                        </form>
                    </div>

                    <!-- TAB B: Change Password -->
                    <div class="tab-pane fade" id="pill-security" role="tabpanel">
                        <h4 class="fw-bold mb-4 text-dark border-bottom pb-2">Change Password</h4>
                        
                        <form method="POST">
                            <input type="hidden" name="action" value="update_password">

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-secondary">New Password</label>
                                    <input type="password" name="new_password" class="form-control" required minlength="6" style="border-radius: 10px;">
                                    <small class="text-muted mt-1 d-block">Choose a strong password containing at least 6 characters.</small>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-secondary">Confirm New Password</label>
                                    <input type="password" name="confirm_password" class="form-control" required minlength="6" style="border-radius: 10px;">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-warning px-4 py-2 fw-semibold mt-3" style="border-radius: 10px;">
                                <i class="fa fa-lock me-2"></i> Update Password Security
                            </button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    // Hash routing for tabs setup
    let hash = window.location.hash;
    if (hash) {
        let activeTab = document.querySelector('button[data-bs-target="' + hash.replace('#', '#pill-') + '"]');
        if (activeTab) {
            let tab = new bootstrap.Tab(activeTab);
            tab.show();
        }
    }

    // Replace URL hash on change
    document.querySelectorAll('button[data-bs-toggle="pill"]').forEach(function(el) {
        el.addEventListener('shown.bs.tab', function (e) {
            let targetHash = e.target.getAttribute("data-bs-target").replace('#pill-', '#');
            history.replaceState(null, null, targetHash);
        });
    });
});

function previewAvatar(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('profile_pic_preview').src = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

<?php 
require_once __DIR__ . '/footer.php';
?>

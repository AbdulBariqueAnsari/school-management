<?php
// includes/header.php
// Universal Entry Point - Route to Role-Specific Subfolder Header

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Track the baseline true role of the user (e.g. Principal role 2, not escalated role 1)
$user_display_role = $_SESSION['true_role_id'] ?? $_SESSION['role_id'] ?? 0;

if ($user_display_role == 1) {
    // Super Admin
    require_once __DIR__ . '/../admin/header.php';
} elseif ($user_display_role == 2) {
    // Principal
    require_once __DIR__ . '/../principal/header.php';
} elseif ($user_display_role == 3) {
    // Clerk
    require_once __DIR__ . '/../clerk/header.php';
} elseif (in_array($user_display_role, [4, 5, 8])) {
    // Class Teacher, Subject Teacher, Teacher
    require_once __DIR__ . '/../teacher/header.php';
} elseif ($user_display_role == 7) {
    // Parent
    require_once __DIR__ . '/../parent/header.php';
} elseif ($user_display_role == 6) {
    // Student
    require_once __DIR__ . '/student_header.php';
} else {
    // Fallback/Default layout
    require_once __DIR__ . '/student_header.php';
}
?>

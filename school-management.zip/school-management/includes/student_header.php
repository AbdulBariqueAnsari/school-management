<?php
$studentPageTitle = $studentPageTitle ?? 'Student Portal';
$studentActive = $studentActive ?? '';
$studentName = student_field($student ?? [], 'student_name', 'Student');
$studentPhoto = $studentPhoto ?? student_photo_url($student ?? [], $user ?? []);

function student_nav_active($key, $studentActive)
{
    return $key === $studentActive ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($studentPageTitle); ?> | Student Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sp-primary: #4361ee;
            --sp-sidebar: #0f172a;
            --sp-bg: #f8fafc;
            --sp-text: #1e293b;
            --sp-muted: #64748b;
            --sp-card: rgba(255,255,255,0.92);
            --sp-border: #e2e8f0;
        }
        body {
            font-family: Inter, system-ui, sans-serif;
            background: var(--sp-bg);
            color: var(--sp-text);
            min-height: 100vh;
            overflow-x: hidden;
        }
        .student-shell { display: flex; min-height: 100vh; }
        .student-sidebar {
            width: 270px;
            background: linear-gradient(185deg, #0b0f19 0%, #121829 100%);
            color: #fff;
            position: fixed;
            inset: 0 auto 0 0;
            z-index: 1100;
            box-shadow: 8px 0 32px rgba(0,0,0,0.25);
            transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            border-right: 1px solid rgba(255,255,255,0.06);
            display: flex;
            flex-direction: column;
        }
        .student-brand-container {
            padding: 28px 24px;
            border-bottom: 1px solid rgba(255,255,255,0.06);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            background: rgba(255,255,255,0.01);
        }
        .student-brand-avatar {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(99, 102, 241, 0.35);
            box-shadow: 0 8px 24px rgba(99,102,241,0.2);
            margin-bottom: 12px;
            transition: all 0.3s ease;
        }
        .student-brand-avatar:hover {
            transform: scale(1.05);
            border-color: rgba(99, 102, 241, 0.7);
            box-shadow: 0 8px 28px rgba(99,102,241,0.4);
        }
        .student-brand-name {
            font-size: 1.05rem;
            font-weight: 700;
            color: #f8fafc;
            letter-spacing: -0.2px;
            margin-bottom: 3px;
        }
        .student-brand-role {
            font-size: 0.78rem;
            color: #a5b4fc;
            font-weight: 600;
            background: rgba(99,102,241,0.12);
            padding: 2px 10px;
            border-radius: 20px;
            border: 1px solid rgba(99,102,241,0.2);
            display: inline-block;
        }
        .student-nav-wrapper {
            flex: 1;
            overflow-y: auto;
            scrollbar-width: none;
        }
        .student-nav-wrapper::-webkit-scrollbar {
            display: none;
        }
        .student-nav { padding: 20px 16px; }
        .student-nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #94a3b8;
            text-decoration: none;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 4px;
            font-size: 0.92rem;
            font-weight: 600;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .student-nav a:hover {
            color: #fff;
            background: rgba(255,255,255,0.04);
            transform: translateX(4px);
        }
        .student-nav a.active {
            color: #fff;
            background: linear-gradient(135deg, #4f46e5 0%, #3b82f6 100%);
            box-shadow: 0 10px 24px rgba(79, 70, 229, 0.35);
        }
        .student-nav a.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 25%;
            height: 50%;
            width: 4px;
            background: #60a5fa;
            border-radius: 0 4px 4px 0;
            box-shadow: 0 0 10px #60a5fa;
        }
        .student-nav i { 
            font-size: 1.1rem;
            width: 22px; 
            text-align: center; 
            transition: transform 0.25s ease;
        }
        .student-nav a:hover i {
            transform: scale(1.15);
        }
        .student-nav-label {
            color: rgba(255,255,255,0.22);
            font-size: 0.68rem;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            font-weight: 800;
            padding: 20px 16px 8px;
        }
        .student-main {
            margin-left: 270px;
            width: calc(100% - 270px);
            min-height: 100vh;
        }
        .student-mobile-header {
            display: none;
            position: sticky;
            top: 0;
            z-index: 1050;
            background: rgba(255,255,255,0.96);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid var(--sp-border);
            padding: 10px 16px;
            min-height: 62px;
            align-items: center;
            justify-content: space-between;
        }
        .student-avatar { width: 38px; height: 38px; border-radius: 50%; object-fit: cover; }
        .student-content { padding: 32px; }
        .portal-card {
            background: var(--sp-card);
            border: 1px solid rgba(226,232,240,0.8);
            border-radius: 14px;
            box-shadow: 0 10px 30px rgba(15,23,42,0.05);
        }
        .portal-section-title {
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: var(--sp-muted);
            font-weight: 800;
            margin-bottom: 14px;
        }
        .data-label {
            color: var(--sp-muted);
            font-size: 0.72rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
        }
        .data-value { font-weight: 650; color: var(--sp-text); margin-bottom: 18px; }
        .module-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
            gap: 16px;
        }
        .module-card {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 18px;
            text-decoration: none;
            color: inherit;
            min-height: 104px;
            transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
        }
        .module-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 16px 34px rgba(15,23,42,0.09);
            border-color: #bfdbfe;
        }
        .module-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: grid;
            place-items: center;
            font-size: 1.25rem;
            flex: 0 0 auto;
        }
        .ic-blue { background: #dbeafe; color: #2563eb; }
        .ic-green { background: #dcfce7; color: #16a34a; }
        .ic-purple { background: #f3e8ff; color: #9333ea; }
        .ic-orange { background: #ffedd5; color: #ea580c; }
        .ic-red { background: #fee2e2; color: #dc2626; }
        .ic-cyan { background: #cffafe; color: #0891b2; }
        .ic-yellow { background: #fef9c3; color: #ca8a04; }
        .empty-state {
            padding: 48px 24px;
            text-align: center;
            color: var(--sp-muted);
        }
        .student-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15,23,42,0.45);
            z-index: 1090;
        }
        @media (max-width: 991.98px) {
            .student-sidebar { transform: translateX(-100%); }
            .student-sidebar.active { transform: translateX(0); }
            .student-main { margin-left: 0; width: 100%; }
            .student-mobile-header { display: flex; }
            .student-overlay.active { display: block; }
            .student-content { padding: 20px; }
        }
    </style>
</head>
<body>
<div class="student-overlay" id="studentOverlay"></div>
<div class="student-shell">
    <aside class="student-sidebar" id="studentSidebar">
        <div class="student-brand-container">
            <img src="<?php echo htmlspecialchars($studentPhoto); ?>" alt="Student Avatar" class="student-brand-avatar">
            <div class="student-brand-name"><?php echo htmlspecialchars($studentName); ?></div>
            <span class="student-brand-role"><i class="fa fa-circle text-success me-1" style="font-size:0.65rem;"></i> Student</span>
        </div>
        <div class="student-nav-wrapper">
            <nav class="student-nav">
                <a href="student_dashboard.php" class="<?php echo student_nav_active('dashboard', $studentActive); ?>"><i class="fa fa-home"></i> Dashboard</a>
                <a href="profile.php" class="<?php echo student_nav_active('profile', $studentActive); ?>"><i class="fa fa-user"></i> My Profile</a>
                <a href="attendance.php" class="<?php echo student_nav_active('attendance', $studentActive); ?>"><i class="fa fa-calendar-check"></i> Attendance</a>
                <a href="assignments.php" class="<?php echo student_nav_active('assignments', $studentActive); ?>"><i class="fa fa-tasks"></i> Assignments</a>
                <a href="materials.php" class="<?php echo student_nav_active('materials', $studentActive); ?>"><i class="fa fa-book-open"></i> Study Material</a>
                <a href="fees.php" class="<?php echo student_nav_active('fees', $studentActive); ?>"><i class="fa fa-file-invoice-dollar"></i> Fees</a>
                <a href="results.php" class="<?php echo student_nav_active('results', $studentActive); ?>"><i class="fa fa-chart-line"></i> Results</a>
                <a href="timetable.php" class="<?php echo student_nav_active('timetable', $studentActive); ?>"><i class="fa fa-clock"></i> Timetable</a>
                <a href="exam-apply.php" class="<?php echo student_nav_active('exam_forms', $studentActive); ?>"><i class="fa fa-clipboard-list"></i> Exam Forms</a>
                <a href="messages.php" class="<?php echo student_nav_active('messages', $studentActive); ?>"><i class="fa fa-envelope"></i> Messages</a>
                <div class="student-nav-label">Account</div>
                <a href="../logout.php" class="text-danger"><i class="fa fa-sign-out-alt"></i> Logout</a>
            </nav>
        </div>
    </aside>
    <main class="student-main">
        <header class="student-mobile-header">
            <div class="d-flex align-items-center gap-2">
                <button class="btn btn-light border" id="studentToggle" type="button"><i class="fa fa-bars"></i></button>
                <span class="fw-bold"><?php echo htmlspecialchars($studentPageTitle); ?></span>
            </div>
            <img src="<?php echo htmlspecialchars($studentPhoto); ?>" alt="Student" class="student-avatar">
        </header>
        <div class="student-content">

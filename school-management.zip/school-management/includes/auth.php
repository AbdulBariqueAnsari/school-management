<?php
// includes/auth.php
require_once __DIR__ . '/init.php';

if (!isLoggedIn()) {
    redirect(BASE_URL . '/login.php');
}
?>

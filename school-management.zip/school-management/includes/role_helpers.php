<?php
function role_count($sql, $params = [])
{
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

function role_rows($sql, $params = [], $limit = 100)
{
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql . " LIMIT " . (int)$limit);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

function role_money($value)
{
    $currency = defined('APP_CURRENCY') ? APP_CURRENCY : 'USD';
    return $currency . ' ' . number_format((float)$value, 2);
}

function role_field($row, $keys, $default = 'N/A')
{
    foreach ((array)$keys as $key) {
        if (isset($row[$key]) && $row[$key] !== '') {
            return $row[$key];
        }
    }
    return $default;
}

function role_render_cards($cards)
{
    foreach ($cards as $card) {
        echo '<div class="col-6 col-xl-3"><div class="card border-0 shadow-sm h-100" style="border-radius:14px;"><div class="card-body">';
        echo '<div class="text-muted small fw-bold">' . htmlspecialchars($card[0]) . '</div>';
        echo '<div class="h3 fw-bold mb-0">' . htmlspecialchars((string)$card[1]) . '</div>';
        echo '</div></div></div>';
    }
}

function role_render_table($columns, $rows, $empty = 'No records found.')
{
    if (!$rows) {
        echo '<div class="text-center py-5 text-muted"><i class="fa fa-inbox fa-3x mb-3 opacity-25"></i><p class="mb-0">' . htmlspecialchars($empty) . '</p></div>';
        return;
    }
    echo '<div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead class="table-light"><tr>';
    foreach ($columns as $column) {
        echo '<th class="small text-uppercase text-muted">' . htmlspecialchars($column) . '</th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr>';
        foreach ($row as $value) {
            echo '<td>' . htmlspecialchars((string)($value ?? 'N/A')) . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

function role_page_hero($title, $subtitle, $icon = 'fa-gauge')
{
    echo '<div class="p-4 mb-4 text-white" style="border-radius:16px;background:linear-gradient(135deg,#0f172a,#2563eb);box-shadow:0 16px 36px rgba(15,23,42,.16);">';
    echo '<div class="small text-white-50 fw-bold text-uppercase mb-2">Role Portal</div>';
    echo '<h1 class="h3 fw-bold mb-1"><i class="fa ' . htmlspecialchars($icon) . ' me-2"></i>' . htmlspecialchars($title) . '</h1>';
    echo '<p class="mb-0 text-white-50">' . htmlspecialchars($subtitle) . '</p>';
    echo '</div>';
}

function role_can($permission)
{
    $roleId = (int)($_SESSION['role_id'] ?? 0);
    $map = [
        1 => ['*'],
        2 => ['view_academics', 'view_reports', 'view_staff'],
        3 => ['manage_fees', 'record_payments', 'view_students', 'support_admissions'],
        4 => ['manage_class_attendance', 'manage_assignments', 'manage_marks', 'message_students', 'view_students'],
        5 => ['manage_assignments', 'manage_marks', 'message_students', 'view_students'],
        7 => ['view_child'],
        8 => ['manage_class_attendance', 'manage_assignments', 'manage_marks', 'message_students', 'view_students'],
    ];

    $allowed = $map[$roleId] ?? [];
    return in_array('*', $allowed, true) || in_array($permission, $allowed, true);
}

function role_alert($message, $type = 'success')
{
    return '<div class="alert alert-' . htmlspecialchars($type) . ' border-0 shadow-sm">' . htmlspecialchars($message) . '</div>';
}
?>

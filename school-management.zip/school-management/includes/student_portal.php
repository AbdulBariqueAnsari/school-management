<?php
require_once __DIR__ . '/init.php';

function student_portal_context()
{
    global $pdo;

    if (!isLoggedIn() || !hasRole(6)) {
        redirect(BASE_URL . '/student/login.php');
    }

    $user_id = $_SESSION['user_id'] ?? 0;
    $student_id = $_SESSION['student_id'] ?? 0;

    if ($student_id) {
        $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->execute([$student_id]);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM students WHERE user_id = ?");
        $stmt->execute([$user_id]);
    }

    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$student) {
        die("Student record not found.");
    }

    $_SESSION['student_id'] = $student['id'];

    $stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmtUser->execute([$user_id]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC) ?: [];

    return [$student, $user];
}

function student_field($student, $keys, $default = 'N/A')
{
    foreach ((array)$keys as $key) {
        if (isset($student[$key]) && $student[$key] !== '') {
            return $student[$key];
        }
    }
    return $default;
}

function student_photo_url($student, $user = [])
{
    $candidates = [
        ['value' => $user['profile_photo'] ?? '', 'dirs' => ['uploads/students', 'uploads/profile', 'uploads']],
        ['value' => $student['student_photo'] ?? '', 'dirs' => ['uploads/students', 'uploads/profile', 'uploads']],
        ['value' => $student['photo'] ?? '', 'dirs' => ['uploads/students', 'uploads/profile', 'uploads']],
    ];

    foreach ($candidates as $candidate) {
        $file = trim((string)$candidate['value']);
        if ($file === '') {
            continue;
        }
        foreach ($candidate['dirs'] as $dir) {
            $fs = BASE_PATH . '/' . $dir . '/' . $file;
            if (file_exists($fs)) {
                return '../' . $dir . '/' . rawurlencode($file);
            }
        }
    }

    $name = student_field($student, 'student_name', 'Student');
    return 'https://ui-avatars.com/api/?name=' . urlencode($name) . '&background=4361ee&color=fff';
}

function student_count_rows($sql, $params = [])
{
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}
function student_class_id($student)
{
    global $pdo;

    // 1. Check if class_id has an integer value
    if (!empty($student['class_id'])) {
        return (int)$student['class_id'];
    }

    // 2. Check if class has an integer value
    if (!empty($student['class']) && is_numeric($student['class'])) {
        return (int)$student['class'];
    }

    // 3. Fallback to class name lookup (e.g. from class_applied or class string)
    $class_name = !empty($student['class_applied']) ? $student['class_applied'] : (!empty($student['class']) ? $student['class'] : '');
    if (!empty($class_name)) {
        // Try exact match
        $stmt = $pdo->prepare("SELECT id FROM classes WHERE name = ?");
        $stmt->execute([$class_name]);
        $id = $stmt->fetchColumn();
        if ($id) {
            return (int)$id;
        }

        // Try clean lookup (e.g. remove spaces, lower case)
        $stmt = $pdo->prepare("SELECT id FROM classes WHERE REPLACE(LOWER(name), ' ', '') = REPLACE(LOWER(?), ' ', '')");
        $stmt->execute([$class_name]);
        $id = $stmt->fetchColumn();
        if ($id) {
            return (int)$id;
        }
    }

    return 0;
}
?>

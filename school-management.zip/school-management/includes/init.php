<?php
// includes/init.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure true_role_id is tracked to prevent stuck roles
if (isset($_SESSION['role_id'])) {
    if (!isset($_SESSION['true_role_id'])) {
        $_SESSION['true_role_id'] = $_SESSION['role_id'];
    }
}

// Restore role_id from true_role_id on every init to ensure correct baseline state
if (isset($_SESSION['true_role_id'])) {
    $_SESSION['role_id'] = $_SESSION['true_role_id'];
}

// If browsing any file inside the admin/ directory, and user is Principal (2), temporarily escalate role_id to 1 (Super Admin)
$request_uri = $_SERVER['REQUEST_URI'] ?? '';
$is_admin_path = (strpos($request_uri, '/admin/') !== false);
if ($is_admin_path && isset($_SESSION['true_role_id']) && $_SESSION['true_role_id'] == 2) {
    $_SESSION['role_id'] = 1;
}

// 1. SSL Proxy Loop Fix (Cloudflare & cPanel Ready)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $protocol = "https://";
}

// 2. Dynamic Project Root URL Calculation
// This detects exactly where your "school-management" folder is on the domain.
define('BASE_PATH', dirname(__DIR__));
$project_root_fs = str_replace('\\', '/', BASE_PATH);
$script_name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
$script_filename = str_replace('\\', '/', $_SERVER['SCRIPT_FILENAME']);
$rel_path_from_root = str_replace($project_root_fs, '', $script_filename);
$base_url_path = substr($script_name, 0, strlen($script_name) - strlen($rel_path_from_root));
$base_url_path = rtrim($base_url_path, '/');

define('BASE_URL', $protocol . $_SERVER['HTTP_HOST'] . $base_url_path);

// 3. Require Database
require_once BASE_PATH . '/config/db.php';

// 4. Include Mail Settings if exists
if (file_exists(BASE_PATH . '/config/mail.php')) {
    require_once BASE_PATH . '/config/mail.php';
}

// 5. Fetch Global Settings
try {
    $global_settings_stmt = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings");
    $app_settings = $global_settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // Apply Timezone
    if (isset($app_settings['timezone']) && !empty($app_settings['timezone'])) {
        date_default_timezone_set($app_settings['timezone']);
    }

    // Set Global Currency and Theme
    define('APP_CURRENCY', isset($app_settings['currency']) ? $app_settings['currency'] : 'USD');
    define('APP_THEME', isset($app_settings['theme']) ? $app_settings['theme'] : 'Light');

    // Maintenance Mode Check
    if (isset($app_settings['maintenance_mode']) && $app_settings['maintenance_mode'] == '1') {
        if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
            $current_file = basename($_SERVER['PHP_SELF']);
            if ($current_file !== 'login.php' && $current_file !== 'maintenance.php') {
                header("Location: " . BASE_URL . "/maintenance.php");
                exit();
            }
        }
    }
} catch (PDOException $e) {
    define('APP_CURRENCY', 'USD');
    define('APP_THEME', 'Light');
}

// 6. Common helper functions
function redirect($url) {
    header("Location: $url");
    exit();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function hasRole($role_id) {
    return isset($_SESSION['role_id']) && $_SESSION['role_id'] == $role_id;
}

function logActivity($action, $user_id = null)
{
    global $pdo;
    if (!$user_id && isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
    }
    if (!$user_id) return;

    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    try {
        $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, ip_address, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$user_id, $action, $ip]);
    } catch (PDOException $e) {
        // Fail silently
    }
}
?>

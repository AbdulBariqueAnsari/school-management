<?php
require 'includes/init.php';
try {
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $schema = [];
    foreach ($tables as $table) {
        if (in_array($table, ['users', 'students', 'parents', 'guardians', 'health_details', 'academic_details', 'admission_requests', 'admission_applications'])) {
            $cols = $pdo->query("DESCRIBE `$table`")->fetchAll(PDO::FETCH_ASSOC);
            $schema[$table] = $cols;
        }
    }
    echo json_encode($schema, JSON_PRETTY_PRINT);
}
catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

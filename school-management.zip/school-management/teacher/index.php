<?php
require_once '../includes/auth.php';

if (!in_array($_SESSION['role_id'], [4, 5, 8])) {
    redirect(BASE_URL . '/dashboard.php');
}

redirect(BASE_URL . '/teacher/dashboard.php');
?>

<?php
// teacher/shared_documents.php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if (!in_array($_SESSION['role_id'], [4, 5, 8])) {
    redirect(BASE_URL . '/login.php');
}

$user_id = (int)$_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

// Fetch user details first
$stmt_u = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt_u->execute([$user_id]);
$user = $stmt_u->fetch(PDO::FETCH_ASSOC) ?: [];

// Fetch active teacher details using user fields
$teacher = null;
$lookups = [
    ["SELECT * FROM teachers WHERE email = ?", [$user['email'] ?? '']],
    ["SELECT * FROM teachers WHERE username = ?", [$user['username'] ?? '']],
    ["SELECT * FROM teachers WHERE full_name = ?", [$user['name'] ?? '']],
];
foreach ($lookups as $lookup) {
    if (empty($lookup[1][0])) continue;
    $stmt_t = $pdo->prepare($lookup[0]);
    $stmt_t->execute($lookup[1]);
    $teacher = $stmt_t->fetch(PDO::FETCH_ASSOC);
    if ($teacher) break;
}
if (!$teacher) {
    $teacher = [];
}

$is_class_teacher = ($_SESSION['role_id'] == 4 || ($teacher['role'] ?? '') === 'class_teacher');
$my_class_names = array_filter(array_map('trim', explode(',', $teacher['class_teacher_of'] ?? '')));
$my_teaching_classes = array_filter(array_map('trim', explode(',', $teacher['assigned_class'] ?? '')));
if ($is_class_teacher && !empty($my_class_names)) {
    foreach ($my_class_names as $mcn) {
        if (!in_array($mcn, $my_teaching_classes)) {
            $my_teaching_classes[] = $mcn;
        }
    }
}

// Self-healing DB table creation
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `study_materials` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `title` varchar(255) NOT NULL,
          `description` text DEFAULT NULL,
          `file_path` varchar(255) NOT NULL,
          `class_id` int(11) NOT NULL,
          `subject_id` int(11) NOT NULL,
          `teacher_id` int(11) NOT NULL,
          `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
          PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ");
} catch (Exception $e) {
    $error_msg = "Database Auto-Init Failed: " . $e->getMessage();
}

// Handle Uploads
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'upload') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $class_id = (int)($_POST['class_id'] ?? 0);
        $subject_id = (int)($_POST['subject_id'] ?? 0);

        if (empty($title) || !$class_id || !$subject_id) {
            $error_msg = "Please fill in all required fields (Title, Class, Subject).";
        } elseif (!isset($_FILES['material_file']) || $_FILES['material_file']['error'] !== UPLOAD_ERR_OK) {
            $error_msg = "Please select a valid study resource file to upload.";
        } else {
            $file_tmp = $_FILES['material_file']['tmp_name'];
            $file_name = $_FILES['material_file']['name'];
            $file_size = $_FILES['material_file']['size'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

            $allowed_exts = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt', 'zip', 'png', 'jpg', 'jpeg'];
            
            if (!in_array($file_ext, $allowed_exts)) {
                $error_msg = "Unsupported file format. Allowed types: PDF, Word, PowerPoint, Excel, Images, Text, ZIP.";
            } elseif ($file_size > 25 * 1024 * 1024) { // 25MB Limit
                $error_msg = "File size must not exceed 25MB.";
            } else {
                $upload_dir = '../uploads/materials/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }

                $new_file_name = time() . '_' . bin2hex(random_bytes(8)) . '.' . $file_ext;
                $dest_path = $upload_dir . $new_file_name;

                if (move_uploaded_file($file_tmp, $dest_path)) {
                    $db_path = 'uploads/materials/' . $new_file_name;
                    try {
                        $stmt = $pdo->prepare("
                            INSERT INTO study_materials (title, description, file_path, class_id, subject_id, teacher_id)
                            VALUES (?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$title, $description, $db_path, $class_id, $subject_id, $user_id]);
                        $success_msg = "Study material uploaded and shared with students successfully!";
                    } catch (Exception $e) {
                        $error_msg = "Database save failed: " . $e->getMessage();
                        if (file_exists($dest_path)) unlink($dest_path);
                    }
                } else {
                    $error_msg = "Could not save file to disk.";
                }
            }
        }
    } elseif ($_POST['action'] === 'delete' && isset($_POST['material_id'])) {
        $material_id = (int)$_POST['material_id'];
        try {
            $stmt_fetch = $pdo->prepare("SELECT file_path FROM study_materials WHERE id = ? AND teacher_id = ?");
            $stmt_fetch->execute([$material_id, $user_id]);
            $material = $stmt_fetch->fetch();

            if ($material) {
                $full_path = '../' . $material['file_path'];
                if (file_exists($full_path)) {
                    unlink($full_path);
                }
                $stmt_del = $pdo->prepare("DELETE FROM study_materials WHERE id = ?");
                $stmt_del->execute([$material_id]);
                $success_msg = "Study material deleted successfully.";
            } else {
                $error_msg = "Material not found or access denied.";
            }
        } catch (Exception $e) {
            $error_msg = "Delete operation failed: " . $e->getMessage();
        }
    }
}

// Self-healing function to auto-populate standard subjects for all classes if they do not exist
function ensure_all_class_subjects($pdo) {
    $standard_subjects = [
        'Mathematics', 'Science', 'English', 'Hindi', 'Social Science', 
        'EVS', 'Computer Science', 'General Knowledge', 'Moral Science', 
        'Drawing', 'Music'
    ];
    try {
        $classes_list = $pdo->query("SELECT id FROM classes")->fetchAll(PDO::FETCH_COLUMN);
        
        $stmt_check = $pdo->prepare("SELECT LOWER(TRIM(name)) FROM subjects WHERE class_id = ?");
        $stmt_ins = $pdo->prepare("INSERT INTO subjects (name, class_id) VALUES (?, ?)");
        
        foreach ($classes_list as $class_id) {
            $stmt_check->execute([$class_id]);
            $existing = $stmt_check->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($standard_subjects as $sub) {
                if (!in_array(strtolower(trim($sub)), $existing)) {
                    $stmt_ins->execute([$sub, $class_id]);
                }
            }
        }
    } catch (Exception $e) {
        // Silent fallback
    }
}

// Ensure subjects exist globally for all classes on load
ensure_all_class_subjects($pdo);

// Fetch lookups after ensuring all class subjects are seeded globally
$classes_raw = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$classes = [];
foreach ($classes_raw as $cls) {
    if (in_array($_SESSION['role_id'], [4, 5, 8]) && !empty($my_teaching_classes)) {
        $match = false;
        foreach ($my_teaching_classes as $tc) {
            if (strtolower(trim($cls['name'])) === strtolower(trim($tc))) {
                $match = true;
                break;
            }
        }
        if (!$match) continue;
    }
    $classes[] = $cls;
}
$subjects_all = $pdo->query("SELECT id, name, class_id FROM subjects ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch already uploaded materials for this teacher
$materials = [];
try {
    $stmt = $pdo->prepare("
        SELECT m.*, c.name as class_name, s.name as subject_name
        FROM study_materials m
        LEFT JOIN classes c ON m.class_id = c.id
        LEFT JOIN subjects s ON m.subject_id = s.id
        WHERE m.teacher_id = ?
        ORDER BY m.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $materials = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Keep empty
}

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php role_page_hero('Shared Study Materials', 'Upload and manage course contents, guides, documents, and reference notes for your student classes.', 'fa-book-open'); ?>

    <?php if ($success_msg): ?>
        <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-circle-check me-2"></i><?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Upload Form Panel -->
        <div class="col-xl-4">
            <div class="card border-0 shadow-sm card-hover-effects" style="border-radius: 16px;">
                <div class="card-header bg-white border-0 pt-4 px-4 pb-2">
                    <h5 class="fw-bold text-dark mb-0"><i class="fa fa-cloud-arrow-up text-primary me-2"></i>Share New Resource</h5>
                    <small class="text-muted">Post revision notes, worksheets, syllabus guides or reference documents.</small>
                </div>
                <div class="card-body p-4">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="upload">

                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Document Title</label>
                            <input type="text" name="title" class="form-control bg-light border-0 py-2" placeholder="e.g. Chapter 4 Chemistry Revision Sheet" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Brief Description</label>
                            <textarea name="description" rows="3" class="form-control bg-light border-0" placeholder="Describe the study contents..."></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Target Class</label>
                            <select name="class_id" id="classSelect" class="form-select bg-light border-0 py-2" required>
                                <option value="" disabled selected>-- Select Class --</option>
                                <?php foreach ($classes as $cls): ?>
                                    <option value="<?php echo $cls['id']; ?>"><?php echo htmlspecialchars($cls['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Target Subject</label>
                            <select name="subject_id" id="subjectSelect" class="form-select bg-light border-0 py-2" required>
                                <option value="" disabled selected>-- Select Subject --</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold text-secondary">Resource File</label>
                            <input type="file" name="material_file" class="form-control bg-light border-0" required>
                            <div class="form-text small text-muted">Supports PDF, Word, Excel, PPT, TXT, ZIP &amp; Images up to 25MB.</div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 fw-bold shadow-sm py-2.5">
                            <i class="fa fa-paper-plane me-2"></i>Upload &amp; Share
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Materials List Grid -->
        <div class="col-xl-8">
            <div class="card border-0 shadow-sm" style="border-radius: 16px;">
                <div class="card-header bg-white border-0 pt-4 px-4 pb-2 d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="fw-bold text-dark mb-0"><i class="fa fa-folder-open text-info me-2"></i>Uploaded Resources</h5>
                        <small class="text-muted">Currently active study resources available to students.</small>
                    </div>
                    <span class="badge bg-info text-white fw-bold px-3 py-2 rounded-pill"><?php echo count($materials); ?> Total Resources</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Resource Details</th>
                                    <th>Class &amp; Subject</th>
                                    <th>File Format</th>
                                    <th>Uploaded On</th>
                                    <th class="text-end pe-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$materials): ?>
                                    <tr><td colspan="5" class="text-center py-5 text-muted">No study materials uploaded yet.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($materials as $m): ?>
                                        <?php 
                                        $file_ext = strtolower(pathinfo($m['file_path'], PATHINFO_EXTENSION));
                                        
                                        // Choose matching icon and badge colors
                                        $icon = 'fa-file-lines text-secondary';
                                        $badge_class = 'bg-secondary-subtle text-secondary';
                                        if ($file_ext === 'pdf') {
                                            $icon = 'fa-file-pdf text-danger';
                                            $badge_class = 'bg-danger-subtle text-danger';
                                        } elseif (in_array($file_ext, ['doc', 'docx'])) {
                                            $icon = 'fa-file-word text-primary';
                                            $badge_class = 'bg-primary-subtle text-primary';
                                        } elseif (in_array($file_ext, ['ppt', 'pptx'])) {
                                            $icon = 'fa-file-powerpoint text-warning';
                                            $badge_class = 'bg-warning-subtle text-warning-emphasis';
                                        } elseif (in_array($file_ext, ['xls', 'xlsx'])) {
                                            $icon = 'fa-file-excel text-success';
                                            $badge_class = 'bg-success-subtle text-success';
                                        } elseif ($file_ext === 'zip') {
                                            $icon = 'fa-file-zipper text-info';
                                            $badge_class = 'bg-info-subtle text-info';
                                        } elseif (in_array($file_ext, ['png', 'jpg', 'jpeg'])) {
                                            $icon = 'fa-file-image text-purple';
                                            $badge_class = 'bg-purple-subtle text-purple';
                                        }
                                        ?>
                                        <tr>
                                            <td class="ps-4 py-3" style="max-width: 280px;">
                                                <div class="d-flex align-items-center gap-3">
                                                    <i class="fa-solid <?php echo $icon; ?> fs-3"></i>
                                                    <div>
                                                        <strong class="text-dark d-block text-truncate" style="max-width: 220px;" title="<?php echo htmlspecialchars($m['title']); ?>">
                                                            <?php echo htmlspecialchars($m['title']); ?>
                                                        </strong>
                                                        <span class="text-muted small text-truncate d-block" style="max-width: 220px; font-size: 0.8rem;">
                                                            <?php echo htmlspecialchars($m['description'] ?: 'No description provided.'); ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <strong class="text-dark d-block"><?php echo htmlspecialchars($m['class_name']); ?></strong>
                                                <span class="badge bg-light text-muted border"><?php echo htmlspecialchars($m['subject_name']); ?></span>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo $badge_class; ?> px-2.5 py-1.5 rounded-pill text-uppercase">
                                                    <?php echo $file_ext; ?> Resource
                                                </span>
                                            </td>
                                            <td><small class="text-muted"><i class="fa-regular fa-clock me-1"></i><?php echo date('d M Y', strtotime($m['created_at'])); ?></small></td>
                                            <td class="text-end pe-4">
                                                <a href="<?php echo BASE_URL . '/' . htmlspecialchars($m['file_path']); ?>" target="_blank" class="btn btn-sm btn-outline-primary me-1" download>
                                                    <i class="fa fa-download"></i> Download
                                                </a>
                                                <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to permanently delete this material? This cannot be undone.');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="material_id" value="<?php echo $m['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash-can"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const subjects = <?php echo json_encode($subjects_all); ?>;
    const teacherRoleId = <?php echo (int)($_SESSION['role_id'] ?? 0); ?>;
    
    // Parse comma-separated assigned subjects from PHP to JS array
    const teacherAssignedSubjects = <?php 
        $subs_array = array_map('trim', explode(',', $teacher['assigned_subject'] ?? ''));
        echo json_encode($subs_array); 
    ?>;

    const classSelect = document.getElementById('classSelect');
    const subjectSelect = document.getElementById('subjectSelect');

    function filterSubjects() {
        const classId = parseInt(classSelect.value) || 0;
        subjectSelect.innerHTML = '<option value="" disabled selected>-- Select Subject --</option>';
        
        let filtered = subjects.filter(sub => sub.class_id === classId);

        // Subject Teacher restriction: support multiple assigned subjects!
        const hasGeneral = teacherAssignedSubjects.some(ts => ts.trim().toLowerCase() === 'general');
        if (teacherRoleId === 5 && teacherAssignedSubjects.length > 0 && teacherAssignedSubjects[0] !== '' && !hasGeneral) {
            const matched = filtered.filter(sub => {
                const cleanSubName = sub.name.trim().toLowerCase();
                return teacherAssignedSubjects.some(ts => {
                    const cleanTs = ts.trim().toLowerCase();
                    return cleanSubName === cleanTs || cleanSubName.includes(cleanTs) || cleanTs.includes(cleanSubName);
                });
            });
            if (matched.length > 0) {
                filtered = matched;
            }
        }

        filtered.forEach(sub => {
            const opt = document.createElement('option');
            opt.value = sub.id;
            opt.textContent = sub.name;
            if (teacherRoleId === 5 && filtered.length === 1) {
                opt.selected = true;
            }
            subjectSelect.appendChild(opt);
        });
    }

    if (classSelect) {
        classSelect.addEventListener('change', filterSubjects);
    }
</script>

<?php require_once '../includes/footer.php'; ?>

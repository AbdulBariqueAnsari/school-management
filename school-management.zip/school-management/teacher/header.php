<?php
// teacher/header.php
// Premium, role-specific header and sidebar for Teacher

$theme_attr = (defined('APP_THEME') && APP_THEME == 'Dark') ? 'data-bs-theme="dark"' : '';
?>
<!DOCTYPE html>
<html lang="en" <?php echo $theme_attr; ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Portal | School CMS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <?php if (file_exists(BASE_PATH . '/assets/css/style.css')): ?>
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <?php endif; ?>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* ═══════════ BASE ═══════════ */
        body { background-color: #f1f5f9; }
        .main-content { padding: 20px; transition: all 0.3s ease; width: 100%; }
        .dashboard-card-hover { transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out; }
        .dashboard-card-hover:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important; z-index: 10; }

        /* ═══════════ SIDEBAR ═══════════ */
        .sidebar {
            background: linear-gradient(180deg, #0f172a 0%, #0369a1 100%);
            color: #fff;
            min-height: 100vh;
            width: 260px;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
            overflow-y: auto;
            padding: 0;
            transition: all 0.3s ease;
            position: relative;
        }
        .sidebar.sidebar-collapsed { width: 0; }

        /* Thin scrollbar */
        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-track { background: transparent; }
        .sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 4px; }

        /* Logo area */
        .sb-logo {
            padding: 24px 20px 18px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.07);
            text-decoration: none;
            display: block;
        }
        .sb-logo img {
            width: 52px; height: 52px;
            object-fit: contain;
            border-radius: 12px;
            box-shadow: 0 0 0 3px rgba(14,165,233,0.3), 0 0 20px rgba(14,165,233,0.2);
            margin-bottom: 8px;
        }
        .sb-logo-icon {
            width: 52px; height: 52px;
            background: linear-gradient(135deg,#0284c7,#0369a1);
            border-radius: 12px;
            display: inline-flex; align-items:center; justify-content:center;
            font-size: 1.4rem; color: #fff; margin: 0 auto 8px;
            box-shadow: 0 0 20px rgba(14,165,233,0.35);
        }
        .sb-school-name { color: #f1f5f9; font-weight: 700; font-size: 0.92rem; letter-spacing: 0.4px; line-height: 1.2; margin: 0; }
        .sb-sub { color: rgba(255,255,255,0.35); font-size: 0.72rem; letter-spacing: 0.8px; text-transform: uppercase; margin-top: 2px; }

        /* Nav wrapper */
        .sb-nav { padding: 14px 12px 20px; flex: 1; }

        /* Section label */
        .sb-section-label {
            font-size: 0.65rem; font-weight: 700; letter-spacing: 1.4px;
            text-transform: uppercase; color: rgba(255,255,255,0.25);
            padding: 12px 8px 6px; margin-top: 6px;
        }

        /* Nav link */
        .sb-link {
            display: flex; align-items: center; gap: 11px;
            padding: 10px 14px;
            border-radius: 10px;
            color: #e0f2fe;
            text-decoration: none;
            font-size: 0.875rem; font-weight: 500;
            margin-bottom: 2px;
            position: relative;
            transition: all 0.25s ease;
            white-space: nowrap;
        }
        .sb-link i { font-size: 1rem; width: 18px; text-align: center; flex-shrink: 0; }
        .sb-link:hover {
            background: rgba(255,255,255,0.06);
            color: #f0f9ff;
            transform: translateX(4px);
        }

        /* Active state */
        .sb-link.active {
            background: linear-gradient(90deg,#0284c7,#0369a1);
            color: #fff;
            font-weight: 600;
            box-shadow: 0 4px 14px rgba(14,165,233,0.4);
        }
        .sb-link.active::before {
            content: '';
            position: absolute; left: -12px; top: 50%;
            transform: translateY(-50%);
            width: 3px; height: 70%;
            background: #0284c7;
            border-radius: 0 3px 3px 0;
        }
        .sb-link.active i { color: #fff; }

        /* Dropdown toggle */
        .sb-toggle {
            display: flex; align-items: center; gap: 11px;
            padding: 10px 14px;
            border-radius: 10px;
            color: #e0f2fe;
            text-decoration: none;
            font-size: 0.875rem; font-weight: 500;
            margin-bottom: 2px;
            cursor: pointer;
            transition: all 0.25s ease;
        }
        .sb-toggle i.sb-icon { font-size: 1rem; width: 18px; text-align: center; flex-shrink: 0; }
        .sb-toggle .sb-chevron { margin-left: auto; font-size: 0.7rem; transition: transform 0.25s ease; }
        .sb-toggle:hover { background: rgba(255,255,255,0.06); color: #f0f9ff; transform: translateX(4px); }
        .sb-toggle[aria-expanded="true"] { color: #f0f9ff; background: rgba(255,255,255,0.06); }
        .sb-toggle[aria-expanded="true"] .sb-chevron { transform: rotate(90deg); }

        /* Submenu */
        .sb-submenu {
            padding-left: 14px;
            list-style: none;
            margin: 0;
        }
        .sb-submenu .sb-link {
            font-size: 0.82rem;
            padding: 8px 12px;
            color: rgba(255,255,255,0.45);
        }
        .sb-submenu .sb-link:hover { color: #cbd5e1; }
        .sb-submenu .sb-link i { font-size: 0.78rem; }

        /* Divider */
        .sb-divider { border: none; border-top: 1px solid rgba(255,255,255,0.07); margin: 12px 8px; }

        /* Logout */
        .sb-logout {
            display: flex; align-items: center; gap: 11px;
            padding: 10px 14px; border-radius: 10px;
            color: #f87171; text-decoration: none;
            font-size: 0.875rem; font-weight: 500;
            transition: all 0.25s ease;
        }
        .sb-logout:hover { background: rgba(248,113,113,0.1); color: #fca5a5; transform: translateX(4px); }
        .sb-logout i { width: 18px; text-align: center; }

        /* ═══════════ RESPONSIVE OVERLAYS ═══════════ */
        @media (max-width: 991.98px) {
            .sidebar {
                position: fixed;
                top: 0; left: 0; bottom: 0;
                z-index: 1040;
                width: 260px;
                transform: translateX(-100%);
                transition: transform 0.3s cubic-bezier(0.22,1,0.36,1);
            }
            .sidebar.show-mobile-sidebar {
                transform: translateX(0);
            }
            .sidebar-overlay {
                display: none;
                position: fixed;
                inset: 0;
                background: rgba(15, 23, 42, 0.45);
                backdrop-filter: blur(5px);
                -webkit-backdrop-filter: blur(5px);
                z-index: 1030;
            }
            .sidebar-overlay.show {
                display: block;
            }
        }

        /* ═══════════ ANIMATIONS ═══════════ */
        @keyframes pageFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .main-content {
            animation: pageFadeIn 0.45s cubic-bezier(0.22,1,0.36,1) both;
        }

        #site-preloader {
            position: fixed; inset: 0; z-index: 99999;
            background: linear-gradient(135deg, #0f172a 0%, #0369a1 100%);
            display: flex; align-items: center; justify-content: center;
            flex-direction: column; gap: 18px;
            transition: opacity 0.4s ease, visibility 0.4s ease;
            opacity: 1; visibility: visible;
        }
        #site-preloader.hidden { opacity: 0; visibility: hidden; }
        .preloader-ring {
            width: 52px; height: 52px;
            border-radius: 50%;
            border: 4px solid rgba(255,255,255,0.08);
            border-top-color: #0284c7;
            border-right-color: #bae6fd;
            animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        .preloader-label {
            color: rgba(255,255,255,0.35);
            font-size: 0.75rem; letter-spacing: 1.5px;
            text-transform: uppercase; font-family: system-ui, sans-serif;
        }
        .reveal {
            opacity: 0;
            transform: translateY(22px);
            transition: opacity 0.52s cubic-bezier(0.22,1,0.36,1), transform 0.52s cubic-bezier(0.22,1,0.36,1);
        }
        .reveal.visible {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div id="site-preloader">
        <div class="preloader-ring"></div>
        <div class="preloader-label">Loading Teacher Portal...</div>
    </div>

    <script>
    (function() {
        var preloader = document.getElementById('site-preloader');
        window.addEventListener('load', function() {
            preloader.classList.add('hidden');
        });
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() { preloader.classList.add('hidden'); }, 200);
        });
        document.addEventListener('click', function(e) {
            var anchor = e.target.closest('a');
            if (!anchor) return;
            var href = anchor.getAttribute('href');
            if (!href || href.startsWith('#') || href.startsWith('javascript') ||
                anchor.target === '_blank' || anchor.getAttribute('data-bs-toggle') ||
                e.ctrlKey || e.metaKey || e.shiftKey) return;
            e.preventDefault();
            preloader.classList.remove('hidden');
            setTimeout(function() { window.location.href = href; }, 380);
        });

        // IntersectionObserver reveal animation
        document.addEventListener('DOMContentLoaded', function() {
            var targets = document.querySelectorAll('.card, .stat-card, .table-responsive, .alert');
            targets.forEach(function(el) {
                el.classList.add('reveal');
            });
            if (!('IntersectionObserver' in window)) {
                document.querySelectorAll('.reveal').forEach(function(el) { el.classList.add('visible'); });
                return;
            }
            var io = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        io.unobserve(entry.target);
                    }
                });
            }, { threshold: 0, rootMargin: '0px 0px -30px 0px' });
            document.querySelectorAll('.reveal').forEach(function(el) { io.observe(el); });
        });
    })();
    </script>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">

            <?php
            $stmt_brand = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings WHERE setting_key IN ('school_name', 'school_logo')");
            $brand_settings = $stmt_brand->fetchAll(PDO::FETCH_KEY_PAIR);
            $school_name = $brand_settings['school_name'] ?? 'School CMS';
            $logo = $brand_settings['school_logo'] ?? '';
            $cur = basename($_SERVER['PHP_SELF']);
            $curQ = $_SERVER['REQUEST_URI'] ?? '';
            
            // Ultra-smart dynamic active highlight logic
            function sb_active($pages, $query_type = null) {
                global $cur;
                $page_list = is_array($pages) ? $pages : [$pages];
                if (!in_array($cur, $page_list)) {
                    return '';
                }
                if ($query_type !== null) {
                    $type = $_GET['type'] ?? '';
                    if ($type !== $query_type) {
                        return '';
                    }
                }
                return 'active';
            }
            ?>

            <!-- Logo area -->
            <a href="<?php echo BASE_URL; ?>/dashboard.php" class="sb-logo">
                <?php if ($logo): ?>
                    <img src="<?php echo BASE_URL; ?>/uploads/branding/<?php echo htmlspecialchars($logo); ?>" alt="Logo">
                <?php else: ?>
                    <div class="sb-logo-icon"><i class="fa fa-graduation-cap"></i></div>
                <?php endif; ?>
                <div class="sb-school-name"><?php echo htmlspecialchars($school_name); ?></div>
                <div class="sb-sub">Teacher Portal</div>
            </a>

            <!-- Navigation -->
            <nav class="sb-nav">

                <div class="sb-section-label">Main</div>

                <a href="<?php echo BASE_URL; ?>/dashboard.php" class="sb-link <?php echo sb_active(['dashboard.php', 'index.php']); ?>">
                    <i class="fa fa-gauge"></i> Dashboard
                </a>

                <div class="sb-section-label">Faculty Controls</div>

                <a href="<?php echo BASE_URL; ?>/teacher/notices.php" class="sb-link <?php echo sb_active('notices.php'); ?>">
                    <i class="fa fa-bullhorn text-warning"></i> Notice Board
                </a>
                
                <?php if (isset($_SESSION['role_id']) && $_SESSION['role_id'] != 5): ?>
                    <a href="<?php echo BASE_URL; ?>/teacher/module.php?type=students" class="sb-link <?php echo sb_active('module.php', 'students'); ?>">
                        <i class="fa fa-user-graduate"></i> My Class Students
                    </a>
                    <a href="<?php echo BASE_URL; ?>/teacher/module.php?type=attendance" class="sb-link <?php echo sb_active('module.php', 'attendance'); ?>">
                        <i class="fa fa-calendar-check text-success"></i> Attendance Mark
                    </a>
                <?php endif; ?>
                
                <a href="<?php echo BASE_URL; ?>/teacher/module.php?type=assignments" class="sb-link <?php echo sb_active('module.php', 'assignments'); ?>">
                    <i class="fa fa-tasks text-primary"></i> Assignments Workspace
                </a>
                
                <a href="<?php echo BASE_URL; ?>/teacher/shared_documents.php" class="sb-link <?php echo sb_active('shared_documents.php'); ?>">
                    <i class="fa fa-book-open text-info"></i> Shared Materials
                </a>

                <a href="<?php echo BASE_URL; ?>/teacher/exam_results.php" class="sb-link <?php echo sb_active('exam_results.php'); ?>">
                    <i class="fa fa-chart-line text-danger"></i> Exam Results Desk
                </a>

                <hr class="sb-divider">
                <a href="<?php echo BASE_URL; ?>/logout.php" class="sb-logout">
                    <i class="fa fa-right-from-bracket"></i> Logout
                </a>

            </nav>
        </div>

        <!-- Main Content -->
        <div class="main-content flex-grow-1" style="min-width: 0;">
            <nav class="navbar navbar-expand-lg navbar-light bg-light rounded shadow-sm mb-4">
                <div class="container-fluid">
                    <div class="d-flex align-items-center">
                        <button class="btn btn-light me-3 border shadow-sm" id="sidebarToggle">
                            <i class="fa-solid fa-bars"></i>
                        </button>
                        <div class="d-flex flex-column">
                            <span class="navbar-brand mb-0 h3 fw-bold">Welcome, <?php echo isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Faculty'; ?>! 👋</span>
                            <span class="badge bg-info fs-6 align-self-start mt-1" style="background-color: #0284c7; color: #fff;">Faculty</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center">
                        <div class="d-none d-md-flex align-items-center me-4 pe-3 border-end">
                            <i class="fa-regular fa-clock text-secondary me-2"></i>
                            <span id="liveClock" class="fw-bold text-dark font-monospace" style="font-size: 1.1rem;">--:--:--</span>
                        </div>
                        
                        <div class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="navbarDropdownProfile" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php
                                $profile_photo = isset($_SESSION['user_id']) ? $pdo->query("SELECT profile_photo FROM users WHERE id = " . (int)$_SESSION['user_id'])->fetchColumn() : null;
                                $img_src = $profile_photo ? BASE_URL . '/uploads/profile/' . htmlspecialchars($profile_photo) : BASE_URL . '/assets/images/default-avatar.png';
                                ?>
                                <img src="<?php echo $img_src; ?>" class="rounded-circle border border-primary me-2" height="35" width="35" alt="Avatar" style="object-fit:cover;" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name'] ?? 'T'); ?>&background=0284c7&color=fff';"/>
                                <div class="d-none d-md-block text-start lh-1">
                                    <span class="d-block fw-bold text-dark"><?php echo isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Faculty'; ?></span>
                                    <small class="text-muted">Faculty</small>
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2" aria-labelledby="navbarDropdownProfile">
                                <li><a class="dropdown-item py-2" href="<?php echo BASE_URL; ?>/teacher/profile.php#personal"><i class="fa-solid fa-user me-2 text-primary"></i> My Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item py-2" href="<?php echo BASE_URL; ?>/teacher/profile.php#security"><i class="fa-solid fa-lock me-2 text-warning"></i> Change Password</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item py-2 text-danger" href="<?php echo BASE_URL; ?>/logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i> Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>

<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if (!in_array($_SESSION['role_id'], [4, 5, 8])) {
    redirect(BASE_URL . '/login.php');
}

$user_id = (int)$_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

$teacher = null;
foreach ([['email', $user['email'] ?? ''], ['username', $user['username'] ?? ''], ['full_name', $user['name'] ?? '']] as $pair) {
    if (!$pair[1]) continue;
    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE {$pair[0]} = ?");
    $stmt->execute([$pair[1]]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($teacher) break;
}
$teacher = $teacher ?: [];
$teacherDbId = (int)role_field($teacher, 'id', 0);
$assignedClassesList = array_filter(array_map('trim', explode(',', role_field($teacher, ['class_teacher_of', 'assigned_class'], ''))));
$assignedClass = $_GET['class'] ?? ($assignedClassesList[0] ?? '');
if (!in_array($assignedClass, $assignedClassesList) && !empty($assignedClassesList)) {
    $assignedClass = $assignedClassesList[0];
}
$classId = $assignedClass ? role_count("SELECT id FROM classes WHERE name = ?", [$assignedClass]) : 0;
$type = $_GET['type'] ?? 'students';
if ($type === 'marks') {
    redirect('exam_results.php');
}
$notice = '';
$error = '';

$students = $assignedClass ? role_rows("SELECT id, admission_no, student_name, gender, status FROM students WHERE class_applied=? OR class=? ORDER BY student_name", [$assignedClass, $assignedClass], 500) : [];
$subjects = $classId ? role_rows("SELECT id, name FROM subjects WHERE class_id=? ORDER BY name", [$classId], 100) : [];
$exams = role_rows("SELECT id, name FROM exams ORDER BY start_date DESC", [], 100);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if ($_POST['action'] === 'create_assignment' && role_can('manage_assignments')) {
            if (!$classId) throw new Exception('Assigned class is not linked with classes table.');
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $subjectId = (int)($_POST['subject_id'] ?? 0);
            $deadline = trim($_POST['deadline'] ?? '');
            if (!$title || !$subjectId || !$deadline) throw new Exception('Assignment title, subject and deadline are required.');
            $stmt = $pdo->prepare("INSERT INTO assignments (title, description, deadline, class_id, subject_id, teacher_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $description, $deadline, $classId, $subjectId, $user_id]);
            logActivity("Teacher created assignment: " . $title);
            $notice = 'Assignment created successfully.';
        }

        if ($_POST['action'] === 'save_attendance' && role_can('manage_class_attendance')) {
            $date = trim($_POST['date'] ?? date('Y-m-d'));
            if (isset($_POST['attendance_students'])) {
                $attendanceStudents = $_POST['attendance_students'] ?? [];
                $presentStudents = $_POST['present_students'] ?? [];
                foreach ($attendanceStudents as $studentId) {
                    $studentId = (int)$studentId;
                    $status = isset($presentStudents[$studentId]) ? 'Present' : 'Absent';
                    $check = $pdo->prepare("SELECT id FROM attendance WHERE student_id=? AND date=?");
                    $check->execute([$studentId, $date]);
                    $existing = $check->fetchColumn();
                    if ($existing) {
                        $stmt = $pdo->prepare("UPDATE attendance SET status=?, marked_by=? WHERE id=?");
                        $stmt->execute([$status, $user_id, $existing]);
                    } else {
                        $stmt = $pdo->prepare("INSERT INTO attendance (student_id, date, status, marked_by) VALUES (?, ?, ?, ?)");
                        $stmt->execute([$studentId, $date, $status, $user_id]);
                    }
                }
            } else {
                foreach (($_POST['status'] ?? []) as $studentId => $status) {
                    $studentId = (int)$studentId;
                    if (!in_array($status, ['Present', 'Absent', 'Late', 'Half Day'], true)) continue;
                    $check = $pdo->prepare("SELECT id FROM attendance WHERE student_id=? AND date=?");
                    $check->execute([$studentId, $date]);
                    $existing = $check->fetchColumn();
                    if ($existing) {
                        $stmt = $pdo->prepare("UPDATE attendance SET status=?, marked_by=? WHERE id=?");
                        $stmt->execute([$status, $user_id, $existing]);
                    } else {
                        $stmt = $pdo->prepare("INSERT INTO attendance (student_id, date, status, marked_by) VALUES (?, ?, ?, ?)");
                        $stmt->execute([$studentId, $date, $status, $user_id]);
                    }
                }
            }
            logActivity("Teacher saved attendance for " . $assignedClass);
            $notice = 'Attendance saved successfully.';
        }

        if ($_POST['action'] === 'save_mark' && role_can('manage_marks')) {
            $examId = (int)($_POST['exam_id'] ?? 0);
            $studentId = (int)($_POST['student_id'] ?? 0);
            $subjectId = (int)($_POST['subject_id'] ?? 0);
            $obtained = (float)($_POST['marks_obtained'] ?? 0);
            $total = (float)($_POST['total_marks'] ?? 0);
            $grade = trim($_POST['grade'] ?? '');
            if (!$examId || !$studentId || !$subjectId || $total <= 0) throw new Exception('Exam, student, subject and total marks are required.');
            $stmt = $pdo->prepare("INSERT INTO marks (exam_id, student_id, subject_id, marks_obtained, total_marks, grade) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$examId, $studentId, $subjectId, $obtained, $total, $grade]);
            logActivity("Teacher entered marks for student ID " . $studentId);
            $notice = 'Marks saved successfully.';
        }

        if ($_POST['action'] === 'send_message' && role_can('message_students')) {
            $receiverId = (int)($_POST['student_id'] ?? 0);
            $message = trim($_POST['message'] ?? '');
            if (!$receiverId || !$message) throw new Exception('Student and message are required.');
            $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, message, sender_role) VALUES (?, ?, ?, 'teacher')");
            $stmt->execute([$teacherDbId ?: $user_id, $receiverId, $message]);
            logActivity("Teacher sent message to student ID " . $receiverId);
            $notice = 'Message sent successfully.';
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$title = 'Teacher Module';
$icon = 'fa-chalkboard-user';
$cards = [['Assigned Class', $assignedClass ?: 'N/A']];
$columns = [];
$rows = [];

switch ($type) {
    case 'attendance':
        $title = 'Class Attendance';
        $icon = 'fa-calendar-check';
        
        $total_marked = 0;
        $total_present = 0;
        $class_attendance_percent = 100.0;
        $student_attendance_stats = [];
        $prev_attendance_summary = [];
        
        if ($assignedClass) {
            // Overall class attendance rate
            $stats = $pdo->prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present FROM attendance a INNER JOIN students s ON a.student_id=s.id WHERE s.class_applied=? OR s.class=?");
            $stats->execute([$assignedClass, $assignedClass]);
            $res = $stats->fetch(PDO::FETCH_ASSOC);
            if ($res && $res['total'] > 0) {
                $total_marked = (int)$res['total'];
                $total_present = (int)$res['present'];
                $class_attendance_percent = round(($total_present / $total_marked) * 100, 1);
            }
            
            // Student-specific percentage stats
            $stmt_stats = $pdo->prepare("
                SELECT student_id, COUNT(*) AS total_days, SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present_days 
                FROM attendance a
                INNER JOIN students s ON a.student_id=s.id
                WHERE s.class_applied=? OR s.class=?
                GROUP BY student_id
            ");
            $stmt_stats->execute([$assignedClass, $assignedClass]);
            $student_attendance_stats = $stmt_stats->fetchAll(PDO::FETCH_UNIQUE | PDO::FETCH_ASSOC);
            
            // Previous attendance dates summary
            $stmt_summary = $pdo->prepare("
                SELECT a.date, 
                       SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS total_present,
                       SUM(CASE WHEN a.status='Absent' THEN 1 ELSE 0 END) AS total_absent,
                       u.name AS marked_by_name
                FROM attendance a
                INNER JOIN students s ON a.student_id=s.id
                LEFT JOIN users u ON a.marked_by=u.id
                WHERE s.class_applied=? OR s.class=?
                GROUP BY a.date
                ORDER BY a.date DESC
                LIMIT 30
            ");
            $stmt_summary->execute([$assignedClass, $assignedClass]);
            $prev_attendance_summary = $stmt_summary->fetchAll(PDO::FETCH_ASSOC);
        }
        
        // Populate standard columns/rows for the general card at bottom
        $columns = ['Date', 'Student', 'Status', 'Marked By'];
        $rows = $assignedClass ? role_rows("SELECT a.date, s.student_name, a.status, u.name FROM attendance a INNER JOIN students s ON a.student_id=s.id LEFT JOIN users u ON a.marked_by=u.id WHERE s.class_applied=? OR s.class=? ORDER BY a.date DESC LIMIT 200", [$assignedClass, $assignedClass], 200) : [];
        break;
    case 'assignments':
        $title = 'Assignments';
        $icon = 'fa-tasks';
        $columns = ['Title', 'Subject ID', 'Deadline', 'Created'];
        $rows = $classId ? role_rows("SELECT title, subject_id, deadline, created_at FROM assignments WHERE class_id=? ORDER BY deadline DESC", [$classId], 200) : [];
        break;
    case 'marks':
        $title = 'Marks';
        $icon = 'fa-chart-line';
        $columns = ['Exam ID', 'Student ID', 'Subject ID', 'Marks', 'Grade'];
        $rows = $assignedClass ? role_rows("SELECT m.exam_id, m.student_id, m.subject_id, CONCAT(m.marks_obtained, '/', m.total_marks) AS marks, m.grade FROM marks m INNER JOIN students s ON m.student_id=s.id WHERE s.class_applied=? OR s.class=? ORDER BY m.id DESC", [$assignedClass, $assignedClass], 200) : [];
        break;
    case 'messages':
        $title = 'Messages';
        $icon = 'fa-envelope';
        $columns = ['Sender', 'Receiver', 'Message', 'Role', 'Created'];
        $rows = role_rows("SELECT sender_id, receiver_id, message, sender_role, created_at FROM messages ORDER BY created_at DESC", [], 200);
        break;
    default:
        $title = 'My Students';
        $icon = 'fa-users';
        $columns = ['ID', 'Admission No', 'Student', 'Gender', 'Status'];
        $rows = $students;
}

require_once '../includes/header.php';
?>
<div class="container-fluid py-4">
    <?php role_page_hero($title, 'Teacher class-wise data entry and operational view.', $icon); ?>
    <?php if ($notice) echo role_alert($notice); ?>
    <?php if ($error) echo role_alert($error, 'danger'); ?>
    <?php if (count($assignedClassesList) > 1): ?>
        <div class="card border-0 shadow-sm mb-4" style="border-radius:14px; background: rgba(255,255,255,0.85); backdrop-filter: blur(10px); border: 1px solid rgba(226, 232, 240, 0.8);">
            <div class="card-body py-3 px-4 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-2">
                    <i class="fa fa-school text-primary fs-5"></i>
                    <span class="fw-bold text-dark">Switch Active Class:</span>
                </div>
                <div class="d-flex gap-2 flex-wrap">
                    <?php foreach ($assignedClassesList as $ac): ?>
                        <a href="?type=<?php echo urlencode($type); ?>&class=<?php echo urlencode($ac); ?>" class="btn btn-sm <?php echo ($assignedClass === $ac) ? 'btn-primary fw-bold shadow-sm' : 'btn-outline-secondary'; ?> px-3 rounded-pill">
                            <?php echo htmlspecialchars($ac); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="row g-3 mb-4"><?php role_render_cards($cards); ?></div>

    <?php if ($type === 'assignments' && role_can('manage_assignments')): ?>
    <div class="card border-0 shadow-sm mb-4" style="border-radius:14px;"><div class="card-body">
        <h2 class="h5 fw-bold mb-3">Create Assignment</h2>
        <form method="POST" class="row g-3">
            <input type="hidden" name="action" value="create_assignment">
            <div class="col-md-4"><input name="title" class="form-control" placeholder="Assignment title" required></div>
            <div class="col-md-3"><select name="subject_id" class="form-select" required><option value="">Subject</option><?php foreach ($subjects as $s): ?><option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name']); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-3"><input type="datetime-local" name="deadline" class="form-control" required></div>
            <div class="col-md-12"><textarea name="description" class="form-control" rows="2" placeholder="Instructions"></textarea></div>
            <div class="col-md-2"><button class="btn btn-primary w-100">Save</button></div>
        </form>
    </div></div>
    <?php endif; ?>

    <?php if ($type === 'attendance' && role_can('manage_class_attendance')): ?>
    
    <!-- 📊 CARD 1: Class Attendance Analytics & Statistics -->
    <div class="row g-4 mb-4">
        <!-- Class Attendance Rate -->
        <div class="col-lg-7 col-md-12">
            <div class="card border-0 shadow-sm h-100" style="border-radius: 16px; background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #fff;">
                <div class="card-body p-4 d-flex flex-column justify-content-between">
                    <div>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-1 fw-bold">Overall Statistics</span>
                            <span class="text-muted small">Academic Year: <?php echo date('Y'); ?></span>
                        </div>
                        <h3 class="h4 fw-bold mb-1">Class Attendance Performance</h3>
                        <p class="text-secondary small mb-4">Average attendance rate calculated across all marked working days for assigned class: <strong><?php echo htmlspecialchars($assignedClass); ?></strong></p>
                    </div>
                    
                    <div class="row align-items-center g-3">
                        <div class="col-sm-5 text-center text-sm-start">
                            <div class="display-3 fw-black text-transparent bg-clip-text" style="background-image: linear-gradient(90deg, #38bdf8, #00f2fe); font-weight: 800; font-size: 3.5rem; color: #38bdf8;">
                                <?php echo $class_attendance_percent; ?>%
                            </div>
                            <span class="text-secondary small">Average Attendance Rate</span>
                        </div>
                        <div class="col-sm-7">
                            <div class="small mb-1 d-flex justify-content-between">
                                <span class="text-secondary">Class Attendance Rate</span>
                                <span class="fw-bold text-white"><?php echo $class_attendance_percent; ?>%</span>
                            </div>
                            <div class="progress bg-secondary-subtle" style="height: 12px; border-radius: 6px;">
                                <div class="progress-bar rounded-pill" role="progressbar" style="width: <?php echo $class_attendance_percent; ?>%; background: linear-gradient(90deg, #38bdf8, #00f2fe);" aria-valuenow="<?php echo $class_attendance_percent; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="d-flex justify-content-between mt-3 text-secondary small">
                                <span><i class="fa fa-calendar-check text-info me-1"></i> Total Marked: <strong><?php echo $total_marked; ?></strong></span>
                                <span><i class="fa fa-circle-check text-success me-1"></i> Present Days: <strong><?php echo $total_present; ?></strong></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Stats Cards -->
        <div class="col-lg-5 col-md-12">
            <div class="row g-3 h-100">
                <div class="col-6">
                    <div class="card border-0 shadow-sm h-100" style="border-radius: 16px;">
                        <div class="card-body p-3 d-flex flex-column justify-content-between">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="bg-primary-subtle p-2 rounded-3 text-primary"><i class="fa fa-users fa-lg"></i></div>
                                <span class="text-muted small">Roster Size</span>
                            </div>
                            <div>
                                <h6 class="text-muted small mb-1">Total Students</h6>
                                <h3 class="fw-bold mb-0 text-dark"><?php echo count($students); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="card border-0 shadow-sm h-100" style="border-radius: 16px;">
                        <div class="card-body p-3 d-flex flex-column justify-content-between">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="bg-success-subtle p-2 rounded-3 text-success"><i class="fa fa-circle-check fa-lg"></i></div>
                                <span class="text-muted small">Consistency</span>
                            </div>
                            <div>
                                <h6 class="text-muted small mb-1">Attendance Status</h6>
                                <span class="badge bg-success-subtle text-success border border-success-subtle">Active Roster</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card border-0 shadow-sm shadow-hover" style="border-radius: 16px;">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center gap-3">
                                <div class="bg-warning-subtle p-3 rounded-3 text-warning"><i class="fa fa-clock-rotate-left fa-xl"></i></div>
                                <div>
                                    <h6 class="text-muted small mb-1">Last Marked Date</h6>
                                    <h5 class="fw-bold mb-0 text-dark"><?php echo !empty($prev_attendance_summary) ? htmlspecialchars($prev_attendance_summary[0]['date']) : 'Never'; ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 📝 CARD 2: Daily Attendance Marker (Tick Box / iOS Switch System) -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 16px;">
        <div class="card-body p-4">
            <form method="POST" id="attendanceForm">
                <input type="hidden" name="action" value="save_attendance">
                
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4 pb-3 border-bottom">
                    <div>
                        <h4 class="h5 fw-bold mb-1 text-dark"><i class="fa fa-pen-to-square text-primary me-2"></i>Daily Attendance Register</h4>
                        <p class="text-muted small mb-0">Check the switch box next to a student's name to mark them <strong>Present</strong> (Green). Uncheck to mark them <strong>Absent</strong> (Red).</p>
                    </div>
                    <div class="d-flex align-items-center gap-2 w-100 w-md-auto">
                        <span class="text-muted small fw-bold d-none d-sm-inline">Select Date:</span>
                        <input type="date" name="date" class="form-control form-control-solid border shadow-none" value="<?php echo date('Y-m-d'); ?>" style="border-radius: 8px; max-width: 180px;">
                    </div>
                </div>
                
                <!-- Quick actions and Search -->
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-sm btn-outline-success px-3" id="markAllPresent" style="border-radius: 8px;">
                            <i class="fa fa-check-double me-1"></i> Mark All Present
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-danger px-3" id="markAllAbsent" style="border-radius: 8px;">
                            <i class="fa fa-times me-1"></i> Mark All Absent
                        </button>
                    </div>
                    <div class="position-relative" style="width: 240px; max-width: 100%;">
                        <i class="fa fa-search position-absolute text-muted top-50 translate-middle-y start-0 ms-3"></i>
                        <input type="text" id="studentSearch" class="form-control form-control-sm ps-5 border shadow-none" placeholder="Search student name..." style="border-radius: 8px; height: 35px;">
                    </div>
                </div>

                <!-- Responsive Roster list/grid -->
                <div class="table-responsive mb-4" style="border-radius: 12px; border: 1px solid #f1f5f9;">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 80px;" class="ps-4">No.</th>
                                <th>Student Details</th>
                                <th class="text-center" style="width: 200px;">Total Attendance Rate</th>
                                <th class="text-center" style="width: 150px;">Status</th>
                                <th class="text-end pe-4" style="width: 140px;">Mark Present</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $count = 1;
                            foreach ($students as $st): 
                                $stat = $student_attendance_stats[$st['id']] ?? ['total_days' => 0, 'present_days' => 0];
                                $percent = $stat['total_days'] > 0 ? round(($stat['present_days'] / $stat['total_days']) * 100, 1) : 100.0;
                                
                                // Color logic for attendance rate
                                if ($percent >= 85) {
                                    $p_badge = 'bg-success-subtle text-success border border-success-subtle';
                                } elseif ($percent >= 75) {
                                    $p_badge = 'bg-info-subtle text-info border border-info-subtle';
                                } else {
                                    $p_badge = 'bg-danger-subtle text-danger border border-danger-subtle';
                                }
                            ?>
                            <tr id="student-row-<?php echo $st['id']; ?>" class="student-row table-success-subtle" style="transition: background-color 0.2s ease;">
                                <td class="ps-4 text-muted font-monospace"><?php echo $count++; ?></td>
                                <td>
                                    <div class="d-flex align-items-center gap-3">
                                        <!-- Avatar initial with dynamic theme -->
                                        <div class="rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-sm" style="width: 40px; height: 40px; background: linear-gradient(135deg, #eff6ff, #dbeafe); color: #1d4ed8; font-size: 0.95rem;">
                                            <?php 
                                            $names = explode(' ', $st['student_name']);
                                            echo count($names) > 1 ? strtoupper(substr($names[0], 0, 1) . substr($names[1], 0, 1)) : strtoupper(substr($st['student_name'], 0, 2));
                                            ?>
                                        </div>
                                        <div>
                                            <input type="hidden" name="attendance_students[]" value="<?php echo $st['id']; ?>">
                                            <div class="fw-bold text-dark student-search-name"><?php echo htmlspecialchars($st['student_name']); ?></div>
                                            <div class="text-muted small">Admission No: <span class="font-monospace text-secondary fw-semibold"><?php echo htmlspecialchars($st['admission_no']); ?></span> | Gender: <span class="fw-medium text-capitalize"><?php echo htmlspecialchars($st['gender']); ?></span></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <span class="badge <?php echo $p_badge; ?> px-3 py-1 fw-bold" style="border-radius: 8px; font-size: 0.85rem;">
                                        <i class="fa fa-chart-line me-1"></i><?php echo $percent; ?>%
                                    </span>
                                </td>
                                <td class="text-center">
                                    <!-- Present/Absent badge changing in real time -->
                                    <span id="status-badge-<?php echo $st['id']; ?>" class="badge bg-success-subtle text-success border border-success-subtle px-3 py-1" style="border-radius: 8px; font-size: 0.85rem;">Present</span>
                                </td>
                                <td class="text-end pe-4">
                                    <!-- Premium Custom Toggle Switch (iOS styled) -->
                                    <div class="form-check form-switch d-inline-block ps-0">
                                        <input type="checkbox" name="present_students[<?php echo $st['id']; ?>]" value="Present" class="form-check-input attendance-toggle shadow-none cursor-pointer" data-student-id="<?php echo $st['id']; ?>" id="toggle-<?php echo $st['id']; ?>" checked style="width: 50px; height: 26px; border-radius: 13px; margin: 0; cursor: pointer;">
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($students)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">
                                    <i class="fa fa-folder-open fa-3x mb-3 text-secondary"></i>
                                    <h5>No Assigned Class Students Found</h5>
                                    <p class="small mb-0">Please link your teacher account with a class in Super Admin Settings first.</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="text-end">
                    <button class="btn btn-primary px-5 py-2.5 fw-bold" style="border-radius: 12px; box-shadow: 0 4px 14px rgba(13,110,253,0.3);"><i class="fa-solid fa-floppy-disk me-2"></i>Save Daily Register</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 📊 CARD 3: Previously Marked Attendance Summary Log -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 16px; overflow: hidden;">
        <div class="card-header bg-white py-3 border-0 d-flex justify-content-between align-items-center">
            <h4 class="h5 fw-bold mb-0 text-dark"><i class="fa fa-clock-rotate-left text-warning me-2"></i>Previously Marked Attendance History</h4>
            <span class="badge bg-secondary-subtle text-secondary px-3 py-1" style="border-radius: 8px;">Last 30 Working Days</span>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Marked Date</th>
                        <th class="text-center">Total Present</th>
                        <th class="text-center">Total Absent</th>
                        <th class="text-center">Class Attendance Rate</th>
                        <th class="pe-4 text-end">Marked By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    foreach ($prev_attendance_summary as $summary): 
                        $total_students = $summary['total_present'] + $summary['total_absent'];
                        $rate = $total_students > 0 ? round(($summary['total_present'] / $total_students) * 100, 1) : 0;
                        if ($rate >= 85) {
                            $rate_class = 'text-success fw-bold';
                        } elseif ($rate >= 75) {
                            $rate_class = 'text-info fw-semibold';
                        } else {
                            $rate_class = 'text-danger fw-bold';
                        }
                    ?>
                    <tr>
                        <td class="ps-4 font-monospace fw-semibold text-secondary">
                            <i class="fa-regular fa-calendar-check me-2 text-primary"></i><?php echo htmlspecialchars($summary['date']); ?>
                        </td>
                        <td class="text-center text-success font-monospace fw-bold">
                            <i class="fa fa-circle-check me-1"></i><?php echo $summary['total_present']; ?>
                        </td>
                        <td class="text-center text-danger font-monospace fw-bold">
                            <i class="fa fa-circle-xmark me-1"></i><?php echo $summary['total_absent']; ?>
                        </td>
                        <td class="text-center font-monospace <?php echo $rate_class; ?>">
                            <?php echo $rate; ?>%
                        </td>
                        <td class="pe-4 text-end text-muted small">
                            <i class="fa fa-user-check me-1"></i><?php echo htmlspecialchars($summary['marked_by_name'] ?? 'System'); ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($prev_attendance_summary)): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4 text-muted">No attendance logs found yet.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- JavaScript block for Attendance Register interactivity -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle switches real-time dynamic label and background update
        const toggles = document.querySelectorAll('.attendance-toggle');
        toggles.forEach(toggle => {
            toggle.addEventListener('change', function() {
                const studentId = this.dataset.studentId;
                const badge = document.getElementById('status-badge-' + studentId);
                const row = document.getElementById('student-row-' + studentId);
                
                if (this.checked) {
                    badge.textContent = 'Present';
                    badge.className = 'badge bg-success-subtle text-success border border-success-subtle px-3 py-1';
                    if (row) {
                        row.classList.add('table-success-subtle');
                        row.classList.remove('table-danger-subtle');
                    }
                } else {
                    badge.textContent = 'Absent';
                    badge.className = 'badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-1';
                    if (row) {
                        row.classList.remove('table-success-subtle');
                        row.classList.add('table-danger-subtle');
                    }
                }
            });
            // Trigger immediately to establish initial colors
            toggle.dispatchEvent(new Event('change'));
        });

        // Mark All Present
        const markAllPresentBtn = document.getElementById('markAllPresent');
        if (markAllPresentBtn) {
            markAllPresentBtn.addEventListener('click', function(e) {
                e.preventDefault();
                toggles.forEach(toggle => {
                    toggle.checked = true;
                    toggle.dispatchEvent(new Event('change'));
                });
            });
        }

        // Mark All Absent
        const markAllAbsentBtn = document.getElementById('markAllAbsent');
        if (markAllAbsentBtn) {
            markAllAbsentBtn.addEventListener('click', function(e) {
                e.preventDefault();
                toggles.forEach(toggle => {
                    toggle.checked = false;
                    toggle.dispatchEvent(new Event('change'));
                });
            });
        }

        // Real-time roster search filter
        const searchInput = document.getElementById('studentSearch');
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const query = this.value.toLowerCase().trim();
                const rows = document.querySelectorAll('.student-row');
                rows.forEach(row => {
                    const name = row.querySelector('.student-search-name').textContent.toLowerCase();
                    if (name.includes(query)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        }
    });
    </script>
    
    <style>
    /* Styling custom switches to feel highly responsive & premium */
    .form-check-input:checked {
        background-color: #10b981 !important;
        border-color: #10b981 !important;
    }
    .form-check-input {
        background-color: #ef4444 !important;
        border-color: #ef4444 !important;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3e%3ccircle r='3' fill='%23fff'/%3e%3c/svg%3e") !important;
        cursor: pointer;
        transition: background-position .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    }
    .table-success-subtle {
        background-color: rgba(240, 253, 250, 0.6) !important;
    }
    .table-danger-subtle {
        background-color: rgba(254, 242, 242, 0.6) !important;
    }
    .cursor-pointer {
        cursor: pointer;
    }
    </style>

    <?php endif; ?>

    <?php if ($type === 'marks' && role_can('manage_marks')): ?>
    <div class="card border-0 shadow-sm mb-4" style="border-radius:14px;"><div class="card-body">
        <h2 class="h5 fw-bold mb-3">Enter Marks</h2>
        <form method="POST" class="row g-3">
            <input type="hidden" name="action" value="save_mark">
            <div class="col-md-3"><select name="exam_id" class="form-select" required><option value="">Exam</option><?php foreach ($exams as $e): ?><option value="<?php echo $e['id']; ?>"><?php echo htmlspecialchars($e['name']); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-3"><select name="student_id" class="form-select" required><option value="">Student</option><?php foreach ($students as $st): ?><option value="<?php echo $st['id']; ?>"><?php echo htmlspecialchars($st['student_name']); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-2"><select name="subject_id" class="form-select" required><option value="">Subject</option><?php foreach ($subjects as $s): ?><option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name']); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-1"><input type="number" step="0.01" name="marks_obtained" class="form-control" placeholder="Got"></div>
            <div class="col-md-1"><input type="number" step="0.01" name="total_marks" class="form-control" placeholder="Total"></div>
            <div class="col-md-1"><input name="grade" class="form-control" placeholder="Grade"></div>
            <div class="col-md-1"><button class="btn btn-primary w-100">Save</button></div>
        </form>
    </div></div>
    <?php endif; ?>

    <?php if ($type === 'messages' && role_can('message_students')): ?>
    <div class="card border-0 shadow-sm mb-4" style="border-radius:14px;"><div class="card-body">
        <h2 class="h5 fw-bold mb-3">Send Message</h2>
        <form method="POST" class="row g-3">
            <input type="hidden" name="action" value="send_message">
            <div class="col-md-4"><select name="student_id" class="form-select" required><option value="">Student</option><?php foreach ($students as $st): ?><option value="<?php echo $st['id']; ?>"><?php echo htmlspecialchars($st['student_name']); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-6"><input name="message" class="form-control" placeholder="Message" required></div>
            <div class="col-md-2"><button class="btn btn-primary w-100">Send</button></div>
        </form>
    </div></div>
    <?php endif; ?>

    <?php if ($type !== 'attendance'): ?>
    <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
        <div class="card-header bg-white py-3 d-flex justify-content-between"><h2 class="h5 fw-bold mb-0">Records</h2><a href="dashboard.php" class="btn btn-sm btn-outline-secondary">Back</a></div>
        <?php role_render_table($columns, $rows, 'No records found for your assigned class yet.'); ?>
    </div>
    <?php endif; ?>
</div>
<?php require_once '../includes/footer.php'; ?>

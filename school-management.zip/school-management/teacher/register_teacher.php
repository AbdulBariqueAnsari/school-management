<?php
require_once '../includes/init.php';

$success = '';
$error = '';

// ICSE Subjects List
$ICSE_subjects = $pdo->query("SELECT DISTINCT name FROM subjects ORDER BY name ASC")->fetchAll(PDO::FETCH_COLUMN);
if (empty($ICSE_subjects)) {
    $ICSE_subjects = [
        'English', 'Hindi', 'Mathematics', 'EVS', 'Science', 'Social Science', 'Computer Science',
        'General Knowledge', 'Moral Science', 'Drawing', 'Music', 'Physical Education',
        'Physics', 'Chemistry', 'Biology', 'Economics', 'Accountancy', 'Business Studies',
        'Political Science', 'History', 'Geography', 'Informatics Practices'
    ];
}

$classes = $pdo->query("SELECT name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);
if (empty($classes)) {
    $classes = ['Pre-Nursery', 'Nursery', 'LKG', 'UKG'];
    for ($i = 1; $i <= 12; $i++) {
        $classes[] = "Class " . $i;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    try {
        $pdo->beginTransaction();

        // 1. Personal Details
        $full_name = trim($_POST['full_name']);
        $gender = $_POST['gender'];
        $dob = $_POST['dob'];
        $age = (int)$_POST['age'];
        $blood_group = $_POST['blood_group'];
        $aadhaar = trim($_POST['aadhaar']);

        // Photo Upload Handling
        $photo = 'default-teacher.png';
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
            $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $filename = time() . '_' . uniqid() . '.' . $ext;
            if (move_uploaded_file($_FILES['photo']['tmp_name'], '../uploads/profile/' . $filename)) {
                $photo = $filename;
            }
        }

        // 2. Contact Details
        $phone = trim($_POST['phone']);
        $email = trim($_POST['email']);
        $present_address = trim($_POST['present_address']);
        $permanent_address = trim($_POST['permanent_address']);

        // 3. Professional Details
        $qualification = trim($_POST['qualification']);
        $specialization = trim($_POST['specialization']);
        $experience_years = (int)$_POST['experience_years'];
        $previous_school = trim($_POST['previous_school']);
        $year_of_joining = $_POST['year_of_joining'];
        $designation = $_POST['designation'];
        $employment_type = $_POST['employment_type'];

        // 4. Subject & Role Assignment
        $assigned_subject_ids_arr = isset($_POST['assigned_subject']) ? (array)$_POST['assigned_subject'] : [];
        $assigned_subject_ids = implode(',', $assigned_subject_ids_arr);
        
        $assigned_class_names = [];
        $assigned_subject_names = [];
        if (!empty($assigned_subject_ids_arr)) {
            $in_placeholder = implode(',', array_fill(0, count($assigned_subject_ids_arr), '?'));
            $stmt_mapped = $pdo->prepare("SELECT s.name as sub_name, c.name as class_name FROM subjects s JOIN classes c ON s.class_id = c.id WHERE s.id IN ($in_placeholder)");
            $stmt_mapped->execute($assigned_subject_ids_arr);
            $mapped_records = $stmt_mapped->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($mapped_records as $rec) {
                $assigned_class_names[] = $rec['class_name'];
                $assigned_subject_names[] = $rec['sub_name'];
            }
            $assigned_class_names = array_unique($assigned_class_names);
            $assigned_subject_names = array_unique($assigned_subject_names);
        }
        
        $assigned_subject = implode(',', $assigned_subject_names);
        $assigned_class = implode(',', $assigned_class_names);
        
        $role = $_POST['role'];
        $class_teacher_of = NULL;
        if ($role === 'class_teacher' && isset($_POST['class_teacher_of'])) {
            $class_teacher_of_array = (array)$_POST['class_teacher_of'];
            $class_teacher_of = implode(',', $class_teacher_of_array);
            
            // --- EXCLUSIVITY RULE FOR CLASS TEACHERS ---
            foreach ($class_teacher_of_array as $target_class) {
                // Find any teacher who has this class in their list
                $stmt_others = $pdo->prepare("SELECT id, class_teacher_of, email FROM teachers WHERE role = 'class_teacher'");
                $stmt_others->execute();
                $others = $stmt_others->fetchAll();
                
                foreach ($others as $other) {
                    $other_classes = array_map('trim', explode(',', $other['class_teacher_of'] ?? ''));
                    if (in_array($target_class, $other_classes)) {
                        // Remove target class from their list
                        $updated_classes = array_diff($other_classes, [$target_class]);
                        if (empty($updated_classes)) {
                            // Demote them if they no longer have any classes
                            $stmt_demote_t = $pdo->prepare("UPDATE teachers SET role = 'subject_teacher', class_teacher_of = NULL WHERE id = ?");
                            $stmt_demote_t->execute([$other['id']]);
                            
                            $stmt_demote_u = $pdo->prepare("UPDATE users SET role_id = 5 WHERE email = ?");
                            $stmt_demote_u->execute([$other['email']]);
                        } else {
                            // Update their list
                            $new_list = implode(',', $updated_classes);
                            $stmt_update_other = $pdo->prepare("UPDATE teachers SET class_teacher_of = ? WHERE id = ?");
                            $stmt_update_other->execute([$new_list, $other['id']]);
                        }
                    }
                }
            }
        }

        // 5. Login Details
        $teacher_id_val = trim($_POST['teacher_id']);
        $username = trim($_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        // CHECK IF EMAIL/USERNAME EXISTS
        $checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR name = ?"); // name used as username sometimes
        $checkStmt->execute([$email, $username]);
        if ($checkStmt->fetch()) {
            throw new Exception("Email or Username already exists.");
        }

        // INSERT INTO USERS TABLE (Role 4 = Class Teacher, Role 5 = Subject Teacher)
        $target_role_id = ($role === 'class_teacher') ? 4 : 5;
        $stmt_user = $pdo->prepare("INSERT INTO users (name, email, password, role_id, phone, is_active) VALUES (?, ?, ?, ?, ?, 0)"); // Initially inactive until approved
        $stmt_user->execute([$full_name, $email, $password, $target_role_id, $phone]);
        $user_id = $pdo->lastInsertId();

        // INSERT INTO TEACHERS TABLE
        $stmt_teacher = $pdo->prepare("INSERT INTO teachers (
            teacher_id, full_name, gender, dob, age, blood_group, aadhaar, phone, email, 
            present_address, permanent_address, photo, qualification, specialization, 
            experience_years, previous_school, year_of_joining, designation, employment_type, 
            assigned_subject, assigned_class, role, class_teacher_of, username, password, status, assigned_subject_ids
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?)");

        $stmt_teacher->execute([
            $teacher_id_val, $full_name, $gender, $dob, $age, $blood_group, $aadhaar, $phone, $email,
            $present_address, $permanent_address, $photo, $qualification, $specialization,
            $experience_years, $previous_school, $year_of_joining, $designation, $employment_type,
            $assigned_subject, $assigned_class, $role, $class_teacher_of, $username, $password, $assigned_subject_ids
        ]);

        $pdo->commit();
        $success = "Registration successful! Your application is pending approval.";

    }
    catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Registration | School Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f7f6; }
        .form-section { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 30px; }
        .section-title { border-bottom: 2px solid #eee; margin-bottom: 25px; padding-bottom: 10px; color: #333; font-weight: 600; }
        .btn-register { padding: 12px 40px; font-weight: 600; border-radius: 50px; }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="text-center mb-5">
                <h2 class="fw-bold">🏫 Teacher Registration Form</h2>
                <p class="text-muted">Fill in the details to join our faculty.</p>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success shadow-sm"><?php echo $success; ?></div>
            <?php
endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger shadow-sm"><?php echo $error; ?></div>
            <?php
endif; ?>

            <form action="" method="POST" enctype="multipart/form-data">
                
                <!-- Section 1: Personal Details -->
                <div class="form-section">
                    <h5 class="section-title"><i class="fa fa-user me-2 text-primary"></i> 1. Personal Details</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="full_name" class="form-control" required placeholder="Enter full name">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-control" required>
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="dob" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Age</label>
                            <input type="number" name="age" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Blood Group</label>
                            <input type="text" name="blood_group" class="form-control" placeholder="e.g. O+">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Aadhaar Number</label>
                            <input type="text" name="aadhaar" class="form-control" required maxlength="12">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Photo Upload</label>
                            <input type="file" name="photo" class="form-control" accept="image/*">
                        </div>
                    </div>
                </div>

                <!-- Section 2: Contact Details -->
                <div class="form-section">
                    <h5 class="section-title"><i class="fa fa-address-book me-2 text-success"></i> 2. Contact Details</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Present Address</label>
                            <textarea name="present_address" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Permanent Address</label>
                            <textarea name="permanent_address" class="form-control" rows="3" required></textarea>
                        </div>
                    </div>
                </div>

                <!-- Section 3: Professional Details -->
                <div class="form-section">
                    <h5 class="section-title"><i class="fa fa-briefcase me-2 text-warning"></i> 3. Professional Details</h5>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Qualification</label>
                            <input type="text" name="qualification" class="form-control" required placeholder="e.g. B.Ed, M.Sc">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Specialization</label>
                            <input type="text" name="specialization" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Years of Experience</label>
                            <input type="number" name="experience_years" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Previous School Name</label>
                            <input type="text" name="previous_school" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Year of Joining</label>
                            <input type="text" name="year_of_joining" class="form-control" placeholder="YYYY" maxlength="4">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Designation</label>
                            <select name="designation" class="form-control" required>
                                <option value="Assistant Teacher">Assistant Teacher</option>
                                <option value="Senior Teacher">Senior Teacher</option>
                                <option value="Head Teacher">Head Teacher</option>
                                <option value="Subject Teacher">Subject Teacher</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Employment Type</label>
                            <select name="employment_type" class="form-control" required>
                                <option value="Full Time">Full Time</option>
                                <option value="Part Time">Part Time</option>
                                <option value="Contract">Contract</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Section 4: Subject & Role Assignment -->
                <div class="form-section">
                    <h5 class="section-title"><i class="fa fa-book me-2 text-info"></i> 4. Subject & Role Assignment</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Role</label>
                            <select name="role" id="role_select" class="form-control" required onchange="toggleClassTeacherField()">
                                <option value="subject_teacher">Regular Subject Teacher</option>
                                <option value="class_teacher">Class Teacher</option>
                            </select>
                        </div>
                        
                        <div class="col-md-12" id="class_teacher_container" style="display: none;">
                            <label class="form-label fw-bold d-block text-success mb-2"><i class="fa fa-chalkboard-teacher me-1"></i> Class Teacher Of (Select one or more)</label>
                            <div class="row g-2 bg-light p-3 rounded" style="max-height: 180px; overflow-y: auto; border: 1px solid #ced4da;">
                                <?php foreach ($classes as $class): ?>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="form-check">
                                            <input class="form-check-input class-teacher-checkbox" type="checkbox" name="class_teacher_of[]" value="<?php echo htmlspecialchars($class); ?>" id="ct_<?php echo md5($class); ?>">
                                            <label class="form-check-label small" for="ct_<?php echo md5($class); ?>">
                                                <?php echo htmlspecialchars($class); ?>
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <label class="form-label fw-bold d-block text-secondary mb-2"><i class="fa fa-school me-1"></i> Class &amp; Subject Assignments Matrix</label>
                            <div class="bg-white p-3 rounded shadow-sm" style="max-height: 350px; overflow-y: auto; border: 1px solid #ced4da;">
                                <?php 
                                // Fetch all classes and their mapped subjects
                                $all_classes_stmt = $pdo->query("SELECT * FROM classes ORDER BY id ASC");
                                $all_classes_res = $all_classes_stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                $all_subjects_stmt = $pdo->query("SELECT * FROM subjects ORDER BY class_id ASC, name ASC");
                                $all_subjects_res = $all_subjects_stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                $subjects_by_class_map = [];
                                foreach ($all_subjects_res as $sub) {
                                    $subjects_by_class_map[$sub['class_id']][] = [
                                        'id' => $sub['id'],
                                        'name' => $sub['name']
                                    ];
                                }
                                
                                $selected_subjects = [];
                                $selected_classes = [];
                                
                                if (empty($all_classes_res)): 
                                ?>
                                    <p class="text-muted small mb-0"><i class="fa fa-info-circle me-1"></i> No classes or subjects configured yet. Setup classes in Academic Setup first.</p>
                                <?php 
                                else:
                                    foreach ($all_classes_res as $cls):
                                        $clsId = $cls['id'];
                                        $clsName = $cls['name'];
                                        $clsSubjects = $subjects_by_class_map[$clsId] ?? [];
                                        $hasSubjects = !empty($clsSubjects);
                                ?>
                                    <div class="mb-3 pb-3 border-bottom" style="border-color: #f1f5f9 !important;">
                                        <div class="d-flex align-items-center mb-2">
                                            <div class="form-check">
                                                <input class="form-check-input class-checkbox" type="checkbox" name="assigned_class[]" value="<?php echo htmlspecialchars($clsName); ?>" id="cls_<?php echo md5($clsName); ?>">
                                                <label class="form-check-label fw-bold text-dark" for="cls_<?php echo md5($clsName); ?>">
                                                    <i class="fa fa-graduation-cap text-muted me-1"></i> <?php echo htmlspecialchars($clsName); ?>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="ps-4 row g-2">
                                            <?php if (!$hasSubjects): ?>
                                                <div class="col-12"><small class="text-muted italic"><i class="fa fa-exclamation-circle me-1"></i> No subjects mapped to this class.</small></div>
                                            <?php else: ?>
                                                <?php foreach ($clsSubjects as $sub): ?>
                                                    <div class="col-6 col-md-4">
                                                        <div class="form-check">
                                                            <input class="form-check-input subject-checkbox" type="checkbox" name="assigned_subject[]" value="<?php echo htmlspecialchars($sub['id']); ?>" data-class="<?php echo htmlspecialchars($clsName); ?>" id="sub_<?php echo md5($clsName . '_' . $sub['id']); ?>">
                                                            <label class="form-check-label small" for="sub_<?php echo md5($clsName . '_' . $sub['id']); ?>">
                                                                <?php echo htmlspecialchars($sub['name']); ?>
                                                            </label>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php 
                                    endforeach;
                                endif; 
                                ?>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                function toggleClassTeacherField() {
                    const role = document.getElementById('role_select').value;
                    const container = document.getElementById('class_teacher_container');
                    
                    if (role === 'class_teacher') {
                        container.style.display = 'block';
                    } else {
                        container.style.display = 'none';
                        const checkboxes = container.querySelectorAll('.class-teacher-checkbox');
                        checkboxes.forEach(function (chk) {
                            chk.checked = false;
                        });
                    }
                }

                document.addEventListener('DOMContentLoaded', function () {
                    // When a subject checkbox is checked, ensure its parent class checkbox is checked
                    const subjectCheckboxes = document.querySelectorAll('.subject-checkbox');
                    subjectCheckboxes.forEach(function (chk) {
                        chk.addEventListener('change', function () {
                            if (this.checked) {
                                const className = this.getAttribute('data-class');
                                const classCheckbox = document.querySelector(`.class-checkbox[value="${className}"]`);
                                if (classCheckbox) {
                                    classCheckbox.checked = true;
                                }
                            }
                        });
                    });

                    // When a class checkbox is changed
                    const classCheckboxes = document.querySelectorAll('.class-checkbox');
                    classCheckboxes.forEach(function (chk) {
                        chk.addEventListener('change', function () {
                            const className = this.value;
                            const relatedSubjects = document.querySelectorAll(`.subject-checkbox[data-class="${className}"]`);
                            
                            // If class checkbox is unchecked, uncheck all its subjects
                            if (!this.checked) {
                                relatedSubjects.forEach(function (subChk) {
                                    subChk.checked = false;
                                });
                            } else {
                                // If checked, check all its subjects
                                relatedSubjects.forEach(function (subChk) {
                                    subChk.checked = true;
                                });
                            }
                        });
                    });
                });
                </script>

                <!-- Section 5: Login Details -->
                <div class="form-section">
                    <h5 class="section-title"><i class="fa fa-key me-2 text-danger"></i> 5. Login Details</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Teacher ID</label>
                            <input type="text" name="teacher_id" class="form-control" required placeholder="e.g. TCH-2026-001">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" name="register" class="btn btn-primary btn-register shadow-sm">
                        <i class="fa fa-paper-plane me-2"></i> Submit Registration
                    </button>
                    <div class="mt-3">
                        Already have an account? <a href="../login.php">Login here</a>
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>
</body>
</html>

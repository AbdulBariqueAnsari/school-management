<?php
// teacher/exam_results.php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if (!in_array($_SESSION['role_id'], [4, 5, 8])) {
    redirect(BASE_URL . '/login.php');
}

$user_id = (int)$_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

// Retrieve teacher profile dynamically
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

$teacher = null;
$lookups = [
    ["SELECT * FROM teachers WHERE email = ?", [$user['email'] ?? '']],
    ["SELECT * FROM teachers WHERE username = ?", [$user['username'] ?? '']],
    ["SELECT * FROM teachers WHERE full_name = ?", [$user['name'] ?? '']],
];
foreach ($lookups as $lookup) {
    if (!$lookup[1][0]) continue;
    $stmt = $pdo->prepare($lookup[0]);
    $stmt->execute($lookup[1]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($teacher) break;
}

if (!$teacher) {
    $teacher = [
        'full_name' => $user['name'] ?? 'Teacher',
        'email' => $user['email'] ?? '',
        'assigned_class' => '',
        'assigned_subject' => '',
        'role' => $_SESSION['role_name'] ?? 'teacher',
        'status' => $user['is_active'] ? 'Active' : 'Inactive',
        'class_teacher_of' => '',
    ];
}

$is_class_teacher = ($_SESSION['role_id'] == 4 || ($teacher['role'] ?? '') === 'class_teacher');
$my_class_names = array_filter(array_map('trim', explode(',', $teacher['class_teacher_of'] ?? '')));

$my_teaching_classes = array_filter(array_map('trim', explode(',', $teacher['assigned_class'] ?? '')));
if ($is_class_teacher && !empty($my_class_names)) {
    foreach ($my_class_names as $mcn) {
        if (!in_array($mcn, $my_teaching_classes)) {
            $my_teaching_classes[] = $mcn;
        }
    }
}

// Handle POST request to save or forward results
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'save' || $_POST['action'] === 'forward') {
        $exam_id = (int)($_POST['exam_id'] ?? 0);
        $class_id = (int)($_POST['class_id'] ?? 0);
        $subject_id = (int)($_POST['subject_id'] ?? 0);
        
        // Subject Teacher submits -> status 'Submitted_by_Subject_Teacher'
        // Class Teacher submits -> status 'Submitted' (Principal Review)
        if ($_POST['action'] === 'forward') {
            $status = ($_SESSION['role_id'] == 5) ? 'Submitted_by_Subject_Teacher' : 'Submitted';
        } else {
            $status = 'Draft';
        }
        
        $marks = $_POST['marks'] ?? [];
        $absent = $_POST['absent'] ?? [];
        $total_marks = $_POST['total_marks'] ?? [];
        $passing_marks = $_POST['passing_marks'] ?? [];
        $remarks = $_POST['remarks'] ?? [];

        if (!$exam_id || !$class_id || !$subject_id) {
            $error_msg = "Invalid target parameters for exam, class, or subject.";
        } else {
            $pdo->beginTransaction();
            try {
                foreach ($marks as $st_id => $obtained) {
                    $st_id = (int)$st_id;
                    $is_abs = isset($absent[$st_id]) ? 1 : 0;
                    $mark_val = $is_abs ? null : ($obtained !== '' ? (float)$obtained : null);
                    $total_val = isset($total_marks[$st_id]) && $total_marks[$st_id] !== '' ? (float)$total_marks[$st_id] : 100.00;
                    $passing_val = isset($passing_marks[$st_id]) && $passing_marks[$st_id] !== '' ? (float)$passing_marks[$st_id] : 33.00;
                    $rem = $remarks[$st_id] ?? '';

                    // Check for existing mark record
                    $stmt_check = $pdo->prepare("SELECT id, status FROM exam_results WHERE student_id = ? AND exam_id = ? AND subject_id = ?");
                    $stmt_check->execute([$st_id, $exam_id, $subject_id]);
                    $existing = $stmt_check->fetch(PDO::FETCH_ASSOC);

                    if ($existing) {
                        // Lock protection: if status is Approved, we skip
                        if ($existing['status'] === 'Approved') {
                            continue;
                        }
                        $stmt_upd = $pdo->prepare("
                            UPDATE exam_results 
                            SET marks_obtained = ?, marks_total = ?, passing_marks = ?, is_absent = ?, status = ?, teacher_id = ?, remarks = ?
                            WHERE id = ?
                        ");
                        $stmt_upd->execute([$mark_val, $total_val, $passing_val, $is_abs, $status, $user_id, $rem, $existing['id']]);
                    } else {
                        $stmt_ins = $pdo->prepare("
                            INSERT INTO exam_results (student_id, exam_id, class_id, subject_id, marks_obtained, marks_total, passing_marks, is_absent, status, teacher_id, remarks)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt_ins->execute([$st_id, $exam_id, $class_id, $subject_id, $mark_val, $total_val, $passing_val, $is_abs, $status, $user_id, $rem]);
                    }
                }
                $pdo->commit();
                $success_msg = ($status === 'Submitted_by_Subject_Teacher') 
                    ? "Marks submitted successfully! forwarded to the Class Teacher for final compilation."
                    : (($status === 'Submitted') ? "Marks compiled and forwarded to the Principal for final approval!" : "Marks saved as Draft successfully.");
            } catch (Exception $e) {
                $pdo->rollBack();
                $error_msg = "Transaction failed: " . $e->getMessage();
            }
        }
    } elseif ($_POST['action'] === 'compile_class') {
        $exam_id = (int)($_POST['exam_id'] ?? 0);
        $class_id = (int)($_POST['class_id'] ?? 0);

        if (!$exam_id || !$class_id) {
            $error_msg = "Invalid parameters for compiling class results.";
        } else {
            try {
                // Class teacher compiles and forwards ALL subject results for this class and exam to Principal
                // We update all results for this class & exam that are not Approved to 'Submitted'
                $stmt_compile = $pdo->prepare("
                    UPDATE exam_results 
                    SET status = 'Submitted', teacher_id = ?
                    WHERE exam_id = ? AND class_id = ? AND status != 'Approved'
                ");
                $stmt_compile->execute([$user_id, $exam_id, $class_id]);
                $success_msg = "Superb! Class results fully compiled and forwarded to the Principal for Final Approval & Publishing!";
            } catch (Exception $e) {
                $error_msg = "Failed to compile results: " . $e->getMessage();
            }
        }
    }
}

// Self-healing function to auto-populate standard subjects for all classes if they do not exist
function ensure_all_class_subjects($pdo) {
    $standard_subjects = [
        'Mathematics', 'Science', 'English', 'Hindi', 'Social Science', 
        'EVS', 'Computer Science', 'General Knowledge', 'Moral Science', 
        'Drawing', 'Music'
    ];
    try {
        $classes_list = $pdo->query("SELECT id FROM classes")->fetchAll(PDO::FETCH_COLUMN);
        
        $stmt_check = $pdo->prepare("SELECT LOWER(TRIM(name)) FROM subjects WHERE class_id = ?");
        $stmt_ins = $pdo->prepare("INSERT INTO subjects (name, class_id) VALUES (?, ?)");
        
        foreach ($classes_list as $class_id) {
            $stmt_check->execute([$class_id]);
            $existing = $stmt_check->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($standard_subjects as $sub) {
                if (!in_array(strtolower(trim($sub)), $existing)) {
                    $stmt_ins->execute([$sub, $class_id]);
                }
            }
        }
    } catch (Exception $e) {
        // Silent fallback
    }
}

// Ensure subjects exist globally for all classes on load
ensure_all_class_subjects($pdo);

// Handle active loads
$selected_exam = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;
$selected_class = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$selected_subject = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;

// Fetch helper tables after ensuring all class subjects are seeded globally
$exams = $pdo->query("SELECT id, name FROM exams ORDER BY start_date DESC")->fetchAll(PDO::FETCH_ASSOC);
$classes = $pdo->query("SELECT id, name FROM classes ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$subjects_all = $pdo->query("SELECT id, name, class_id FROM subjects ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Auto-select subject for Subject Teacher (Role 5) if class is loaded but subject is not set
$teacher_assigned_subject_names = array_map('trim', explode(',', $teacher['assigned_subject'] ?? ''));
if ($_SESSION['role_id'] == 5 && !empty($teacher_assigned_subject_names) && $teacher_assigned_subject_names[0] !== '' && !$selected_subject && $selected_class) {
    foreach ($teacher_assigned_subject_names as $sub_name) {
        // Try exact trimmed match first
        $stmt_find_sub = $pdo->prepare("SELECT id FROM subjects WHERE class_id = ? AND LOWER(TRIM(name)) = LOWER(TRIM(?)) LIMIT 1");
        $stmt_find_sub->execute([$selected_class, $sub_name]);
        $auto_sub_id = $stmt_find_sub->fetchColumn();
        
        // Fallback: try partial / substring matching
        if (!$auto_sub_id) {
            $stmt_find_sub = $pdo->prepare("
                SELECT id FROM subjects 
                WHERE class_id = ? AND (
                    LOWER(name) LIKE LOWER(?) 
                    OR LOWER(?) LIKE CONCAT('%', LOWER(name), '%')
                ) 
                LIMIT 1
            ");
            $stmt_find_sub->execute([$selected_class, '%' . $sub_name . '%', $sub_name]);
            $auto_sub_id = $stmt_find_sub->fetchColumn();
        }

        if ($auto_sub_id) {
            $selected_subject = (int)$auto_sub_id;
            break;
        }
    }
}

$students_list = [];
$existing_marks = [];
$is_locked = false;
$overall_status = 'Not Entered';

if ($selected_exam && $selected_class && $selected_subject) {
    // Fetch Class name
    $stmt_class_info = $pdo->prepare("SELECT name FROM classes WHERE id = ?");
    $stmt_class_info->execute([$selected_class]);
    $class_name_str = $stmt_class_info->fetchColumn() ?: '';
    $class_number_str = preg_replace('/[^0-9]/', '', $class_name_str);

    // Fetch active students
    $stmt_students = $pdo->prepare("
        SELECT s.id, u.name as student_name, s.admission_no
        FROM students s
        JOIN users u ON s.user_id = u.id
        WHERE u.is_active = 1 AND (
            s.class_id = :class_id 
            OR s.class = :class_id
            OR s.class_applied = :class_id
            OR s.class = :class_name
            OR s.class_applied = :class_name
            OR (:class_number != '' AND s.class = :class_number)
            OR (:class_number != '' AND s.class_applied = :class_number)
        )
        ORDER BY u.name ASC
    ");
    $stmt_students->execute([
        'class_id' => $selected_class,
        'class_name' => $class_name_str,
        'class_number' => $class_number_str
    ]);
    $students_list = $stmt_students->fetchAll(PDO::FETCH_ASSOC);

    // Fetch existing results
    $stmt_results = $pdo->prepare("
        SELECT * FROM exam_results 
        WHERE exam_id = ? AND class_id = ? AND subject_id = ?
    ");
    $stmt_results->execute([$selected_exam, $selected_class, $selected_subject]);
    $results_rows = $stmt_results->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($results_rows as $row) {
        $existing_marks[$row['student_id']] = $row;
        // Lock: locked if Submitted or Approved
        if (in_array($row['status'], ['Submitted', 'Approved'])) {
            $is_locked = true;
            $overall_status = $row['status'];
        } elseif ($row['status'] === 'Submitted_by_Subject_Teacher' && $overall_status !== 'Submitted') {
            $overall_status = 'Submitted_by_Subject_Teacher';
            if ($_SESSION['role_id'] == 5) {
                $is_locked = true; // Subject Teacher locked once submitted
            }
        } elseif ($row['status'] === 'Draft' && !in_array($overall_status, ['Submitted', 'Submitted_by_Subject_Teacher'])) {
            $overall_status = 'Draft';
        }
    }
}

// Fetch dynamic Class Compilation Summary if Class Teacher
$compiled_students_summary = [];
$class_subjects_list = [];
if ($selected_exam && $selected_class && $is_class_teacher) {
    // Get all subjects in this class
    $stmt_class_subs = $pdo->prepare("SELECT id, name FROM subjects WHERE class_id = ? ORDER BY name ASC");
    $stmt_class_subs->execute([$selected_class]);
    $class_subjects_list = $stmt_class_subs->fetchAll(PDO::FETCH_ASSOC);

    // Fetch compiled marks spreadsheet
    $stmt_comp_all = $pdo->prepare("
        SELECT r.student_id, r.subject_id, r.marks_obtained, r.marks_total, r.is_absent, r.status
        FROM exam_results r
        WHERE r.exam_id = ? AND r.class_id = ?
    ");
    $stmt_comp_all->execute([$selected_exam, $selected_class]);
    $all_results_raw = $stmt_comp_all->fetchAll(PDO::FETCH_ASSOC);

    // Organize by student and subject
    $results_mapped = [];
    foreach ($all_results_raw as $raw_row) {
        $results_mapped[$raw_row['student_id']][$raw_row['subject_id']] = $raw_row;
    }

    // Prepare student list
    foreach ($students_list as $st) {
        $student_row = [
            'id' => $st['id'],
            'name' => $st['student_name'],
            'admission_no' => $st['admission_no'],
            'marks' => [],
            'total_obtained' => 0,
            'total_max' => 0,
            'status' => 'Pending Entry'
        ];

        $has_any_marks = false;
        $draft_count = 0;
        $sub_teacher_count = 0;
        $approved_count = 0;
        $submitted_count = 0;

        foreach ($class_subjects_list as $sub) {
            $sub_res = $results_mapped[$st['id']][$sub['id']] ?? null;
            if ($sub_res) {
                $student_row['marks'][$sub['id']] = $sub_res;
                if (!$sub_res['is_absent']) {
                    $student_row['total_obtained'] += (float)$sub_res['marks_obtained'];
                }
                $student_row['total_max'] += (float)$sub_res['marks_total'];
                $has_any_marks = true;
                
                if ($sub_res['status'] === 'Draft') $draft_count++;
                elseif ($sub_res['status'] === 'Submitted_by_Subject_Teacher') $sub_teacher_count++;
                elseif ($sub_res['status'] === 'Submitted') $submitted_count++;
                elseif ($sub_res['status'] === 'Approved') $approved_count++;
            } else {
                $student_row['marks'][$sub['id']] = null;
            }
        }

        // Determine student status
        if (!$has_any_marks) {
            $student_row['status'] = 'Not Entered';
        } elseif ($approved_count == count($class_subjects_list)) {
            $student_row['status'] = 'Approved';
        } elseif ($submitted_count == count($class_subjects_list)) {
            $student_row['status'] = 'Submitted to Principal';
        } elseif ($draft_count > 0) {
            $student_row['status'] = 'Draft';
        } else {
            $student_row['status'] = 'In Compilation';
        }

        $compiled_students_summary[] = $student_row;
    }
}

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php 
    $hero_title = $is_class_teacher ? 'Marksheet Compiler & Class Center' : 'Subject Marks Entry Desk';
    $hero_desc = $is_class_teacher ? 'Enter subject marks, view class compilation spreadsheets, and submit completed report cards to the Principal.' : 'Enter marks for your specialized subject and submit to class teachers for compilation.';
    role_page_hero($hero_title, $hero_desc, 'fa-chart-line'); 
    ?>

    <?php if ($success_msg): ?>
        <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-circle-check me-2"></i><?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger border-0 shadow-sm alert-dismissible fade show" role="alert">
            <i class="fa fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Locked Warning Alert -->
    <?php if ($is_locked): ?>
        <div class="alert alert-warning border-0 shadow-sm p-3 mb-4 rounded-3 d-flex align-items-center">
            <i class="fa fa-lock fa-xl me-3 text-warning"></i>
            <div>
                <strong class="d-block">This Marksheet is Locked (Status: <?php echo htmlspecialchars($overall_status); ?>)</strong>
                <span class="small text-muted">Marks are locked because they have been forwarded or approved. To make revisions, contact the Class Teacher or Principal for a rollback.</span>
            </div>
        </div>
    <?php endif; ?>

    <!-- Selector Card -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius: 16px;">
        <div class="card-body p-4">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label fw-bold text-secondary">Target Examination</label>
                    <select name="exam_id" class="form-select bg-light" required>
                        <option value="" disabled selected>-- Select Exam --</option>
                        <?php foreach ($exams as $ex): ?>
                            <option value="<?php echo $ex['id']; ?>" <?php echo ($selected_exam == $ex['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($ex['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label fw-bold text-secondary">Target Class</label>
                    <select name="class_id" id="classSelect" class="form-select bg-light" required>
                        <option value="" disabled selected>-- Select Class --</option>
                        <?php foreach ($classes as $cls): ?>
                            <?php 
                            if (in_array($_SESSION['role_id'], [4, 5, 8]) && !empty($my_teaching_classes)) {
                                $match = false;
                                foreach ($my_teaching_classes as $tc) {
                                    if (strtolower(trim($cls['name'])) === strtolower(trim($tc))) {
                                        $match = true;
                                        break;
                                    }
                                }
                                if (!$match) continue;
                            }
                            ?>
                            <option value="<?php echo $cls['id']; ?>" <?php echo ($selected_class == $cls['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cls['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label fw-bold text-secondary">Subject Name</label>
                    <select name="subject_id" id="subjectSelect" class="form-select bg-light" required>
                        <option value="" disabled selected>-- Select Subject --</option>
                        <!-- Filled dynamically via JS -->
                    </select>
                </div>

                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100 fw-bold shadow-sm py-2">
                        <i class="fa fa-clipboard-list me-2"></i>Load Desk
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($selected_exam && $selected_class): ?>
        <!-- Role Specific Workspace Navigation tabs -->
        <?php if ($is_class_teacher): ?>
            <ul class="nav nav-pills mb-4 gap-2" id="workspaceTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="btn btn-outline-primary active fw-bold px-4 rounded-pill" id="subject-tab" data-bs-toggle="pill" data-bs-target="#subjectWorkspace" type="button" role="tab"><i class="fa fa-pen me-2"></i>Subject Marks Entry</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="btn btn-outline-success fw-bold px-4 rounded-pill" id="class-tab" data-bs-toggle="pill" data-bs-target="#classWorkspace" type="button" role="tab"><i class="fa fa-compass me-2"></i>Class Compiler Panel</button>
                </li>
            </ul>
        <?php endif; ?>

        <div class="tab-content" id="workspaceContent">
            <!-- Subject Workspace -->
            <div class="tab-pane fade show active" id="subjectWorkspace" role="tabpanel">
                <?php if ($selected_subject): ?>
                    <form method="POST">
                        <input type="hidden" name="exam_id" value="<?php echo $selected_exam; ?>">
                        <input type="hidden" name="class_id" value="<?php echo $selected_class; ?>">
                        <input type="hidden" name="subject_id" value="<?php echo $selected_subject; ?>">

                        <div class="card border-0 shadow-sm" style="border-radius: 16px; overflow: hidden;">
                            <div class="card-header bg-white border-0 py-3 px-4 d-flex align-items-center justify-content-between">
                                <div>
                                    <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-pen-to-square text-primary me-2"></i>Marks Compiling Workspace</h5>
                                    <small class="text-muted">Status: <span class="badge bg-light text-dark border"><?php echo htmlspecialchars($overall_status); ?></span></small>
                                </div>
                                <?php if (!$is_locked): ?>
                                    <div class="d-flex gap-2">
                                        <button type="submit" name="action" value="save" class="btn btn-outline-primary fw-bold btn-sm px-3">
                                            <i class="fa fa-floppy-disk me-2"></i>Save as Draft
                                        </button>
                                        <button type="submit" name="action" value="forward" class="btn btn-success fw-bold btn-sm px-3" onclick="return confirm('Forward compiled marksheet? You will not be able to edit it unless rolled back.');">
                                            <i class="fa fa-paper-plane me-2"></i><?php echo ($_SESSION['role_id'] == 5) ? 'Submit to Class Teacher' : 'Submit to Principal'; ?>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th class="ps-4">Student</th>
                                                <th width="15%">Obtained Marks</th>
                                                <th width="15%">Total Marks</th>
                                                <th width="15%">Passing Marks</th>
                                                <th width="15%" class="text-center">Absent Indicator</th>
                                                <th width="25%" class="pe-4">Teacher Notes / Remarks</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (!$students_list): ?>
                                                <tr><td colspan="6" class="text-center py-4 text-muted">No students registered in this class.</td></tr>
                                            <?php else: ?>
                                                <?php foreach ($students_list as $st): ?>
                                                    <?php 
                                                    $record = $existing_marks[$st['id']] ?? [];
                                                    $is_abs = !empty($record['is_absent']);
                                                    $obtained_val = ($is_abs) ? '' : ($record['marks_obtained'] ?? '');
                                                    $total_val = $record['marks_total'] ?? '100';
                                                    $passing_val = $record['passing_marks'] ?? '33';
                                                    $notes = $record['remarks'] ?? '';
                                                    ?>
                                                    <tr>
                                                        <td class="ps-4">
                                                            <strong class="text-dark d-block"><?php echo htmlspecialchars($st['student_name']); ?></strong>
                                                            <small class="text-muted">Adm No: <?php echo htmlspecialchars($st['admission_no'] ?: 'N/A'); ?></small>
                                                        </td>
                                                        <td>
                                                            <input type="number" step="0.5" min="0" max="1000" 
                                                                   name="marks[<?php echo $st['id']; ?>]" 
                                                                   class="form-control form-control-sm obtained-input" 
                                                                   value="<?php echo htmlspecialchars($obtained_val); ?>"
                                                                   placeholder="Marks"
                                                                   data-student="<?php echo $st['id']; ?>"
                                                                   <?php echo ($is_locked || $is_abs) ? 'disabled' : ''; ?> required>
                                                        </td>
                                                        <td>
                                                            <input type="number" step="1" min="1" max="1000" 
                                                                   name="total_marks[<?php echo $st['id']; ?>]" 
                                                                   class="form-control form-control-sm total-input" 
                                                                   value="<?php echo htmlspecialchars($total_val); ?>"
                                                                   data-student="<?php echo $st['id']; ?>"
                                                                   <?php echo $is_locked ? 'disabled' : ''; ?> required>
                                                        </td>
                                                        <td>
                                                            <input type="number" step="1" min="1" max="1000" 
                                                                   name="passing_marks[<?php echo $st['id']; ?>]" 
                                                                   class="form-control form-control-sm passing-input" 
                                                                   value="<?php echo htmlspecialchars($passing_val); ?>"
                                                                   data-student="<?php echo $st['id']; ?>"
                                                                   <?php echo $is_locked ? 'disabled' : ''; ?> required>
                                                        </td>
                                                        <td class="text-center">
                                                            <div class="form-check form-switch d-inline-block">
                                                                <input class="form-check-input absent-toggle" type="checkbox" 
                                                                       name="absent[<?php echo $st['id']; ?>]" 
                                                                       value="1" 
                                                                       data-student="<?php echo $st['id']; ?>"
                                                                       <?php echo $is_abs ? 'checked' : ''; ?>
                                                                       <?php echo $is_locked ? 'disabled' : ''; ?>>
                                                            </div>
                                                            <span class="badge bg-danger-subtle text-danger px-2 py-1 ms-2 absent-badge <?php echo !$is_abs ? 'd-none' : ''; ?>">ABSENT</span>
                                                        </td>
                                                        <td class="pe-4">
                                                            <input type="text" name="remarks[<?php echo $st['id']; ?>]" 
                                                                   class="form-control form-control-sm" 
                                                                   value="<?php echo htmlspecialchars($notes); ?>"
                                                                   placeholder="e.g. Good performance"
                                                                   <?php echo $is_locked ? 'disabled' : ''; ?>>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- Footer Actions -->
                            <?php if (!$is_locked && $students_list): ?>
                                <div class="card-footer bg-white border-0 py-3 px-4 d-flex justify-content-end gap-2 border-top">
                                    <button type="submit" name="action" value="save" class="btn btn-outline-primary fw-bold btn-sm px-4">
                                        <i class="fa fa-floppy-disk me-2"></i>Save Draft
                                    </button>
                                    <button type="submit" name="action" value="forward" class="btn btn-success fw-bold btn-sm px-4" onclick="return confirm('Forward compiled marksheet?');">
                                        <i class="fa fa-paper-plane me-2"></i><?php echo ($_SESSION['role_id'] == 5) ? 'Submit to Class Teacher' : 'Submit to Principal'; ?>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-info border-0 shadow-sm"><i class="fa fa-info-circle me-2"></i>Please select a Subject in the dropdown to load the marksheet workspace.</div>
                <?php endif; ?>
            </div>

            <!-- Class Workspace (Only for Class Teacher) -->
            <?php if ($is_class_teacher): ?>
                <div class="tab-pane fade" id="classWorkspace" role="tabpanel">
                    <div class="card border-0 shadow-sm mb-4" style="border-radius: 16px;">
                        <div class="card-header bg-white border-0 py-3 px-4 d-flex justify-content-between align-items-center">
                            <div>
                                <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-compass text-success me-2"></i>Class Results Compilation Board</h5>
                                <small class="text-muted">Aggregated marks for all subjects in your class.</small>
                            </div>
                            <form method="POST">
                                <input type="hidden" name="exam_id" value="<?php echo $selected_exam; ?>">
                                <input type="hidden" name="class_id" value="<?php echo $selected_class; ?>">
                                <button type="submit" name="action" value="compile_class" class="btn btn-success fw-bold py-2 px-4 shadow-sm rounded-pill" onclick="return confirm('Forward all subject marksheets to the Principal? This action will freeze student marks compilation.');">
                                    <i class="fa fa-check-circle me-2"></i>Finalize &amp; Forward to Principal
                                </button>
                            </form>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th class="ps-4">Student</th>
                                            <?php foreach ($class_subjects_list as $sub): ?>
                                                <th class="text-center"><?php echo htmlspecialchars($sub['name']); ?></th>
                                            <?php endforeach; ?>
                                            <th class="text-center">Aggregated Marks</th>
                                            <th class="text-center">Percentage</th>
                                            <th class="pe-4 text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!$compiled_students_summary): ?>
                                            <tr><td colspan="<?php echo count($class_subjects_list) + 4; ?>" class="text-center py-4 text-muted">No student records found.</td></tr>
                                        <?php else: ?>
                                            <?php foreach ($compiled_students_summary as $summary_st): ?>
                                                <tr>
                                                    <td class="ps-4">
                                                        <strong class="text-dark d-block"><?php echo htmlspecialchars($summary_st['name']); ?></strong>
                                                        <small class="text-muted">Adm: <?php echo htmlspecialchars($summary_st['admission_no']); ?></small>
                                                    </td>
                                                    
                                                    <?php foreach ($class_subjects_list as $sub): ?>
                                                        <td class="text-center">
                                                            <?php 
                                                            $sub_m = $summary_st['marks'][$sub['id']] ?? null;
                                                            if ($sub_m):
                                                                if ($sub_m['is_absent']):
                                                                    echo '<span class="badge bg-danger-subtle text-danger">ABSENT</span>';
                                                                else:
                                                                    $marks_color = ((float)$sub_m['marks_obtained'] < (float)$sub_m['passing_marks']) ? 'text-danger fw-bold' : 'text-primary';
                                                                    echo '<strong class="'.$marks_color.'">' . (float)$sub_m['marks_obtained'] . '</strong> <span class="text-muted">/ ' . (float)$sub_m['marks_total'] . '</span>';
                                                                endif;
                                                            else:
                                                                echo '<span class="text-muted opacity-50 small">-- Not Entered --</span>';
                                                            endif;
                                                            ?>
                                                        </td>
                                                    <?php endforeach; ?>

                                                    <td class="text-center fw-bold">
                                                        <?php echo $summary_st['total_obtained']; ?> <span class="text-muted">/ <?php echo $summary_st['total_max']; ?></span>
                                                    </td>
                                                    
                                                    <td class="text-center">
                                                        <?php 
                                                        $perc = $summary_st['total_max'] > 0 ? round(($summary_st['total_obtained'] / $summary_st['total_max']) * 100, 2) : 0;
                                                        echo '<strong class="text-secondary">' . $perc . '%</strong>';
                                                        ?>
                                                    </td>
                                                    
                                                    <td class="pe-4 text-center">
                                                        <?php 
                                                        $status_badge = 'bg-secondary';
                                                        if ($summary_st['status'] === 'Draft') $status_badge = 'bg-light text-muted border';
                                                        elseif ($summary_st['status'] === 'Submitted to Principal') $status_badge = 'bg-success';
                                                        elseif ($summary_st['status'] === 'Approved') $status_badge = 'bg-info text-white';
                                                        elseif ($summary_st['status'] === 'In Compilation') $status_badge = 'bg-warning text-dark';
                                                        ?>
                                                        <span class="badge <?php echo $status_badge; ?>">
                                                            <?php echo htmlspecialchars($summary_st['status']); ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<!-- JavaScript dynamic loader & indicators -->
<script>
    const subjects = <?php echo json_encode($subjects_all); ?>;
    const selectedClass = <?php echo $selected_class ?: 0; ?>;
    const selectedSubject = <?php echo $selected_subject ?: 0; ?>;
    const teacherRoleId = <?php echo (int)($_SESSION['role_id'] ?? 0); ?>;
    
    // Parse comma-separated assigned subjects from PHP to JS array
    const teacherAssignedSubjects = <?php 
        $subs_array = array_map('trim', explode(',', $teacher['assigned_subject'] ?? ''));
        echo json_encode($subs_array); 
    ?>;

    const classSelect = document.getElementById('classSelect');
    const subjectSelect = document.getElementById('subjectSelect');

    function filterSubjects() {
        const classId = parseInt(classSelect.value) || 0;
        subjectSelect.innerHTML = '<option value="" disabled selected>-- Select Subject --</option>';
        
        let filtered = subjects.filter(sub => sub.class_id === classId);
        
        // Subject Teacher restriction: support multiple assigned subjects!
        const hasGeneral = teacherAssignedSubjects.some(ts => ts.trim().toLowerCase() === 'general');
        if (teacherRoleId === 5 && teacherAssignedSubjects.length > 0 && teacherAssignedSubjects[0] !== '' && !hasGeneral) {
            const matched = filtered.filter(sub => {
                const cleanSubName = sub.name.trim().toLowerCase();
                return teacherAssignedSubjects.some(ts => {
                    const cleanTs = ts.trim().toLowerCase();
                    return cleanSubName === cleanTs || cleanSubName.includes(cleanTs) || cleanTs.includes(cleanSubName);
                });
            });
            if (matched.length > 0) {
                filtered = matched;
            }
        }

        filtered.forEach(sub => {
            const opt = document.createElement('option');
            opt.value = sub.id;
            opt.textContent = sub.name;
            if (sub.id === selectedSubject || (teacherRoleId === 5 && filtered.length === 1)) {
                opt.selected = true;
            }
            subjectSelect.appendChild(opt);
        });
    }

    if (classSelect) {
        classSelect.addEventListener('change', filterSubjects);
        if (selectedClass) {
            filterSubjects();
        }
    }

    // Interactive fail highlighting
    document.querySelectorAll('.obtained-input').forEach(input => {
        const studentId = input.dataset.student;
        const passingIn = document.querySelector(`.passing-input[data-student="${studentId}"]`);
        
        function checkPassing() {
            const val = parseFloat(input.value) || 0;
            const threshold = parseFloat(passingIn.value) || 33;
            if (val < threshold && input.value !== '') {
                input.classList.add('text-danger', 'fw-bold', 'border-danger');
            } else {
                input.classList.remove('text-danger', 'fw-bold', 'border-danger');
            }
        }
        
        input.addEventListener('input', checkPassing);
        passingIn.addEventListener('input', checkPassing);
        checkPassing();
    });

    // Absent toggles
    document.querySelectorAll('.absent-toggle').forEach(chk => {
        const studentId = chk.dataset.student;
        const obInput = document.querySelector(`.obtained-input[data-student="${studentId}"]`);
        const badge = chk.parentElement.nextElementSibling;
        
        chk.addEventListener('change', function() {
            if (this.checked) {
                obInput.value = '';
                obInput.disabled = true;
                obInput.required = false;
                obInput.classList.remove('text-danger', 'fw-bold', 'border-danger');
                badge.classList.remove('d-none');
            } else {
                obInput.disabled = false;
                obInput.required = true;
                badge.classList.add('d-none');
            }
        });
    });
</script>

<?php require_once '../includes/footer.php'; ?>

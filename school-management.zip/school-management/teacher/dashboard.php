<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';

if (!in_array($_SESSION['role_id'], [4, 5, 8])) {
    redirect(BASE_URL . '/login.php');
}

$user_id = (int)$_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

$teacher = null;
$lookups = [
    ["SELECT * FROM teachers WHERE email = ?", [$user['email'] ?? '']],
    ["SELECT * FROM teachers WHERE username = ?", [$user['username'] ?? '']],
    ["SELECT * FROM teachers WHERE full_name = ?", [$user['name'] ?? '']],
];
foreach ($lookups as $lookup) {
    if (!$lookup[1][0]) {
        continue;
    }
    $stmt = $pdo->prepare($lookup[0]);
    $stmt->execute($lookup[1]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($teacher) {
        break;
    }
}

if (!$teacher) {
    $teacher = [
        'full_name' => $user['name'] ?? 'Teacher',
        'email' => $user['email'] ?? '',
        'assigned_class' => '',
        'assigned_subject' => '',
        'role' => $_SESSION['role_name'] ?? 'teacher',
        'status' => $user['is_active'] ? 'Active' : 'Inactive',
    ];
}

$fullAssignedClasses = role_field($teacher, ['class_teacher_of', 'assigned_class'], '');
$assignedClassesList = array_filter(array_map('trim', explode(',', $fullAssignedClasses)));
$assignedClass = $assignedClassesList[0] ?? '';

$assignedSubject = role_field($teacher, 'assigned_subject', '');
$teacherId = (int)role_field($teacher, 'id', 0);
$classId = $assignedClass ? role_count("SELECT id FROM classes WHERE name = ?", [$assignedClass]) : 0;
$students = $assignedClass ? role_rows("SELECT id, admission_no, student_name, gender, status FROM students WHERE class_applied = ? OR class = ? ORDER BY student_name", [$assignedClass, $assignedClass], 12) : [];

$cards = [
    ['My Students', count($students)],
    ['Assignments', $classId ? role_count("SELECT COUNT(*) FROM assignments WHERE class_id = ?", [$classId]) : 0],
    ['Attendance Rows', $assignedClass ? role_count("SELECT COUNT(*) FROM attendance a INNER JOIN students s ON a.student_id=s.id WHERE s.class_applied=? OR s.class=?", [$assignedClass, $assignedClass]) : 0],
    ['Messages', role_count("SELECT COUNT(*) FROM messages WHERE sender_id = ? OR receiver_id = ?", [$teacherId, $teacherId])],
];

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <?php role_page_hero('Teacher Dashboard', 'Class work, assigned students, attendance, assignments and communication.', 'fa-chalkboard-user'); ?>

    <div class="row g-4 mb-4">
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100 text-center" style="border-radius:14px;">
                <div class="card-body p-4">
                    <?php $photo = !empty($teacher['photo']) ? '../uploads/profile/' . htmlspecialchars($teacher['photo']) : 'https://ui-avatars.com/api/?name=' . urlencode($teacher['full_name']) . '&background=4361ee&color=fff'; ?>
                    <img src="<?php echo $photo; ?>" class="rounded-circle shadow mb-3" width="120" height="120" style="object-fit:cover;">
                    <h2 class="h4 fw-bold mb-1"><?php echo htmlspecialchars(role_field($teacher, 'full_name', 'Teacher')); ?></h2>
                    <p class="text-muted mb-3"><?php echo htmlspecialchars(role_field($teacher, 'designation', 'Faculty')); ?></p>
                    <span class="badge text-bg-primary"><?php echo htmlspecialchars($assignedSubject ?: 'Subject not assigned'); ?></span>
                    <span class="badge text-bg-light border text-dark"><?php echo htmlspecialchars($fullAssignedClasses ?: 'Class not assigned'); ?></span>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="row g-3 h-100"><?php role_render_cards($cards); ?></div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3 d-flex justify-content-between">
                    <h2 class="h5 fw-bold mb-0">My Class Students</h2>
                    <a href="module.php?type=students" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <?php role_render_table(['ID', 'Admission No', 'Student', 'Gender', 'Status'], $students, 'No assigned class students found.'); ?>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
                <div class="card-header bg-white py-3"><h2 class="h5 fw-bold mb-0">Teacher Tools</h2></div>
                <div class="list-group list-group-flush">
                    <a href="notices.php" class="list-group-item list-group-item-action"><i class="fa fa-bullhorn me-2 text-warning"></i> School Notice Board</a>
                    <a href="module.php?type=students" class="list-group-item list-group-item-action"><i class="fa fa-users me-2 text-primary"></i> My Students</a>
                    <a href="module.php?type=attendance" class="list-group-item list-group-item-action"><i class="fa fa-calendar-check me-2 text-success"></i> Attendance</a>
                    <a href="module.php?type=assignments" class="list-group-item list-group-item-action"><i class="fa fa-tasks me-2 text-warning"></i> Assignments</a>
                    <a href="exam_results.php" class="list-group-item list-group-item-action"><i class="fa fa-chart-line me-2 text-info"></i> Marks</a>
                    <a href="module.php?type=messages" class="list-group-item list-group-item-action"><i class="fa fa-envelope me-2 text-danger"></i> Messages</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

<?php
require_once '../includes/auth.php';

if (!in_array($_SESSION['role_id'], [4, 5, 8])) {
    redirect(BASE_URL . '/login.php');
}

$portal_title = 'Teacher Profile & Settings';
require_once '../includes/shared_profile.php';
?>

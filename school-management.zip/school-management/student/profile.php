<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$user_id = (int)($_SESSION['user_id'] ?? 0);
$msg = '';
$err = '';

// Fetch active exam submissions for profile listing
$my_submissions = $pdo->prepare("
    SELECT s.*, e.name as exam_name, settings.fee_amount
    FROM exam_form_submissions s
    JOIN exams e ON s.exam_id = e.id
    JOIN students st ON s.student_id = st.id
    LEFT JOIN exam_form_settings settings ON (settings.exam_id = e.id AND settings.class_id = COALESCE(NULLIF(st.class_id, 0), (SELECT id FROM classes WHERE name = st.class_applied LIMIT 1)))
    WHERE s.student_id = ?
    ORDER BY s.submitted_at DESC
");
$my_submissions->execute([$student['id']]);
$submissions_list = $my_submissions->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $mobile = trim($_POST['mobile_number'] ?? '');
    $address = trim($_POST['present_address'] ?? '');

    try {
        $stmtS = $pdo->prepare("UPDATE students SET student_mobile = ?, present_address = ? WHERE user_id = ?");
        $stmtS->execute([$mobile, $address, $user_id]);

        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $allowed = ['jpg', 'jpeg', 'png'];
            $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed, true) || $_FILES['photo']['size'] > 2097152) {
                throw new Exception('Please upload a JPG or PNG image up to 2MB.');
            }

            $uploadDir = BASE_PATH . '/uploads/students/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $newName = 'stu_' . $user_id . '_' . time() . '.' . $ext;
            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $uploadDir . $newName)) {
                throw new Exception('Could not save the uploaded photo.');
            }

            $pdo->prepare("UPDATE users SET profile_photo = ? WHERE id = ?")->execute([$newName, $user_id]);
            $pdo->prepare("UPDATE students SET student_photo = ? WHERE user_id = ?")->execute([$newName, $user_id]);
        }

        logActivity('Student updated their profile');
        $msg = 'Profile updated successfully.';
        [$student, $user] = student_portal_context();
    } catch (Exception $e) {
        $err = $e->getMessage();
    }
}

$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'My Profile';
$studentActive = 'profile';
require_once '../includes/student_header.php';
?>

<div class="d-flex flex-column flex-lg-row justify-content-between gap-3 mb-4">
    <div>
        <div class="portal-section-title mb-2">Student Profile</div>
        <h1 class="h3 fw-bold mb-0">My Profile</h1>
    </div>
    <a href="../admin/actions/export_student.php?id=<?php echo (int)$student['id']; ?>&type=student" class="btn btn-outline-primary align-self-start" target="_blank">
        <i class="fa fa-file-pdf me-2"></i> Download PDF
    </a>
</div>

<?php if ($msg): ?><div class="alert alert-success border-0 shadow-sm"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger border-0 shadow-sm"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>

<div class="row g-4">
    <div class="col-xl-4">
        <div class="portal-card p-4 text-center position-sticky" style="top:24px;">
            <img src="<?php echo htmlspecialchars($studentPhoto); ?>" alt="Profile" id="profilePreview" style="width:150px;height:150px;border-radius:50%;object-fit:cover;border:5px solid #fff;box-shadow:0 18px 40px rgba(15,23,42,0.14);">
            <h2 class="h4 fw-bold mt-4 mb-1"><?php echo htmlspecialchars(student_field($student, 'student_name', 'Student')); ?></h2>
            <p class="text-muted mb-3"><?php echo htmlspecialchars(student_field($student, 'admission_no')); ?></p>
            <div class="d-flex justify-content-center gap-2 flex-wrap">
                <span class="badge text-bg-primary px-3 py-2"><?php echo htmlspecialchars(student_field($student, ['class_applied', 'class'])); ?></span>
                <span class="badge text-bg-light border px-3 py-2"><?php echo htmlspecialchars(student_field($student, 'status', 'Active')); ?></span>
            </div>

            <form method="POST" enctype="multipart/form-data" class="text-start mt-4">
                <input type="file" id="photoInput" name="photo" class="d-none" accept="image/png,image/jpeg">
                <label for="photoInput" class="btn btn-light border w-100 mb-3"><i class="fa fa-camera me-2"></i> Change Photo</label>
                <div class="mb-3">
                    <label class="data-label">Contact Number</label>
                    <input type="text" name="mobile_number" class="form-control" value="<?php echo htmlspecialchars(student_field($student, ['student_mobile', 'mobile_number'], '')); ?>">
                </div>
                <div class="mb-3">
                    <label class="data-label">Present Address</label>
                    <textarea name="present_address" rows="4" class="form-control"><?php echo htmlspecialchars(student_field($student, ['present_address', 'address'], '')); ?></textarea>
                </div>
                <button type="submit" name="update_profile" class="btn btn-primary w-100 py-2">
                    <i class="fa fa-save me-2"></i> Save Changes
                </button>
            </form>
        </div>
    </div>

    <div class="col-xl-8">
        <div class="portal-card p-4 p-lg-5 mb-4">
            <h2 class="h5 fw-bold mb-4"><i class="fa fa-address-card text-primary me-2"></i> Basic Identity</h2>
            <div class="row">
                <div class="col-md-6"><div class="data-label">Full Name</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'student_name')); ?></div></div>
                <div class="col-md-6"><div class="data-label">Username</div><div class="data-value"><?php echo htmlspecialchars(student_field($user, 'username')); ?></div></div>
                <div class="col-md-6"><div class="data-label">Email</div><div class="data-value"><?php echo htmlspecialchars(student_field($user, 'email')); ?></div></div>
                <div class="col-md-6"><div class="data-label">DOB</div><div class="data-value"><?php echo !empty($student['dob']) ? date('d M Y', strtotime($student['dob'])) : 'N/A'; ?></div></div>
                <div class="col-md-6"><div class="data-label">Gender</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'gender')); ?></div></div>
                <div class="col-md-6"><div class="data-label">Blood Group</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'blood_group')); ?></div></div>
            </div>
        </div>

        <div class="portal-card p-4 p-lg-5 mb-4">
            <h2 class="h5 fw-bold mb-4"><i class="fa fa-school text-success me-2"></i> Academic Details</h2>
            <div class="row">
                <div class="col-md-6"><div class="data-label">Class</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, ['class_applied', 'class'])); ?></div></div>
                <div class="col-md-6"><div class="data-label">Section</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'section_id')); ?></div></div>
                <div class="col-md-6"><div class="data-label">Previous School</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, ['previous_school_name', 'previous_school'])); ?></div></div>
                <div class="col-md-6"><div class="data-label">Previous Board</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'previous_board')); ?></div></div>
            </div>
        </div>

        <div class="portal-card p-4 p-lg-5 mb-4">
            <h2 class="h5 fw-bold mb-4"><i class="fa fa-users text-info me-2"></i> Family &amp; Guardian</h2>
            <div class="row">
                <div class="col-md-6"><div class="data-label">Father</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'father_name')); ?></div></div>
                <div class="col-md-6"><div class="data-label">Father Mobile</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'father_mobile')); ?></div></div>
                <div class="col-md-6"><div class="data-label">Mother</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'mother_name')); ?></div></div>
                <div class="col-md-6"><div class="data-label">Mother Mobile</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'mother_mobile')); ?></div></div>
                <div class="col-md-6"><div class="data-label">Guardian</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'guardian_name')); ?></div></div>
                <div class="col-md-6"><div class="data-label">Relation</div><div class="data-value"><?php echo htmlspecialchars(student_field($student, 'relation')); ?></div></div>
                <div class="col-12"><div class="data-label">Parents Address</div><div class="data-value mb-0"><?php echo nl2br(htmlspecialchars(student_field($student, 'parents_address'))); ?></div></div>
            </div>
        </div>

        <div class="portal-card p-4 p-lg-5">
            <h2 class="h5 fw-bold mb-4"><i class="fa fa-receipt text-warning me-2"></i> Exam Applications &amp; Fee Receipts</h2>
            <?php if (!$submissions_list): ?>
                <div class="text-center py-4 text-muted">
                    <i class="fa fa-receipt fa-2x mb-2 opacity-50"></i>
                    <p class="mb-0">No exam applications found for your account.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Application Sl No</th>
                                <th>Exam Name</th>
                                <th>Fee</th>
                                <th>Payment Mode / Ref</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($submissions_list as $sub_item): ?>
                                <?php 
                                $sub_data = json_decode($sub_item['form_data'], true) ?: [];
                                $p_mode = $sub_data['Payment Mode'] ?? 'Cash';
                                $p_ref = $sub_data['Payment Reference/Receipt'] ?? $sub_data['Payment Reference'] ?? 'N/A';
                                
                                $badge = 'bg-secondary';
                                if ($sub_item['status'] === 'Approved') $badge = 'bg-success';
                                elseif ($sub_item['status'] === 'Rejected') $badge = 'bg-danger';
                                elseif ($sub_item['status'] === 'Pending') $badge = 'bg-warning text-dark';
                                elseif ($sub_item['status'] === 'Verified') $badge = 'bg-info text-dark';
                                ?>
                                <tr>
                                    <td><strong class="text-primary"><?php echo htmlspecialchars($sub_item['application_sl_no'] ?: 'N/A'); ?></strong></td>
                                    <td><?php echo htmlspecialchars($sub_item['exam_name']); ?></td>
                                    <td>₹<?php echo number_format($sub_item['fee_amount'], 2); ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border mb-1"><?php echo htmlspecialchars($p_mode); ?></span><br>
                                        <small class="text-muted">Ref: <strong class="text-dark"><?php echo htmlspecialchars($p_ref); ?></strong></small>
                                    </td>
                                    <td><span class="badge <?php echo $badge; ?>"><?php echo htmlspecialchars($sub_item['status']); ?></span></td>
                                    <td class="text-end">
                                        <a href="download-exam-pdf.php?submission_id=<?php echo $sub_item['id']; ?>" target="_blank" class="btn btn-sm btn-danger fw-bold"><i class="fa fa-file-pdf me-1"></i> Receipt</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
$studentExtraScripts = <<<'HTML'
<script>
document.addEventListener('DOMContentLoaded', function () {
    const input = document.getElementById('photoInput');
    const preview = document.getElementById('profilePreview');
    if (!input || !preview) return;
    input.addEventListener('change', function () {
        if (!this.files || !this.files[0]) return;
        const reader = new FileReader();
        reader.onload = event => preview.src = event.target.result;
        reader.readAsDataURL(this.files[0]);
    });
});
</script>
HTML;
require_once '../includes/student_footer.php';
?>

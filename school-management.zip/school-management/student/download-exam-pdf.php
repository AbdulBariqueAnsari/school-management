<?php
require_once '../includes/student_portal.php';
require_once '../includes/fpdf/fpdf.php';

// Authenticate student session
[$student, $user] = student_portal_context();
$student_id = (int)$student['id'];

// Get submission ID
$submission_id = isset($_GET['submission_id']) ? (int)$_GET['submission_id'] : 0;

if (!$submission_id) {
    die("Invalid application request.");
}

// Fetch submission details and verify ownership
$stmt = $pdo->prepare("
    SELECT s.*, e.name as exam_name, settings.fee_amount, 
           c.name as class_name, settings.memo_no
    FROM exam_form_submissions s
    JOIN exams e ON s.exam_id = e.id
    JOIN students st ON s.student_id = st.id
    LEFT JOIN exam_form_settings settings ON (settings.exam_id = e.id AND settings.class_id = COALESCE(NULLIF(st.class_id, 0), (SELECT id FROM classes WHERE name = st.class_applied LIMIT 1)))
    LEFT JOIN classes c ON c.id = settings.class_id
    WHERE s.id = ? AND s.student_id = ?
");
$stmt->execute([$submission_id, $student_id]);
$sub = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$sub) {
    die("Application not found or access denied.");
}

// Parse Form Data JSON
$formData = json_decode($sub['form_data'], true) ?: [];

// Get Branding settings
$stmt_brand = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings WHERE setting_key IN ('school_name')");
$school_name = $stmt_brand->fetchAll(PDO::FETCH_KEY_PAIR)['school_name'] ?? 'GLOBAL INTERNATIONAL SCHOOL';

// Extend FPDF to design a premium layout
class ExamPDF extends FPDF {
    private $schoolName;
    private $appSlNo;
    private $memoNo;

    function setBranding($schoolName, $appSlNo, $memoNo) {
        $this->schoolName = strtoupper($schoolName);
        $this->appSlNo = $appSlNo;
        $this->memoNo = $memoNo;
    }

    function Header() {
        // Page border
        $this->Rect(5, 5, 200, 287, 'D');

        // Header Title
        $this->SetFont('Arial', 'B', 15);
        $this->SetTextColor(15, 23, 42); // Navy Dark
        $this->Cell(0, 8, $this->schoolName, 0, 1, 'C');

        $this->SetFont('Arial', 'B', 10);
        $this->SetTextColor(99, 102, 241); // Accent Indigo
        $this->Cell(0, 5, 'OFFICIAL EXAMINATION APPLICATION & BIODATA RECEIPT', 0, 1, 'C');
        
        // Horizontal line
        $this->SetDrawColor(226, 232, 240);
        $this->Line(10, 26, 200, 26);
        $this->Ln(4);
    }

    function Footer() {
        // Go to 15 mm from bottom
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(100, 116, 139);
        // Print Page Number
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . ' | Generated via Student Portal System', 0, 0, 'C');
    }

    // Dynamic Helper to print styled row
    function StyledRow($label1, $val1, $label2, $val2) {
        $this->SetFont('Arial', 'B', 8);
        $this->SetTextColor(100, 116, 139); // Muted grey
        $this->Cell(45, 6, strtoupper($label1), 0, 0, 'L');
        
        $this->SetFont('Arial', '', 9.5);
        $this->SetTextColor(15, 23, 42); // Dark value
        $this->Cell(50, 6, $val1 ?: 'N/A', 0, 0, 'L');

        $this->SetFont('Arial', 'B', 8);
        $this->SetTextColor(100, 116, 139);
        $this->Cell(45, 6, strtoupper($label2), 0, 0, 'L');
        
        $this->SetFont('Arial', '', 9.5);
        $this->SetTextColor(15, 23, 42);
        $this->Cell(50, 6, $val2 ?: 'N/A', 0, 1, 'L');

        $this->Ln(1);
    }
}

// Create instance
$pdf = new ExamPDF('P', 'mm', 'A4');
$pdf->setBranding($school_name, $sub['application_sl_no'], $sub['memo_no']);
$pdf->SetMargins(10, 10, 10);
$pdf->AddPage();

// 1. Reference Block (Memo No & Application Sl No)
$pdf->SetFillColor(241, 245, 249);
$pdf->Rect(10, 29, 190, 20, 'F');

$pdf->SetXY(15, 31);
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetTextColor(71, 85, 105);
$pdf->Cell(90, 5, 'APPLICATION SERIAL NUMBER:', 0, 0, 'L');
$pdf->Cell(90, 5, 'PRINCIPAL WINDOW MEMO NO:', 0, 1, 'L');

$pdf->SetXY(15, 37);
$pdf->SetFont('Arial', 'B', 13);
$pdf->SetTextColor(67, 97, 238); // Premium Blue
$pdf->Cell(90, 8, $sub['application_sl_no'] ?: 'PENDING GENERATION', 0, 0, 'L');
$pdf->SetTextColor(15, 23, 42);
$pdf->Cell(90, 8, $sub['memo_no'] ?: 'N/A', 0, 1, 'L');

$pdf->Ln(12);

// 2. Section: Examination applied
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(224, 231, 255); // Indigo light
$pdf->SetTextColor(67, 97, 238);
$pdf->Cell(190, 7, '  1. ACADEMIC & EXAMINATION DETAILS', 0, 1, 'L', true);
$pdf->Ln(2);

$pdf->StyledRow('EXAMINATION NAME', $sub['exam_name'], 'APPLIED FOR CLASS', $sub['class_name'] ?: student_field($student, 'class_applied'));
$pdf->StyledRow('EXAM FEE DECLARED', 'Rs. ' . number_format($sub['fee_amount'], 2), 'APPLICATION STATUS', strtoupper($sub['status']));
$pdf->StyledRow('SUBMISSION DATE', date('d M Y h:i A', strtotime($sub['submitted_at'])), 'CLERK REVIEW STATUS', $sub['clerk_id'] ? 'VERIFIED' : 'PENDING REVIEW');

$pdf->Ln(4);

// 3. Section: Student Personal details (Read-Only)
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(224, 231, 255);
$pdf->SetTextColor(67, 97, 238);
$pdf->Cell(190, 7, '  2. STUDENT PERSONAL DETAILS', 0, 1, 'L', true);
$pdf->Ln(2);

$pdf->StyledRow('FULL NAME', $formData['Student Name'] ?? $student['student_name'], 'ADMISSION NUMBER', $formData['Admission No'] ?? $student['admission_no']);
$pdf->StyledRow('DATE OF BIRTH', $formData['Date of Birth'] ?? $student['dob'], 'GENDER', $formData['Gender'] ?? $student['gender']);
$pdf->StyledRow('BLOOD GROUP', $formData['Blood Group'] ?? 'N/A', 'AADHAAR NUMBER', $formData['Aadhaar Number'] ?? 'N/A');
$pdf->StyledRow('RELIGION', $formData['Religion'] ?? 'N/A', 'CASTE CATEGORY', $formData['Caste/Category'] ?? $formData['Category'] ?? 'N/A');
$pdf->StyledRow('MOTHER TONGUE', $formData['Mother Tongue'] ?? 'N/A', 'OPTIONAL SUBJECT', $formData['Optional Subject'] ?? 'None');

$pdf->Ln(4);

// 4. Section: Parent & Contact Details
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(224, 231, 255);
$pdf->SetTextColor(67, 97, 238);
$pdf->Cell(190, 7, '  3. FAMILY & CONTACT INFORMATION', 0, 1, 'L', true);
$pdf->Ln(2);

$pdf->StyledRow('FATHER NAME', $formData['Father Name'] ?? $student['father_name'], 'FATHER CONTACT', $formData['Father Mobile'] ?? 'N/A');
$pdf->StyledRow('MOTHER NAME', $formData['Mother Name'] ?? $student['mother_name'], 'MOTHER CONTACT', $formData['Mother Mobile'] ?? 'N/A');
$pdf->StyledRow('STUDENT CONTACT', $formData['Student Mobile'] ?? 'N/A', 'STUDENT EMAIL', $formData['Student Email'] ?? 'N/A');

$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(100, 116, 139);
$pdf->Cell(45, 6, 'PRESENT ADDRESS:', 0, 0, 'L');
$pdf->SetFont('Arial', '', 9);
$pdf->SetTextColor(15, 23, 42);
$pdf->MultiCell(145, 5, $formData['Present Address'] ?? 'N/A', 0, 'L');
$pdf->Ln(1);

$pdf->SetFont('Arial', 'B', 8);
$pdf->SetTextColor(100, 116, 139);
$pdf->Cell(45, 6, 'PERMANENT ADDRESS:', 0, 0, 'L');
$pdf->SetFont('Arial', '', 9);
$pdf->SetTextColor(15, 23, 42);
$pdf->MultiCell(145, 5, $formData['Permanent Address'] ?? 'N/A', 0, 'L');

$pdf->Ln(4);

// 5. Section: Payment & Declaration
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(224, 231, 255);
$pdf->SetTextColor(67, 97, 238);
$pdf->Cell(190, 7, '  4. PAYMENT METHOD & DECLARATION', 0, 1, 'L', true);
$pdf->Ln(2);

$pdf->StyledRow('DECLARED PAYMENT METHOD', $formData['Payment Mode'] ?? 'Cash at Counter', 'TRANSACTION REF / DETAILS', $formData['Payment Reference/Receipt'] ?? 'N/A');

$pdf->Ln(1);
$pdf->SetFont('Arial', 'I', 8.5);
$pdf->SetTextColor(71, 85, 105);
$pdf->MultiCell(190, 4.5, "Declaration: I hereby declare that all the information provided in this exam application and biodata form is true, complete, and correct to the best of my knowledge and belief. I agree to pay the exam fee as configured by the school administration.", 0, 'L');

$pdf->Ln(12);

// 6. Signatures block
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetTextColor(15, 23, 42);
$pdf->Cell(60, 5, '-----------------------------', 0, 0, 'C');
$pdf->Cell(65, 5, '-----------------------------', 0, 0, 'C');
$pdf->Cell(65, 5, '-----------------------------', 0, 1, 'C');

$pdf->Cell(60, 5, 'Student Signature', 0, 0, 'C');
$pdf->Cell(65, 5, 'Verifying Clerk', 0, 0, 'C');
$pdf->Cell(65, 5, 'Principal Approval', 0, 1, 'C');

// Output PDF to browser
$pdf->Output('I', 'Exam_Application_' . ($sub['application_sl_no'] ?: $sub['id']) . '.pdf');
exit();

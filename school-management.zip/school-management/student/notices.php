<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Notices & Datesheets';
$studentActive = 'notices';

$notices = [];
$schedules = [];

try {
    // Fetch standard announcements for students
    $stmt = $pdo->prepare("
        SELECT a.*, u.name as creator_name
        FROM announcements a
        LEFT JOIN users u ON a.created_by = u.id
        WHERE a.target_role_id = 6 OR a.target_role_id IS NULL
        ORDER BY a.created_at DESC
    ");
    $stmt->execute();
    $notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch approved exam schedules for student's specific class
    $stmt_sch = $pdo->prepare("
        SELECT n.*, e.name as exam_name, c.name as class_name, u.name as creator_name
        FROM exam_schedule_notices n
        JOIN exams e ON n.exam_id = e.id
        JOIN classes c ON n.class_id = c.id
        LEFT JOIN users u ON n.created_by = u.id
        WHERE n.class_id = ? AND n.status = 'Approved'
        ORDER BY n.created_at DESC
    ");
    // Determine student's class ID dynamically (handles empty class_id column fallbacks)
    $my_class_id = (int)$student['class_id'];
    if (!$my_class_id) {
        $stmt_cls_find = $pdo->prepare("
            SELECT id FROM classes 
            WHERE name = ? 
               OR name = CONCAT('Class ', ?)
               OR id = ?
            LIMIT 1
        ");
        $stmt_cls_find->execute([$student['class_applied'], $student['class'], $student['class']]);
        $my_class_id = (int)$stmt_cls_find->fetchColumn();
    }

    $stmt_sch->execute([$my_class_id]);
    $schedules = $stmt_sch->fetchAll(PDO::FETCH_ASSOC);

    // Fetch exam admit cards for student with real-time form submission status
    $stmt_admit = $pdo->prepare("
        SELECT c.*, e.name as exam_name, sub.status as form_status
        FROM exam_admit_cards c
        JOIN exams e ON c.exam_id = e.id
        LEFT JOIN exam_form_submissions sub ON (c.student_id = sub.student_id AND c.exam_id = sub.exam_id)
        WHERE c.student_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt_admit->execute([$student['id']]);
    $admit_cards = $stmt_admit->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Fallback empty
}

require_once '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-start gap-3 mb-4">
    <div>
        <div class="portal-section-title mb-2">NOTICE BOARD &amp; TIMETABLES</div>
        <h1 class="h3 fw-bold mb-0">Official Communications</h1>
    </div>
    <a href="student_dashboard.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-2"></i> Dashboard</a>
</div>

<?php 
// Filter admit cards to only show those where the exam form submission is fully Approved
$active_admit_cards = array_filter($admit_cards, function($c) {
    return $c['form_status'] === 'Approved';
});
if ($active_admit_cards): 
?>
    <div class="portal-card border-0 shadow-sm p-4 mb-4" style="background: linear-gradient(135deg, #4f46e5, #06b6d4); color: white; border-radius: 16px;">
        <div class="row align-items-center g-3">
            <div class="col-md-8">
                <h4 class="fw-bold mb-1"><i class="fa fa-id-card me-2"></i>Official Examination Hall Tickets Issued!</h4>
                <p class="mb-0 opacity-90 small">Your cryptographically sealed exam admit card is ready. Download it immediately and print a copy for the examination hall.</p>
                <div class="mt-3 d-flex flex-wrap gap-2">
                    <?php foreach ($active_admit_cards as $card): ?>
                        <span class="badge bg-white text-dark py-2 px-3 fw-bold border-0">
                            <i class="fa fa-calendar-check text-indigo me-1"></i> <?php echo htmlspecialchars($card['exam_name']); ?> (Roll: <?php echo htmlspecialchars($card['roll_number']); ?>)
                        </span>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="col-md-4 text-md-end">
                <?php foreach ($active_admit_cards as $card): ?>
                    <a href="download-admit-pdf.php?id=<?php echo $card['id']; ?>&hash=<?php echo $card['security_hash']; ?>" target="_blank" class="btn btn-light fw-bold px-4 py-2 text-primary shadow-sm mb-2 d-inline-block">
                        <i class="fa fa-download me-2"></i>Download (<?php echo htmlspecialchars($card['exam_name']); ?>)
                    </a><br>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Exam Datesheets Column -->
    <div class="col-lg-7">
        <div class="portal-card overflow-hidden h-100">
            <div class="p-4 border-bottom bg-light d-flex align-items-center justify-content-between">
                <h2 class="h5 fw-bold mb-0 text-primary"><i class="fa fa-calendar-days me-2"></i>Exam Timetables &amp; Datesheets</h2>
                <span class="badge bg-primary-subtle text-primary fw-semibold px-3 py-2 rounded-pill"><?php echo count($schedules); ?> Active</span>
            </div>
            
            <div class="p-4">
                <?php if (!$schedules): ?>
                    <div class="py-5 text-center text-muted">
                        <i class="fa fa-calendar-xmark fa-3x mb-3 text-secondary opacity-50"></i>
                        <p class="mb-0">No exam timetables published for your class yet.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($schedules as $sch): ?>
                        <?php 
                        $sch_rows = json_decode($sch['schedule_data'], true) ?: [];
                        ?>
                        <div class="card border border-light-subtle shadow-sm mb-4" style="border-radius: 12px; overflow: hidden;">
                            <div class="card-header bg-dark text-white p-3 border-0 d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="text-info small fw-bold d-block"><?php echo htmlspecialchars($sch['notice_no']); ?></span>
                                    <strong class="fs-5"><?php echo htmlspecialchars($sch['exam_name']); ?></strong>
                                </div>
                                <span class="badge bg-light text-dark"><?php echo htmlspecialchars($sch['class_name']); ?></span>
                            </div>
                            <div class="card-body p-3">
                                <div class="table-responsive">
                                    <table class="table table-sm table-hover align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Subject</th>
                                                <th>Date</th>
                                                <th>Timing</th>
                                                <th class="text-end">Full Marks</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($sch_rows as $row): ?>
                                                <tr>
                                                    <td><strong class="text-dark"><?php echo htmlspecialchars($row['subject'] ?? 'N/A'); ?></strong></td>
                                                    <td>
                                                        <span class="badge bg-light text-dark border">
                                                            <i class="fa fa-calendar text-primary me-1"></i>
                                                            <?php echo !empty($row['date']) ? date('d M Y', strtotime($row['date'])) : 'N/A'; ?>
                                                        </span>
                                                    </td>
                                                    <td><small class="text-muted fw-semibold"><?php echo htmlspecialchars($row['time'] ?? 'N/A'); ?></small></td>
                                                    <td class="text-end fw-bold text-primary"><?php echo htmlspecialchars($row['full_marks'] ?? 'N/A'); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer bg-light border-0 py-2 px-3 text-muted small d-flex justify-content-between">
                                <span>Published by: <strong><?php echo htmlspecialchars($sch['creator_name'] ?: 'Principal'); ?></strong></span>
                                <span>Date: <?php echo date('d M Y', strtotime($sch['created_at'])); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- General Notices Column -->
    <div class="col-lg-5">
        <div class="portal-card overflow-hidden h-100">
            <div class="p-4 border-bottom bg-light d-flex align-items-center justify-content-between">
                <h2 class="h5 fw-bold mb-0 text-success"><i class="fa fa-bullhorn me-2"></i>School Announcements</h2>
                <span class="badge bg-success-subtle text-success fw-semibold px-3 py-2 rounded-pill"><?php echo count($notices); ?> Total</span>
            </div>
            
            <?php if (!$notices): ?>
                <div class="p-5 text-center text-muted">
                    <i class="fa fa-bell-slash fa-3x mb-3 text-secondary opacity-50"></i>
                    <p class="mb-0">No notices at the moment.</p>
                </div>
            <?php else: ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($notices as $notice): ?>
                        <div class="list-group-item p-4">
                            <div class="d-flex w-100 justify-content-between mb-2 align-items-center">
                                <h5 class="mb-0 fw-bold text-success fs-6"><?php echo htmlspecialchars($notice['title']); ?></h5>
                                <small class="text-muted text-nowrap ms-2"><i class="fa fa-clock me-1"></i><?php echo date('d M', strtotime($notice['created_at'])); ?></small>
                            </div>
                            <p class="mb-2 text-secondary small" style="line-height: 1.5;"><?php echo nl2br(htmlspecialchars($notice['content'])); ?></p>
                            
                            <!-- Attachments display -->
                            <?php if (!empty($notice['attachment_path'])): ?>
                                <div class="mt-3 p-2 border rounded-3 bg-light d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center gap-2">
                                        <?php if ($notice['attachment_type'] === 'pdf'): ?>
                                            <i class="fa-solid fa-file-pdf text-danger fs-4"></i>
                                            <div>
                                                <span class="d-block small fw-bold text-dark text-truncate" style="max-width: 150px;">Document.pdf</span>
                                                <small class="text-muted small">PDF Notice Document</small>
                                            </div>
                                        <?php else: ?>
                                            <i class="fa-solid fa-image text-primary fs-4"></i>
                                            <div>
                                                <span class="d-block small fw-bold text-dark text-truncate" style="max-width: 150px;">Image_Notice.jpg</span>
                                                <small class="text-muted small">Visual Notice Attachment</small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <?php if ($notice['attachment_type'] === 'pdf'): ?>
                                            <a href="<?php echo BASE_URL . '/' . htmlspecialchars($notice['attachment_path']); ?>" target="_blank" class="btn btn-xs btn-outline-danger fw-bold py-1 px-2.5 shadow-none" style="font-size:0.75rem;">
                                                <i class="fa-solid fa-arrow-up-right-from-square me-1"></i>Open PDF
                                            </a>
                                        <?php else: ?>
                                            <button class="btn btn-xs btn-outline-primary fw-bold py-1 px-2.5 shadow-none" style="font-size:0.75rem;" data-bs-toggle="modal" data-bs-target="#studentViewImageModal<?php echo $notice['id']; ?>">
                                                <i class="fa-solid fa-eye me-1"></i>View Image
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top border-light">
                                <span class="text-muted small" style="font-size: 0.75rem;">Posted by: <strong><?php echo htmlspecialchars($notice['creator_name'] ?? 'Admin'); ?></strong></span>
                                <small class="text-muted small" style="font-size: 0.75rem;"><?php echo date('h:i A', strtotime($notice['created_at'])); ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal Definitions for Students -->
<?php if ($notices): ?>
    <?php foreach ($notices as $notice): ?>
        <?php if (!empty($notice['attachment_path']) && $notice['attachment_type'] === 'image'): ?>
            <div class="modal fade" id="studentViewImageModal<?php echo $notice['id']; ?>" tabindex="-1" aria-hidden="true" style="background: rgba(15,23,42,0.65); backdrop-filter: blur(10px);">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content border-0 bg-transparent">
                        <div class="text-end mb-2">
                            <button type="button" class="btn-close btn-close-white fs-4" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="text-center">
                            <img src="<?php echo BASE_URL . '/' . htmlspecialchars($notice['attachment_path']); ?>" class="img-fluid rounded shadow-lg" style="max-height: 80vh; object-fit: contain;">
                            <div class="text-white mt-3 fw-bold fs-5"><?php echo htmlspecialchars($notice['title']); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once '../includes/student_footer.php'; ?>

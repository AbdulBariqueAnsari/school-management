<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Exam Forms';
$studentActive = 'exam_forms';
$student_id = (int)$student['id'];
$class_id = student_class_id($student);

$success_msg = '';
$error_msg = '';

$class_name = '';
if ($class_id) {
    try {
        $class_name = $pdo->query("SELECT name FROM classes WHERE id = " . (int)$class_id)->fetchColumn();
    } catch(Exception $e) {
        $class_name = 'N/A';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['exam_id'])) {
    $exam_id = (int)$_POST['exam_id'];
    
    // Collect comprehensive modern school form/biodata fields
    $form_data = [
        'Student Name' => $_POST['student_name'] ?? '',
        'Admission No' => $_POST['admission_no'] ?? '',
        'Class' => $_POST['class_name'] ?? '',
        'Date of Birth' => $_POST['dob'] ?? '',
        'Gender' => $_POST['gender'] ?? '',
        'Blood Group' => $_POST['blood_group'] ?? '',
        'Aadhaar Number' => $_POST['aadhaar_number'] ?? '',
        'Religion' => $_POST['religion'] ?? '',
        'Caste/Category' => $_POST['caste_category'] ?? '',
        'Mother Tongue' => $_POST['mother_tongue'] ?? '',
        'Father Name' => $_POST['father_name'] ?? '',
        'Mother Name' => $_POST['mother_name'] ?? '',
        'Father Mobile' => $_POST['father_mobile'] ?? '',
        'Mother Mobile' => $_POST['mother_mobile'] ?? '',
        'Present Address' => $_POST['present_address'] ?? '',
        'Permanent Address' => $_POST['permanent_address'] ?? '',
        'Student Mobile' => $_POST['student_mobile'] ?? '',
        'Student Email' => $_POST['student_email'] ?? '',
        'Optional Subject' => $_POST['optional_subject'] ?? 'None',
        'Payment Mode' => $_POST['payment_mode'] ?? 'Cash at Counter',
        'Payment Reference/Receipt' => $_POST['payment_ref'] ?? 'N/A'
    ];
    $form_data_json = json_encode($form_data);

    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("SELECT id FROM exam_form_submissions WHERE student_id = ? AND exam_id = ?");
        $stmt->execute([$student_id, $exam_id]);
        if ($stmt->fetch()) {
            $error_msg = "You have already applied for this exam.";
            $pdo->rollBack();
        } else {
            // Generate Application Sl No dynamically and check uniqueness
            do {
                $application_sl_no = "APP/EXAM/" . date('Y') . "/" . str_pad(mt_rand(10000, 99999), 5, '0', STR_PAD_LEFT);
                $check_sl = $pdo->prepare("SELECT id FROM exam_form_submissions WHERE application_sl_no = ?");
                $check_sl->execute([$application_sl_no]);
            } while ($check_sl->fetch());

            $insert = $pdo->prepare("INSERT INTO exam_form_submissions (student_id, exam_id, form_data, status, application_sl_no) VALUES (?, ?, ?, 'Pending', ?)");
            $insert->execute([$student_id, $exam_id, $form_data_json, $application_sl_no]);
            $pdo->commit();
            $success_msg = "Exam form submitted successfully! Application Serial No: " . $application_sl_no . ". Pending Clerk verification.";
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error_msg = "Error submitting form: " . $e->getMessage();
    }
}

// Fetch open exams for this class
$open_exams = [];
try {
    $stmt = $pdo->prepare("
        SELECT e.id, e.name, s.fee_amount, s.deadline, 
               sub.status as submission_status, sub.application_sl_no, sub.id as submission_id
        FROM exam_form_settings s
        JOIN exams e ON s.exam_id = e.id
        LEFT JOIN exam_form_submissions sub ON sub.student_id = ? AND sub.exam_id = e.id
        WHERE s.class_id = ? AND s.is_open = 1
    ");
    $stmt->execute([$student_id, $class_id]);
    $open_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $open_exams = [];
}

require_once '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-start gap-3 mb-4">
    <div>
        <div class="portal-section-title mb-2">Examinations</div>
        <h1 class="h3 fw-bold mb-0">Exam Form Fillup</h1>
    </div>
    <a href="student_dashboard.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-2"></i> Dashboard</a>
</div>

<?php if ($success_msg): ?>
<div class="alert alert-success"><i class="fa fa-check-circle me-2"></i><?php echo htmlspecialchars($success_msg); ?></div>
<?php endif; ?>
<?php if ($error_msg): ?>
<div class="alert alert-danger"><i class="fa fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error_msg); ?></div>
<?php endif; ?>

<div class="portal-card overflow-hidden">
    <div class="p-4 border-bottom"><h2 class="h5 fw-bold mb-0">Available Exams</h2></div>
    <?php if (!$open_exams): ?>
        <div class="p-5 text-center text-muted">
            <i class="fa fa-clipboard-list fa-3x mb-3 text-secondary"></i>
            <p class="mb-0">No exam forms are currently open for your class.</p>
        </div>
    <?php else: ?>
        <div class="list-group list-group-flush">
            <?php foreach ($open_exams as $exam): ?>
                <div class="list-group-item p-4">
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                        <div>
                            <h3 class="h5 fw-bold mb-1 text-dark"><?php echo htmlspecialchars($exam['name']); ?></h3>
                            <div class="text-muted small mb-2">
                                Fee: <strong class="text-primary">₹<?php echo number_format($exam['fee_amount'], 2); ?></strong> | Deadline: <strong><?php echo !empty($exam['deadline']) ? date('d M Y', strtotime($exam['deadline'])) : 'N/A'; ?></strong>
                            </div>
                            <?php if ($exam['submission_status']): ?>
                                <?php 
                                    $badge = 'bg-secondary';
                                    if ($exam['submission_status'] === 'Approved') $badge = 'bg-success';
                                    elseif ($exam['submission_status'] === 'Rejected') $badge = 'bg-danger';
                                    elseif ($exam['submission_status'] === 'Pending') $badge = 'bg-warning text-dark';
                                    elseif ($exam['submission_status'] === 'Verified') $badge = 'bg-info text-dark';
                                ?>
                                <span class="badge <?php echo $badge; ?>">Status: <?php echo htmlspecialchars($exam['submission_status']); ?></span>
                                <?php if (!empty($exam['application_sl_no'])): ?>
                                    <div class="mt-2 small text-muted">
                                        <strong>App Sl No:</strong> <span class="badge bg-light text-dark border"><?php echo htmlspecialchars($exam['application_sl_no']); ?></span>
                                    </div>
                                    <div class="mt-2">
                                        <a href="download-exam-pdf.php?submission_id=<?php echo $exam['submission_id']; ?>" target="_blank" class="btn btn-sm btn-outline-danger fw-bold"><i class="fa fa-file-pdf me-1"></i> Download PDF Receipt</a>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="text-end">
                            <?php if (!$exam['submission_status']): ?>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#applyModal<?php echo $exam['id']; ?>"><i class="fa fa-pen me-2"></i> Fill Form</button>
                                
                                <!-- Application Modal -->
                                <div class="modal fade" id="applyModal<?php echo $exam['id']; ?>" tabindex="-1" data-bs-backdrop="false" style="background: rgba(15,23,42,0.45); backdrop-filter: blur(4px);">
                                  <div class="modal-dialog modal-lg text-start">
                                    <form method="POST" class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
                                      <div class="modal-header border-0 pb-0 bg-light rounded-top p-4">
                                        <div>
                                            <h5 class="modal-title fw-bold text-dark"><i class="fa fa-pen-nib text-primary me-2"></i>Exam Application & Biodata</h5>
                                            <small class="text-muted"><?php echo htmlspecialchars($exam['name']); ?></small>
                                        </div>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                      </div>
                                      <div class="modal-body p-4" style="max-height:75vh; overflow-y:auto;">
                                        <input type="hidden" name="exam_id" value="<?php echo $exam['id']; ?>">
                                        
                                        <div class="alert bg-primary-subtle text-primary border-0 rounded-3 mb-4 d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong>Form Fee:</strong> ₹<?php echo number_format($exam['fee_amount'], 2); ?><br>
                                                <small class="opacity-75">Submit this form with complete biodata details.</small>
                                            </div>
                                            <div class="text-end">
                                                <span class="badge bg-primary text-white py-2 px-3 fs-6">Memo No: <?php 
                                                    $form_memo = $pdo->query("SELECT memo_no FROM exam_form_settings WHERE exam_id = " . (int)$exam['id'] . " AND class_id = " . (int)$class_id)->fetchColumn();
                                                    echo htmlspecialchars($form_memo ?: 'N/A');
                                                ?></span>
                                            </div>
                                        </div>

                                        <!-- Section: Student Details -->
                                        <h6 class="fw-bold text-primary border-bottom pb-2 mb-3"><i class="fa fa-user me-2"></i>1. Student Personal Details (Read-Only)</h6>
                                        <div class="row g-3 mb-4">
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Student Full Name</label>
                                                <input type="text" name="student_name" class="form-control bg-light" value="<?php echo htmlspecialchars($student['student_name'] ?? ''); ?>" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Admission Number</label>
                                                <input type="text" name="admission_no" class="form-control bg-light" value="<?php echo htmlspecialchars($student['admission_no'] ?? $student['admission_number'] ?? ''); ?>" readonly>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label text-muted small fw-bold mb-1">Class</label>
                                                <input type="text" name="class_name" class="form-control bg-light" value="<?php echo htmlspecialchars($class_name); ?>" readonly>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label text-muted small fw-bold mb-1">Date of Birth</label>
                                                <input type="date" name="dob" class="form-control bg-light" value="<?php echo htmlspecialchars($student['dob'] ?? ''); ?>" readonly>
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label text-muted small fw-bold mb-1">Gender</label>
                                                <input type="text" name="gender" class="form-control bg-light" value="<?php echo htmlspecialchars($student['gender'] ?? ''); ?>" readonly>
                                            </div>
                                        </div>

                                        <!-- Section: Additional Details -->
                                        <h6 class="fw-bold text-primary border-bottom pb-2 mb-3"><i class="fa fa-id-card me-2"></i>2. Additional Profile & Biodata</h6>
                                        <div class="row g-3 mb-4">
                                            <div class="col-md-3">
                                                <label class="form-label text-muted small fw-bold mb-1">Blood Group</label>
                                                <input type="text" name="blood_group" class="form-control" placeholder="e.g. O+" value="<?php echo htmlspecialchars($student['blood_group'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-5">
                                                <label class="form-label text-muted small fw-bold mb-1">Aadhaar Number</label>
                                                <input type="text" name="aadhaar_number" class="form-control" placeholder="12-digit Aadhaar" value="<?php echo htmlspecialchars($student['aadhaar_number'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label text-muted small fw-bold mb-1">Religion</label>
                                                <input type="text" name="religion" class="form-control" placeholder="e.g. Hinduism" value="<?php echo htmlspecialchars($student['religion'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Category</label>
                                                <select name="caste_category" class="form-select">
                                                    <option value="General" <?php echo (isset($student['caste_category']) && $student['caste_category'] == 'General') ? 'selected' : ''; ?>>General</option>
                                                    <option value="OBC" <?php echo (isset($student['caste_category']) && $student['caste_category'] == 'OBC') ? 'selected' : ''; ?>>OBC</option>
                                                    <option value="SC" <?php echo (isset($student['caste_category']) && $student['caste_category'] == 'SC') ? 'selected' : ''; ?>>SC</option>
                                                    <option value="ST" <?php echo (isset($student['caste_category']) && $student['caste_category'] == 'ST') ? 'selected' : ''; ?>>ST</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Mother Tongue</label>
                                                <input type="text" name="mother_tongue" class="form-control" placeholder="e.g. Hindi" value="<?php echo htmlspecialchars($student['mother_tongue'] ?? ''); ?>">
                                            </div>
                                        </div>

                                        <!-- Section: Parent Details -->
                                        <h6 class="fw-bold text-primary border-bottom pb-2 mb-3"><i class="fa fa-users me-2"></i>3. Family & Contact Information</h6>
                                        <div class="row g-3 mb-4">
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Father's Name (Read-Only)</label>
                                                <input type="text" name="father_name" class="form-control bg-light" value="<?php echo htmlspecialchars($student['father_name'] ?? $student['parent_name'] ?? ''); ?>" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Father's Mobile</label>
                                                <input type="text" name="father_mobile" class="form-control" value="<?php echo htmlspecialchars($student['father_mobile'] ?? $student['parent_phone'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Mother's Name (Read-Only)</label>
                                                <input type="text" name="mother_name" class="form-control bg-light" value="<?php echo htmlspecialchars($student['mother_name'] ?? ''); ?>" readonly>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Mother's Mobile</label>
                                                <input type="text" name="mother_mobile" class="form-control" value="<?php echo htmlspecialchars($student['mother_mobile'] ?? ''); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Student Contact Mobile</label>
                                                <input type="text" name="student_mobile" class="form-control" value="<?php echo htmlspecialchars($student['student_mobile'] ?? $student['mobile_number'] ?? ''); ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Student Email Address</label>
                                                <input type="email" name="student_email" class="form-control" value="<?php echo htmlspecialchars($student['email'] ?? $user['email'] ?? ''); ?>">
                                            </div>
                                            <div class="col-12">
                                                <label class="form-label text-muted small fw-bold mb-1">Present Address</label>
                                                <textarea name="present_address" class="form-control" rows="2" required><?php echo htmlspecialchars($student['present_address'] ?? $student['address'] ?? ''); ?></textarea>
                                            </div>
                                            <div class="col-12">
                                                <label class="form-label text-muted small fw-bold mb-1">Permanent Address</label>
                                                <textarea name="permanent_address" class="form-control" rows="2" required><?php echo htmlspecialchars($student['parents_address'] ?? $student['address'] ?? ''); ?></textarea>
                                            </div>
                                        </div>

                                        <!-- Section: Preferences & Payment -->
                                        <h6 class="fw-bold text-primary border-bottom pb-2 mb-3"><i class="fa fa-cog me-2"></i>4. Exam Electives & Payment Declaration</h6>
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Optional/Elective Subject</label>
                                                <select name="optional_subject" class="form-select">
                                                    <option value="None">None</option>
                                                    <option value="Computer Science">Computer Science</option>
                                                    <option value="Physical Education">Physical Education</option>
                                                    <option value="Art & Design">Art & Design</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label text-muted small fw-bold mb-1">Payment Method</label>
                                                <select name="payment_mode" class="form-select" required>
                                                    <option value="Cash at Counter">Cash at Counter (Pay to Clerk)</option>
                                                    <option value="Online Banking/UPI">Online Banking / UPI</option>
                                                </select>
                                            </div>
                                            <div class="col-12">
                                                <label class="form-label text-muted small fw-bold mb-1">Payment Reference / Cash Receipt details (if any)</label>
                                                <input type="text" name="payment_ref" class="form-control" placeholder="e.g. Cash Handed Over, UPI Transaction ID, or leave blank if paying now">
                                            </div>
                                            <div class="col-12 mt-4">
                                                <div class="form-check p-3 bg-light rounded-3 border">
                                                    <input type="checkbox" name="address_confirm" class="form-check-input ms-0 me-2" id="checkAdd<?php echo $exam['id']; ?>" required>
                                                    <label class="form-check-label small fw-semibold text-dark" for="checkAdd<?php echo $exam['id']; ?>">I hereby declare that all the information provided above is true, complete, and correct to the best of my knowledge and belief.</label>
                                                </div>
                                            </div>
                                        </div>
                                      </div>
                                      <div class="modal-footer border-0 bg-light rounded-bottom p-4">
                                        <button type="button" class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-success px-4 fw-bold shadow-sm"><i class="fa fa-paper-plane me-2"></i>Submit Application</button>
                                      </div>
                                    </form>
                                  </div>
                                </div>
                            <?php else: ?>
                                <button class="btn btn-outline-secondary" disabled><i class="fa fa-check-circle me-1"></i> Already Applied</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/student_footer.php'; ?>

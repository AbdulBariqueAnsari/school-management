<?php
// student/materials.php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Study Material';
$studentActive = 'materials';

$materials = [];
$error_msg = '';

try {
    // Self-healing table check/init
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `study_materials` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `title` varchar(255) NOT NULL,
          `description` text DEFAULT NULL,
          `file_path` varchar(255) NOT NULL,
          `class_id` int(11) NOT NULL,
          `subject_id` int(11) NOT NULL,
          `teacher_id` int(11) NOT NULL,
          `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
          PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ");

    // Determine student's class ID dynamically
    $my_class_id = (int)$student['class_id'];
    if (!$my_class_id) {
        $stmt_cls_find = $pdo->prepare("
            SELECT id FROM classes 
            WHERE name = ? 
               OR name = CONCAT('Class ', ?)
               OR id = ?
            LIMIT 1
        ");
        $stmt_cls_find->execute([$student['class_applied'], $student['class'], $student['class']]);
        $my_class_id = (int)$stmt_cls_find->fetchColumn();
    }

    if ($my_class_id) {
        $stmt = $pdo->prepare("
            SELECT m.*, u.name as teacher_name, s.name as subject_name
            FROM study_materials m
            LEFT JOIN users u ON m.teacher_id = u.id
            LEFT JOIN subjects s ON m.subject_id = s.id
            WHERE m.class_id = ?
            ORDER BY m.created_at DESC
        ");
        $stmt->execute([$my_class_id]);
        $materials = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $error_msg = "Could not fetch materials: " . $e->getMessage();
}

require_once '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-start gap-3 mb-4">
    <div>
        <div class="portal-section-title mb-2">ACADEMIC RESOURCES</div>
        <h1 class="h3 fw-bold mb-0">Study Material &amp; Lectures</h1>
    </div>
    <a href="student_dashboard.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-2"></i> Dashboard</a>
</div>

<?php if ($error_msg): ?>
    <div class="alert alert-danger border-0 shadow-sm"><i class="fa fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error_msg); ?></div>
<?php endif; ?>

<!-- Filter & Search Panel -->
<div class="portal-card p-3 mb-4" style="background: rgba(255,255,255,0.7); backdrop-filter: blur(10px);">
    <div class="row g-2">
        <div class="col-md-8 position-relative">
            <i class="fa fa-magnifying-glass position-absolute text-muted" style="left: 20px; top: 50%; transform: translateY(-50%);"></i>
            <input type="text" id="materialSearch" class="form-control bg-light border-0 ps-5 py-2.5" placeholder="Search resources by title, keywords or notes..." onkeyup="filterMaterials();">
        </div>
        <div class="col-md-4">
            <select id="subjectFilter" class="form-select bg-light border-0 py-2.5" onchange="filterMaterials();">
                <option value="all">All Subjects</option>
                <?php 
                $unique_subjects = array_unique(array_column($materials, 'subject_name'));
                sort($unique_subjects);
                foreach ($unique_subjects as $sub):
                    if ($sub):
                ?>
                    <option value="<?php echo htmlspecialchars($sub); ?>"><?php echo htmlspecialchars($sub); ?></option>
                <?php 
                    endif;
                endforeach; 
                ?>
            </select>
        </div>
    </div>
</div>

<div class="row g-4" id="materialsContainer">
    <?php if (!$materials): ?>
        <div class="col-12 text-center py-5">
            <div class="portal-card py-5">
                <div class="empty-state py-4">
                    <i class="fa fa-book-open fa-3x mb-3 text-secondary opacity-50"></i>
                    <h3 class="fw-bold text-dark">No Study Material Found</h3>
                    <p class="text-muted mb-0">Your class portal is fully ready. Resources uploaded by your subject teachers will instantly appear here.</p>
                </div>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($materials as $m): ?>
            <?php 
            $file_ext = strtolower(pathinfo($m['file_path'], PATHINFO_EXTENSION));
            
            // Layout customization per file extension
            $icon = 'fa-file-lines text-secondary';
            $btn_theme = 'btn-outline-primary';
            $bg_color = '#f8fafc';
            if ($file_ext === 'pdf') {
                $icon = 'fa-file-pdf text-danger';
                $btn_theme = 'btn-outline-danger';
                $bg_color = 'rgba(239, 68, 68, 0.03)';
            } elseif (in_array($file_ext, ['doc', 'docx'])) {
                $icon = 'fa-file-word text-primary';
                $btn_theme = 'btn-outline-primary';
                $bg_color = 'rgba(59, 130, 246, 0.03)';
            } elseif (in_array($file_ext, ['ppt', 'pptx'])) {
                $icon = 'fa-file-powerpoint text-warning';
                $btn_theme = 'btn-outline-warning';
                $bg_color = 'rgba(245, 158, 11, 0.03)';
            } elseif (in_array($file_ext, ['xls', 'xlsx'])) {
                $icon = 'fa-file-excel text-success';
                $btn_theme = 'btn-outline-success';
                $bg_color = 'rgba(16, 185, 129, 0.03)';
            } elseif ($file_ext === 'zip') {
                $icon = 'fa-file-zipper text-info';
                $btn_theme = 'btn-outline-info';
                $bg_color = 'rgba(6, 182, 212, 0.03)';
            } elseif (in_array($file_ext, ['png', 'jpg', 'jpeg'])) {
                $icon = 'fa-file-image text-purple';
                $btn_theme = 'btn-outline-secondary';
                $bg_color = 'rgba(139, 92, 246, 0.03)';
            }
            ?>
            <div class="col-md-6 col-xl-4 material-card-wrapper" data-subject="<?php echo htmlspecialchars($m['subject_name'] ?? ''); ?>">
                <div class="portal-card h-100 d-flex flex-column justify-content-between p-4 transition-all hover-translate" style="background-color: <?php echo $bg_color; ?>;">
                    <div>
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <span class="badge bg-white text-dark border px-2.5 py-1.5 rounded-pill shadow-sm">
                                <i class="fa fa-book-open text-primary me-1"></i> <?php echo htmlspecialchars($m['subject_name'] ?? 'General'); ?>
                            </span>
                            <span class="badge bg-light text-secondary border uppercase font-monospace" style="font-size: 0.72rem;"><?php echo $file_ext; ?></span>
                        </div>

                        <div class="d-flex gap-3 align-items-start mb-3">
                            <i class="fa-solid <?php echo $icon; ?> fs-2 mt-1"></i>
                            <div>
                                <h5 class="fw-bold text-dark mb-1 material-title"><?php echo htmlspecialchars($m['title']); ?></h5>
                                <p class="text-secondary small mb-0 material-description" style="line-height: 1.5;"><?php echo nl2br(htmlspecialchars($m['description'] ?: 'No description provided.')); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="pt-3 mt-3 border-top border-light-subtle d-flex justify-content-between align-items-center">
                        <div class="lh-sm">
                            <small class="text-muted d-block" style="font-size: 0.7rem;">Uploaded by:</small>
                            <strong class="text-dark small"><?php echo htmlspecialchars($m['teacher_name'] ?? 'School Faculty'); ?></strong>
                        </div>
                        <a href="<?php echo BASE_URL . '/' . htmlspecialchars($m['file_path']); ?>" target="_blank" class="btn btn-sm <?php echo $btn_theme; ?> fw-bold px-3 py-1.5 rounded-pill shadow-sm" download>
                            <i class="fa fa-download me-1"></i> Download
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
function filterMaterials() {
    const searchVal = document.getElementById('materialSearch').value.toLowerCase();
    const filterVal = document.getElementById('subjectFilter').value;
    const cards = document.querySelectorAll('.material-card-wrapper');

    cards.forEach(card => {
        const title = card.querySelector('.material-title').textContent.toLowerCase();
        const description = card.querySelector('.material-description').textContent.toLowerCase();
        const subject = card.getAttribute('data-subject');

        const matchesSearch = title.includes(searchVal) || description.includes(searchVal);
        const matchesFilter = (filterVal === 'all' || subject === filterVal);

        if (matchesSearch && matchesFilter) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}
</script>

<?php require_once '../includes/student_footer.php'; ?>

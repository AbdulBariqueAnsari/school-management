<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$student_id = (int)$student['id'];
$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Dashboard';
$studentActive = 'dashboard';

$className = student_field($student, ['class_applied', 'class'], 'N/A');
$sectionName = student_field($student, 'section_id', 'N/A');

$attendance_count = student_count_rows("SELECT COUNT(*) FROM attendance WHERE student_id = ?", [$student_id]);
$assignments_count = student_count_rows(
    "SELECT COUNT(*) FROM assignments WHERE class_id = ? OR class_id = 0",
    [student_class_id($student)]
);
$marks_count = student_count_rows("SELECT COUNT(*) FROM marks WHERE student_id = ?", [$student_id]);
$fees_count = student_count_rows("SELECT COUNT(*) FROM payments WHERE student_id = ?", [$student_id]);

$recent_messages = [];
try {
    $msg_stmt = $pdo->prepare("
        SELECT * FROM messages
        WHERE sender_id = ? OR receiver_id = ?
        ORDER BY created_at DESC LIMIT 3
    ");
    $msg_stmt->execute([$student_id, $student_id]);
    $recent_messages = $msg_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $recent_messages = [];
}

// Check for open exam forms
$open_exam_count = 0;
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM exam_form_settings 
        WHERE class_id = ? AND is_open = 1 AND (deadline IS NULL OR deadline >= CURRENT_DATE())
        AND exam_id NOT IN (SELECT exam_id FROM exam_form_submissions WHERE student_id = ?)
    ");
    $stmt->execute([student_class_id($student), $student_id]);
    $open_exam_count = $stmt->fetchColumn();
} catch(Exception $e){}

require_once '../includes/student_header.php';
?>

<section class="portal-card p-4 p-lg-5 mb-4" style="background: linear-gradient(135deg, #4361ee, #0891b2); color: #fff;">
    <div class="d-flex flex-column flex-md-row align-items-md-center gap-4">
        <img src="<?php echo htmlspecialchars($studentPhoto); ?>" alt="Student Photo" style="width:108px;height:108px;border-radius:50%;object-fit:cover;border:4px solid rgba(255,255,255,0.35);box-shadow:0 14px 34px rgba(15,23,42,0.22);">
        <div class="flex-grow-1">
            <div class="text-white-50 fw-semibold mb-1">Welcome back</div>
            <h1 class="fw-bold mb-2"><?php echo htmlspecialchars(student_field($student, 'student_name', 'Student')); ?></h1>
            <div class="d-flex flex-wrap gap-3 small">
                <span><i class="fa fa-id-card me-1"></i> <?php echo htmlspecialchars(student_field($student, 'admission_no')); ?></span>
                <span><i class="fa fa-chalkboard-user me-1"></i> <?php echo htmlspecialchars($className); ?></span>
                <span><i class="fa fa-layer-group me-1"></i> Section <?php echo htmlspecialchars($sectionName); ?></span>
                <span><i class="fa fa-calendar-alt me-1"></i> <?php echo !empty($student['dob']) ? date('d M Y', strtotime($student['dob'])) : 'DOB N/A'; ?></span>
            </div>
        </div>
        <a href="profile.php" class="btn btn-light text-primary fw-bold px-4">
            <i class="fa fa-user-pen me-2"></i> Profile
        </a>
    </div>
</section>

<?php if ($open_exam_count > 0): ?>
<div class="alert alert-warning border-0 shadow-sm mb-4 d-flex align-items-center gap-3 reveal" style="border-radius: 12px; background: linear-gradient(to right, #fffbeb, #fef3c7); border-left: 5px solid #f59e0b !important;">
    <div class="bg-warning text-white rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width:48px;height:48px;">
        <i class="fa fa-bell fa-lg"></i>
    </div>
    <div class="flex-grow-1">
        <h4 class="h6 fw-bold mb-1 text-dark">Exam Form Fill-up is Open!</h4>
        <p class="mb-0 text-muted small">There <?php echo $open_exam_count == 1 ? 'is 1 exam' : 'are ' . $open_exam_count . ' exams'; ?> available for application. Please fill the form before the deadline.</p>
    </div>
    <a href="exam-apply.php" class="btn btn-warning fw-bold text-dark flex-shrink-0 px-4 rounded-pill">Apply Now</a>
</div>
<?php endif; ?>

<div class="row g-3 mb-4">
    <div class="col-6 col-xl-3"><div class="portal-card p-3"><div class="text-muted small">Attendance Entries</div><div class="h3 fw-bold mb-0"><?php echo $attendance_count; ?></div></div></div>
    <div class="col-6 col-xl-3"><div class="portal-card p-3"><div class="text-muted small">Assignments</div><div class="h3 fw-bold mb-0"><?php echo $assignments_count; ?></div></div></div>
    <div class="col-6 col-xl-3"><div class="portal-card p-3"><div class="text-muted small">Result Records</div><div class="h3 fw-bold mb-0"><?php echo $marks_count; ?></div></div></div>
    <div class="col-6 col-xl-3"><div class="portal-card p-3"><div class="text-muted small">Fee Payments</div><div class="h3 fw-bold mb-0"><?php echo $fees_count; ?></div></div></div>
</div>

<div class="d-flex align-items-center justify-content-between mb-3">
    <h2 class="h5 fw-bold mb-0">Quick Modules</h2>
    <span class="badge text-bg-primary rounded-pill px-3">Student</span>
</div>

<div class="module-grid mb-5">
    <a href="profile.php" class="portal-card module-card"><span class="module-icon ic-blue"><i class="fa fa-user"></i></span><span><strong>Profile</strong><br><small class="text-muted">Identity, family and contact info</small></span></a>
    <a href="attendance.php" class="portal-card module-card"><span class="module-icon ic-green"><i class="fa fa-calendar-check"></i></span><span><strong>Attendance</strong><br><small class="text-muted">Daily attendance records</small></span></a>
    <a href="assignments.php" class="portal-card module-card"><span class="module-icon ic-purple"><i class="fa fa-tasks"></i></span><span><strong>Assignments</strong><br><small class="text-muted">Homework and tasks</small></span></a>
    <a href="materials.php" class="portal-card module-card"><span class="module-icon ic-orange"><i class="fa fa-book-open"></i></span><span><strong>Study Material</strong><br><small class="text-muted">Notes and resources</small></span></a>
    <a href="fees.php" class="portal-card module-card"><span class="module-icon ic-red"><i class="fa fa-file-invoice-dollar"></i></span><span><strong>Fees</strong><br><small class="text-muted">Dues and payments</small></span></a>
    <a href="results.php" class="portal-card module-card"><span class="module-icon ic-cyan"><i class="fa fa-chart-line"></i></span><span><strong>Results</strong><br><small class="text-muted">Exam marksheets</small></span></a>
    <a href="timetable.php" class="portal-card module-card"><span class="module-icon ic-yellow"><i class="fa fa-clock"></i></span><span><strong>Timetable</strong><br><small class="text-muted">Weekly schedule view</small></span></a>
    <a href="messages.php" class="portal-card module-card"><span class="module-icon ic-blue"><i class="fa fa-comments"></i></span><span><strong>Messages</strong><br><small class="text-muted">Contact teachers or admin</small></span></a>
    <a href="exam-apply.php" class="portal-card module-card"><span class="module-icon ic-purple"><i class="fa fa-clipboard-list"></i></span><span><strong>Exam Forms</strong><br><small class="text-muted">Apply for exams</small></span></a>
    <a href="notices.php" class="portal-card module-card"><span class="module-icon ic-green"><i class="fa fa-bullhorn"></i></span><span><strong>Notices</strong><br><small class="text-muted">School announcements</small></span></a>
</div>

<div class="portal-card">
    <div class="p-4 border-bottom d-flex justify-content-between align-items-center">
        <h2 class="h5 fw-bold mb-0">Recent Messages</h2>
        <a href="messages.php" class="text-decoration-none fw-semibold">Open all</a>
    </div>
    <?php if (!$recent_messages): ?>
        <div class="empty-state"><i class="fa fa-inbox fa-2x mb-3"></i><p class="mb-0">No recent messages yet.</p></div>
    <?php else: ?>
        <?php foreach ($recent_messages as $msg): ?>
            <div class="p-3 px-4 border-bottom d-flex justify-content-between gap-3">
                <div>
                    <div class="fw-bold"><?php echo (($msg['sender_role'] ?? '') === 'student') ? 'Sent by You' : 'School Message'; ?></div>
                    <div class="text-muted small"><?php echo htmlspecialchars($msg['message'] ?? $msg['content'] ?? ''); ?></div>
                </div>
                <small class="text-muted text-nowrap"><?php echo !empty($msg['created_at']) ? date('d M, h:i A', strtotime($msg['created_at'])) : ''; ?></small>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require_once '../includes/student_footer.php'; ?>

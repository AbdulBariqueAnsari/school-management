<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$student_id = (int)$student['id'];
$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Messages';
$studentActive = 'messages';

require_once '../includes/student_header.php';
?>

<style>
    .chat-container {
        height: calc(100vh - 64px);
        min-height: 620px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }
    .chat-messages {
        flex: 1;
        overflow-y: auto;
        background: #f8fafc;
        padding: 22px;
        display: flex;
        flex-direction: column;
        gap: 14px;
    }
    .msg-bubble {
        max-width: min(76%, 720px);
        padding: 12px 16px;
        border-radius: 18px;
        line-height: 1.5;
        box-shadow: 0 5px 16px rgba(15,23,42,0.06);
    }
    .msg-teacher { align-self: flex-start; background: #fff; border: 1px solid #e2e8f0; border-bottom-left-radius: 5px; }
    .msg-student { align-self: flex-end; background: #4361ee; color: #fff; border-bottom-right-radius: 5px; }
    .msg-time { opacity: 0.72; font-size: 0.72rem; margin-top: 6px; text-align: right; }
    .chat-input-area { display: flex; gap: 12px; padding: 16px; border-top: 1px solid #e2e8f0; background: #fff; }
    .chat-input { flex: 1; border-radius: 20px; border: 1px solid #e2e8f0; background: #f8fafc; padding: 12px 16px; resize: none; outline: none; max-height: 120px; }
    .chat-input:focus { border-color: #4361ee; box-shadow: 0 0 0 4px rgba(67,97,238,0.12); background: #fff; }
    .btn-send { width: 48px; height: 48px; border-radius: 50%; border: 0; background: #4361ee; color: #fff; flex: 0 0 auto; }
    @media (max-width: 991.98px) {
        .chat-container { min-height: calc(100vh - 110px); height: calc(100vh - 110px); }
        .msg-bubble { max-width: 90%; }
    }
</style>

<div class="portal-card chat-container">
    <div class="p-3 p-md-4 border-bottom d-flex align-items-center gap-3 bg-white">
        <div class="module-icon ic-blue"><i class="fa fa-chalkboard-teacher"></i></div>
        <div>
            <h1 class="h5 fw-bold mb-1">Teacher Center</h1>
            <small class="text-success"><i class="fa fa-circle me-1" style="font-size:7px;"></i> Message support</small>
        </div>
    </div>
    <div class="chat-messages" id="chatBox">
        <div class="text-center text-muted small my-3"><i class="fa fa-lock me-1"></i> Messages are secure.</div>
    </div>
    <div class="chat-input-area">
        <textarea id="messageInput" class="chat-input" rows="1" placeholder="Type a message..." oninput="this.style.height='';this.style.height=this.scrollHeight+'px'"></textarea>
        <button id="sendBtn" class="btn-send" type="button" onclick="sendMessage()"><i class="fa fa-paper-plane"></i></button>
    </div>
</div>

<?php
$studentExtraScripts = '<script>
const chatBox = document.getElementById("chatBox");
const messageInput = document.getElementById("messageInput");
const studentId = ' . $student_id . ';
let lastMessageCount = -1;

function escapeHtml(text) {
    return String(text || "").replace(/[&<>"\']/g, function (match) {
        return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","\'":"&#039;"}[match];
    }).replace(/\\n/g, "<br>");
}

function fetchMessages() {
    fetch("api/messages_api.php?action=fetch")
        .then(response => response.json())
        .then(data => {
            if (data.status === "success" && data.messages.length !== lastMessageCount) {
                renderMessages(data.messages);
                lastMessageCount = data.messages.length;
                chatBox.scrollTop = chatBox.scrollHeight;
            }
        });
}

function renderMessages(messages) {
    chatBox.innerHTML = \'<div class="text-center text-muted small my-3"><i class="fa fa-lock me-1"></i> Messages are secure.</div>\';
    if (!messages.length) {
        chatBox.innerHTML += \'<div class="empty-state">No messages yet. Start the conversation below.</div>\';
        return;
    }
    messages.forEach(msg => {
        const isStudent = msg.sender_role === "student" && parseInt(msg.sender_id, 10) === studentId;
        const dateObj = new Date(msg.created_at);
        const timeStr = isNaN(dateObj) ? "" : dateObj.toLocaleString("en-IN", { month: "short", day: "numeric", hour: "numeric", minute: "numeric" });
        const div = document.createElement("div");
        div.className = "msg-bubble " + (isStudent ? "msg-student" : "msg-teacher");
        div.innerHTML = escapeHtml(msg.message || msg.content || "") + \'<div class="msg-time">\' + escapeHtml(timeStr) + "</div>";
        chatBox.appendChild(div);
    });
}

function sendMessage() {
    const text = messageInput.value.trim();
    if (!text) return;
    messageInput.disabled = true;
    document.getElementById("sendBtn").disabled = true;
    const formData = new FormData();
    formData.append("message", text);
    fetch("api/messages_api.php?action=send", { method: "POST", body: formData })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                messageInput.value = "";
                messageInput.style.height = "auto";
                lastMessageCount = -1;
                fetchMessages();
            }
        })
        .finally(() => {
            messageInput.disabled = false;
            document.getElementById("sendBtn").disabled = false;
            messageInput.focus();
        });
}

messageInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
});

fetchMessages();
setInterval(fetchMessages, 3000);
</script>';
require_once '../includes/student_footer.php';
?>

<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Fees';
$studentActive = 'fees';
$student_id = (int)$student['id'];

$payments = [];
$dues = [];
try {
    // Payment History
    $stmt = $pdo->prepare("
        SELECT p.*, f.title AS fee_title, f.amount AS fee_amount, f.due_date
        FROM payments p
        LEFT JOIN fees f ON p.fee_id = f.id
        WHERE p.student_id = ?
        ORDER BY p.payment_date DESC
    ");
    $stmt->execute([$student_id]);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Dues (Fees for this class not fully paid)
    $class_id = student_class_id($student);
    $due_stmt = $pdo->prepare("
        SELECT f.id, f.title, f.amount, f.due_date,
            COALESCE((SELECT SUM(amount_paid) FROM payments p WHERE p.fee_id = f.id AND p.student_id = ?), 0) as paid_amount
        FROM fees f
        WHERE f.class_id = ?
        HAVING paid_amount < f.amount
        ORDER BY f.due_date ASC
    ");
    $due_stmt->execute([$student_id, $class_id]);
    $dues = $due_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $payments = [];
    $dues = [];
}

// Handle Mock Payment
$success_msg = '';
$error_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_fee_id'])) {
    $pay_fee_id = (int)$_POST['pay_fee_id'];
    $amount_to_pay = (float)$_POST['amount_to_pay'];
    if ($amount_to_pay > 0) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO payments (student_id, fee_id, amount_paid, payment_method, status) VALUES (?, ?, ?, 'Online', 'Completed')");
            $stmt->execute([$student_id, $pay_fee_id, $amount_to_pay]);
            $pdo->commit();
            $success_msg = "Payment of ₹" . number_format($amount_to_pay, 2) . " successful!";
            // Refresh page to show updated dues
            header("Refresh: 2");
        } catch (Exception $e) {
            $pdo->rollBack();
            $error_msg = "Payment failed. Please try again.";
        }
    } else {
        $error_msg = "Invalid amount.";
    }
}

require_once '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-start gap-3 mb-4">
    <div>
        <div class="portal-section-title mb-2">Fees & Dues</div>
        <h1 class="h3 fw-bold mb-0">Financial Overview</h1>
    </div>
    <a href="student_dashboard.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-2"></i> Dashboard</a>
</div>

<?php if ($success_msg): ?>
<div class="alert alert-success"><i class="fa fa-check-circle me-2"></i><?php echo htmlspecialchars($success_msg); ?></div>
<?php endif; ?>
<?php if ($error_msg): ?>
<div class="alert alert-danger"><i class="fa fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error_msg); ?></div>
<?php endif; ?>

<div class="row g-4 mb-4">
    <div class="col-12 col-xl-6">
        <div class="portal-card overflow-hidden h-100">
            <div class="p-4 border-bottom"><h2 class="h5 fw-bold mb-0">Pending Dues</h2></div>
            <?php if (!$dues): ?>
                <div class="p-4 text-center text-success"><i class="fa fa-check-circle fa-2x mb-3"></i><p>All clear! No pending dues.</p></div>
            <?php else: ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($dues as $due): ?>
                        <?php 
                            $balance = $due['amount'] - $due['paid_amount']; 
                            $is_overdue = !empty($due['due_date']) && strtotime($due['due_date']) < time();
                        ?>
                        <div class="list-group-item p-4">
                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                                <div>
                                    <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($due['title']); ?></h6>
                                    <div class="small text-muted mb-2">
                                        Total: ₹<?php echo number_format($due['amount'], 2); ?> | Paid: ₹<?php echo number_format($due['paid_amount'], 2); ?>
                                    </div>
                                    <span class="badge <?php echo $is_overdue ? 'text-bg-danger' : 'text-bg-warning'; ?>">
                                        Due Date: <?php echo !empty($due['due_date']) ? date('d M Y', strtotime($due['due_date'])) : 'N/A'; ?>
                                    </span>
                                </div>
                                <div class="text-end">
                                    <div class="h5 fw-bold text-danger mb-2">₹<?php echo number_format($balance, 2); ?></div>
                                    <form method="POST" onsubmit="return confirm('Confirm payment of ₹<?php echo $balance; ?>?');">
                                        <input type="hidden" name="pay_fee_id" value="<?php echo $due['id']; ?>">
                                        <input type="hidden" name="amount_to_pay" value="<?php echo $balance; ?>">
                                        <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-credit-card me-1"></i> Pay Now</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-12 col-xl-6">
        <div class="portal-card overflow-hidden h-100">
            <div class="p-4 border-bottom"><h2 class="h5 fw-bold mb-0">Payment History</h2></div>
            <?php if (!$payments): ?>
                <div class="p-4 text-center text-muted"><i class="fa fa-file-invoice-dollar fa-2x mb-3"></i><p>No fee payments are recorded yet.</p></div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="table-light"><tr><th>Fee</th><th>Paid</th><th>Method</th><th>Date</th></tr></thead>
                        <tbody>
                            <?php foreach ($payments as $payment): ?>
                                <tr>
                                    <td class="fw-semibold"><?php echo htmlspecialchars($payment['fee_title'] ?? 'Fee'); ?></td>
                                    <td class="text-success fw-bold">₹<?php echo number_format($payment['amount_paid'], 2); ?></td>
                                    <td><span class="badge bg-light text-dark border"><i class="fa fa-receipt me-1"></i><?php echo htmlspecialchars($payment['payment_method'] ?? 'N/A'); ?></span></td>
                                    <td class="small"><?php echo !empty($payment['payment_date']) ? date('d M Y', strtotime($payment['payment_date'])) : 'N/A'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/student_footer.php'; ?>

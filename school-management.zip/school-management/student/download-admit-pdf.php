<?php
require_once '../includes/auth.php';
require_once '../includes/role_helpers.php';
require_once '../includes/fpdf/fpdf.php';

// Verify session authentication
if (!isset($_SESSION['user_id'])) {
    die("Access Denied: Please log in first.");
}

$user_id = (int)$_SESSION['user_id'];
$role_id = (int)$_SESSION['role_id'];

// Get Admit Card ID and Hash from URL
$card_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$passed_hash = isset($_GET['hash']) ? trim($_GET['hash']) : '';

if (!$card_id || empty($passed_hash)) {
    die("Access Denied: Missing cryptographic parameters.");
}

// Fetch Admit Card details and join dependencies
$stmt = $pdo->prepare("
    SELECT c.*, u.name as student_name, u.email as student_email, 
           st.admission_no, st.dob, st.gender, 
           e.name as exam_name, cl.name as class_name,
           st.id as actual_student_id,
           sub.status as form_status
    FROM exam_admit_cards c
    JOIN students s ON c.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN exams e ON c.exam_id = e.id
    JOIN classes cl ON c.class_id = cl.id
    JOIN students st ON st.user_id = u.id
    LEFT JOIN exam_form_submissions sub ON (c.student_id = sub.student_id AND c.exam_id = sub.exam_id)
    WHERE c.id = ?
");
$stmt->execute([$card_id]);
$sub = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$sub) {
    die("Access Denied: Admit card not found.");
}

// SECURITY GUARD 1: Student ownership check (Anti-Guess-Hacking)
if ($role_id == 6) { // If logged-in user is a Student
    // Get their student record id
    $stmt_st = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
    $stmt_st->execute([$user_id]);
    $my_student_id = (int)$stmt_st->fetchColumn();

    if ($sub['actual_student_id'] !== $my_student_id) {
        die("Security Alert: Access Denied. You do not have ownership rights to this Admit Card!");
    }

    // Lock direct download for pending/unapproved exam applications
    if ($sub['form_status'] !== 'Approved') {
        die("Security Alert: Access Denied. Your Exam Application Form is currently pending review. Admit card is locked until fully approved.");
    }
} elseif ($role_id != 2) { // If not Principal either
    die("Access Denied: Unauthorized role access.");
}

// SECURITY GUARD 2: Cryptographic HMAC SHA-256 re-check (Anti-Forgery & Spoofing)
$salt = "SECURE_SCHOOL_ERP_SALT_2026_!@#";
$signature_payload = $sub['student_id'] . '-' . $sub['exam_id'] . '-' . $sub['class_id'] . '-' . $sub['admit_card_no'];
$expected_hash = hash_hmac('sha256', $signature_payload, $salt);

if ($sub['security_hash'] !== $expected_hash || $passed_hash !== $sub['security_hash']) {
    die("Security Threat Blocked: Cryptographic signature mismatch. This Admit Card is forged or altered!");
}

// Fetch dynamic Datesheet schedule for this exam & class to print on Admit Card
$stmt_sch = $pdo->prepare("
    SELECT schedule_data 
    FROM exam_schedule_notices 
    WHERE exam_id = ? AND class_id = ? AND status = 'Approved' 
    LIMIT 1
");
$stmt_sch->execute([$sub['exam_id'], $sub['class_id']]);
$sch_json = $stmt_sch->fetchColumn();
$sch_rows = $sch_json ? (json_decode($sch_json, true) ?: []) : [];

// Get Branding settings
$stmt_brand = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings WHERE setting_key IN ('school_name')");
$school_name = $stmt_brand->fetchAll(PDO::FETCH_KEY_PAIR)['school_name'] ?? 'GLOBAL INTERNATIONAL SCHOOL';

// Extend FPDF to design a premium layout
class AdmitCardPDF extends FPDF {
    private $schoolName;
    private $admitNo;
    private $secHash;

    function setBranding($schoolName, $admitNo, $secHash) {
        $this->schoolName = strtoupper($schoolName);
        $this->admitNo = $admitNo;
        $this->secHash = $secHash;
    }

    function Header() {
        // Page double border
        $this->Rect(5, 5, 200, 287, 'D');
        $this->Rect(6, 6, 198, 285, 'D');

        // Header Title
        $this->SetFont('Arial', 'B', 15);
        $this->SetTextColor(15, 23, 42); // Navy Dark
        $this->Cell(0, 8, $this->schoolName, 0, 1, 'C');

        $this->SetFont('Arial', 'B', 11);
        $this->SetTextColor(67, 97, 238); // Premium Blue
        $this->Cell(0, 6, 'OFFICIAL EXAMINATION ADMIT CARD', 0, 1, 'C');
        
        // Horizontal line
        $this->SetDrawColor(226, 232, 240);
        $this->Line(10, 26, 200, 26);
        $this->Ln(5);
    }

    function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-25);
        
        // Modern Cryptographic Security Seal stamp
        $this->SetFont('Courier', 'B', 8);
        $this->SetTextColor(79, 70, 229);
        $this->Cell(0, 4, 'SECURE DIGITAL SEAL: ' . $this->secHash, 0, 1, 'C');
        
        $this->SetFont('Arial', 'I', 7.5);
        $this->SetTextColor(100, 116, 139);
        $this->Cell(0, 4, 'VERIFIED BY SCHOOL ERP CRYPTOGRAPHIC SHIELD PROTOCOL. ANTI-FORGERY LOCK ACTIVE.', 0, 1, 'C');
        
        $this->SetY(-12);
        $this->Cell(0, 5, 'Page 1 of 1 | Generated Security System', 0, 0, 'C');
    }

    function StyledRow($label1, $val1, $label2, $val2) {
        $this->SetFont('Arial', 'B', 8.5);
        $this->SetTextColor(100, 116, 139);
        $this->Cell(45, 6.5, strtoupper($label1), 0, 0, 'L');
        
        $this->SetFont('Arial', 'B', 9.5);
        $this->SetTextColor(15, 23, 42);
        $this->Cell(50, 6.5, $val1 ?: 'N/A', 0, 0, 'L');

        $this->SetFont('Arial', 'B', 8.5);
        $this->SetTextColor(100, 116, 139);
        $this->Cell(45, 6.5, strtoupper($label2), 0, 0, 'L');
        
        $this->SetFont('Arial', 'B', 9.5);
        $this->SetTextColor(15, 23, 42);
        $this->Cell(50, 6.5, $val2 ?: 'N/A', 0, 1, 'L');

        $this->Ln(0.5);
    }
}

// Create instance
$pdf = new AdmitCardPDF('P', 'mm', 'A4');
$pdf->setBranding($school_name, $sub['admit_card_no'], $sub['security_hash']);
$pdf->SetMargins(10, 10, 10);
$pdf->AddPage();

// 1. Reference Block (Admit Card No & Roll)
$pdf->SetFillColor(241, 245, 249);
$pdf->Rect(10, 28, 190, 22, 'F');

$pdf->SetXY(15, 30);
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetTextColor(71, 85, 105);
$pdf->Cell(95, 5, 'ADMIT CARD SERIAL NUMBER:', 0, 0, 'L');
$pdf->Cell(85, 5, 'EXAMINATION ROLL NUMBER:', 0, 1, 'L');

$pdf->SetXY(15, 36);
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetTextColor(220, 38, 38); // High Warning Red for admit no
$pdf->Cell(95, 8, $sub['admit_card_no'], 0, 0, 'L');
$pdf->SetTextColor(15, 23, 42);
$pdf->Cell(85, 8, $sub['roll_number'] ?: 'N/A', 0, 1, 'L');

$pdf->Ln(12);

// 2. Section: Student Biodata
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(224, 231, 255); // Indigo light
$pdf->SetTextColor(67, 97, 238);
$pdf->Cell(190, 7, '  1. CANDIDATE IDENTIFICATION & BIODATA', 0, 1, 'L', true);
$pdf->Ln(2);

$pdf->StyledRow('FULL NAME', $sub['student_name'], 'CLASS & SECTION', $sub['class_name']);
$pdf->StyledRow('ADMISSION NO', $sub['admission_no'], 'GENDER', $sub['gender'] ?: 'Male');
$pdf->StyledRow('DATE OF BIRTH', $sub['dob'] ? date('d M Y', strtotime($sub['dob'])) : 'N/A', 'TARGET EXAMINATION', $sub['exam_name']);

$pdf->Ln(5);

// 3. Section: Examination Schedule (Datesheet Timetable)
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(224, 231, 255);
$pdf->SetTextColor(67, 97, 238);
$pdf->Cell(190, 7, '  2. OFFICIAL TIMETABLE & SUBJECT DATESHEET', 0, 1, 'L', true);
$pdf->Ln(3);

$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(30, 41, 59); // Slate-900 header
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(60, 8, ' Subject Name', 0, 0, 'L', true);
$pdf->Cell(45, 8, ' Exam Date', 0, 0, 'L', true);
$pdf->Cell(60, 8, ' Timings', 0, 0, 'L', true);
$pdf->Cell(25, 8, ' Full Marks', 0, 1, 'R', true);

$pdf->SetFont('Arial', '', 9);
$pdf->SetTextColor(15, 23, 42);

if (empty($sch_rows)) {
    $pdf->SetFont('Arial', 'I', 9.5);
    $pdf->Cell(190, 12, 'No active schedule matches published yet. Contact Admin office.', 1, 1, 'C');
} else {
    foreach ($sch_rows as $row) {
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->Cell(60, 8.5, ' ' . ($row['subject'] ?? 'N/A'), 'B', 0, 'L');
        
        $pdf->SetFont('Arial', '', 9);
        $exam_d = !empty($row['date']) ? date('d M Y', strtotime($row['date'])) : 'N/A';
        $pdf->Cell(45, 8.5, $exam_d, 'B', 0, 'L');
        $pdf->Cell(60, 8.5, $row['time'] ?? 'N/A', 'B', 0, 'L');
        
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->SetTextColor(67, 97, 238);
        $pdf->Cell(25, 8.5, $row['full_marks'] ?? '100', 'B', 1, 'R');
        $pdf->SetTextColor(15, 23, 42);
    }
}

$pdf->Ln(6);

// 4. Section: Rules & Instructions
$pdf->SetFont('Arial', 'B', 9.5);
$pdf->SetFillColor(254, 242, 242); // Rose light warning background
$pdf->SetTextColor(153, 27, 27); // Dark Warning Red
$pdf->Cell(190, 7, '  3. CANDIDATE INSTRUCTIONS & REGULATIONS', 0, 1, 'L', true);
$pdf->Ln(2);

$pdf->SetFont('Arial', '', 8);
$pdf->SetTextColor(31, 41, 55);
$pdf->Cell(5, 4, '1.', 0, 0);
$pdf->MultiCell(185, 4, 'Candidates must present this original signed and cryptographically signed Admit Card to gain entrance to the examination hall. Altered or forged admit cards will lead to immediate expulsion.', 0, 'L');

$pdf->Cell(5, 4, '2.', 0, 0);
$pdf->MultiCell(185, 4, 'Bring this card along with your official student identification card. Please report at least 30 minutes before the scheduled time.', 0, 'L');

$pdf->Cell(5, 4, '3.', 0, 0);
$pdf->MultiCell(185, 4, 'No digital items, smartphones, calculators, or smartwatches are permitted inside the examination hall unless explicitly authorized.', 0, 'L');

$pdf->Ln(12);

// 5. Signatures Block
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetTextColor(15, 23, 42);
$pdf->Cell(60, 4, '------------------------------', 0, 0, 'C');
$pdf->Cell(65, 4, '------------------------------', 0, 0, 'C');
$pdf->Cell(65, 4, '------------------------------', 0, 1, 'C');

$pdf->Cell(60, 4, 'Candidate Signature', 0, 0, 'C');
$pdf->Cell(65, 4, 'Controller of Exams', 0, 0, 'C');
$pdf->Cell(65, 4, 'Principal Authorization', 0, 1, 'C');

// Output PDF to browser with secure download file name
$pdf->Output('I', 'AdmitCard_' . $sub['admit_card_no'] . '.pdf');
exit();

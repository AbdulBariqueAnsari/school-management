<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Attendance';
$studentActive = 'attendance';
$student_id = (int)$student['id'];

$records = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM attendance WHERE student_id = ? ORDER BY date DESC LIMIT 120");
    $stmt->execute([$student_id]);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $records = [];
}

$summary = ['Present' => 0, 'Absent' => 0, 'Late' => 0, 'Half Day' => 0];
foreach ($records as $row) {
    if (isset($summary[$row['status']])) {
        $summary[$row['status']]++;
    }
}

require_once '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-start gap-3 mb-4">
    <div>
        <div class="portal-section-title mb-2">Attendance</div>
        <h1 class="h3 fw-bold mb-0">Daily Attendance</h1>
    </div>
    <a href="student_dashboard.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-2"></i> Dashboard</a>
</div>

<div class="row g-3 mb-4">
    <?php foreach ($summary as $label => $count): ?>
        <div class="col-6 col-lg-3">
            <div class="portal-card p-3">
                <div class="text-muted small"><?php echo htmlspecialchars($label); ?></div>
                <div class="h3 fw-bold mb-0"><?php echo $count; ?></div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="portal-card overflow-hidden">
    <div class="p-4 border-bottom"><h2 class="h5 fw-bold mb-0">Attendance Records</h2></div>
    <?php if (!$records): ?>
        <div class="empty-state"><i class="fa fa-calendar-check fa-2x mb-3"></i><p>No attendance records are available yet.</p></div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead class="table-light"><tr><th>Date</th><th>Status</th><th>Marked By</th></tr></thead>
                <tbody>
                    <?php foreach ($records as $row): ?>
                        <tr>
                            <td class="fw-semibold"><?php echo !empty($row['date']) ? date('d M Y', strtotime($row['date'])) : 'N/A'; ?></td>
                            <td><span class="badge text-bg-<?php echo $row['status'] === 'Present' ? 'success' : ($row['status'] === 'Absent' ? 'danger' : 'warning'); ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['marked_by'] ?? 'N/A'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/student_footer.php'; ?>

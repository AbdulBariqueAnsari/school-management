<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Timetable';
$studentActive = 'timetable';
require_once '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-start gap-3 mb-4">
    <div>
        <div class="portal-section-title mb-2">Timetable</div>
        <h1 class="h3 fw-bold mb-0">Weekly Schedule</h1>
    </div>
    <a href="student_dashboard.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-2"></i> Dashboard</a>
</div>

<div class="portal-card">
    <div class="empty-state">
        <i class="fa fa-clock fa-2x mb-3"></i>
        <h2 class="h5 fw-bold">No timetable published</h2>
        <p class="mb-0">This tab is ready. Your weekly class schedule will appear here once it is configured by the school.</p>
    </div>
</div>

<?php require_once '../includes/student_footer.php'; ?>

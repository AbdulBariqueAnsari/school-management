<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Assignments';
$studentActive = 'assignments';
$student_id = (int)$student['id'];
$class_id = student_class_id($student);

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['assignment_file'], $_POST['assignment_id'])) {
    $assignment_id = (int)$_POST['assignment_id'];
    $upload_dir = '../uploads/assignments/';
    if (!is_dir($upload_dir)) @mkdir($upload_dir, 0777, true);
    
    $file_name = time() . '_' . preg_replace('/[^a-zA-Z0-9.\-_]/', '', basename($_FILES['assignment_file']['name']));
    $target_file = $upload_dir . $file_name;
    
    if (move_uploaded_file($_FILES['assignment_file']['tmp_name'], $target_file)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO assignment_submissions (assignment_id, student_id, file_path) VALUES (?, ?, ?)");
            $stmt->execute([$assignment_id, $student_id, 'uploads/assignments/' . $file_name]);
            $success_msg = "Assignment uploaded successfully.";
        } catch (Exception $e) {
            $error_msg = "Database error saving submission.";
        }
    } else {
        $error_msg = "Error uploading file.";
    }
}

$assignments = [];
try {
    $stmt = $pdo->prepare("
        SELECT a.*, s.name AS subject_name,
               (SELECT file_path FROM assignment_submissions sub WHERE sub.assignment_id = a.id AND sub.student_id = ?) as submission_file,
               (SELECT marks FROM assignment_submissions sub WHERE sub.assignment_id = a.id AND sub.student_id = ?) as submission_marks
        FROM assignments a
        LEFT JOIN subjects s ON a.subject_id = s.id
        WHERE a.class_id = ?
        ORDER BY a.deadline ASC
    ");
    $stmt->execute([$student_id, $student_id, $class_id]);
    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $assignments = [];
}

require_once '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-start gap-3 mb-4">
    <div>
        <div class="portal-section-title mb-2">Assignments</div>
        <h1 class="h3 fw-bold mb-0">Homework & Tasks</h1>
    </div>
    <a href="student_dashboard.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-2"></i> Dashboard</a>
</div>

<div class="portal-card overflow-hidden">
    <div class="p-4 border-bottom d-flex justify-content-between">
        <h2 class="h5 fw-bold mb-0">Assigned Work</h2>
        <span class="badge text-bg-primary"><?php echo count($assignments); ?> total</span>
    </div>
    
    <?php if ($success_msg): ?>
    <div class="alert alert-success m-3"><i class="fa fa-check-circle me-2"></i><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
    <div class="alert alert-danger m-3"><i class="fa fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>

    <?php if (!$assignments): ?>
        <div class="empty-state"><i class="fa fa-tasks fa-2x mb-3"></i><p>No assignments have been posted for your class yet.</p></div>
    <?php else: ?>
        <div class="list-group list-group-flush">
            <?php foreach ($assignments as $assignment): ?>
                <div class="list-group-item p-4">
                    <div class="d-flex justify-content-between flex-wrap gap-2">
                        <div>
                            <h3 class="h6 fw-bold mb-1"><?php echo htmlspecialchars($assignment['title']); ?></h3>
                            <p class="text-muted mb-2"><?php echo nl2br(htmlspecialchars($assignment['description'] ?? '')); ?></p>
                            <span class="badge text-bg-light border"><?php echo htmlspecialchars($assignment['subject_name'] ?? 'Subject'); ?></span>
                        </div>
                        <div class="text-end" style="min-width: 250px;">
                            <div class="data-label">Deadline</div>
                            <div class="fw-bold mb-2"><?php echo !empty($assignment['deadline']) ? date('d M Y, h:i A', strtotime($assignment['deadline'])) : 'N/A'; ?></div>
                            
                            <?php if (!empty($assignment['file_path'])): ?>
                                <a class="btn btn-sm btn-outline-primary mb-2 w-100" href="../<?php echo htmlspecialchars($assignment['file_path']); ?>" target="_blank"><i class="fa fa-download me-1"></i> Download Assignment</a>
                            <?php endif; ?>
                            
                            <?php if (!empty($assignment['submission_file'])): ?>
                                <div class="alert alert-success p-2 mb-0 mt-2 small text-start">
                                    <i class="fa fa-check-circle me-1"></i> Submitted
                                    <?php if ($assignment['submission_marks'] !== null): ?>
                                        <br><strong>Marks:</strong> <?php echo htmlspecialchars($assignment['submission_marks']); ?>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <form action="assignments.php" method="POST" enctype="multipart/form-data" class="mt-2 text-start p-2 border rounded bg-light">
                                    <input type="hidden" name="assignment_id" value="<?php echo $assignment['id']; ?>">
                                    <div class="mb-2">
                                        <label class="form-label small mb-1">Upload Submission</label>
                                        <input type="file" name="assignment_file" class="form-control form-control-sm" required>
                                    </div>
                                    <button type="submit" class="btn btn-success btn-sm w-100"><i class="fa fa-upload me-1"></i> Submit</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/student_footer.php'; ?>

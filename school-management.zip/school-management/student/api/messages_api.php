<?php
header('Content-Type: application/json');
require_once '../../includes/init.php';

if (!isLoggedIn() || !hasRole(6)) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$student_id = $_SESSION['student_id'] ?? 0;

if (!$student_id) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid student session']);
    exit;
}

$action = $_GET['action'] ?? '';

if ($action === 'fetch') {
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM messages 
            WHERE sender_id = ? OR receiver_id = ? 
            ORDER BY created_at ASC
        ");
        $stmt->execute([$student_id, $student_id]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['status' => 'success', 'messages' => $messages]);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database error']);
    }
    exit;
}
elseif ($action === 'send') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
        exit;
    }
    
    $message = trim($_POST['message'] ?? '');
    
    if (empty($message)) {
        echo json_encode(['status' => 'error', 'message' => 'Message is required']);
        exit;
    }
    
    try {
        // Send message to "All Teachers/Admins" as receiver_id = 0
        $stmt = $pdo->prepare("
            INSERT INTO messages (sender_id, receiver_id, message, sender_role) 
            VALUES (?, ?, ?, 'student')
        ");
        $stmt->execute([$student_id, 0, $message]);
        
        echo json_encode(['status' => 'success']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Failed to send message']);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Unknown action']);

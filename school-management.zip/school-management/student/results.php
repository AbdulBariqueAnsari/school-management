<?php
require_once '../includes/student_portal.php';
[$student, $user] = student_portal_context();

$studentPhoto = student_photo_url($student, $user);
$studentPageTitle = 'Results';
$studentActive = 'results';
$student_id = (int)$student['id'];

$marks_grouped = [];
try {
    // Select ONLY fully Approved (Published) exam results
    $stmt = $pdo->prepare("
        SELECT r.*, e.name AS exam_name, s.name AS subject_name
        FROM exam_results r
        LEFT JOIN exams e ON r.exam_id = e.id
        LEFT JOIN subjects s ON r.subject_id = s.id
        WHERE r.student_id = ? AND r.status = 'Approved'
        ORDER BY e.start_date DESC, s.name ASC
    ");
    $stmt->execute([$student_id]);
    $raw_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($raw_results as $res) {
        $exam_name = $res['exam_name'] ?? 'Other Exams';
        if (!isset($marks_grouped[$exam_name])) {
            $marks_grouped[$exam_name] = [];
        }
        $marks_grouped[$exam_name][] = $res;
    }
} catch (Exception $e) {
    $marks_grouped = [];
}

require_once '../includes/student_header.php';
?>

<div class="d-flex justify-content-between align-items-start gap-3 mb-4">
    <div>
        <div class="portal-section-title mb-2">RESULTS &amp; PERFORMANCE</div>
        <h1 class="h3 fw-bold mb-0">Official Examination Scorecards</h1>
    </div>
    <a href="student_dashboard.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-2"></i> Dashboard</a>
</div>

<?php if (!$marks_grouped): ?>
    <div class="portal-card overflow-hidden text-center py-5 border-0 shadow-sm" style="border-radius: 16px;">
        <div class="empty-state py-4">
            <i class="fa fa-circle-exclamation fa-3x mb-3 text-warning"></i>
            <h4 class="fw-bold text-dark">No Published Scorecards</h4>
            <p class="text-muted mb-0">Your exam results are currently compiled by class teachers and awaiting official Principal publishing approvals.</p>
        </div>
    </div>
<?php else: ?>
    <div class="row g-4">
        <?php foreach ($marks_grouped as $exam_name => $exam_marks): ?>
            <?php
            // Calculate overall aggregates to display a premium scorecard summary
            $total_obtained = 0;
            $total_max = 0;
            $any_absent = false;
            $any_failed = false;
            
            foreach ($exam_marks as $mark) {
                if ($mark['is_absent']) {
                    $any_absent = true;
                    $any_failed = true;
                } else {
                    $total_obtained += (float)$mark['marks_obtained'];
                    if ((float)$mark['marks_obtained'] < (float)$mark['passing_marks']) {
                        $any_failed = true;
                    }
                }
                $total_max += (float)$mark['marks_total'];
            }
            
            $percentage = $total_max > 0 ? round(($total_obtained / $total_max) * 100, 2) : 0;
            
            // Standard traditional overall grade assessment
            if ($any_failed) {
                $overall_grade = 'F';
                $overall_status = 'FAILED';
                $status_theme = 'bg-danger';
                $card_gradient = 'linear-gradient(135deg, #ef4444, #f97316)';
            } else {
                $overall_status = 'PASSED';
                $status_theme = 'bg-success';
                $card_gradient = 'linear-gradient(135deg, #10b981, #06b6d4)';
                
                if ($percentage >= 90) $overall_grade = 'A+';
                elseif ($percentage >= 80) $overall_grade = 'A';
                elseif ($percentage >= 70) $overall_grade = 'B';
                elseif ($percentage >= 60) $overall_grade = 'C';
                elseif ($percentage >= 50) $overall_grade = 'D';
                elseif ($percentage >= 33) $overall_grade = 'E';
                else $overall_grade = 'F';
            }
            ?>

            <!-- Individual Scorecard Sheet -->
            <div class="col-12">
                <div class="portal-card overflow-hidden mb-4 border-0 shadow-sm" style="border-radius: 16px;">
                    
                    <!-- Scorecard Header Grid -->
                    <div class="p-4 text-white" style="background: <?php echo $card_gradient; ?>;">
                        <div class="row align-items-center g-3">
                            <div class="col-md-7">
                                <span class="badge bg-white bg-opacity-25 text-white fw-bold mb-2 py-1 px-3 border border-white border-opacity-25 rounded-pill">
                                    <i class="fa fa-award me-1"></i> Official Scorecard
                                </span>
                                <h3 class="fw-bold mb-1"><?php echo htmlspecialchars($exam_name); ?></h3>
                                <p class="mb-0 opacity-90 small">Final marks verified under cryptographically signed authorization by the School Controller of Examinations &amp; Principal.</p>
                            </div>
                            <div class="col-md-5 text-md-end">
                                <div class="d-inline-block text-start bg-white bg-opacity-15 p-3 rounded-3 border border-white border-opacity-20">
                                    <div class="row g-2 align-items-center">
                                        <div class="col-auto">
                                            <span class="small opacity-75 d-block text-uppercase fw-bold" style="font-size:0.7rem; letter-spacing:0.5px;">Overall Outcome</span>
                                            <strong class="fs-4 fw-black"><?php echo $overall_status; ?></strong>
                                        </div>
                                        <div class="col-auto ps-3 border-start border-white border-opacity-20">
                                            <span class="small opacity-75 d-block text-uppercase fw-bold" style="font-size:0.7rem; letter-spacing:0.5px;">Grade / Perc</span>
                                            <strong class="fs-4 fw-black"><?php echo $overall_grade; ?> <span class="fs-6 opacity-75">(<?php echo $percentage; ?>%)</span></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Subjects Marksheet Grid -->
                    <div class="table-responsive">
                        <table class="table align-middle mb-0 table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Subject Name</th>
                                    <th class="text-center">Obtained Marks</th>
                                    <th class="text-center">Passing Threshold</th>
                                    <th class="text-center">Maximum Marks</th>
                                    <th class="text-center">Subject Status</th>
                                    <th class="pe-4">Teacher's Evaluation</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($exam_marks as $mark): ?>
                                    <?php 
                                    $is_sub_fail = (!$mark['is_absent'] && (float)$mark['marks_obtained'] < (float)$mark['passing_marks']);
                                    ?>
                                    <tr>
                                        <td class="fw-bold text-dark ps-4"><?php echo htmlspecialchars($mark['subject_name']); ?></td>
                                        <td class="text-center fw-black">
                                            <?php if ($mark['is_absent']): ?>
                                                <span class="text-danger fw-bold"><i class="fa fa-triangle-exclamation me-1"></i> ABSENT</span>
                                            <?php else: ?>
                                                <span class="<?php echo $is_sub_fail ? 'text-danger' : 'text-primary'; ?>">
                                                    <?php echo (float)$mark['marks_obtained']; ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center text-muted fw-semibold"><?php echo (float)$mark['passing_marks']; ?></td>
                                        <td class="text-center text-muted fw-semibold"><?php echo (float)$mark['marks_total']; ?></td>
                                        <td class="text-center">
                                            <?php if ($mark['is_absent']): ?>
                                                <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill"><i class="fa fa-circle-exclamation me-1"></i> ABSENT</span>
                                            <?php elseif ($is_sub_fail): ?>
                                                <span class="badge bg-danger-subtle text-danger px-3 py-2 rounded-pill"><i class="fa fa-circle-xmark me-1"></i> FAILED</span>
                                            <?php else: ?>
                                                <span class="badge bg-success-subtle text-success px-3 py-2 rounded-pill"><i class="fa fa-circle-check me-1"></i> PASSED</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="pe-4 text-muted small italic">
                                            <?php echo htmlspecialchars($mark['remarks'] ?: 'Satisfactory completion of syllabus.'); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            
                            <!-- Scorecard Footer Aggregates -->
                            <tfoot class="table-light fw-bold">
                                <tr>
                                    <td class="ps-4 text-end">Grand Aggregates:</td>
                                    <td class="text-center text-primary fs-5 fw-black"><?php echo $total_obtained; ?></td>
                                    <td class="text-center text-muted">--</td>
                                    <td class="text-center text-dark fs-5 fw-black"><?php echo $total_max; ?></td>
                                    <td class="text-center">
                                        <span class="badge <?php echo $status_theme; ?> px-3 py-2 fs-6 shadow-sm"><?php echo $overall_status; ?></span>
                                    </td>
                                    <td class="pe-4 text-dark fs-5 fw-black">
                                        Percentage Score: <?php echo $percentage; ?>%
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once '../includes/student_footer.php'; ?>

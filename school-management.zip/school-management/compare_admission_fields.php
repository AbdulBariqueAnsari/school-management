<?php
require 'config/db.php';
$cols = $pdo->query("DESCRIBE admission_requests")->fetchAll(PDO::FETCH_COLUMN);
echo "admission_requests: " . implode(", ", $cols) . "\n\n";
$cols2 = $pdo->query("DESCRIBE students")->fetchAll(PDO::FETCH_COLUMN);
echo "students: " . implode(", ", $cols2) . "\n";

<?php
$module_key = 'routine';
$module_title = 'Class Routine';
$module_icon = 'fa-clock';
require_once __DIR__ . '/includes/class_module.php';
?>

<?php
require_once '../includes/auth.php';
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$stmt = $pdo->query("SELECT * FROM teachers WHERE status = 'Pending' ORDER BY created_at DESC");
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>
<?php include 'includes/teacher_page_styles.php'; ?>

<div class="container-fluid py-4">
    <div class="tp-header tp-header--yellow">
        <div>
            <h2><i class="fa fa-clock me-2"></i> Pending Applications</h2>
            <p>Awaiting admin review — <strong><?php echo count($teachers); ?></strong> records</p>
        </div>
        <div>
            <a href="teachers.php" class="tp-back-btn"><i class="fa fa-arrow-left me-1"></i> Back</a>
        </div>
    </div>

    <?php if (empty($teachers)): ?>
        <div class="tp-empty">
            <i class="fa fa-clock fa-3x text-warning mb-3"></i>
            <p class="text-muted">No pending applications found.</p>
        </div>
    <?php
else: ?>
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 bg-white tp-table">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Teacher</th>
                        <th>Subject</th>
                        <th>Designation</th>
                        <th>Class</th>
                        <th>Experience</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($teachers as $i => $t): ?>
                    <tr class="tp-row" data-id="<?php echo $t['id']; ?>">
                        <td><span class="text-muted small"><?php echo $i + 1; ?></span></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <img src="../uploads/profile/<?php echo $t['photo'] ?: 'default-teacher.png'; ?>"
                                     class="rounded-circle border border-2 border-white shadow-sm"
                                     width="42" height="42" style="object-fit:cover;"
                                     onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($t['full_name']); ?>&background=random'">
                                <div>
                                    <span class="fw-bold d-block"><?php echo htmlspecialchars($t['full_name']); ?></span>
                                    <small class="text-muted"><?php echo htmlspecialchars($t['teacher_id']); ?></small>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-warning bg-opacity-15 text-warning border border-warning-subtle"><?php echo htmlspecialchars($t['assigned_subject']); ?></span></td>
                        <td><small><?php echo htmlspecialchars($t['designation']); ?></small></td>
                        <td><small class="fw-semibold"><?php echo htmlspecialchars($t['assigned_class']); ?></small></td>
                        <td><span class="fw-bold"><?php echo htmlspecialchars($t['experience_years']); ?></span> <small class="text-muted">yrs</small></td>
                        <td><span class="badge bg-warning text-dark">Pending</span></td>
                    </tr>
                    <!-- Action Panel -->
                    <tr class="tp-action-row" id="panel-<?php echo $t['id']; ?>" style="display:none;">
                        <td colspan="7">
                            <div class="tp-action-panel">
                                <a href="teacher_profile.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-view"><i class="fa fa-eye"></i> View</a>
                                <a href="edit_teacher.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-edit"><i class="fa fa-edit"></i> Edit</a>
                                <a href="actions/export_teacher.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-pdf" target="_blank"><i class="fa fa-file-pdf"></i> Export PDF</a>
                                <button class="tp-btn tp-btn-approve btn-confirm"
                                        data-url="actions/approve_teacher.php?id=<?php echo $t['id']; ?>"
                                        data-title="Approve Teacher?" data-text="Approve this teacher application?" data-icon="question" data-confirm="Yes, Approve">
                                    <i class="fa fa-check"></i> Approve
                                </button>
                                <button class="tp-btn tp-btn-reject btn-confirm"
                                        data-url="actions/reject_teacher.php?id=<?php echo $t['id']; ?>"
                                        data-title="Reject Teacher?" data-text="Reject this teacher application?" data-icon="warning" data-confirm="Yes, Reject">
                                    <i class="fa fa-times"></i> Reject
                                </button>
                                <button class="tp-btn tp-btn-delete btn-confirm"
                                        data-url="actions/delete_teacher.php?id=<?php echo $t['id']; ?>"
                                        data-title="Move to Trash?" data-text="Move this teacher to deleted records?" data-icon="warning" data-confirm="Yes, Delete">
                                    <i class="fa fa-trash"></i> Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
    endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
endif; ?>
</div>

<?php include 'includes/teacher_page_scripts.php'; ?>
<?php require_once '../includes/footer.php'; ?>

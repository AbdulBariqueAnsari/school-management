<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
$stmt->execute([$id]);
$teacher = $stmt->fetch();

if (!$teacher) {
    die("Teacher not found.");
}

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="fa fa-user-tie text-primary me-2"></i> Teacher Profile</h2>
        <div class="d-flex gap-2">
            <a href="edit_teacher.php?id=<?php echo $teacher['id']; ?>" class="btn btn-warning shadow-sm"><i class="fa fa-edit me-1"></i> Edit Profile</a>
            <a href="actions/export_teacher.php?id=<?php echo $teacher['id']; ?>" class="btn btn-info text-white shadow-sm" target="_blank"><i class="fa fa-file-pdf me-1"></i> Export PDF</a>
            <a href="teachers.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-1"></i> Back to List</a>
        </div>
    </div>

    <div class="row">
        <!-- Sidebar Info -->
        <div class="col-lg-3">
            <div class="card shadow-sm border-0 mb-4 overflow-hidden" style="border-radius: 15px;">
                <div class="bg-primary py-5 text-center position-relative">
                    <img src="../uploads/profile/<?php echo $teacher['photo'] ?: 'default-teacher.png'; ?>" class="rounded-circle border border-4 border-white shadow-lg" width="140" height="140" style="object-fit:cover; background: #fff;" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($teacher['full_name']); ?>&background=random';">
                </div>
                <div class="card-body text-center pt-5 mt-2">
                    <h4 class="fw-bold mb-1 text-dark"><?php echo htmlspecialchars($teacher['full_name']); ?></h4>
                    <p class="text-primary fw-bold mb-3"><?php echo htmlspecialchars($teacher['teacher_id']); ?></p>
                    
                    <!-- Assignment Highlights -->
                    <div class="mb-4">
                        <?php if ($teacher['role'] === 'class_teacher'): ?>
                            <div class="d-inline-block px-3 py-2 bg-success bg-opacity-10 border border-success border-opacity-25 rounded-pill mb-2">
                                <span class="text-success fw-bold small"><i class="fa fa-chalkboard-teacher me-1"></i> Class Teacher: <?php echo htmlspecialchars($teacher['class_teacher_of']); ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <div class="d-inline-block px-3 py-2 bg-primary bg-opacity-10 border border-primary border-opacity-25 rounded-pill">
                            <span class="text-primary fw-bold small"><i class="fa fa-book me-1"></i> Subject: <?php echo htmlspecialchars($teacher['assigned_subject']); ?></span>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2 mb-4">
                        <span class="badge <?php echo ($teacher['status'] == 'Approved') ? 'bg-success' : (($teacher['status'] == 'Rejected') ? 'bg-danger' : 'bg-warning text-dark'); ?> py-2">
                            <i class="fa <?php echo ($teacher['status'] == 'Approved') ? 'fa-check-circle' : (($teacher['status'] == 'Rejected') ? 'fa-times-circle' : 'fa-clock'); ?> me-1"></i>
                            <?php echo htmlspecialchars($teacher['status'] ?? 'Pending'); ?>
                        </span>
                        <span class="badge bg-light text-dark border py-2">
                            <i class="fa fa-briefcase me-1 text-primary"></i> 
                            <?php echo htmlspecialchars($teacher['designation']); ?>
                        </span>
                    </div>
                    
                    <div class="text-start border-top pt-3">
                        <div class="mb-3">
                            <label class="text-muted small fw-bold text-uppercase d-block mb-1">Email Address</label>
                            <span class="fw-bold small text-break"><i class="fa fa-envelope text-primary me-2"></i><?php echo htmlspecialchars($teacher['email']); ?></span>
                        </div>
                        <div class="mb-3">
                            <label class="text-muted small fw-bold text-uppercase d-block mb-1">Username</label>
                            <span class="fw-bold"><i class="fa fa-user-tag text-primary me-2"></i><?php echo htmlspecialchars($teacher['username'] ?: 'N/A'); ?></span>
                        </div>
                        <div class="mb-2">
                            <label class="text-muted small fw-bold text-uppercase d-block mb-1">Mobile Number</label>
                            <span class="fw-bold"><i class="fa fa-phone text-primary me-2"></i><?php echo htmlspecialchars($teacher['phone']); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions Card -->
            <div class="card shadow-sm border-0" style="border-radius: 12px;">
                <div class="card-body p-3">
                    <h6 class="fw-bold border-bottom pb-2 mb-3">Quick Actions</h6>
                    <div class="d-grid gap-2">
                        <a href="edit_teacher.php?id=<?php echo $teacher['id']; ?>" class="btn btn-sm btn-outline-warning text-dark"><i class="fa fa-edit me-2"></i>Edit Profile</a>
                        <a href="actions/export_teacher.php?id=<?php echo $teacher['id']; ?>" class="btn btn-sm btn-outline-info text-dark" target="_blank"><i class="fa fa-file-pdf me-2"></i>Export PDF</a>
                        <button class="btn btn-sm btn-outline-danger" onclick="if(confirm('Are you sure?')) alert('Feature locked by admin panel settings.');"><i class="fa fa-archive me-2"></i>Archive Teacher</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Details -->
        <div class="col-lg-9">
            <!-- Navigation Tabs -->
            <ul class="nav nav-pills mb-4 bg-white p-2 rounded shadow-sm border" id="teacherTab" role="tablist" style="border-radius: 12px;">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active fw-bold px-4" id="personal-tab" data-bs-toggle="pill" data-bs-target="#personal" type="button" role="tab"><i class="fa fa-user me-2"></i>Personal Details</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold px-4" id="professional-tab" data-bs-toggle="pill" data-bs-target="#professional" type="button" role="tab"><i class="fa fa-briefcase me-2"></i>Professional Background</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold px-4" id="assignment-tab" data-bs-toggle="pill" data-bs-target="#assignment" type="button" role="tab"><i class="fa fa-book me-2"></i>Assignment</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold px-4 text-dark" id="account-tab" data-bs-toggle="pill" data-bs-target="#account" type="button" role="tab"><i class="fa fa-key me-2"></i>Account & Credentials</button>
                </li>
            </ul>

            <div class="tab-content" id="teacherTabContent">
                <!-- Tab 1: Personal Details -->
                <div class="tab-pane fade show active" id="personal" role="tabpanel">
                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom-0">
                            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-id-card text-primary me-2"></i> Basic Information</h5>
                        </div>
                        <div class="card-body p-4 pt-0">
                            <div class="row g-4">
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Gender</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['gender'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Date of Birth</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['dob'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Calculated Age</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['age'] ?: 'N/A'); ?> Years</p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Blood Group</label>
                                    <p class="mb-0 fw-bold text-danger"><?php echo htmlspecialchars($teacher['blood_group'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Aadhaar Number</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['aadhaar'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-6 border-end">
                                            <label class="text-muted small text-uppercase fw-bold">Present Address</label>
                                            <p class="mb-0 fw-bold"><?php echo nl2br(htmlspecialchars($teacher['present_address'] ?: 'N/A')); ?></p>
                                        </div>
                                        <div class="col-md-6 ps-md-4">
                                            <label class="text-muted small text-uppercase fw-bold">Permanent Address</label>
                                            <p class="mb-0 fw-bold"><?php echo nl2br(htmlspecialchars($teacher['permanent_address'] ?: 'N/A')); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 2: Professional Details -->
                <div class="tab-pane fade" id="professional" role="tabpanel">
                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom-0">
                            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-graduation-cap text-warning me-2"></i> Professional Background</h5>
                        </div>
                        <div class="card-body p-4 pt-0">
                            <div class="row g-4">
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Qualification</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['qualification']); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Specialization</label>
                                    <p class="mb-0 fw-bold text-primary"><?php echo htmlspecialchars($teacher['specialization']); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Total Experience</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['experience_years']); ?> Years</p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Previous School</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['previous_school'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Year of Joining</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['year_of_joining']); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Employment Type</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['employment_type']); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 3: Assignment -->
                <div class="tab-pane fade" id="assignment" role="tabpanel">
                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom-0">
                            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-chalkboard-teacher text-info me-2"></i> Current Assignments</h5>
                        </div>
                        <div class="card-body p-4 pt-0">
                            <div class="row g-4">
                                <div class="col-md-6 border-bottom pb-3">
                                    <label class="text-muted small text-uppercase fw-bold">Assigned Subject</label>
                                    <p class="mb-0"><span class="badge bg-soft-info text-info fs-6 px-3"><?php echo htmlspecialchars($teacher['assigned_subject']); ?></span></p>
                                </div>
                                <div class="col-md-6 border-bottom pb-3">
                                    <label class="text-muted small text-uppercase fw-bold">Assigned Class (Teaching)</label>
                                    <p class="mb-0"><span class="badge bg-soft-primary text-primary fs-6 px-3"><?php echo htmlspecialchars($teacher['assigned_class']); ?></span></p>
                                </div>
                                <div class="col-md-6 border-bottom pb-3">
                                    <label class="text-muted small text-uppercase fw-bold">Primary Role</label>
                                    <p class="mb-0 fw-bold text-dark text-capitalize"><?php echo str_replace('_', ' ', htmlspecialchars($teacher['role'])); ?></p>
                                </div>
                                <?php if ($teacher['role'] === 'class_teacher'): ?>
                                <div class="col-md-6 border-bottom pb-3">
                                    <label class="text-muted small text-uppercase fw-bold">Class Teacher Of</label>
                                    <p class="mb-0 fw-bold text-success fs-5"><?php echo htmlspecialchars($teacher['class_teacher_of']); ?></p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 4: Account & Credentials -->
                <div class="tab-pane fade" id="account" role="tabpanel">
                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom-0">
                            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-shield-halved text-danger me-2"></i> Account Access Details</h5>
                        </div>
                        <div class="card-body p-4 pt-0">
                            <div class="alert alert-info border-0 shadow-sm mb-4" style="border-radius: 10px;">
                                <i class="fa fa-info-circle me-2"></i> These credentials allow the teacher to access their individual portal.
                            </div>
                            <div class="row g-4">
                                <div class="col-md-6 border-end">
                                    <div class="p-3 bg-light rounded shadow-sm h-100">
                                        <label class="text-muted small text-uppercase fw-bold d-block mb-2">Teacher Login ID</label>
                                        <h4 class="fw-bold text-primary mb-0"><?php echo htmlspecialchars($teacher['username'] ?: 'N/A'); ?></h4>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="p-3 bg-light rounded shadow-sm h-100">
                                        <label class="text-muted small text-uppercase fw-bold d-block mb-2">Registered Email</label>
                                        <h5 class="fw-bold text-dark mb-0"><?php echo htmlspecialchars($teacher['email']); ?></h5>
                                    </div>
                                </div>
                                <div class="col-md-12 mt-4 text-center">
                                    <p class="text-muted small mb-3">To reset the password, use the "Edit Profile" button.</p>
                                    <a href="edit_teacher.php?id=<?php echo $teacher['id']; ?>" class="btn btn-sm btn-warning fw-bold px-4 rounded-pill">
                                        <i class="fa fa-key me-1"></i> Manage Password
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .bg-soft-info { background-color: rgba(13, 202, 240, 0.1); }
    .bg-soft-primary { background-color: rgba(13, 110, 253, 0.1); }
    .nav-pills .nav-link { color: #64748b; border: 1px solid transparent; transition: all 0.3s ease; }
    .nav-pills .nav-link:hover { background: #f8fafc; color: #1e293b; }
    .nav-pills .nav-link.active { background: #0d6efd !important; color: #fff !important; box-shadow: 0 4px 12px rgba(13, 110, 253, 0.25); }
    .fw-600 { font-weight: 600; }
</style>

<?php require_once '../includes/footer.php'; ?>

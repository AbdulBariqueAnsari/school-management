<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

if (!isset($_GET['class']) || empty($_GET['class'])) {
    $_SESSION['error'] = "Invalid class selected.";
    redirect('class_teachers.php');
}

$class_name = $_GET['class'];

// Fakes - If actual data tables don't exist yet, we'll gracefully show empty or basic info
$total_students = 0;
$total_subjects = 0;
$attendance_rate = 'N/A';

// Fetch Class Teacher if Assigned
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE role='class_teacher' AND FIND_IN_SET(?, class_teacher_of) AND status='Approved' LIMIT 1");
$stmt->execute([$class_name]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch students for this class (Assuming 'students' table exists with 'class_applied' or similar)
try {
    // Modify based on actual students table structure - using standard assumptions
    $stmt_students = $pdo->prepare("SELECT * FROM students WHERE class_applied = ? AND status='Approved'");
    $stmt_students->execute([$class_name]);
    $students = $stmt_students->fetchAll(PDO::FETCH_ASSOC);
    $total_students = count($students);
}
catch (Exception $e) {
    $students = [];
}

require_once '../includes/header.php';
?>

<style>
/* Modern ERP UI Upgrades */
.glass-card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 16px;
    border: 1px solid rgba(255,255,255,0.2);
    box-shadow: 0 8px 30px rgba(0,0,0,0.12);
}

.widget-animate {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    animation: slideUp 0.5s ease-out forwards;
    opacity: 0;
}

@keyframes slideUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

.widget-animate:hover {
    transform: translateY(-5px) scale(1.03);
}

.neumorphic-btn {
    background: #f0f0f0;
    border-radius: 10px;
    box-shadow: 6px 6px 12px #cfcfcf, -6px -6px 12px #ffffff;
    border: none;
    color: #333;
    font-weight: 600;
    padding: 10px 20px;
    transition: all 0.2s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
}

.neumorphic-btn:hover {
    box-shadow: inset 6px 6px 12px #cfcfcf, inset -6px -6px 12px #ffffff;
    color: #000;
}

/* Gradient Header */
.class-header-gradient {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 16px;
    color: white;
}

/* Custom Toggle Actions */
.student-actions {
    display: flex;
    transition: all 0.3s ease;
}
.student-row.active {
    background-color: rgba(13, 110, 253, 0.05);
}
.enrolled-students-section {
    display: none;
    transition: all 0.4s ease;
}

/* ERM Grid Dashboard Alignment */
.erp-card-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 24px;
}
@media (max-width: 1200px) { .erp-card-grid { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 992px)  { .erp-card-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 576px)  { .erp-card-grid { grid-template-columns: 1fr; } }

.erp-card-link { text-decoration: none; display: block; width: 100%; height: 100%; border: none; background: none; padding: 0; }
.erp-card-link:hover, .erp-card-link:focus, .erp-card-link:active { outline: none; text-decoration: none; }

.erp-card {
    background: rgba(255,255,255,0.13);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border: 1px solid rgba(255,255,255,0.22);
    border-radius: 20px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.13);
    padding: 28px 22px;
    text-align: center;
    position: relative;
    overflow: hidden;
    cursor: pointer;
    transition: transform 0.35s cubic-bezier(0.34,1.56,0.64,1),
                box-shadow 0.35s ease, background 0.25s ease;
    opacity: 0;
    transform: translateY(15px);
    height: 100%;
}
.erp-card.animated { opacity: 1; transform: translateY(0); }
.erp-card:hover {
    transform: translateY(-8px) scale(1.025);
    box-shadow: 0 20px 50px rgba(0,0,0,0.2);
    background: rgba(255,255,255,0.2);
    border-color: rgba(255,255,255,0.35);
}
.erp-card::before {
    content: ''; position: absolute; top: -40px; right: -40px;
    width: 110px; height: 110px; border-radius: 50%; opacity: 0.15;
    transition: opacity 0.3s;
}
.erp-card:hover::before { opacity: 0.25; }

/* Themes */
.erp-card--blue   { background: linear-gradient(135deg,rgba(13,110,253,0.18),rgba(255,255,255,0.08)); } .erp-card--blue::before   { background: #0d6efd; }
.erp-card--teal   { background: linear-gradient(135deg,rgba(20,184,166,0.18),rgba(255,255,255,0.08)); } .erp-card--teal::before   { background: #14b8a6; }
.erp-card--green  { background: linear-gradient(135deg,rgba(25,135,84,0.18),rgba(255,255,255,0.08)); } .erp-card--green::before  { background: #198754; }
.erp-card--yellow { background: linear-gradient(135deg,rgba(245,158,11,0.18),rgba(255,255,255,0.08));} .erp-card--yellow::before { background: #f59e0b; }
.erp-card--purple { background: linear-gradient(135deg,rgba(124,58,237,0.18),rgba(255,255,255,0.08));} .erp-card--purple::before { background: #7c3aed; }
.erp-card--red    { background: linear-gradient(135deg,rgba(220,53,69,0.18),rgba(255,255,255,0.08)); } .erp-card--red::before    { background: #dc3545; }
.erp-card--pink   { background: linear-gradient(135deg,rgba(236,72,153,0.18),rgba(255,255,255,0.08));} .erp-card--pink::before   { background: #ec4899; }
.erp-card--cyan   { background: linear-gradient(135deg,rgba(6,182,212,0.18),rgba(255,255,255,0.08)); } .erp-card--cyan::before   { background: #06b6d4; }
.erp-card--orange { background: linear-gradient(135deg,rgba(234,88,12,0.18),rgba(255,255,255,0.08)); } .erp-card--orange::before { background: #ea580c; }
.erp-card--indigo { background: linear-gradient(135deg,rgba(99,102,241,0.18),rgba(255,255,255,0.08));} .erp-card--indigo::before { background: #6366f1; }
.erp-card--grey   { background: linear-gradient(135deg,rgba(100,116,139,0.18),rgba(255,255,255,0.08));} .erp-card--grey::before  { background: #64748b; }
.erp-card--lime   { background: linear-gradient(135deg,rgba(101,163,13,0.18),rgba(255,255,255,0.08));} .erp-card--lime::before   { background: #65a30d; }

/* Icon */
.erp-card-icon {
    width: 68px; height: 68px; border-radius: 16px;
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 16px; font-size: 1.7rem;
    position: relative; z-index: 1;
    transition: transform 0.3s ease;
}
.erp-card:hover .erp-card-icon { transform: scale(1.1) rotate(-3deg); }

.i--blue   { background: linear-gradient(135deg,#0d6efd,#6610f2); color: #fff; }
.i--teal   { background: linear-gradient(135deg,#0d9488,#14b8a6); color: #fff; }
.i--green  { background: linear-gradient(135deg,#198754,#20c997); color: #fff; }
.i--yellow { background: linear-gradient(135deg,#f59e0b,#fcd34d); color: #fff; }
.i--purple { background: linear-gradient(135deg,#7c3aed,#a855f7); color: #fff; }
.i--red    { background: linear-gradient(135deg,#dc3545,#f43f5e); color: #fff; }
.i--pink   { background: linear-gradient(135deg,#db2777,#ec4899); color: #fff; }
.i--cyan   { background: linear-gradient(135deg,#0891b2,#06b6d4); color: #fff; }
.i--orange { background: linear-gradient(135deg,#ea580c,#f97316); color: #fff; }
.i--indigo { background: linear-gradient(135deg,#4f46e5,#6366f1); color: #fff; }
.i--grey   { background: linear-gradient(135deg,#475569,#64748b); color: #fff; }
.i--lime   { background: linear-gradient(135deg,#4d7c0f,#65a30d); color: #fff; }

.erp-card-title { font-size: 1rem; font-weight: 700; color: #1a1a2e; margin-bottom: 4px; position: relative; z-index: 1; }
.erp-card-sub   { font-size: 0.8rem; color: #666; margin-bottom: 14px; position: relative; z-index: 1; line-height: 1.4; text-decoration: none; }
.erp-card-arrow {
    position: absolute; bottom: 16px; right: 18px; font-size: 0.88rem;
    color: rgba(0,0,0,0.22); transition: transform 0.25s ease, color 0.25s ease; z-index: 1;
}
.erp-card:hover .erp-card-arrow { transform: translateX(4px); color: rgba(0,0,0,0.5); }
</style>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="fa fa-users-rectangle text-primary me-2"></i> Class Overview</h2>
        <a href="class_teachers.php" class="neumorphic-btn"><i class="fa fa-arrow-left text-secondary"></i> Back</a>
    </div>

    <!-- Header Banner -->
    <div class="class-header-gradient p-4 p-md-5 mb-4 shadow-sm widget-animate" style="animation-delay: 0s;">
        <div class="row align-items-center">
            <div class="col-md-7 border-end border-white-50">
                <div class="d-flex justify-content-between align-items-center pe-md-4 flex-wrap">
                    <div class="mb-3 mb-md-0">
                        <h1 class="display-5 fw-bold mb-2"><?php echo htmlspecialchars($class_name); ?></h1>
                        <p class="fs-5 mb-0 text-white-50">Academic Dashboard</p>
                    </div>
                    <div class="text-center bg-white bg-opacity-10 rounded-4 p-3 border border-white border-opacity-25 shadow-sm me-md-4 widget-animate" style="backdrop-filter: blur(10px); animation-delay: 0.2s;">
                        <div class="d-flex align-items-center justify-content-center mb-1">
                            <i class="fa fa-user-graduate fs-5 text-white-50 me-2"></i>
                            <h3 class="display-6 fw-bold mb-0 text-white"><?php echo $total_students; ?></h3>
                        </div>
                        <p class="small text-white-50 text-uppercase mb-3 text-nowrap fw-semibold tracking-wide">Total Students</p>
                        <button class="btn btn-sm btn-light rounded-pill px-4 py-2 shadow border-0 text-primary w-100 hover-shadow widget-animate" onclick="toggleStudentList()" style="font-size: 0.85rem; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); animation-delay: 0.3s;">
                            <i class="fa fa-users me-2"></i> View List
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-md-5 ps-md-5 mt-4 mt-md-0">
                <div class="d-flex align-items-center">
                    <?php if ($teacher): ?>
                        <img src="../uploads/profile/<?php echo htmlspecialchars($teacher['photo']); ?>" alt="Class Teacher" class="rounded-circle border border-3 border-white shadow mr-3" style="width: 80px; height: 80px; object-fit: cover;">
                        <div class="ms-3">
                            <h4 class="mb-0 fw-bold"><?php echo htmlspecialchars($teacher['full_name']); ?></h4>
                            <span class="badge bg-light text-dark shadow-sm">Class Teacher</span>
                        </div>
                    <?php
else: ?>
                        <div class="rounded-circle bg-white text-muted d-flex align-items-center justify-content-center border border-3 border-white shadow mr-3" style="width: 80px; height: 80px;">
                            <i class="fa fa-user-slash fa-2x"></i>
                        </div>
                        <div class="ms-3">
                            <h4 class="mb-0 fw-bold text-white-50">Not Assigned</h4>
                            <a href="teachers.php" class="btn btn-sm btn-light mt-2 rounded-pill">Assign Now</a>
                        </div>
                    <?php
endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Enrolled Students List (Hidden by default) -->
    <div class="row g-4 mb-5 enrolled-students-section" id="enrolledStudentsSection">
        <div class="col-12">
            <div class="glass-card p-0 overflow-hidden" style="cursor: default; transform: none; box-shadow: 0 8px 30px rgba(0,0,0,0.12);">
                <div class="bg-white p-3 border-bottom d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                    <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-users me-2 text-primary"></i> Enrolled Students List</h5>
                    
                    <div class="d-flex flex-column flex-sm-row gap-2 align-items-sm-center">
                        <!-- Search Box -->
                        <div class="input-group input-group-sm rounded-pill overflow-hidden shadow-sm" style="border: 1px solid #dee2e6; max-width: 250px;">
                            <span class="input-group-text bg-white border-0 text-muted ps-3"><i class="fa fa-search"></i></span>
                            <input type="text" id="studentSearchInput" class="form-control border-0 shadow-none px-2" placeholder="Search name or ADM..." onkeyup="filterStudents()" aria-label="Search">
                        </div>
                        
                        <!-- Section Dropdown -->
                        <select id="sectionFilter" class="form-select form-select-sm rounded-pill shadow-sm" style="border: 1px solid #dee2e6; max-width: 140px; cursor: pointer;" onchange="filterStudents()">
                            <option value="">All Sections</option>
                            <option value="A">Section A</option>
                            <option value="B">Section B</option>
                            <option value="C">Section C</option>
                            <option value="D">Section D</option>
                        </select>

                        <a href="class_students.php?class=<?php echo urlencode($class_name); ?>" class="btn btn-sm btn-primary rounded-pill px-3 shadow-sm text-nowrap mt-2 mt-sm-0">
                            View All <i class="fa fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
                <div class="table-responsive p-0 bg-white">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Photo</th>
                                <th>Student Name</th>
                                <th>Admission No.</th>
                                <th>Father Name</th>
                                <th>Phone</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($students)): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">No approved students found in this class yet.</td>
                                </tr>
                            <?php
else: ?>
                                <?php foreach ($students as $student): 
                                        $sec = (isset($student['section']) && !empty($student['section'])) ? htmlspecialchars($student['section']) : 'A';
                                ?>
                                    <tr class="student-row" onclick="toggleRowActions(this)" style="cursor: pointer;" data-section="<?php echo $sec; ?>">
                                        <td>
                                            <img src="../uploads/students/<?php echo htmlspecialchars($student['photo'] ?? 'default.png'); ?>" 
                                                 class="rounded-circle shadow-sm" width="40" height="40" style="object-fit:cover;" 
                                                 onerror="this.src='../assets/images/default-avatar.png'">
                                        </td>
                                        <td class="fw-bold text-dark"><?php echo htmlspecialchars($student['student_name'] ?? 'N/A'); ?></td>
                                        <td><span class="badge bg-light text-dark shadow-sm"><?php echo htmlspecialchars($student['application_number'] ?? 'N/A'); ?></span></td>
                                        <td><?php echo htmlspecialchars($student['father_name'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($student['phone'] ?? 'N/A'); ?></td>
                                        <td><span class="badge bg-success">Approved</span></td>
                                    </tr>
                                    <!-- Hidden actions row -->
                                    <tr class="bg-light p-0 border-0" style="display: none;">
                                        <td colspan="6" class="p-0 border-0">
                                            <div class="student-actions gap-2 p-2 justify-content-center border-bottom border-top" style="background: #f8f9fa;">
                                                <a href="student_profile.php?id=<?php echo $student['id']; ?>&type=stu" class="btn btn-sm btn-primary shadow-sm"><i class="fa fa-eye"></i> View</a>
                                                <a href="edit_student.php?id=<?php echo $student['id']; ?>&type=stu" class="btn btn-sm btn-warning shadow-sm"><i class="fa fa-edit"></i> Edit</a>
                                                <a href="actions/export_student.php?id=<?php echo $student['id']; ?>&type=student" class="btn btn-sm btn-info text-white shadow-sm" target="_blank"><i class="fa fa-file-pdf"></i> Export PDF</a>
                                                <a href="actions/reject_student.php?id=<?php echo $student['id']; ?>&type=stu" class="btn btn-sm btn-dark shadow-sm" onclick="return confirm('Are you sure you want to reject this approved student?');"><i class="fa fa-times"></i> Reject</a>
                                                <a href="actions/delete_student.php?id=<?php echo $student['id']; ?>&type=stu" class="btn btn-sm btn-danger shadow-sm" onclick="return confirm('Are you sure you want to delete this student?');"><i class="fa fa-trash"></i> Delete</a>
                                                <a href="student_dashboard.php?id=<?php echo $student['id']; ?>" class="btn btn-sm btn-secondary shadow-sm"><i class="fa fa-gauge"></i> Dashboard</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php
    endforeach; ?>
                            <?php
endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- ===== CLASS DASHBOARD CARDS ===== -->
    <h4 class="fw-bold mb-4 mt-5"><i class="fa fa-layer-group text-primary me-2"></i> Class Utilities</h4>
    <div class="erp-card-grid mb-5">
        
        <a href="class_students.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--blue animated" data-delay="0">
                <div class="erp-card-icon i--blue"><i class="fa fa-users"></i></div>
                <div class="erp-card-title">View Dashboard</div>
                <div class="erp-card-sub">Student Management</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_attendance.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--green animated" data-delay="100">
                <div class="erp-card-icon i--green"><i class="fa fa-calendar-check"></i></div>
                <div class="erp-card-title">Attendance</div>
                <div class="erp-card-sub">Daily records</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_notice.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--yellow animated" data-delay="200">
                <div class="erp-card-icon i--yellow"><i class="fa fa-bullhorn"></i></div>
                <div class="erp-card-title">Notice</div>
                <div class="erp-card-sub">Class announcements</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_messages.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--info animated" data-delay="300" style="background:linear-gradient(135deg,rgba(13,110,253,0.18),rgba(255,255,255,0.08));">
                <div class="erp-card-icon i--cyan"><i class="fa fa-envelope"></i></div>
                <div class="erp-card-title">Messages</div>
                <div class="erp-card-sub">Communication</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_materials.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--purple animated" data-delay="400">
                <div class="erp-card-icon i--purple"><i class="fa fa-file-pdf"></i></div>
                <div class="erp-card-title">Study Materials</div>
                <div class="erp-card-sub">Shared resources</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_tests.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--red animated" data-delay="500">
                <div class="erp-card-icon i--red"><i class="fa fa-pen-to-square"></i></div>
                <div class="erp-card-title">Class Test</div>
                <div class="erp-card-sub">Weekly assessments</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_routine.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--cyan animated" data-delay="600">
                <div class="erp-card-icon i--cyan"><i class="fa fa-clock"></i></div>
                <div class="erp-card-title">Routine</div>
                <div class="erp-card-sub">Class timetable</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_syllabus.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--teal animated" data-delay="700">
                <div class="erp-card-icon i--teal"><i class="fa fa-book-open"></i></div>
                <div class="erp-card-title">Syllabus</div>
                <div class="erp-card-sub">Curriculum tracker</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_books.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--lime animated" data-delay="800">
                <div class="erp-card-icon i--lime"><i class="fa fa-book"></i></div>
                <div class="erp-card-title">Book List</div>
                <div class="erp-card-sub">Required reading</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_marks.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--indigo animated" data-delay="900">
                <div class="erp-card-icon i--indigo"><i class="fa fa-star"></i></div>
                <div class="erp-card-title">Marks Record</div>
                <div class="erp-card-sub">Exam results</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_assignments.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--pink animated" data-delay="1000">
                <div class="erp-card-icon i--pink"><i class="fa fa-tasks"></i></div>
                <div class="erp-card-title">Assignments</div>
                <div class="erp-card-sub">Project tracking</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_homework.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--orange animated" data-delay="1100">
                <div class="erp-card-icon i--orange"><i class="fa fa-home"></i></div>
                <div class="erp-card-title">Homework</div>
                <div class="erp-card-sub">Daily tasks</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_events.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--red animated" data-delay="1200">
                <div class="erp-card-icon i--red"><i class="fa fa-calendar-star"></i></div>
                <div class="erp-card-title">Events</div>
                <div class="erp-card-sub">Class activities</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <a href="class_reports.php?class=<?php echo urlencode($class_name); ?>" class="erp-card-link">
            <div class="erp-card erp-card--grey animated" data-delay="1300">
                <div class="erp-card-icon i--grey"><i class="fa fa-chart-line"></i></div>
                <div class="erp-card-title">Reports</div>
                <div class="erp-card-sub">Analytics &amp; insights</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

    </div>

</div>

<script>
function toggleStudentList() {
    const section = document.getElementById('enrolledStudentsSection');
    const isHidden = window.getComputedStyle(section).display === 'none';

    if (isHidden) {
        section.style.display = 'block';
        section.style.opacity = '0';
        section.style.transform = 'translateY(-20px)';
        
        // Trigger a reflow
        void section.offsetWidth;
        
        section.style.transition = 'opacity 0.5s ease-out, transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)';
        section.style.opacity = '1';
        section.style.transform = 'translateY(0)';
    } else {
        section.style.transition = 'opacity 0.3s ease-in, transform 0.3s ease-in';
        section.style.opacity = '0';
        section.style.transform = 'translateY(-15px)';
        
        setTimeout(() => {
            section.style.display = 'none';
        }, 300);
    }
}

function toggleRowActions(rowElement) {
    // Remove active class and hide action row from all other rows
    const allRows = document.querySelectorAll('.student-row');
    allRows.forEach(row => {
        if (row !== rowElement) {
            row.classList.remove('active');
            if (row.nextElementSibling) {
                row.nextElementSibling.style.display = 'none';
            }
        }
    });
    
    // Toggle active class on clicked row
    rowElement.classList.toggle('active');
    
    // Toggle display of its sibling action row
    const actionRow = rowElement.nextElementSibling;
    if (rowElement.classList.contains('active')) {
        actionRow.style.display = 'table-row';
    } else {
        actionRow.style.display = 'none';
    }
}

function filterStudents() {
    const searchInput = document.getElementById('studentSearchInput').value.toLowerCase();
    const sectionVal = document.getElementById('sectionFilter').value;
    const rows = document.querySelectorAll('#enrolledStudentsSection .table tbody tr.student-row');

    rows.forEach(row => {
        // Find the action row right after this one
        const actionRow = row.nextElementSibling;
        
        // Extract data for filtering
        const studentName = row.cells[1].textContent.toLowerCase();
        const admissionNo = row.cells[2].textContent.toLowerCase();
        const rowSection = row.getAttribute('data-section') || '';

        // Match Logic
        const matchesSearch = studentName.includes(searchInput) || admissionNo.includes(searchInput);
        const matchesSection = (sectionVal === '' || rowSection === sectionVal);

        if (matchesSearch && matchesSection) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
            // Also hide the action row and remove active class if we hide it
            row.classList.remove('active');
            if (actionRow && actionRow.classList.contains('bg-light')) {
                actionRow.style.display = 'none';
            }
        }
    });
}

// Add staggered animation delay to cards dynamically
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.erp-card');
    cards.forEach(card => {
        const delay = parseInt(card.getAttribute('data-delay'));
        if(!isNaN(delay)) {
            setTimeout(() => {
                card.style.transition = 'opacity 0.45s ease, transform 0.45s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.35s ease, background 0.25s ease';
                card.classList.add('animated');
            }, delay);
        }
    });
});
</script>

</div>

<?php require_once '../includes/footer.php'; ?>

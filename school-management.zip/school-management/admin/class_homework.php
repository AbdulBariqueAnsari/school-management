<?php
$module_key = 'homework';
$module_title = 'Class Homework';
$module_icon = 'fa-clipboard-list';
require_once __DIR__ . '/includes/class_module.php';
?>

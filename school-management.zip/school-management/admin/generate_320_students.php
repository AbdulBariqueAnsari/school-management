<?php
/**
 * admin/generate_320_students.php
 * Generates 320 students across 16 classes (20 students per class: 10 Male, 10 Female).
 * Fills all fields and assigns real photos from the server.
 */

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/database_init.php';

// Check if script has already run (more than 10 students generated)
$existing = $pdo->query("SELECT COUNT(*) FROM students WHERE username LIKE 'student_0%' OR username LIKE 'student_1%' OR username LIKE 'student_2%'")->fetchColumn();
if ($existing >= 300) {
    die("Data already generated. Existing generated student counts look high: $existing. Delete them first if you want to rerun.");
}

// Ensure columns exist (same as insert_test_students.php)
$required_cols = [
    "admission_no VARCHAR(50)", "student_name VARCHAR(150)", "gender VARCHAR(10)", "dob DATE", "age INT",
    "blood_group VARCHAR(10)", "aadhaar_number VARCHAR(20)", "student_photo VARCHAR(255)", "present_address TEXT",
    "student_mobile VARCHAR(20)", "father_name VARCHAR(150)", "father_mobile VARCHAR(20)", "mother_name VARCHAR(150)",
    "mother_mobile VARCHAR(20)", "parent_name VARCHAR(150)", "parent_email VARCHAR(150)", "parent_phone VARCHAR(20)",
    "parents_address TEXT", "guardian_name VARCHAR(150)", "relation VARCHAR(100)", "guardian_mobile VARCHAR(20)",
    "guardian_address TEXT", "guardian_details TEXT", "has_medical_condition TINYINT(1) DEFAULT 0",
    "medical_condition_desc TEXT", "has_disability TINYINT(1) DEFAULT 0", "disability_desc TEXT",
    "has_allergies TINYINT(1) DEFAULT 0", "allergies_desc TEXT", "religion VARCHAR(50)", "caste_category VARCHAR(50)",
    "mother_tongue VARCHAR(100)", "previous_schooling_status VARCHAR(100)", "class_applied VARCHAR(50)",
    "previous_class VARCHAR(50)", "previous_school_name VARCHAR(150)", "previous_school VARCHAR(150)",
    "previous_board VARCHAR(100)", "year_of_passing INT", "username VARCHAR(100)", "email VARCHAR(150)",
    "password VARCHAR(255)", "status VARCHAR(20) DEFAULT 'Pending'", "address TEXT", "mobile_number VARCHAR(20)",
    "admission_date DATE"
];

foreach ($required_cols as $col_def) {
    $col_name = explode(' ', $col_def)[0];
    try {
        $pdo->exec("ALTER TABLE students ADD COLUMN $col_def");
    } catch (Exception $e) { }
}

$classes = [
    'Play Nursery', 'Nursery', 'LKG', 'UKG',
    'Class 1', 'Class 2', 'Class 3', 'Class 4',
    'Class 5', 'Class 6', 'Class 7', 'Class 8',
    'Class 9', 'Class 10', 'Class 11', 'Class 12'
];

$male_first_names = ['Aarav', 'Vivaan', 'Aditya', 'Krishna', 'Arjun', 'Rohan', 'Rahul', 'Amit', 'Vikrant', 'Manish', 'Suresh', 'Ramesh', 'Sumit', 'Abhishek', 'Akash', 'Vishal', 'Vikas', 'Karan', 'Kunal', 'Neeraj', 'Nitin', 'Rajesh', 'Sanjay', 'Sunil', 'Vijay', 'Vikram', 'Ravi', 'Anil', 'Deepak', 'Manoj'];
$female_first_names = ['Ananya', 'Diya', 'Kavya', 'Ishita', 'Priya', 'Sneha', 'Neha', 'Pooja', 'Riya', 'Shruti', 'Swati', 'Shweta', 'Nisha', 'Nidhi', 'Divya', 'Aakanksha', 'Rekha', 'Sunita', 'Kavita', 'Meena', 'Geeta', 'Sita', 'Anita', 'Ayesha', 'Fatima', 'Zainab', 'Kiran', 'Simran', 'Preeti', 'Sonia'];
$surnames = ['Sharma', 'Singh', 'Verma', 'Kumar', 'Gupta', 'Patel', 'Reddy', 'Joshi', 'Mistry', 'Nair', 'Menon', 'Pillai', 'Iyer', 'Deshmukh', 'Kulkarni', 'Patil', 'Bhat', 'Das', 'Sen', 'Bose', 'Chatterjee', 'Banerjee', 'Mukherjee', 'Chowdhury', 'Dubey', 'Tiwari', 'Mishra', 'Pandey', 'Yadav', 'Chauhan'];

$religions = ['Hindu', 'Islam', 'Christian', 'Buddhist'];
$categories = ['General', 'OBC-A', 'OBC-B', 'ST', 'SC'];
$mother_tongues = ['Hindi', 'English', 'Bengali', 'Telugu', 'Marathi', 'Tamil', 'Urdu', 'Gujarati', 'Kannada', 'Odia'];

$photo_dir = __DIR__ . '/../uploads/students/';
$photo_files = [];
if (is_dir($photo_dir)) {
    $files = scandir($photo_dir);
    foreach ($files as $f) {
        if ($f != '.' && $f != '..' && is_file($photo_dir . $f)) {
            $photo_files[] = 'uploads/students/' . $f;
        }
    }
}
// Default if no photos found
if (empty($photo_files)) {
    $photo_files = ['uploads/students/default.png'];
}

$sql = "INSERT INTO students 
    (admission_no, student_name, gender, dob, age, blood_group, aadhaar_number,
     student_photo, class_applied, present_address, mobile_number, father_name, father_mobile,
     mother_name, mother_mobile, parent_email, parents_address,
     guardian_name, relation, guardian_mobile, guardian_address,
     has_medical_condition, medical_condition_desc, has_disability, disability_desc,
     has_allergies, allergies_desc,
     religion, caste_category, mother_tongue, previous_schooling_status,
     previous_class, previous_school_name, previous_board, year_of_passing,
     username, email, password, status, admission_date)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

$stmt = $pdo->prepare($sql);
$student_count =  $pdo->query("SELECT MAX(CAST(SUBSTRING(admission_no, 10) AS UNSIGNED)) FROM students WHERE admission_no LIKE 'ADM-2026-%'")->fetchColumn();
$student_count = $student_count ? $student_count + 1 : 1;

$generated_names = [];
$account_index = 1;

$hash = password_hash('Student@123', PASSWORD_BCRYPT);
$log = [];
$success_count = 0;

$pdo->beginTransaction();

try {
    foreach ($classes as $class_name) {
        for ($i = 0; $i < 20; $i++) {
            $gender = ($i < 10) ? 'Male' : 'Female';
            
            // Unique Name Generation
            do {
                $first = ($gender === 'Male') ? $male_first_names[array_rand($male_first_names)] : $female_first_names[array_rand($female_first_names)];
                $last = $surnames[array_rand($surnames)];
                $full_name = "$first $last";
            } while (isset($generated_names[$full_name]));
            $generated_names[$full_name] = true;

            $admission_no = sprintf("ADM-2026-%04d", $student_count++);
            
            // Generate DOB based on class roughly (older for higher classes)
            $class_index = array_search($class_name, $classes);
            $base_age = 3 + $class_index; // Play Nursery starts at ~3
            $year_of_birth = date('Y') - $base_age;
            $month = str_pad(rand(1, 12), 2, '0', STR_PAD_LEFT);
            $day = str_pad(rand(1, 28), 2, '0', STR_PAD_LEFT);
            $dob = "$year_of_birth-$month-$day";
            
            $blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
            $blood_group = $blood_groups[array_rand($blood_groups)];
            
            $aadhaar = rand(1000, 9999) . rand(1000, 9999) . rand(1000, 9999);
            $photo = $photo_files[array_rand($photo_files)];
            
            $address = rand(1, 999) . " " . ['MG Road', 'Gandhi Nagar', 'Civil Lines', 'Shastri Nagar', 'Station Road'][array_rand(['MG Road', 'Gandhi Nagar', 'Civil Lines', 'Shastri Nagar', 'Station Road'])] . ", " . ['Delhi', 'Mumbai', 'Chennai', 'Kolkata', 'Bangalore', 'Hyderabad', 'Pune'][array_rand(['Delhi', 'Mumbai', 'Chennai', 'Kolkata', 'Bangalore', 'Hyderabad', 'Pune'])];
            
            $father = ($gender === 'Male' ? $male_first_names[array_rand($male_first_names)] : $male_first_names[array_rand($male_first_names)]) . " $last";
            $mother = $female_first_names[array_rand($female_first_names)] . " $last";
            
            $mobile = '9' . rand(100000000, 999999999);
            $f_mobile = '9' . rand(100000000, 999999999);
            $m_mobile = '9' . rand(100000000, 999999999);
            
            $email = "student" . $account_index . "@classschool.com";
            $parent_email = strtolower(str_replace(' ', '', $father)) . rand(10,99) . "@example.com";
            
            $username = "student_" . sprintf("%03d", $account_index);
            
            $has_medical = rand(0, 10) > 8 ? 1 : 0;
            $medical_desc = $has_medical ? "Asthma" : null;
            
            $has_disability = rand(0, 20) > 19 ? 1 : 0;
            $disability_desc = $has_disability ? "Mild hearing impairment" : null;
            
            $has_allergy = rand(0, 10) > 8 ? 1 : 0;
            $allergy_desc = $has_allergy ? "Peanut allergy" : null;
            
            $religion = $religions[array_rand($religions)];
            $caste = $categories[array_rand($categories)];
            $mother_tongue = $mother_tongues[array_rand($mother_tongues)];
            
            $prev_status = $class_index > 3 ? 'Passed from Previous School' : 'First Time Schooling';
            $prev_class = $class_index > 0 ? $classes[$class_index - 1] : null;
            $prev_school = $class_index > 3 ? "Previous Public School" : null;
            $prev_board = $class_index > 3 ? "CBSE" : null;
            $pass_year = $class_index > 3 ? date('Y') - 1 : null;
            
            $rand_status = rand(1, 100);
            if ($rand_status <= 48) $status = 'Approved';
            else if ($rand_status <= 96) $status = 'Pending';
            else if ($rand_status <= 98) $status = 'Rejected';
            else $status = 'Deleted';

            $admission_date = date('Y-m-d', strtotime('-' . rand(1, 30) . ' days'));
            
            $data = [
                $admission_no, $full_name, $gender, $dob, $base_age, $blood_group, $aadhaar,
                $photo, $class_name, $address, $mobile, $father, $f_mobile,
                $mother, $m_mobile, $parent_email, $address,
                $father, 'Father', $f_mobile, $address,
                $has_medical, $medical_desc, $has_disability, $disability_desc,
                $has_allergy, $allergy_desc,
                $religion, $caste, $mother_tongue, $prev_status,
                $prev_class, $prev_school, $prev_board, $pass_year,
                $username, $email, $hash, $status, $admission_date
            ];
            
            $stmt->execute($data);
            $success_count++;
            $account_index++;
        }
    }
    
    // Sync alias columns
    $pdo->exec("UPDATE students SET parent_name = father_name WHERE (parent_name IS NULL OR parent_name = '') AND father_name IS NOT NULL");
    $pdo->exec("UPDATE students SET parent_phone = father_mobile WHERE (parent_phone IS NULL OR parent_phone = '') AND father_mobile IS NOT NULL");
    $pdo->exec("UPDATE students SET student_mobile = mobile_number WHERE (student_mobile IS NULL OR student_mobile = '') AND mobile_number IS NOT NULL");
    
    $pdo->commit();
    echo "Successfully generated $success_count students.\n";

} catch (Exception $e) {
    $pdo->rollBack();
    die("Error generating students: " . $e->getMessage());
}

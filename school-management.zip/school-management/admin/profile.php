<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

// Fetch user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Fetch all settings into an associative array
$settings_query = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings");
$settings_raw = $settings_query->fetchAll(PDO::FETCH_KEY_PAIR);

// Helper function for settings
function get_setting($key, $settings_raw, $default = '')
{
    return isset($settings_raw[$key]) ? htmlspecialchars($settings_raw[$key]) : $default;
}

require_once '../includes/header.php';
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Super Admin Settings & Profile</h1>
    <a href="index.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-1"></i> Back to Dashboard</a>
</div>

<div class="row">
    <!-- Left Sidebar for Tabs -->
    <div class="col-md-3 mb-4">
        <div class="card shadow border-0">
            <div class="card-body p-0">
                <div class="nav flex-column nav-pills p-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <button class="nav-link active text-start mb-2" id="v-pills-personal-tab" data-bs-toggle="pill" data-bs-target="#v-pills-personal" type="button" role="tab" aria-controls="v-pills-personal" aria-selected="true">
                        <i class="fa-solid fa-user me-2"></i> Personal Information
                    </button>
                    <button class="nav-link text-start mb-2" id="v-pills-branding-tab" data-bs-toggle="pill" data-bs-target="#v-pills-branding" type="button" role="tab" aria-controls="v-pills-branding" aria-selected="false">
                        <i class="fa-solid fa-building me-2"></i> Branding Settings
                    </button>
                    <button class="nav-link text-start mb-2" id="v-pills-academic-tab" data-bs-toggle="pill" data-bs-target="#v-pills-academic" type="button" role="tab" aria-controls="v-pills-academic" aria-selected="false">
                        <i class="fa-solid fa-graduation-cap me-2"></i> Academic Settings
                    </button>
                    <button class="nav-link text-start mb-2" id="v-pills-system-tab" data-bs-toggle="pill" data-bs-target="#v-pills-system" type="button" role="tab" aria-controls="v-pills-system" aria-selected="false">
                        <i class="fa-solid fa-cogs me-2"></i> System Settings
                    </button>
                    <button class="nav-link text-start" id="v-pills-security-tab" data-bs-toggle="pill" data-bs-target="#v-pills-security" type="button" role="tab" aria-controls="v-pills-security" aria-selected="false">
                        <i class="fa-solid fa-shield-halved me-2"></i> Security Settings
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Side Content Area -->
    <div class="col-md-9">
        <div id="alert-container"></div>
        
        <div class="card shadow border-0">
            <div class="card-body p-4">
                <div class="tab-content" id="v-pills-tabContent">
                    
                    <!-- TAB A: Personal Information -->
                    <div class="tab-pane fade show active" id="v-pills-personal" role="tabpanel" aria-labelledby="v-pills-personal-tab">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="mb-0">Personal Information</h4>
                            <button type="button" class="btn btn-outline-secondary btn-sm" onclick="printProfileDetails()">
                                <i class="fa-solid fa-print me-1"></i> Print Details to PDF
                            </button>
                        </div>
                        
                        <!-- Hidden Printable Area -->
                        <div id="printableProfileData" class="d-none">
                            <div style="text-align: center; margin-bottom: 20px;">
                                <?php $print_logo = get_setting('school_logo', $settings_raw); ?>
                                <?php if ($print_logo): ?>
                                    <img src="<?php echo BASE_URL . '/uploads/branding/' . $print_logo; ?>" style="max-height: 60px; margin-bottom: 10px;">
                                <?php
endif; ?>
                                <h2 style="margin: 0; font-family: sans-serif;"><?php echo get_setting('school_name', $settings_raw); ?></h2>
                                <p style="margin: 5px 0; color: #555;"><?php echo get_setting('school_tagline', $settings_raw); ?></p>
                                <p style="margin: 0; font-size: 12px;"><?php echo get_setting('school_address', $settings_raw); ?> | Email: <?php echo get_setting('school_email', $settings_raw); ?> | Phone: <?php echo get_setting('school_phone', $settings_raw); ?></p>
                                <hr style="margin-top: 20px;">
                            </div>
                            
                            <h3 style="font-family: sans-serif; border-bottom: 1px solid #ccc; padding-bottom: 5px;">Super Admin Profile Record</h3>
                            <table style="width: 100%; border-collapse: collapse; font-family: sans-serif; margin-top: 15px;">
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #ddd; width: 30%;"><strong>Full Name</strong></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($user['name'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><strong>Username</strong></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($user['username'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><strong>Email Address</strong></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($user['email'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><strong>Phone Number</strong></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><strong>Date of Birth</strong></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($user['dob'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><strong>Gender</strong></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($user['gender'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><strong>Registered Address</strong></td>
                                    <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($user['address'] ?? 'N/A'); ?></td>
                                </tr>
                            </table>
                            
                            <div style="margin-top: 40px; text-align: right; font-family: sans-serif;">
                                <p style="margin-bottom: 50px;"><strong>Authorized Signature</strong></p>
                                <p>_______________________</p>
                                <p style="font-size: 12px; color: #777;">Generated on: <?php echo date('Y-m-d H:i:s'); ?></p>
                            </div>
                        </div>

                        <form id="form-personal" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="update_personal">
                            <div class="row align-items-center mb-4">
                                <div class="col-auto">
                                    <?php $img_src = $user['profile_photo'] ? BASE_URL . '/uploads/profile/' . htmlspecialchars($user['profile_photo']) : BASE_URL . '/assets/images/default-avatar.png'; ?>
                                    <img src="<?php echo $img_src; ?>" class="rounded-circle border" width="100" height="100" style="object-fit: cover;" id="profile_preview" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($user['name']); ?>&background=0D8ABC&color=fff';">
                                </div>
                                <div class="col">
                                    <label class="form-label fw-bold">Profile Photo</label>
                                    <input class="form-control" type="file" name="profile_photo" accept="image/*" onchange="previewImage(this, 'profile_preview')">
                                    <small class="text-muted">JPG, PNG or GIF. Max size 2MB.</small>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Full Name</label>
                                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Username</label>
                                    <input type="text" name="username" class="form-control" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Email Address</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Phone Number</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Date of Birth</label>
                                    <input type="date" name="dob" class="form-control" value="<?php echo htmlspecialchars($user['dob'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Gender</label>
                                    <select name="gender" class="form-select">
                                        <option value="">Select Gender</option>
                                        <option value="Male" <?php echo($user['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                                        <option value="Female" <?php echo($user['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                                        <option value="Other" <?php echo($user['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-bold">Address</label>
                                <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary d-flex align-items-center">
                                <span class="spinner-border spinner-border-sm d-none me-2" role="status" aria-hidden="true"></span>
                                Save Changes
                            </button>
                        </form>
                    </div>

                    <!-- TAB B: Branding Settings -->
                    <div class="tab-pane fade" id="v-pills-branding" role="tabpanel" aria-labelledby="v-pills-branding-tab">
                        <h4 class="mb-4">Branding Settings</h4>
                        <form id="form-branding" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="update_branding">
                            <div class="row mb-4">
                                <div class="col-md-6 text-center">
                                    <label class="form-label fw-bold d-block">School Logo</label>
                                    <?php $logo = get_setting('school_logo', $settings_raw); ?>
                                    <img src="<?php echo $logo ? BASE_URL . '/uploads/branding/' . $logo : 'https://placehold.co/150x50?text=Logo'; ?>" id="logo_preview" class="img-thumbnail mb-2" style="max-height: 80px;">
                                    <input class="form-control" type="file" name="school_logo" accept="image/*" onchange="previewImage(this, 'logo_preview')">
                                </div>
                                <div class="col-md-6 text-center">
                                    <label class="form-label fw-bold d-block">School Favicon</label>
                                    <?php $fav = get_setting('school_favicon', $settings_raw); ?>
                                    <img src="<?php echo $fav ? BASE_URL . '/uploads/branding/' . $fav : 'https://placehold.co/32x32?text=Fav'; ?>" id="favicon_preview" class="img-thumbnail mb-2" style="max-height: 50px;">
                                    <input class="form-control" type="file" name="school_favicon" accept="image/x-icon,image/png" onchange="previewImage(this, 'favicon_preview')">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">School Name</label>
                                    <input type="text" name="school_name" class="form-control" value="<?php echo get_setting('school_name', $settings_raw); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Tagline</label>
                                    <input type="text" name="school_tagline" class="form-control" value="<?php echo get_setting('school_tagline', $settings_raw); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">School Code</label>
                                    <input type="text" name="school_code" class="form-control" value="<?php echo get_setting('school_code', $settings_raw); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">School Board</label>
                                    <input type="text" name="school_board" class="form-control" value="<?php echo get_setting('school_board', $settings_raw); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Registration Number</label>
                                    <input type="text" name="school_registration_number" class="form-control" value="<?php echo get_setting('school_registration_number', $settings_raw); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">School Email</label>
                                    <input type="email" name="school_email" class="form-control" value="<?php echo get_setting('school_email', $settings_raw); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">School Phone</label>
                                    <input type="text" name="school_phone" class="form-control" value="<?php echo get_setting('school_phone', $settings_raw); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">School Website</label>
                                    <input type="text" name="school_website" class="form-control" value="<?php echo get_setting('school_website', $settings_raw); ?>">
                                </div>
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-bold">School Address</label>
                                <textarea name="school_address" class="form-control" rows="2"><?php echo get_setting('school_address', $settings_raw); ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary d-flex align-items-center">
                                <span class="spinner-border spinner-border-sm d-none me-2" role="status" aria-hidden="true"></span>
                                Save Branding
                            </button>
                        </form>
                    </div>

                    <!-- TAB C: Academic Settings -->
                    <div class="tab-pane fade" id="v-pills-academic" role="tabpanel" aria-labelledby="v-pills-academic-tab">
                        <h4 class="mb-4">Academic Settings</h4>
                        <form id="form-academic">
                            <input type="hidden" name="action" value="update_academic">
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Current Academic Year</label>
                                    <input type="text" name="academic_year" class="form-control" value="<?php echo get_setting('academic_year', $settings_raw); ?>" placeholder="e.g. 2023-2024">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Academic Start Date</label>
                                    <input type="date" name="academic_start_date" class="form-control" value="<?php echo get_setting('academic_start_date', $settings_raw); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Academic End Date</label>
                                    <input type="date" name="academic_end_date" class="form-control" value="<?php echo get_setting('academic_end_date', $settings_raw); ?>">
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Grade System</label>
                                    <select name="grade_system" class="form-select">
                                        <option value="Percentage" <?php echo get_setting('grade_system', $settings_raw) == 'Percentage' ? 'selected' : ''; ?>>Percentage</option>
                                        <option value="GPA" <?php echo get_setting('grade_system', $settings_raw) == 'GPA' ? 'selected' : ''; ?>>GPA</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Passing Percentage</label>
                                    <input type="number" name="passing_percentage" class="form-control" value="<?php echo get_setting('passing_percentage', $settings_raw); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Attendance Type</label>
                                    <select name="attendance_type" class="form-select">
                                        <option value="Daily" <?php echo get_setting('attendance_type', $settings_raw) == 'Daily' ? 'selected' : ''; ?>>Daily (Once)</option>
                                        <option value="Subject-wise" <?php echo get_setting('attendance_type', $settings_raw) == 'Subject-wise' ? 'selected' : ''; ?>>Subject-wise/Class-wise</option>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary d-flex align-items-center">
                                <span class="spinner-border spinner-border-sm d-none me-2" role="status" aria-hidden="true"></span>
                                Save Academic Settings
                            </button>
                        </form>
                    </div>

                    <!-- TAB D: System Settings -->
                    <div class="tab-pane fade" id="v-pills-system" role="tabpanel" aria-labelledby="v-pills-system-tab">
                        <h4 class="mb-4">System Settings</h4>
                        <form id="form-system">
                            <input type="hidden" name="action" value="update_system">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Timezone</label>
                                    <select name="timezone" class="form-select">
                                        <option value="UTC" <?php echo get_setting('timezone', $settings_raw) == 'UTC' ? 'selected' : ''; ?>>UTC</option>
                                        <option value="America/New_York" <?php echo get_setting('timezone', $settings_raw) == 'America/New_York' ? 'selected' : ''; ?>>America/New_York</option>
                                        <option value="Asia/Kolkata" <?php echo get_setting('timezone', $settings_raw) == 'Asia/Kolkata' ? 'selected' : ''; ?>>Asia/Kolkata</option>
                                        <!-- Need a full list in production -->
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Currency</label>
                                    <select name="currency" class="form-select">
                                        <option value="USD" <?php echo get_setting('currency', $settings_raw) == 'USD' ? 'selected' : ''; ?>>USD ($)</option>
                                        <option value="EUR" <?php echo get_setting('currency', $settings_raw) == 'EUR' ? 'selected' : ''; ?>>EUR (€)</option>
                                        <option value="INR" <?php echo get_setting('currency', $settings_raw) == 'INR' ? 'selected' : ''; ?>>INR (₹)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Date Format</label>
                                    <select name="date_format" class="form-select">
                                        <option value="Y-m-d" <?php echo get_setting('date_format', $settings_raw) == 'Y-m-d' ? 'selected' : ''; ?>>YYYY-MM-DD</option>
                                        <option value="d/m/Y" <?php echo get_setting('date_format', $settings_raw) == 'd/m/Y' ? 'selected' : ''; ?>>DD/MM/YYYY</option>
                                        <option value="m/d/Y" <?php echo get_setting('date_format', $settings_raw) == 'm/d/Y' ? 'selected' : ''; ?>>MM/DD/YYYY</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Language</label>
                                    <select name="language" class="form-select">
                                        <option value="English" <?php echo get_setting('language', $settings_raw) == 'English' ? 'selected' : ''; ?>>English</option>
                                        <option value="Spanish" <?php echo get_setting('language', $settings_raw) == 'Spanish' ? 'selected' : ''; ?>>Spanish</option>
                                        <option value="French" <?php echo get_setting('language', $settings_raw) == 'French' ? 'selected' : ''; ?>>French</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Theme</label>
                                    <select name="theme" class="form-select">
                                        <option value="Light" <?php echo get_setting('theme', $settings_raw) == 'Light' ? 'selected' : ''; ?>>Light</option>
                                        <option value="Dark" <?php echo get_setting('theme', $settings_raw) == 'Dark' ? 'selected' : ''; ?>>Dark</option>
                                    </select>
                                </div>
                                <?php if (!isset($_SESSION['true_role_id']) || $_SESSION['true_role_id'] != 2): ?>
                                <div class="col-md-6 d-flex align-items-center mt-4">
                                    <div class="form-check form-switch fs-5">
                                        <input class="form-check-input" type="checkbox" name="maintenance_mode" value="1" id="maintenance_mode" <?php echo get_setting('maintenance_mode', $settings_raw) == '1' ? 'checked' : ''; ?>>
                                        <label class="form-check-label fs-6 ms-2" for="maintenance_mode">Enable Maintenance Mode</label>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary d-flex align-items-center">
                                <span class="spinner-border spinner-border-sm d-none me-2" role="status" aria-hidden="true"></span>
                                Save System Settings
                            </button>
                        </form>
                    </div>

                    <!-- TAB E: Security Settings -->
                    <div class="tab-pane fade" id="v-pills-security" role="tabpanel" aria-labelledby="v-pills-security-tab">
                        <h4 class="mb-4">Security Settings</h4>
                        
                        <div class="card bg-light border-0 mb-4">
                            <div class="card-body">
                                <h6 class="fw-bold mb-3">Password Management</h6>
                                <form id="form-password">
                                    <input type="hidden" name="action" value="update_password">
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label">New Password</label>
                                            <input type="password" name="new_password" class="form-control" required minlength="6">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Confirm Password</label>
                                            <input type="password" name="confirm_password" class="form-control" required minlength="6">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-warning d-flex align-items-center">
                                        <span class="spinner-border spinner-border-sm d-none me-2" role="status" aria-hidden="true"></span>
                                        Update Password
                                    </button>
                                </form>
                            </div>
                        </div>

                        <div class="card bg-light border-0">
                            <div class="card-body">
                                <h6 class="fw-bold mb-3">System Security & Sessions</h6>
                                <form id="form-security">
                                    <input type="hidden" name="action" value="update_security">
                                    <div class="mb-3">
                                        <div class="form-check form-switch fs-5">
                                            <input class="form-check-input" type="checkbox" name="two_factor_auth" value="1" id="two_factor_auth" <?php echo get_setting('two_factor_auth', $settings_raw) == '1' ? 'checked' : ''; ?>>
                                            <label class="form-check-label fs-6 ms-2" for="two_factor_auth">Enable Two-Factor Authentication (2FA)</label>
                                        </div>
                                    </div>
                                    <div class="row align-items-center mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label">Session Timeout (Minutes)</label>
                                            <input type="number" name="session_timeout" class="form-control" value="<?php echo get_setting('session_timeout', $settings_raw); ?>" min="15">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary mt-2 d-flex align-items-center">
                                        <span class="spinner-border spinner-border-sm d-none me-2" role="status" aria-hidden="true"></span>
                                        Save Security Settings
                                    </button>
                                </form>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for AJAX Handling and UI -->
<script>
// Hash routing to open specific tabs
document.addEventListener("DOMContentLoaded", function () {
    let hash = window.location.hash;
    if (hash) {
        let targetTab = document.querySelector('button[data-bs-target="' + hash.replace('#', '#v-pills-') + '"]');
        if (targetTab) {
            let tab = new bootstrap.Tab(targetTab);
            tab.show();
        }
    }

    // Update URL hash on tab click without jumping
    document.querySelectorAll('button[data-bs-toggle="pill"]').forEach(function(el) {
        el.addEventListener('shown.bs.tab', function (e) {
            let target = e.target.getAttribute("data-bs-target").replace('#v-pills-', '');
            history.replaceState(null, null, '#' + target);
        });
    });
});

// Image previewer
function previewImage(input, previewId) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById(previewId).src = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
}

// Global AJAX Form Submitter
const forms = ['form-personal', 'form-branding', 'form-academic', 'form-system', 'form-password', 'form-security'];

forms.forEach(formId => {
    const form = document.getElementById(formId);
    if(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading spinner
            const btn = form.querySelector('button[type="submit"]');
            const spinner = btn.querySelector('.spinner-border');
            btn.disabled = true;
            spinner.classList.remove('d-none');
            
            const formData = new FormData(form);

            fetch('ajax_profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                let alertHtml = '';
                if(data.status === 'success') {
                    alertHtml = `<div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <i class="fa-solid fa-circle-check me-2"></i>${data.message}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                 </div>`;
                    if(formId === 'form-password') form.reset();
                } else {
                    alertHtml = `<div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="fa-solid fa-triangle-exclamation me-2"></i>${data.message}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                 </div>`;
                }
                document.getElementById('alert-container').innerHTML = alertHtml;
                window.scrollTo({top: 0, behavior: 'smooth'});
            })
            .catch(error => {
                document.getElementById('alert-container').innerHTML = `<div class="alert alert-danger">An unexpected error occurred. Please try again.</div>`;
            })
            .finally(() => {
                btn.disabled = false;
                spinner.classList.add('d-none');
            });
        });
    }
});

// PDF Print Function
function printProfileDetails() {
    const printContent = document.getElementById('printableProfileData').innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    
    printWindow.document.write('<html><head><title>Print User Profile</title>');
    printWindow.document.write('<style>body { font-family: sans-serif; padding: 20px; }</style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write(printContent);
    printWindow.document.write('</body></html>');
    
    printWindow.document.close();
    printWindow.focus();
    
    // Slight delay to ensure images load before printing
    setTimeout(() => {
        printWindow.print();
        printWindow.close();
    }, 500);
}
</script>

<?php require_once '../includes/footer.php'; ?>

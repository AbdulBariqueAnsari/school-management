<?php
$module_key = 'messages';
$module_title = 'Class Messages';
$module_icon = 'fa-envelope';
require_once __DIR__ . '/includes/class_module.php';
?>

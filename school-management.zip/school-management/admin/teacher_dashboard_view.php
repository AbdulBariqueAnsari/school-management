<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
$stmt->execute([$id]);
$teacher = $stmt->fetch();

if (!$teacher) {
    die("Teacher not found.");
}

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-0 text-dark"><i class="fa fa-gauge-high text-primary me-2"></i> Teacher Activity Dashboard</h2>
            <p class="text-muted mb-0">Overview for <strong><?php echo htmlspecialchars($teacher['full_name']); ?></strong> (<?php echo htmlspecialchars($teacher['teacher_id']); ?>)</p>
        </div>
        <div class="d-flex gap-2">
            <a href="teacher_profile.php?id=<?php echo $teacher['id']; ?>" class="btn btn-outline-primary shadow-sm"><i class="fa fa-user me-1"></i> Profile View</a>
            <a href="teachers.php" class="btn btn-outline-secondary shadow-sm"><i class="fa fa-arrow-left me-1"></i> Back</a>
        </div>
    </div>

    <!-- Quick Stats Card -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-primary text-white p-3">
                <div class="d-flex justify-content-between">
                    <div>
                        <small class="text-white-50 d-block">Status</small>
                        <h4 class="fw-bold mb-0"><?php echo htmlspecialchars($teacher['status']); ?></h4>
                    </div>
                    <i class="fa fa-shield-check fa-2x text-white-50"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-success text-white p-3">
                <div class="d-flex justify-content-between">
                    <div>
                        <small class="text-white-50 d-block">Experience</small>
                        <h4 class="fw-bold mb-0"><?php echo htmlspecialchars($teacher['experience_years']); ?> Years</h4>
                    </div>
                    <i class="fa fa-award fa-2x text-white-50"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-info text-white p-3">
                <div class="d-flex justify-content-between">
                    <div>
                        <small class="text-white-50 d-block">Class</small>
                        <h4 class="fw-bold mb-0"><?php echo htmlspecialchars($teacher['assigned_class']); ?></h4>
                    </div>
                    <i class="fa fa-chalkboard fa-2x text-white-50"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-warning text-dark p-3">
                <div class="d-flex justify-content-between">
                    <div>
                        <small class="text-dark-50 d-block text-muted">Joining Date</small>
                        <h4 class="fw-bold mb-0 text-dark"><?php echo htmlspecialchars($teacher['year_of_joining']); ?></h4>
                    </div>
                    <i class="fa fa-calendar-check fa-2x text-dark-50 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Profile Summary Column -->
        <div class="col-lg-4">
            <div class="card shadow-sm border-0 mb-4 h-100">
                <div class="card-body text-center py-5">
                    <img src="../uploads/profile/<?php echo $teacher['photo'] ?: 'default-teacher.png'; ?>" class="rounded-circle border border-4 border-white shadow mb-4" width="120" height="120" style="object-fit:cover;" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($teacher['full_name']); ?>&background=random';">
                    <h4 class="fw-bold"><?php echo htmlspecialchars($teacher['full_name']); ?></h4>
                    <span class="badge bg-soft-primary text-primary px-3 py-2 mb-4"><?php echo htmlspecialchars($teacher['assigned_subject']); ?></span>
                    
                    <div class="text-start mt-3">
                        <p class="mb-2"><i class="fa fa-envelope text-muted me-2"></i> <?php echo htmlspecialchars($teacher['email']); ?></p>
                        <p class="mb-2"><i class="fa fa-phone text-muted me-2"></i> <?php echo htmlspecialchars($teacher['phone']); ?></p>
                        <p class="mb-0"><i class="fa fa-map-marker-alt text-muted me-2"></i> <?php echo htmlspecialchars(substr($teacher['present_address'], 0, 50)); ?>...</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Activity/Insight Column -->
        <div class="col-lg-8">
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white py-3 border-0">
                    <h5 class="fw-bold mb-0"><i class="fa fa-chart-line text-success me-2"></i> Teacher Insights (Mock Stats)</h5>
                </div>
                <div class="card-body">
                    <div class="row g-4 text-center">
                        <div class="col-md-4">
                            <div class="p-3 border rounded">
                                <h2 class="fw-bold text-success mb-0">98%</h2>
                                <small class="text-muted">Attendance</small>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 border rounded">
                                <h2 class="fw-bold text-info mb-0">12</h2>
                                <small class="text-muted">Classes/Week</small>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 border rounded">
                                <h2 class="fw-bold text-primary mb-0">A+</h2>
                                <small class="text-muted">Performance Rating</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3 border-0 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><i class="fa fa-history text-secondary me-2"></i> Recent Activity Log</h5>
                    <button class="btn btn-sm btn-link text-decoration-none">View All</button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <tbody class="border-top">
                                <tr>
                                    <td class="ps-4" style="width: 50px;"><i class="fa fa-check-circle text-success"></i></td>
                                    <td>
                                        <div class="fw-bold">Marked Attendance</div>
                                        <small class="text-muted">Class 10 - Section A</small>
                                    </td>
                                    <td class="text-end pe-4 text-muted small">Today, 09:30 AM</td>
                                </tr>
                                <tr>
                                    <td class="ps-4"><i class="fa fa-file-upload text-info"></i></td>
                                    <td>
                                        <div class="fw-bold">Uploaded Notes</div>
                                        <small class="text-muted">Subject: Physics - Newton's Laws</small>
                                    </td>
                                    <td class="text-end pe-4 text-muted small">Yesterday, 04:15 PM</td>
                                </tr>
                                <tr>
                                    <td class="ps-4"><i class="fa fa-edit text-warning"></i></td>
                                    <td>
                                        <div class="fw-bold">Modified Exam Schedule</div>
                                        <small class="text-muted">Mid-term Exam Date Update</small>
                                    </td>
                                    <td class="text-end pe-4 text-muted small">02 Mar 2026</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .bg-soft-primary { background-color: rgba(13, 110, 253, 0.1); }
    .card { transition: transform 0.2s; }
    .card:hover { transform: translateY(-3px); }
</style>

<?php require_once '../includes/footer.php'; ?>

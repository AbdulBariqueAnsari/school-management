<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../dashboard.php");
    exit();
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$stu = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$stu) {
    die('<div class="container mt-5"><div class="alert alert-danger">Record not found. <a href="admissions.php">Back</a></div></div>');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'student_name'              => trim($_POST['student_name'] ?? ''),
        'gender'                    => $_POST['gender'] ?? '',
        'dob'                       => $_POST['dob'] ?? '',
        'age'                       => (int)$_POST['age'] ?: null,
        'blood_group'               => $_POST['blood_group'] ?? '',
        'aadhaar_number'            => trim($_POST['aadhaar_number'] ?? ''),
        'class_applied'             => $_POST['class_applied'] ?? '',
        'class'                     => $_POST['class_applied'] ?? '', // Sync both
        'mobile_number'             => trim($_POST['mobile_number'] ?? ''),
        'student_mobile'            => trim($_POST['mobile_number'] ?? ''), // Sync both
        'address'                   => trim($_POST['address'] ?? ''),
        'present_address'           => trim($_POST['address'] ?? ''), // Sync both
        'religion'                  => $_POST['religion'] ?? '',
        'caste_category'            => $_POST['caste_category'] ?? '',
        'mother_tongue'             => trim($_POST['mother_tongue'] ?? ''),
        'previous_schooling_status' => $_POST['previous_schooling_status'] ?? '',
        'father_name'               => trim($_POST['father_name'] ?? ''),
        'father_mobile'             => trim($_POST['father_mobile'] ?? ''),
        'parent_name'               => trim($_POST['father_name'] ?? ''),
        'parent_phone'              => trim($_POST['father_mobile'] ?? ''),
        'mother_name'               => trim($_POST['mother_name'] ?? ''),
        'mother_mobile'             => trim($_POST['mother_mobile'] ?? ''),
        'parent_email'              => trim($_POST['parent_email'] ?? ''),
        'parents_address'           => trim($_POST['parents_address'] ?? ''),
        'guardian_name'             => trim($_POST['guardian_name'] ?? ''),
        'relation'                  => trim($_POST['relation'] ?? ''),
        'guardian_mobile'           => trim($_POST['guardian_mobile'] ?? ''),
        'guardian_address'          => trim($_POST['guardian_address'] ?? ''),
        'guardian_details'          => trim($_POST['guardian_address'] ?? ''),
        'has_medical_condition'     => isset($_POST['has_medical_condition']) ? 1 : 0,
        'medical_condition_desc'    => trim($_POST['medical_condition_desc'] ?? ''),
        'has_disability'            => isset($_POST['has_disability']) ? 1 : 0,
        'disability_desc'           => trim($_POST['disability_desc'] ?? ''),
        'has_allergies'             => isset($_POST['has_allergies']) ? 1 : 0,
        'allergies_desc'            => trim($_POST['allergies_desc'] ?? ''),
        'previous_class'            => trim($_POST['previous_class'] ?? ''),
        'previous_school_name'      => trim($_POST['previous_school_name'] ?? ''),
        'previous_school'           => trim($_POST['previous_school_name'] ?? ''), // Sync both
        'previous_board'            => trim($_POST['previous_board'] ?? ''),
        'year_of_passing'           => $_POST['year_of_passing'] ?: null,
        'username'                  => trim($_POST['username'] ?? ''),
        'email'                     => trim($_POST['email'] ?? ''),
        'admission_no'              => trim($_POST['admission_no'] ?? ''),
        'admission_date'            => $_POST['admission_date'] ?? null,
    ];

    $password = trim($_POST['new_password'] ?? '');
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $data['password'] = $hashed_password;
    }

    $photo = $stu['student_photo'];
    if (isset($_FILES['student_photo']) && $_FILES['student_photo']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['student_photo']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png']) && $_FILES['student_photo']['size'] <= 2097152) {
            if (!is_dir('../uploads')) mkdir('../uploads', 0777, true);
            $photo = 'stu_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['student_photo']['tmp_name'], '../uploads/' . $photo)) {
                $data['photo'] = $photo; // Sync both photo columns
            } else {
                $error = 'Failed to save photo.';
                $photo = $stu['student_photo'];
            }
        } else { $error = 'Invalid photo. JPG/PNG max 2MB.'; }
    }

    if (!$error) {
        $data['student_photo'] = $photo;
        $set = []; $params = [];
        foreach ($data as $col => $val) {
            $set[] = "`$col` = ?";
            $params[] = ($val === '') ? null : $val;
        }
        $params[] = $id;
        try {
            $pdo->prepare("UPDATE students SET " . implode(', ', $set) . " WHERE id = ?")->execute($params);
            
            // Sync with users table if password/username/email changed
            if (!empty($stu['user_id'])) {
                $userUpdates = [];
                $userParams = [];
                if (!empty($password)) {
                    $userUpdates[] = "password = ?";
                    $userParams[] = password_hash($password, PASSWORD_DEFAULT);
                }
                // Only update username/email if they actually changed to avoid potential duplicate errors on some MySQL versions/configs
                if ($data['username'] && $data['username'] !== $stu['username']) {
                    $userUpdates[] = "username = ?";
                    $userParams[] = $data['username'];
                }
                if ($data['email'] && $data['email'] !== $stu['email']) {
                    $userUpdates[] = "email = ?";
                    $userParams[] = $data['email'];
                }
                
                if ($userUpdates) {
                    $userParams[] = $stu['user_id'];
                    try {
                        $pdo->prepare("UPDATE users SET " . implode(', ', $userUpdates) . " WHERE id = ?")->execute($userParams);
                    } catch (PDOException $e) {
                        // If sync fails (e.g. username taken by another user), we'll still have the student record updated
                    }
                }
            }

            // Log the activity
            if (function_exists('logActivity')) {
                logActivity("Updated student record for " . $data['student_name'] . " (ID: $id)");
            }

            $_SESSION['success'] = 'Student details updated successfully.';
            header('Location: student_profile.php?id=' . $id);
            exit();
        } catch (PDOException $e) { $error = 'DB error: ' . $e->getMessage(); }
    }
}

require_once '../includes/header.php';
?>
<div class="container-fluid pt-3 pb-5">
<div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
    <h2 class="fw-bold"><i class="fa fa-user-edit me-2 text-primary"></i>Edit Student: <span class="text-muted"><?= htmlspecialchars($stu['student_name']) ?></span></h2>
    <div class="d-flex gap-2">
        <a href="student_profile.php?id=<?= $id ?>" class="btn btn-outline-info shadow-sm"><i class="fa fa-eye me-1"></i> View Profile</a>
        <a href="admissions.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-1"></i> Back</a>
    </div>
</div>

<?php if ($error): ?><div class="alert alert-danger shadow-sm border-0 mb-4"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<form method="POST" enctype="multipart/form-data">
<div class="row g-4">

    <!-- Section 1: Identity & Application -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4" style="border-radius:15px;">
            <div class="card-header bg-primary text-white py-3" style="border-radius:15px 15px 0 0;">
                <h6 class="mb-0 fw-bold"><i class="fa fa-id-card me-2"></i>Personal & Application Identity</h6>
            </div>
            <div class="card-body p-4">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="student_name" class="form-control" value="<?= htmlspecialchars($stu['student_name'] ?? '') ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Gender</label>
                        <select name="gender" class="form-select">
                            <option value="">Select</option>
                            <?php foreach(['Male','Female','Other'] as $g): ?>
                                <option value="<?=$g?>"<?=($stu['gender']??'')===$g?' selected':''?>><?=$g?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Date of Birth</label>
                        <input type="date" name="dob" id="edit_dob" class="form-control" value="<?= htmlspecialchars($stu['dob'] ?? '') ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Age (Years)</label>
                        <input type="number" name="age" id="edit_age" class="form-control" value="<?= htmlspecialchars($stu['age'] ?? '') ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Blood Group</label>
                        <select name="blood_group" class="form-select">
                            <option value="">Select</option>
                            <?php foreach(['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg): ?>
                                <option value="<?=$bg?>"<?=($stu['blood_group']??'')===$bg?' selected':''?>><?=$bg?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Religion</label>
                        <select name="religion" class="form-select">
                            <option value="">Select</option>
                            <?php foreach(['Hindu','Islam','Christian','Buddhist','Sikh','Jain','Other'] as $r): ?>
                                <option value="<?=$r?>"<?=($stu['religion']??'')===$r?' selected':''?>><?=$r?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">Caste Category</label>
                        <select name="caste_category" class="form-select">
                            <option value="">Select</option>
                            <?php foreach(['General','OBC-A','OBC-B','SC','ST'] as $c): ?>
                                <option value="<?=$c?>"<?=($stu['caste_category']??'')===$c?' selected':''?>><?=$c?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Mother Tongue</label>
                        <input type="text" name="mother_tongue" class="form-control" value="<?= htmlspecialchars($stu['mother_tongue'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Aadhaar Number</label>
                        <input type="text" name="aadhaar_number" class="form-control" value="<?= htmlspecialchars($stu['aadhaar_number'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Mobile Number</label>
                        <input type="text" name="mobile_number" class="form-control" value="<?= htmlspecialchars($stu['mobile_number'] ?? $stu['student_mobile'] ?? '') ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-bold">Present Address</label>
                        <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($stu['present_address'] ?? $stu['address'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 2: Family & Parents -->
        <div class="card border-0 shadow-sm mb-4" style="border-radius:15px;">
            <div class="card-header bg-success text-white py-3" style="border-radius:15px 15px 0 0;">
                <h6 class="mb-0 fw-bold"><i class="fa fa-users me-2"></i>Family & Parent Details</h6>
            </div>
            <div class="card-body p-4">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Father's Full Name</label>
                        <input type="text" name="father_name" class="form-control" value="<?= htmlspecialchars($stu['father_name'] ?? $stu['parent_name'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Father's Mobile</label>
                        <input type="text" name="father_mobile" class="form-control" value="<?= htmlspecialchars($stu['father_mobile'] ?? $stu['parent_phone'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Mother's Full Name</label>
                        <input type="text" name="mother_name" class="form-control" value="<?= htmlspecialchars($stu['mother_name'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Mother's Mobile</label>
                        <input type="text" name="mother_mobile" class="form-control" value="<?= htmlspecialchars($stu['mother_mobile'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Parent/Guardian Email</label>
                        <input type="email" name="parent_email" class="form-control" value="<?= htmlspecialchars($stu['parent_email'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Guardian Name</label>
                        <input type="text" name="guardian_name" class="form-control" value="<?= htmlspecialchars($stu['guardian_name'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Relation with Guardian</label>
                        <input type="text" name="relation" class="form-control" value="<?= htmlspecialchars($stu['relation'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small">Guardian Mobile</label>
                        <input type="text" name="guardian_mobile" class="form-control" value="<?= htmlspecialchars($stu['guardian_mobile'] ?? '') ?>">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label fw-bold small">Permanent / Parents Address</label>
                        <textarea name="parents_address" class="form-control" rows="2"><?= htmlspecialchars($stu['parents_address'] ?? $stu['guardian_address'] ?? $stu['guardian_details'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Sidebar Sections -->
    <div class="col-lg-4">
        <!-- Photo & Admission -->
        <div class="card border-0 shadow-sm mb-4" style="border-radius:15px;">
            <div class="card-header bg-dark text-white py-3" style="border-radius:15px 15px 0 0;">
                <h6 class="mb-0 fw-bold"><i class="fa fa-school me-2"></i>Admission Data</h6>
            </div>
            <div class="card-body p-4 text-center">
                <div class="mb-3">
                    <?php 
                    $photo_path = !empty($stu['student_photo']) ? $stu['student_photo'] : (!empty($stu['photo']) ? $stu['photo'] : '');
                    ?>
                    <img src="../uploads/<?= htmlspecialchars($photo_path) ?>" height="120" width="120" class="rounded-circle border shadow-sm mb-2" style="object-fit: cover;" onerror="this.src='https://ui-avatars.com/api/?name=<?=urlencode($stu['student_name'])?>';">
                    <input type="file" name="student_photo" class="form-control form-control-sm mt-2" accept="image/jpeg,image/png">
                    <small class="text-muted d-block mt-1">Change student photo (JPG/PNG, max 2MB)</small>
                </div>
                <div class="text-start">
                    <div class="mb-3">
                        <label class="form-label fw-bold small text-uppercase">Admission No</label>
                        <input type="text" name="admission_no" class="form-control form-control-sm" value="<?= htmlspecialchars($stu['admission_no'] ?? $stu['admission_number'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small text-uppercase">Admission Date</label>
                        <input type="date" name="admission_date" class="form-control form-control-sm" value="<?= htmlspecialchars($stu['admission_date'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small text-uppercase">Class</label>
                        <input type="text" name="class_applied" class="form-control form-control-sm" value="<?= htmlspecialchars($stu['class'] ?? $stu['class_applied'] ?? '') ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Account Settings -->
        <div class="card border-0 shadow-sm mb-4" style="border-radius:15px;">
            <div class="card-header bg-secondary text-white py-3" style="border-radius:15px 15px 0 0;">
                <h6 class="mb-0 fw-bold"><i class="fa fa-user-lock me-2"></i>Portal Account</h6>
            </div>
            <div class="card-body p-4">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-uppercase">Login Username</label>
                    <input type="text" name="username" class="form-control form-control-sm" value="<?= htmlspecialchars($stu['username'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-uppercase">Portal Email</label>
                    <input type="email" name="email" class="form-control form-control-sm" value="<?= htmlspecialchars($stu['email'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-uppercase">Reset Password</label>
                    <input type="password" name="new_password" class="form-control form-control-sm" placeholder="Enter new password">
                    <small class="text-muted" style="font-size:0.8em;">Leave blank to keep existing password.</small>
                </div>
                <small class="text-muted"><i class="fa fa-info-circle me-1"></i> These details are used by the student to log in.</small>
            </div>
        </div>

        <!-- Health Switchers -->
        <div class="card border-0 shadow-sm mb-4" style="border-radius:15px;">
            <div class="card-header bg-danger text-white py-3" style="border-radius:15px 15px 0 0;">
                <h6 class="mb-0 fw-bold"><i class="fa fa-heartbeat me-2"></i>Health Declares</h6>
            </div>
            <div class="card-body p-4">
                <div class="mb-4">
                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="has_medical_condition" id="chk_med"<?=($stu['has_medical_condition']??0)?' checked':''?>>
                        <label class="form-check-label fw-bold" for="chk_med">Medical Condition</label>
                    </div>
                    <textarea name="medical_condition_desc" class="form-control form-control-sm mt-2" rows="2" placeholder="Describe..."><?= htmlspecialchars($stu['medical_condition_desc'] ?? '') ?></textarea>
                </div>
                <div class="mb-4">
                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="has_disability" id="chk_dis"<?=($stu['has_disability']??0)?' checked':''?>>
                        <label class="form-check-label fw-bold" for="chk_dis">Physical Disability</label>
                    </div>
                    <textarea name="disability_desc" class="form-control form-control-sm mt-2" rows="2" placeholder="Describe..."><?= htmlspecialchars($stu['disability_desc'] ?? '') ?></textarea>
                </div>
                <div>
                    <div class="form-check form-switch mb-1">
                        <input class="form-check-input" type="checkbox" name="has_allergies" id="chk_alg"<?=($stu['has_allergies']??0)?' checked':''?>>
                        <label class="form-check-label fw-bold" for="chk_alg">Known Allergies</label>
                    </div>
                    <textarea name="allergies_desc" class="form-control form-control-sm mt-2" rows="2" placeholder="Describe..."><?= htmlspecialchars($stu['allergies_desc'] ?? '') ?></textarea>
                </div>
            </div>
        </div>

        <!-- Academic Background Summary -->
        <div class="card border-0 shadow-sm mb-4" style="border-radius:15px;">
            <div class="card-header bg-warning text-dark py-3" style="border-radius:15px 15px 0 0;">
                <h6 class="mb-0 fw-bold"><i class="fa fa-book me-2"></i>History Background</h6>
            </div>
            <div class="card-body p-4">
                <div class="mb-3">
                    <label class="form-label fw-bold small text-uppercase">Previous Schooling</label>
                    <select name="previous_schooling_status" class="form-select form-select-sm">
                        <option value="">Select</option>
                        <?php foreach(['Passed from Previous School','Currently Studying','Transfer Certificate','Left School','Never Attended School'] as $ps): ?>
                            <option value="<?=$ps?>"<?=($stu['previous_schooling_status']??'')===$ps?' selected':''?>><?=$ps?></option>
                        <?php endforeach;?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small text-uppercase">Prev School Name</label>
                    <input type="text" name="previous_school_name" class="form-control form-control-sm" value="<?= htmlspecialchars($stu['previous_school_name'] ?? $stu['previous_school'] ?? '') ?>">
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-6">
                        <label class="form-label fw-bold small text-uppercase">Last Class</label>
                        <input type="text" name="previous_class" class="form-control form-control-sm" value="<?= htmlspecialchars($stu['previous_class'] ?? '') ?>">
                    </div>
                    <div class="col-6">
                        <label class="form-label fw-bold small text-uppercase">Pass Year</label>
                        <input type="number" name="year_of_passing" class="form-control form-control-sm" value="<?= htmlspecialchars($stu['year_of_passing'] ?? '') ?>">
                    </div>
                </div>
                <div class="mb-0">
                    <label class="form-label fw-bold small text-uppercase">Prev Board</label>
                    <input type="text" name="previous_board" class="form-control form-control-sm" value="<?= htmlspecialchars($stu['previous_board'] ?? '') ?>">
                </div>
            </div>
        </div>
    </div>

    <!-- Form Footer -->
    <div class="col-12 py-3">
        <div class="card border-0 shadow-sm" style="border-radius:12px;">
            <div class="card-body d-flex justify-content-between align-items-center">
                <p class="mb-0 text-muted"><i class="fa fa-info-circle me-2"></i> Please review all details carefully before saving.</p>
                <div class="d-flex gap-3">
                    <a href="student_profile.php?id=<?= $id ?>" class="btn btn-outline-secondary px-4">Cancel</a>
                    <button type="submit" class="btn btn-primary px-5 fw-bold shadow-sm"><i class="fa fa-save me-2"></i>Update All Records</button>
                </div>
            </div>
        </div>
    </div>

</div>
</form>
</div>
<?php require_once '../includes/footer.php'; ?>

<script src="../assets/js/age_calc.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const dobInput = document.getElementById('edit_dob');
    const ageInput = document.getElementById('edit_age');
    
    if (dobInput && ageInput) {
        dobInput.addEventListener('change', function() {
            const dobValue = this.value;
            if (dobValue) {
                const dob = new Date(dobValue);
                const today = new Date();
                let age = today.getFullYear() - dob.getFullYear();
                const m = today.getMonth() - dob.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
                    age--;
                }
                ageInput.value = age >= 0 ? age : 0;
            }
        });
    }
});
</script>


<?php
require_once '../includes/auth.php';
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

// Search and Filter Logic
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$class_filter = isset($_GET['class']) ? trim($_GET['class']) : '';

$query = "SELECT * FROM teachers WHERE status = 'Approved'";
$params = [];

if ($search !== '') {
    $query .= " AND (full_name LIKE ? OR teacher_id LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($class_filter !== '') {
    $query .= " AND assigned_class = ?";
    $params[] = $class_filter;
}

$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch distinct classes for filter dropdown
$class_stmt = $pdo->query("SELECT DISTINCT assigned_class FROM teachers WHERE status = 'Approved' AND assigned_class IS NOT NULL AND assigned_class != '' ORDER BY assigned_class ASC");
$classes = $class_stmt->fetchAll(PDO::FETCH_COLUMN);

require_once '../includes/header.php';
?>
<?php include 'includes/teacher_page_styles.php'; ?>

<div class="container-fluid py-4">
    <div class="tp-header tp-header--green">
        <div>
            <h2><i class="fa fa-user-check me-2"></i> Approved Teachers</h2>
            <p>All active teachers — <strong><?php echo count($teachers); ?></strong> records <?php echo ($search || $class_filter) ? '(filtered)' : ''; ?></p>
        </div>
        <div>
            <a href="teachers.php" class="tp-back-btn"><i class="fa fa-arrow-left me-1"></i> Back</a>
        </div>
    </div>

    <!-- Search & Filter Bar -->
    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
        <div class="card-body p-3">
            <form method="GET" class="row g-3 align-items-center">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="fa fa-search text-muted"></i></span>
                        <input type="text" name="search" class="form-control border-start-0 shape-none" placeholder="Search by name or Teacher ID..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="fa fa-filter text-muted"></i></span>
                        <select name="class" class="form-select border-start-0" onchange="this.form.submit()">
                            <option value="">All Classes (Teaching)</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo htmlspecialchars($class); ?>" <?php echo ($class_filter === $class) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($class); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary px-4 h-100">Search</button>
                    <?php if ($search !== '' || $class_filter !== ''): ?>
                        <a href="approved_teacher.php" class="btn btn-outline-secondary h-100 d-flex align-items-center"><i class="fa fa-times me-1"></i> Clear</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <?php if (empty($teachers)): ?>
        <div class="tp-empty">
            <i class="fa fa-user-check fa-3x text-success mb-3"></i>
            <p class="text-muted">No approved teachers found.</p>
        </div>
    <?php
else: ?>
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 bg-white tp-table">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Teacher</th>
                        <th>Subject</th>
                        <th>Designation</th>
                        <th>Class</th>
                        <th>Experience</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($teachers as $i => $t): ?>
                    <tr class="tp-row" data-id="<?php echo $t['id']; ?>" data-section="approved">
                        <td><span class="text-muted small"><?php echo $i + 1; ?></span></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <img src="../uploads/profile/<?php echo $t['photo'] ?: 'default-teacher.png'; ?>"
                                     class="rounded-circle border border-2 border-white shadow-sm"
                                     width="42" height="42" style="object-fit:cover;"
                                     onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($t['full_name']); ?>&background=random'">
                                <div>
                                    <span class="fw-bold d-block"><?php echo htmlspecialchars($t['full_name']); ?></span>
                                    <small class="text-muted"><?php echo htmlspecialchars($t['teacher_id']); ?></small>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-primary bg-opacity-10 text-primary border border-primary-subtle"><?php echo htmlspecialchars($t['assigned_subject']); ?></span></td>
                        <td><small><?php echo htmlspecialchars($t['designation']); ?></small></td>
                        <td><small class="fw-semibold"><?php echo htmlspecialchars($t['assigned_class']); ?></small></td>
                        <td><span class="fw-bold"><?php echo htmlspecialchars($t['experience_years']); ?></span> <small class="text-muted">yrs</small></td>
                        <td><span class="badge bg-success">Approved</span></td>
                    </tr>
                    <!-- Action Panel -->
                    <tr class="tp-action-row" id="panel-<?php echo $t['id']; ?>" style="display:none;">
                        <td colspan="7">
                            <div class="tp-action-panel">
                                <a href="teacher_profile.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-view"><i class="fa fa-eye"></i> View</a>
                                <a href="edit_teacher.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-edit"><i class="fa fa-edit"></i> Edit</a>
                                <a href="actions/export_teacher.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-pdf" target="_blank"><i class="fa fa-file-pdf"></i> Export PDF</a>
                                <a href="teacher_dashboard_view.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-dash"><i class="fa fa-gauge"></i> Dashboard</a>
                                <button class="tp-btn tp-btn-reject btn-confirm"
                                        data-url="actions/reject_teacher.php?id=<?php echo $t['id']; ?>"
                                        data-title="Reject Teacher?" data-text="Move this teacher to rejected?" data-icon="warning" data-confirm="Yes, Reject">
                                    <i class="fa fa-times"></i> Reject
                                </button>
                                <button class="tp-btn tp-btn-delete btn-confirm"
                                        data-url="actions/delete_teacher.php?id=<?php echo $t['id']; ?>"
                                        data-title="Move to Trash?" data-text="Move this teacher to deleted records?" data-icon="warning" data-confirm="Yes, Delete">
                                    <i class="fa fa-trash"></i> Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
    endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
endif; ?>
</div>

<?php include 'includes/teacher_page_scripts.php'; ?>
<?php require_once '../includes/footer.php'; ?>

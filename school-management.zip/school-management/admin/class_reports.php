<?php
$module_key = 'reports';
$module_title = 'Class Reports';
$module_icon = 'fa-chart-pie';
require_once __DIR__ . '/includes/class_module.php';
?>

<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
// Fetch student details from students table
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
    die("Student not found.");
}

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="fa fa-user-graduate text-success me-2"></i> Student Profile</h2>
        <div class="d-flex gap-2">
            <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="btn btn-warning shadow-sm"><i class="fa fa-edit me-1"></i> Edit Profile</a>
            <a href="actions/export_student.php?id=<?php echo $student['id']; ?>&type=student" class="btn btn-info text-white shadow-sm" target="_blank"><i class="fa fa-file-pdf me-1"></i> Export PDF</a>
            <a href="approved_students.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-1"></i> Back to List</a>
        </div>
    </div>

    <div class="row">
        <!-- Sidebar Info -->
        <div class="col-lg-3">
            <div class="card shadow-sm border-0 mb-4 overflow-hidden" style="border-radius: 15px;">
                <div class="bg-primary py-5 text-center position-relative">
                    <?php 
                    $photo_path = !empty($student['student_photo']) ? $student['student_photo'] : (!empty($student['photo']) ? $student['photo'] : '');
                    ?>
                    <img src="../uploads/<?php echo htmlspecialchars($photo_path); ?>" class="rounded-circle border border-4 border-white shadow-lg" width="140" height="140" style="object-fit:cover; background: #fff;" onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($student['student_name']); ?>&background=random';">
                </div>
                <div class="card-body text-center pt-5 mt-2">
                    <h4 class="fw-bold mb-1 text-dark"><?php echo htmlspecialchars($student['student_name']); ?></h4>
                    <p class="text-primary fw-bold mb-3"><?php echo htmlspecialchars($student['admission_no'] ?: $student['admission_number'] ?: 'ADM-'.$student['id']); ?></p>
                    
                    <div class="d-grid gap-2 mb-4">
                        <span class="badge <?php echo ($student['status'] == 'Approved') ? 'bg-success' : (($student['status'] == 'Rejected') ? 'bg-danger' : 'bg-warning text-dark'); ?> py-2">
                            <i class="fa <?php echo ($student['status'] == 'Approved') ? 'fa-check-circle' : (($student['status'] == 'Rejected') ? 'fa-times-circle' : 'fa-clock'); ?> me-1"></i>
                            <?php echo htmlspecialchars($student['status'] ?? 'Pending'); ?>
                        </span>
                        <span class="badge bg-light text-dark border py-2">
                            <i class="fa fa-school me-1 text-primary"></i> 
                            Class: <?php echo htmlspecialchars($student['class'] ?: $student['class_applied'] ?: 'N/A'); ?>
                        </span>
                    </div>
                    
                    <div class="text-start border-top pt-3">
                        <div class="mb-3">
                            <label class="text-muted small fw-bold text-uppercase d-block mb-1">Assigned Email</label>
                            <span class="fw-bold small text-break"><i class="fa fa-envelope text-primary me-2"></i><?php echo htmlspecialchars($student['email'] ?: $student['parent_email'] ?: 'N/A'); ?></span>
                        </div>
                        <div class="mb-3">
                            <label class="text-muted small fw-bold text-uppercase d-block mb-1">Username</label>
                            <span class="fw-bold"><i class="fa fa-user-tag text-primary me-2"></i><?php echo htmlspecialchars($student['username'] ?: 'N/A'); ?></span>
                        </div>
                        <div class="mb-2">
                            <label class="text-muted small fw-bold text-uppercase d-block mb-1">Student Contact</label>
                            <span class="fw-bold"><i class="fa fa-phone text-primary me-2"></i><?php echo htmlspecialchars($student['student_mobile'] ?: $student['mobile_number'] ?: 'N/A'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions Card -->
            <div class="card shadow-sm border-0" style="border-radius: 12px;">
                <div class="card-body p-3">
                    <h6 class="fw-bold border-bottom pb-2 mb-3">Quick Actions</h6>
                    <div class="d-grid gap-2">
                        <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="btn btn-sm btn-outline-warning text-dark"><i class="fa fa-edit me-2"></i>Edit Profile</a>
                        <a href="actions/export_student.php?id=<?php echo $student['id']; ?>&type=student" class="btn btn-sm btn-outline-info text-dark" target="_blank"><i class="fa fa-file-pdf me-2"></i>Export PDF</a>
                        <button class="btn btn-sm btn-outline-danger" onclick="if(confirm('Are you sure?')) alert('Feature locked by admin panel settings.');"><i class="fa fa-trash me-2"></i>Archive Student</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Details -->
        <div class="col-lg-9">
            <!-- Navigation Tabs -->
            <ul class="nav nav-pills mb-4 bg-white p-2 rounded shadow-sm border" id="studentTab" role="tablist" style="border-radius: 12px;">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active fw-bold px-4" id="personal-tab" data-bs-toggle="pill" data-bs-target="#personal" type="button" role="tab"><i class="fa fa-user me-2"></i>Personal & Family</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold px-4" id="academic-tab" data-bs-toggle="pill" data-bs-target="#academic" type="button" role="tab"><i class="fa fa-graduation-cap me-2"></i>Academic History</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold px-4" id="health-tab" data-bs-toggle="pill" data-bs-target="#health" type="button" role="tab"><i class="fa fa-heartbeat me-2"></i>Health & Medical</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold px-4 text-dark" id="account-tab" data-bs-toggle="pill" data-bs-target="#account" type="button" role="tab"><i class="fa fa-key me-2"></i>Account & Credentials</button>
                </li>
            </ul>

            <div class="tab-content" id="studentTabContent">
                <!-- Tab 1: Personal & Family -->
                <div class="tab-pane fade show active" id="personal" role="tabpanel">
                    <!-- Personal Info -->
                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom-0">
                            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-id-card text-primary me-2"></i> Personal Information</h5>
                        </div>
                        <div class="card-body p-4 pt-0">
                            <div class="row g-4">
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Gender</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['gender'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Date of Birth</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['dob'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Calculated Age</label>
                                    <p class="mb-0 fw-bold">
                                        <?php 
                                        if (!empty($student['dob'])) {
                                            $dob = new DateTime($student['dob']);
                                            $today = new DateTime();
                                            $age = $today->diff($dob)->y;
                                            echo $age . ' Years';
                                        } else {
                                            echo htmlspecialchars($student['age'] ?: 'N/A') . ' Years';
                                        }
                                        ?>
                                    </p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Blood Group</label>
                                    <p class="mb-0 fw-bold text-danger"><?php echo htmlspecialchars($student['blood_group'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Aadhaar Number</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['aadhaar_number'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Mother Tongue</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['mother_tongue'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Religion</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['religion'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Caste Category</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['caste_category'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-12">
                                    <label class="text-muted small text-uppercase fw-bold">Present Address</label>
                                    <p class="mb-0 fw-bold"><?php echo nl2br(htmlspecialchars($student['present_address'] ?: $student['address'] ?: 'N/A')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Family Info -->
                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom-0">
                            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-users text-primary me-2"></i> Family Details</h5>
                        </div>
                        <div class="card-body p-4 pt-0">
                            <div class="row g-4">
                                <div class="col-md-6 border-end">
                                    <label class="text-muted small text-uppercase fw-bold mb-3 d-block border-bottom pb-1">Father's Information</label>
                                    <div class="mb-3">
                                        <label class="text-muted x-small d-block">Full Name</label>
                                        <span class="fw-bold"><?php echo htmlspecialchars($student['father_name'] ?: $student['parent_name'] ?: 'N/A'); ?></span>
                                    </div>
                                    <div>
                                        <label class="text-muted x-small d-block">Contact Number</label>
                                        <span class="fw-bold"><i class="fa fa-phone-alt text-success me-2"></i><?php echo htmlspecialchars($student['father_mobile'] ?: $student['parent_phone'] ?: 'N/A'); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="text-muted small text-uppercase fw-bold mb-3 d-block border-bottom pb-1">Mother's Information</label>
                                    <div class="mb-3">
                                        <label class="text-muted x-small d-block">Full Name</label>
                                        <span class="fw-bold"><?php echo htmlspecialchars($student['mother_name'] ?: 'N/A'); ?></span>
                                    </div>
                                    <div>
                                        <label class="text-muted x-small d-block">Contact Number</label>
                                        <span class="fw-bold"><i class="fa fa-phone-alt text-success me-2"></i><?php echo htmlspecialchars($student['mother_mobile'] ?: 'N/A'); ?></span>
                                    </div>
                                </div>
                                <div class="col-12 border-top pt-3">
                                    <label class="text-muted small text-uppercase fw-bold mb-3 d-block border-bottom pb-1">Guardian & Address</label>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label class="text-muted x-small d-block">Guardian Name</label>
                                            <span class="fw-bold"><?php echo htmlspecialchars($student['guardian_name'] ?: 'N/A'); ?> (<?php echo htmlspecialchars($student['relation'] ?: 'Self'); ?>)</span>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="text-muted x-small d-block">Guardian Mobile</label>
                                            <span class="fw-bold"><?php echo htmlspecialchars($student['guardian_mobile'] ?: 'N/A'); ?></span>
                                        </div>
                                        <div class="col-12 mt-3">
                                            <label class="text-muted x-small d-block">Home / Permanent Address</label>
                                            <p class="mb-0 fw-bold small"><?php echo nl2br(htmlspecialchars($student['parents_address'] ?: $student['guardian_address'] ?: $student['guardian_details'] ?: 'Same as Present Address')); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 2: Academic History -->
                <div class="tab-pane fade" id="academic" role="tabpanel">
                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom-0">
                            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-university text-primary me-2"></i> Current Admission Details</h5>
                        </div>
                        <div class="card-body p-4 pt-0">
                            <div class="row g-4">
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Admission Date</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['admission_date'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Class Assigned</label>
                                    <p class="mb-0 fw-bold text-primary"><?php echo htmlspecialchars($student['class'] ?: $student['class_applied'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-4">
                                    <label class="text-muted small text-uppercase fw-bold">Schooling Status</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['previous_schooling_status'] ?: 'N/A'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom-0">
                            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-history text-primary me-2"></i> Previous Academic Background</h5>
                        </div>
                        <div class="card-body p-4 pt-0">
                            <div class="row g-4">
                                <div class="col-md-6">
                                    <label class="text-muted small text-uppercase fw-bold">Previous School Name</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['previous_school_name'] ?: $student['previous_school'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-3">
                                    <label class="text-muted small text-uppercase fw-bold">Last Class</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['previous_class'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-3">
                                    <label class="text-muted small text-uppercase fw-bold">Year of Passing</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['year_of_passing'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <label class="text-muted small text-uppercase fw-bold">Previous Board / University</label>
                                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($student['previous_board'] ?: 'N/A'); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <label class="text-muted small text-uppercase fw-bold">Application ID</label>
                                    <p class="mb-0 fw-bold small text-muted"><?php echo htmlspecialchars($student['application_id'] ?: 'Internal Registration'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 3: Health & Medical -->
                <div class="tab-pane fade" id="health" role="tabpanel">
                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-white py-3 border-bottom-0">
                            <h5 class="fw-bold mb-0 text-dark"><i class="fa fa-heartbeat text-danger me-2"></i> Medical Information</h5>
                        </div>
                        <div class="card-body p-4 pt-0">
                            <div class="row g-4">
                                <div class="col-md-12">
                                    <div class="p-3 rounded mb-3 <?php echo ($student['has_medical_condition']) ? 'bg-danger bg-opacity-10 border border-danger border-opacity-25' : 'bg-light border'; ?>">
                                        <label class="text-muted small text-uppercase fw-bold d-block mb-1">Medical Condition</label>
                                        <?php if ($student['has_medical_condition']): ?>
                                            <p class="mb-0 text-danger fw-bold"><i class="fa fa-exclamation-triangle me-2"></i><?php echo nl2br(htmlspecialchars($student['medical_condition_desc'])); ?></p>
                                        <?php else: ?>
                                            <p class="mb-0 text-muted italic">No medical conditions reported.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="p-3 rounded mb-3 <?php echo ($student['has_disability']) ? 'bg-danger bg-opacity-10 border border-danger border-opacity-25' : 'bg-light border'; ?>">
                                        <label class="text-muted small text-uppercase fw-bold d-block mb-1">Physical Disability</label>
                                        <?php if ($student['has_disability']): ?>
                                            <p class="mb-0 text-danger fw-bold"><i class="fa fa-wheelchair me-2"></i><?php echo nl2br(htmlspecialchars($student['disability_desc'])); ?></p>
                                        <?php else: ?>
                                            <p class="mb-0 text-muted italic">No disabilities reported.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="p-3 rounded <?php echo ($student['has_allergies']) ? 'bg-danger bg-opacity-10 border border-danger border-opacity-25' : 'bg-light border'; ?>">
                                        <label class="text-muted small text-uppercase fw-bold d-block mb-1">Known Allergies</label>
                                        <?php if ($student['has_allergies']): ?>
                                            <p class="mb-0 text-danger fw-bold"><i class="fa fa-virus me-2"></i><?php echo nl2br(htmlspecialchars($student['allergies_desc'])); ?></p>
                                        <?php else: ?>
                                            <p class="mb-0 text-muted italic">No allergies reported.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab 4: Account & Credentials -->
                <div class="tab-pane fade" id="account" role="tabpanel">
                    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
                        <div class="card-header bg-dark text-white py-3 border-bottom-0" style="border-radius:12px 12px 0 0;">
                            <h5 class="fw-bold mb-0"><i class="fa fa-user-lock me-2"></i> Portal Access Credentials</h5>
                        </div>
                        <div class="card-body p-4">
                            <div class="row g-4 align-items-center">
                                <div class="col-md-6">
                                    <div class="p-3 bg-light rounded border">
                                        <label class="text-muted small text-uppercase fw-bold d-block mb-1">Login Username</label>
                                        <h4 class="fw-bold text-primary mb-0"><?php echo htmlspecialchars($student['username'] ?: 'NOT GENERATED'); ?></h4>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="p-3 bg-light rounded border">
                                        <label class="text-muted small text-uppercase fw-bold d-block mb-1">Registered Email</label>
                                        <h4 class="fw-bold text-primary mb-0"><?php echo htmlspecialchars($student['email'] ?: 'NOT GENERATED'); ?></h4>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="p-3 bg-light rounded border">
                                        <label class="text-muted small text-uppercase fw-bold d-block mb-1">Login Password</label>
                                        <div class="d-flex align-items-center">
                                            <h4 class="fw-bold text-muted mb-0 me-3">••••••••••••</h4>
                                            <span class="badge bg-secondary">Encrypted</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="alert alert-info mb-0 py-2 border-0 shadow-sm" style="font-size:0.9em;">
                                        <i class="fa fa-info-circle me-2"></i> To reset the password, click the <strong>Edit Profile</strong> button above and enter a new password in the Account Settings section.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

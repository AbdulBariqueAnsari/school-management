<?php
$module_key = 'tests';
$module_title = 'Class Tests';
$module_icon = 'fa-file-circle-check';
require_once __DIR__ . '/includes/class_module.php';
?>

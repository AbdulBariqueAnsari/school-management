<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';

// Super Admin Check
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

if (!isset($_GET['class']) || empty($_GET['class'])) {
    $_SESSION['error'] = "Invalid class selected.";
    redirect('class_teachers.php');
}

$class_name = $_GET['class'];
$page_title = "Class Students";
$icon = "fa-users";

$stmt = $pdo->prepare("SELECT * FROM students WHERE class_applied=? AND status='Approved' ORDER BY student_name ASC");
$stmt->execute([$class_name]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>
<?php include 'includes/student_page_styles.php'; ?>

<div class="container-fluid py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <h2 class="fw-bold mb-0"><i class="fa <?php echo $icon; ?> text-primary me-2"></i> <?php echo htmlspecialchars($class_name); ?> - <?php echo $page_title; ?></h2>
        
        <div class="d-flex flex-column flex-sm-row gap-2 align-items-sm-center">
            <!-- Search Box -->
            <div class="input-group input-group-sm rounded-pill overflow-hidden shadow-sm" style="border: 1px solid #dee2e6; max-width: 250px;">
                <span class="input-group-text bg-white border-0 text-muted ps-3"><i class="fa fa-search"></i></span>
                <input type="text" id="studentSearchInput" class="form-control border-0 shadow-none px-2" placeholder="Search name or ID..." onkeyup="filterStudents()" aria-label="Search">
            </div>
            
            <!-- Section Dropdown -->
            <select id="sectionFilter" class="form-select form-select-sm rounded-pill shadow-sm" style="border: 1px solid #dee2e6; max-width: 140px; cursor: pointer;" onchange="filterStudents()">
                <option value="">All Sections</option>
                <option value="A">Section A</option>
                <option value="B">Section B</option>
                <option value="C">Section C</option>
                <option value="D">Section D</option>
            </select>

            <a href="class_view.php?class=<?php echo urlencode($class_name); ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3 shadow-sm text-nowrap mt-2 mt-sm-0">
                <i class="fa fa-arrow-left me-1"></i> Back
            </a>
        </div>
    </div>

    <?php if (empty($students)): ?>
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body py-5 text-center text-muted">
                <i class="fa <?php echo $icon; ?> fa-4x mb-3 text-light"></i>
                <h4>No Students Found</h4>
                <p>There are currently no approved students enrolled in <?php echo htmlspecialchars($class_name); ?>.</p>
            </div>
        </div>
    <?php else: ?>
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 bg-white sp-table">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Admission No</th>
                        <th>Student Name</th>
                        <th>Parent Name</th>
                        <th>Class</th>
                        <th>Admission Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $i => $s): 
                            $sec = (isset($s['section']) && !empty($s['section'])) ? htmlspecialchars($s['section']) : 'A';
                    ?>
                    <tr class="sp-row" data-id="<?php echo $s['id']; ?>" data-section="<?php echo $sec; ?>">
                        <td><span class="text-muted small"><?php echo $i + 1; ?></span></td>
                        <td><strong class="text-primary"><?php echo htmlspecialchars($s['admission_no'] ?? 'N/A'); ?></strong></td>
                        <td><strong><?php echo htmlspecialchars($s['student_name']); ?></strong></td>
                        <td><small><?php echo htmlspecialchars($s['parent_name'] ?? $s['father_name'] ?? 'N/A'); ?></small></td>
                        <td><small class="fw-semibold"><?php echo htmlspecialchars($s['class_applied'] ?? 'N/A'); ?></small></td>
                        <td><small><?php echo $s['admission_date'] ? date('d M Y', strtotime($s['admission_date'])) : 'N/A'; ?></small></td>
                        <td><span class="badge bg-success">Approved</span></td>
                    </tr>
                    <tr class="sp-action-row" id="sp-panel-<?php echo $s['id']; ?>" style="display:none;">
                        <td colspan="7">
                            <div class="sp-action-panel">
                                <a href="student_profile.php?id=<?php echo $s['id']; ?>&type=stu" class="sp-btn sp-btn-view"><i class="fa fa-eye"></i> View</a>
                                <a href="edit_student.php?id=<?php echo $s['id']; ?>&type=stu" class="sp-btn sp-btn-edit"><i class="fa fa-edit"></i> Edit</a>
                                <a href="actions/export_student.php?id=<?php echo $s['id']; ?>&type=student" class="sp-btn sp-btn-pdf" target="_blank"><i class="fa fa-file-pdf"></i> Export PDF</a>
                                <a href="student_dashboard.php?id=<?php echo $s['id']; ?>" class="sp-btn" style="color: #64748b !important;"><i class="fa fa-gauge" style="color: #64748b;"></i> Dashboard</a>
                                <button class="sp-btn sp-btn-reject sp-confirm"
                                    data-url="actions/reject_student.php?id=<?php echo $s['id']; ?>&type=stu"
                                    data-title="Reject Student?" data-text="Move this student to rejected?" data-icon="warning" data-confirm="Yes, Reject">
                                    <i class="fa fa-times"></i> Reject
                                </button>
                                <button class="sp-btn sp-btn-delete sp-confirm"
                                    data-url="actions/delete_student.php?id=<?php echo $s['id']; ?>&type=stu"
                                    data-title="Delete Record?" data-text="Move this student to deleted records?" data-icon="warning" data-confirm="Yes, Delete">
                                    <i class="fa fa-trash"></i> Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
function filterStudents() {
    const searchInput = document.getElementById('studentSearchInput').value.toLowerCase();
    const sectionVal = document.getElementById('sectionFilter').value;
    const rows = document.querySelectorAll('.table tbody tr.sp-row');

    rows.forEach(row => {
        const actionRow = document.getElementById('sp-panel-' + row.getAttribute('data-id'));
        
        // Extract data for filtering
        const admissionNo = row.cells[1].textContent.toLowerCase();
        const studentName = row.cells[2].textContent.toLowerCase();
        const rowSection = row.getAttribute('data-section') || '';

        // Match Logic
        const matchesSearch = studentName.includes(searchInput) || admissionNo.includes(searchInput);
        const matchesSection = (sectionVal === '' || rowSection === sectionVal);

        if (matchesSearch && matchesSection) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
            row.classList.remove('active-row');
            if (actionRow) {
                actionRow.style.display = 'none';
            }
        }
    });
}
</script>

<?php include 'includes/student_page_scripts.php'; ?>
<?php require_once '../includes/footer.php'; ?>

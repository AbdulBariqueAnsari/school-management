<?php
require_once __DIR__ . '/../includes/init.php';
$stmt = $pdo->query("DESCRIBE students");
$columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
echo "STUDENTS: " . implode(', ', $columns) . "\n";

$stmt2 = $pdo->query("SHOW TABLES");
$tables = $stmt2->fetchAll(PDO::FETCH_COLUMN);
echo "TABLES: " . implode(', ', $tables) . "\n";

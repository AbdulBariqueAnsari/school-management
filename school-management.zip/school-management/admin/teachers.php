<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

// Count teachers by status/role
$counts = [];

$stmt = $pdo->query("SELECT COUNT(*) FROM teachers WHERE role = 'class_teacher' AND status = 'Approved'");
$counts['class'] = (int)$stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM teachers WHERE status = 'Approved'");
$counts['approved'] = (int)$stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM teachers WHERE status = 'Pending'");
$counts['pending'] = (int)$stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM teachers WHERE status = 'Rejected'");
$counts['rejected'] = (int)$stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM teachers WHERE status = 'Approved'");
$counts['subject'] = (int)$stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM teachers WHERE status = 'Deleted'");
$counts['deleted'] = (int)$stmt->fetchColumn();

require_once '../includes/header.php';
?>

<style>
/* ============================================================
   TEACHER MANAGEMENT — GLASSMORPHISM CARD GRID
   ============================================================ */

.teacher-hub-header {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    border-radius: 20px;
    padding: 30px 36px;
    margin-bottom: 32px;
    position: relative;
    overflow: hidden;
}

.teacher-hub-header::before {
    content: '';
    position: absolute;
    top: -60px; right: -60px;
    width: 200px; height: 200px;
    background: rgba(255,255,255,0.05);
    border-radius: 50%;
}

.teacher-hub-header::after {
    content: '';
    position: absolute;
    bottom: -80px; left: 40px;
    width: 160px; height: 160px;
    background: rgba(255,255,255,0.03);
    border-radius: 50%;
}

.teacher-hub-header h2 {
    color: #fff;
    font-weight: 800;
    font-size: 1.8rem;
    margin: 0;
    position: relative;
    z-index: 1;
}

.teacher-hub-header p {
    color: rgba(255,255,255,0.6);
    margin: 4px 0 0;
    font-size: 0.95rem;
    position: relative;
    z-index: 1;
}

/* ---- Action Buttons ---- */
.hub-btn {
    background: rgba(255,255,255,0.12);
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255,255,255,0.2);
    color: #fff !important;
    border-radius: 10px;
    padding: 9px 18px;
    font-weight: 600;
    font-size: 0.88rem;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 7px;
    transition: all 0.25s ease;
}
.hub-btn:hover {
    background: rgba(255,255,255,0.22);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.25);
}

/* ---- Card Grid ---- */
.erp-card-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
}

@media (max-width: 992px) {
    .erp-card-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 576px) {
    .erp-card-grid { grid-template-columns: 1fr; }
}

/* ---- Single ERP Card ---- */
.erp-card-link {
    text-decoration: none;
    display: block;
}

.erp-card {
    background: rgba(255,255,255,0.13);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border: 1px solid rgba(255,255,255,0.22);
    border-radius: 20px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.13);
    padding: 32px 24px;
    text-align: center;
    position: relative;
    overflow: hidden;
    cursor: pointer;
    transition: transform 0.35s cubic-bezier(0.34,1.56,0.64,1),
                box-shadow 0.35s ease,
                background 0.25s ease;
    /* Animation start state */
    opacity: 0;
    transform: translateY(15px);
}

.erp-card.animated {
    opacity: 1;
    transform: translateY(0);
}

.erp-card:hover {
    transform: translateY(-8px) scale(1.025);
    box-shadow: 0 20px 50px rgba(0,0,0,0.2);
    background: rgba(255,255,255,0.2);
    border-color: rgba(255,255,255,0.35);
}

/* Card background gradient orbs */
.erp-card::before {
    content: '';
    position: absolute;
    top: -40px; right: -40px;
    width: 120px; height: 120px;
    border-radius: 50%;
    opacity: 0.15;
    transition: opacity 0.3s;
}
.erp-card:hover::before { opacity: 0.25; }

/* Per-card colour themes */
.erp-card--blue   { background: linear-gradient(135deg, rgba(13,110,253,0.18), rgba(255,255,255,0.08)); }
.erp-card--blue::before   { background: #0d6efd; }

.erp-card--green  { background: linear-gradient(135deg, rgba(25,135,84,0.18), rgba(255,255,255,0.08)); }
.erp-card--green::before  { background: #198754; }

.erp-card--yellow { background: linear-gradient(135deg, rgba(255,193,7,0.22), rgba(255,255,255,0.08)); }
.erp-card--yellow::before { background: #ffc107; }

.erp-card--red    { background: linear-gradient(135deg, rgba(220,53,69,0.18), rgba(255,255,255,0.08)); }
.erp-card--red::before    { background: #dc3545; }

.erp-card--purple { background: linear-gradient(135deg, rgba(111,66,193,0.18), rgba(255,255,255,0.08)); }
.erp-card--purple::before { background: #6f42c1; }

.erp-card--grey   { background: linear-gradient(135deg, rgba(108,117,125,0.18), rgba(255,255,255,0.08)); }
.erp-card--grey::before   { background: #6c757d; }

/* Card Icon */
.erp-card-icon {
    width: 72px;
    height: 72px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 18px;
    font-size: 1.8rem;
    position: relative;
    z-index: 1;
}

.erp-card-icon--blue   { background: linear-gradient(135deg, #0d6efd, #6610f2); color: #fff; }
.erp-card-icon--green  { background: linear-gradient(135deg, #198754, #20c997); color: #fff; }
.erp-card-icon--yellow { background: linear-gradient(135deg, #fd7e14, #ffc107); color: #fff; }
.erp-card-icon--red    { background: linear-gradient(135deg, #dc3545, #e83e8c); color: #fff; }
.erp-card-icon--purple { background: linear-gradient(135deg, #6f42c1, #6610f2); color: #fff; }
.erp-card-icon--grey   { background: linear-gradient(135deg, #495057, #6c757d); color: #fff; }

/* Card Text */
.erp-card-title {
    font-size: 1.05rem;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 4px;
    position: relative;
    z-index: 1;
}

.erp-card-sub {
    font-size: 0.82rem;
    color: #666;
    margin-bottom: 16px;
    position: relative;
    z-index: 1;
}

/* Count Badge */
.erp-card-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    font-weight: 800;
    line-height: 1;
    position: relative;
    z-index: 1;
}

.erp-card-count--blue   { color: #0d6efd; }
.erp-card-count--green  { color: #198754; }
.erp-card-count--yellow { color: #fd7e14; }
.erp-card-count--red    { color: #dc3545; }
.erp-card-count--purple { color: #6f42c1; }
.erp-card-count--grey   { color: #6c757d; }

/* Arrow indicator */
.erp-card-arrow {
    position: absolute;
    bottom: 18px;
    right: 20px;
    font-size: 0.9rem;
    color: rgba(0,0,0,0.25);
    transition: transform 0.25s ease, color 0.25s ease;
    z-index: 1;
}
.erp-card:hover .erp-card-arrow {
    transform: translateX(4px);
    color: rgba(0,0,0,0.5);
}

/* Sidebar overrides */
.sidebar, #sidebar {
    background: #212529 !important;
    border-right: 1px solid rgba(255,255,255,0.1);
}
.sidebar .nav-link, #sidebar .nav-link { color: rgba(255,255,255,0.7) !important; }
.sidebar .nav-link:hover, #sidebar .nav-link:hover { color: #fff !important; background: rgba(255,255,255,0.1); }
.sidebar .nav-link.active, #sidebar .nav-link.active { color: #fff !important; background: #0d6efd !important; }
</style>

<div class="container-fluid py-4">

    <!-- ===== HEADER ===== -->
    <div class="teacher-hub-header d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h2><i class="fa fa-chalkboard-user me-2"></i> Teacher Management</h2>
            <p>Overview of all teacher categories — click a card to manage</p>
        </div>
        <div class="d-flex gap-2 flex-wrap" style="position:relative;z-index:1;">
            <a href="../teacher/register_teacher.php" class="hub-btn">
                <i class="fa fa-user-plus"></i> Add Teacher
            </a>
            <a href="index.php" class="hub-btn">
                <i class="fa fa-arrow-left"></i> Dashboard
            </a>
        </div>
    </div>

    <!-- ===== CARD GRID ===== -->
    <div class="erp-card-grid">

        <!-- 1. Class Teachers -->
        <a href="class_teacher.php" class="erp-card-link">
            <div class="erp-card erp-card--blue" data-delay="0">
                <div class="erp-card-icon erp-card-icon--blue">
                    <i class="fa fa-chalkboard"></i>
                </div>
                <div class="erp-card-title">Class Teachers</div>
                <div class="erp-card-sub">Assigned class-in-charge</div>
                <div class="erp-card-count erp-card-count--blue"><?php echo $counts['class']; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 2. Approved Teachers -->
        <a href="approved_teacher.php" class="erp-card-link">
            <div class="erp-card erp-card--green" data-delay="100">
                <div class="erp-card-icon erp-card-icon--green">
                    <i class="fa fa-user-check"></i>
                </div>
                <div class="erp-card-title">Approved Teachers</div>
                <div class="erp-card-sub">Active staff members</div>
                <div class="erp-card-count erp-card-count--green"><?php echo $counts['approved']; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 3. Pending Applications -->
        <a href="pending_apps.php" class="erp-card-link">
            <div class="erp-card erp-card--yellow" data-delay="200">
                <div class="erp-card-icon erp-card-icon--yellow">
                    <i class="fa fa-clock"></i>
                </div>
                <div class="erp-card-title">Pending Applications</div>
                <div class="erp-card-sub">Awaiting admin review</div>
                <div class="erp-card-count erp-card-count--yellow"><?php echo $counts['pending']; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 4. Rejected Teachers -->
        <a href="rejected_teachers.php" class="erp-card-link">
            <div class="erp-card erp-card--red" data-delay="300">
                <div class="erp-card-icon erp-card-icon--red">
                    <i class="fa fa-user-xmark"></i>
                </div>
                <div class="erp-card-title">Rejected Teachers</div>
                <div class="erp-card-sub">Declined applications</div>
                <div class="erp-card-count erp-card-count--red"><?php echo $counts['rejected']; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 5. Subject Teachers -->
        <a href="subject_teacher.php" class="erp-card-link">
            <div class="erp-card erp-card--purple" data-delay="400">
                <div class="erp-card-icon erp-card-icon--purple">
                    <i class="fa fa-layer-group"></i>
                </div>
                <div class="erp-card-title">Subject Teachers</div>
                <div class="erp-card-sub">Grouped by class assignment</div>
                <div class="erp-card-count erp-card-count--purple"><?php echo $counts['subject']; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 6. Deleted Records -->
        <a href="deleted_teacher.php" class="erp-card-link">
            <div class="erp-card erp-card--grey" data-delay="500">
                <div class="erp-card-icon erp-card-icon--grey">
                    <i class="fa fa-trash-can"></i>
                </div>
                <div class="erp-card-title">Deleted Teachers</div>
                <div class="erp-card-sub">Soft-deleted records</div>
                <div class="erp-card-count erp-card-count--grey"><?php echo $counts['deleted']; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

    </div><!-- /.erp-card-grid -->

</div>

<script>
// Staggered fade-in animation
document.addEventListener('DOMContentLoaded', function () {
    const cards = document.querySelectorAll('.erp-card');
    cards.forEach(function (card) {
        const delay = parseInt(card.getAttribute('data-delay')) || 0;
        setTimeout(function () {
            card.style.transition = 'opacity 0.45s ease, transform 0.45s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.35s ease, background 0.25s ease';
            card.classList.add('animated');
        }, delay);
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>

<?php
require_once '../includes/auth.php';
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$stmt = $pdo->query("SELECT * FROM teachers WHERE status = 'Deleted' ORDER BY created_at DESC");
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>
<?php include 'includes/teacher_page_styles.php'; ?>

<div class="container-fluid py-4">
    <div class="tp-header tp-header--grey">
        <div>
            <h2><i class="fa fa-trash-can me-2"></i> Deleted Teachers</h2>
            <p>Soft-deleted records — <strong><?php echo count($teachers); ?></strong> records</p>
        </div>
        <div>
            <a href="teachers.php" class="tp-back-btn"><i class="fa fa-arrow-left me-1"></i> Back</a>
        </div>
    </div>

    <?php if (empty($teachers)): ?>
        <div class="tp-empty">
            <i class="fa fa-trash-can fa-3x text-secondary mb-3"></i>
            <p class="text-muted">No deleted teacher records found.</p>
        </div>
    <?php
else: ?>
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 bg-white tp-table">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Teacher</th>
                        <th>Subject</th>
                        <th>Designation</th>
                        <th>Class</th>
                        <th>Experience</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($teachers as $i => $t): ?>
                    <tr class="tp-row" data-id="<?php echo $t['id']; ?>">
                        <td><span class="text-muted small"><?php echo $i + 1; ?></span></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <img src="../uploads/profile/<?php echo $t['photo'] ?: 'default-teacher.png'; ?>"
                                     class="rounded-circle border border-2 border-white shadow-sm"
                                     width="42" height="42" style="object-fit:cover;"
                                     onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($t['full_name']); ?>&background=random'">
                                <div>
                                    <span class="fw-bold d-block"><?php echo htmlspecialchars($t['full_name']); ?></span>
                                    <small class="text-muted"><?php echo htmlspecialchars($t['teacher_id']); ?></small>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary-subtle"><?php echo htmlspecialchars($t['assigned_subject']); ?></span></td>
                        <td><small><?php echo htmlspecialchars($t['designation']); ?></small></td>
                        <td><small class="fw-semibold"><?php echo htmlspecialchars($t['assigned_class']); ?></small></td>
                        <td><span class="fw-bold"><?php echo htmlspecialchars($t['experience_years']); ?></span> <small class="text-muted">yrs</small></td>
                        <td><span class="badge bg-secondary">Deleted</span></td>
                    </tr>
                    <!-- Action Panel -->
                    <tr class="tp-action-row" id="panel-<?php echo $t['id']; ?>" style="display:none;">
                        <td colspan="7">
                            <div class="tp-action-panel">
                                <button class="tp-btn tp-btn-restore btn-confirm"
                                        data-url="actions/restore_teacher.php?id=<?php echo $t['id']; ?>"
                                        data-title="Restore Teacher?" data-text="Restore this teacher to Pending status?" data-icon="info" data-confirm="Yes, Restore">
                                    <i class="fa fa-undo"></i> Restore
                                </button>
                                <button class="tp-btn tp-btn-purge btn-confirm"
                                        data-url="actions/delete_teacher_permanent.php?id=<?php echo $t['id']; ?>"
                                        data-title="Delete Permanently?" data-text="WARNING: This will PERMANENTLY delete all records. This cannot be undone!" data-icon="error" data-confirm="Yes, Purge">
                                    <i class="fa fa-fire"></i> Purge Permanently
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
    endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
endif; ?>
</div>

<?php include 'includes/teacher_page_scripts.php'; ?>
<?php require_once '../includes/footer.php'; ?>

<?php
$module_key = 'syllabus';
$module_title = 'Class Syllabus';
$module_icon = 'fa-book-atlas';
require_once __DIR__ . '/includes/class_module.php';
?>

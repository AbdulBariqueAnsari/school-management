<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../dashboard.php");
    exit();
}

// Search and Filter Logic
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$class_filter = isset($_GET['class']) ? trim($_GET['class']) : '';
$section_filter = isset($_GET['section']) ? trim($_GET['section']) : '';
$teacher_filter = isset($_GET['teacher']) ? trim($_GET['teacher']) : '';

$query = "SELECT s.*, t.full_name as class_teacher_name 
          FROM students s 
          LEFT JOIN teachers t ON (FIND_IN_SET(s.class_applied, t.class_teacher_of) AND t.role = 'class_teacher' AND t.status = 'Approved')
          WHERE s.status='Approved'";
$params = [];

if ($search !== '') {
    $query .= " AND (s.student_name LIKE ? OR s.admission_no LIKE ? OR s.username LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($class_filter !== '') {
    $query .= " AND s.class_applied = ?";
    $params[] = $class_filter;
}

if ($section_filter !== '') {
    $query .= " AND s.section_id = ?";
    $params[] = $section_filter;
}

if ($teacher_filter !== '') {
    $query .= " AND t.id = ?";
    $params[] = $teacher_filter;
}

$query .= " ORDER BY s.student_name ASC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch filter options
$classes = $pdo->query("SELECT DISTINCT class_applied FROM students WHERE status = 'Approved' AND class_applied IS NOT NULL AND class_applied != '' ORDER BY class_applied ASC")->fetchAll(PDO::FETCH_COLUMN);
$sections = $pdo->query("SELECT DISTINCT section_id FROM students WHERE status = 'Approved' AND section_id IS NOT NULL AND section_id != '' ORDER BY section_id ASC")->fetchAll(PDO::FETCH_COLUMN);
$class_teachers = $pdo->query("SELECT id, full_name, class_teacher_of FROM teachers WHERE role = 'class_teacher' AND status = 'Approved' ORDER BY full_name ASC")->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>
<?php include 'includes/student_page_styles.php'; ?>

<div class="container-fluid py-4">
    <div class="sp-header sp-header--green">
        <div>
            <h2><i class="fa fa-user-graduate me-2"></i> Approved Students</h2>
            <p>Currently enrolled students — <strong><?php echo count($students); ?></strong> records <?php echo ($search || $class_filter || $section_filter || $teacher_filter) ? '(filtered)' : ''; ?></p>
        </div>
        <a href="admissions.php" class="sp-back-btn"><i class="fa fa-arrow-left me-1"></i> Back</a>
    </div>

    <!-- Multi-Filter Bar -->
    <div class="card shadow-sm border-0 mb-4" style="border-radius: 12px;">
        <div class="card-body p-3">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="small fw-bold text-muted mb-1">Search Student</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-white border-end-0"><i class="fa fa-search text-muted"></i></span>
                        <input type="text" name="search" class="form-control border-start-0" placeholder="Name, Adm No, Username..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                </div>
                <div class="col-md-2">
                    <label class="small fw-bold text-muted mb-1">Class</label>
                    <select name="class" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?php echo htmlspecialchars($c); ?>" <?php echo ($class_filter === $c) ? 'selected' : ''; ?>><?php echo htmlspecialchars($c); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="small fw-bold text-muted mb-1">Section</label>
                    <select name="section" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">All Sections</option>
                        <?php foreach ($sections as $s_id): ?>
                            <option value="<?php echo htmlspecialchars($s_id); ?>" <?php echo ($section_filter === $s_id) ? 'selected' : ''; ?>>Section <?php echo htmlspecialchars($s_id); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="small fw-bold text-muted mb-1">Class Teacher</label>
                    <select name="teacher" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">All Teachers</option>
                        <?php foreach ($class_teachers as $ct): ?>
                            <option value="<?php echo $ct['id']; ?>" <?php echo ($teacher_filter == $ct['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($ct['full_name']); ?> (<?php echo htmlspecialchars($ct['class_teacher_of']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-sm btn-primary w-100">Apply</button>
                    <?php if ($search || $class_filter || $section_filter || $teacher_filter): ?>
                        <a href="approved_students.php" class="btn btn-sm btn-outline-secondary" title="Clear All"><i class="fa fa-refresh"></i></a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <?php if (empty($students)): ?>
        <div class="sp-empty"><i class="fa fa-user-graduate fa-3x text-success mb-3"></i><p class="text-muted">No approved students found.</p></div>
    <?php
else: ?>
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 bg-white sp-table">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Admission No</th>
                        <th>Student Name</th>
                        <th>Parent Name</th>
                        <th>Class</th>
                        <th>Admission Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $i => $s): ?>
                    <tr class="sp-row" data-id="<?php echo $s['id']; ?>">
                        <td><span class="text-muted small"><?php echo $i + 1; ?></span></td>
                        <td><strong class="text-primary"><?php echo htmlspecialchars($s['admission_no'] ?? 'N/A'); ?></strong></td>
                        <td><strong><?php echo htmlspecialchars($s['student_name']); ?></strong></td>
                        <td><small><?php echo htmlspecialchars($s['parent_name'] ?? $s['father_name'] ?? 'N/A'); ?></small></td>
                        <td><small class="fw-semibold"><?php echo htmlspecialchars($s['class_applied'] ?? 'N/A'); ?></small></td>
                        <td><small><?php echo $s['admission_date'] ? date('d M Y', strtotime($s['admission_date'])) : 'N/A'; ?></small></td>
                        <td><span class="badge bg-success">Approved</span></td>
                    </tr>
                    <tr class="sp-action-row" id="sp-panel-<?php echo $s['id']; ?>" style="display:none;">
                        <td colspan="7">
                            <div class="sp-action-panel">
                                <a href="student_profile.php?id=<?php echo $s['id']; ?>&type=stu" class="sp-btn sp-btn-view"><i class="fa fa-eye"></i> View</a>
                                <a href="edit_student.php?id=<?php echo $s['id']; ?>&type=stu" class="sp-btn sp-btn-edit"><i class="fa fa-edit"></i> Edit</a>
                                <a href="actions/export_student.php?id=<?php echo $s['id']; ?>&type=student" class="sp-btn sp-btn-pdf" target="_blank"><i class="fa fa-file-pdf"></i> Export PDF</a>
                                <button class="sp-btn sp-btn-reject sp-confirm"
                                    data-url="actions/reject_student.php?id=<?php echo $s['id']; ?>&type=stu"
                                    data-title="Reject Student?" data-text="Move this approved student to rejected?" data-icon="warning" data-confirm="Yes, Reject">
                                    <i class="fa fa-times"></i> Reject
                                </button>
                                <button class="sp-btn sp-btn-delete sp-confirm"
                                    data-url="actions/delete_student.php?id=<?php echo $s['id']; ?>&type=stu"
                                    data-title="Delete Record?" data-text="Move this student to deleted records?" data-icon="warning" data-confirm="Yes, Delete">
                                    <i class="fa fa-trash"></i> Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
    endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
endif; ?>
</div>

<?php include 'includes/student_page_scripts.php'; ?>
<?php require_once '../includes/footer.php'; ?>



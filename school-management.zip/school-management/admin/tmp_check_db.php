<?php
require_once 'c:/xampp/htdocs/school-management/config/database_init.php';
$stmt = $pdo->query("SHOW COLUMNS FROM students");
$cols = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($cols as $col) {
    if (strpos(strtolower($col['Field']), 'section') !== false) {
        echo "Found: " . $col['Field'] . "\n";
    }
}
echo "Done checking columns.";
?>

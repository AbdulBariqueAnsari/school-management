<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    die("Unauthorized access.");
}

$type = isset($_GET['type']) ? $_GET['type'] : 'pdf';
$appointments_file = '../data/appointments.json';

$appointments = [];
if (file_exists($appointments_file)) {
    $appointments = json_decode(file_get_contents($appointments_file), true);
    if (!is_array($appointments)) $appointments = [];
}
// Show latest first
$appointments = array_reverse($appointments);

// Fetch branding
$settings_query = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings");
$settings = $settings_query->fetchAll(PDO::FETCH_KEY_PAIR);

// EXCEL (CSV) OUTPUT
if ($type === 'excel') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=appointments_export_' . date('Ymd_His') . '.csv');
    $output = fopen('php://output', 'w');
    
    // Header
    fputcsv($output, ['Application Date', 'Date', 'Time', 'Visitor Name', 'Student Name', 'Contact', 'Status', 'Meeting With', 'Purpose']);
    
    foreach ($appointments as $apt) {
        fputcsv($output, [
            $apt['created_at'] ?? '',
            $apt['date'] ?? '',
            $apt['time'] ?? '',
            $apt['visitor_name'] ?? '',
            $apt['student_name'] ?? '',
            $apt['contact'] ?? '',
            $apt['status'] ?? 'New',
            $apt['meeting_with'] ?? '',
            $apt['purpose'] ?? ''
        ]);
    }
    fclose($output);
    exit();
}

// PDF FORMAT USING FPDF
if ($type === 'pdf') {
    require_once '../includes/fpdf/fpdf.php';

    class PDF extends FPDF
    {
        public $settings, $report_title;

        function Header()
        {
            $school_logo = $this->settings['school_logo'] ?? '';
            $school_name = $this->settings['school_name'] ?? 'School Management System';
            $school_tagline = $this->settings['school_tagline'] ?? '';
            $school_code = $this->settings['school_code'] ?? '';
            $school_board = $this->settings['school_board'] ?? '';
            $school_registration_number = $this->settings['school_registration_number'] ?? '';
            $school_phone = $this->settings['school_phone'] ?? '';
            $school_email = $this->settings['school_email'] ?? '';
            $school_website = $this->settings['school_website'] ?? '';
            $school_address = $this->settings['school_address'] ?? '';

            if (!empty($school_logo)) {
                $logo_path1 = __DIR__ . '/../uploads/branding/' . $school_logo;
                $logo_path2 = __DIR__ . '/../uploads/logos/' . $school_logo;
                $logo_path3 = __DIR__ . '/../assets/images/' . $school_logo;

                if (file_exists($logo_path1)) {
                    $this->Image($logo_path1, 10, 6, 20);
                }
                elseif (file_exists($logo_path2)) {
                    $this->Image($logo_path2, 10, 6, 20);
                }
                elseif (file_exists($logo_path3)) {
                    $this->Image($logo_path3, 10, 6, 20);
                }
            }
            else {
                $logo = __DIR__ . '/../assets/images/logo.png';
                if (file_exists($logo)) {
                    $this->Image($logo, 10, 6, 20);
                }
            }
            $this->SetX(35);
            $this->SetFont('Arial', 'B', 16);
            $this->SetTextColor(13, 110, 253);
            $this->Cell(0, 8, $school_name, 0, 1, 'L');

            if (!empty($school_tagline)) {
                $this->SetX(35);
                $this->SetFont('Arial', 'I', 10);
                $this->SetTextColor(100, 100, 100);
                $this->Cell(0, 5, $school_tagline, 0, 1, 'L');
            }
            $code_info = [];
            if (!empty($school_code))
                $code_info[] = "Code: " . $school_code;
            if (!empty($school_board))
                $code_info[] = "Board: " . $school_board;
            if (!empty($school_registration_number))
                $code_info[] = "Reg No: " . $school_registration_number;
            if (!empty($code_info)) {
                $this->SetX(35);
                $this->SetFont('Arial', '', 9);
                $this->SetTextColor(50, 50, 50);
                $this->Cell(0, 5, implode(' | ', $code_info), 0, 1, 'L');
            }
            $contact_info = [];
            if (!empty($school_phone))
                $contact_info[] = "Phone: " . $school_phone;
            if (!empty($school_email))
                $contact_info[] = "Email: " . $school_email;
            if (!empty($school_website))
                $contact_info[] = "Website: " . $school_website;
            if (!empty($contact_info)) {
                $this->SetX(35);
                $this->SetFont('Arial', '', 9);
                $this->SetTextColor(80, 80, 80);
                $this->Cell(0, 5, implode(' | ', $contact_info), 0, 1, 'L');
            }
            if (!empty($school_address)) {
                $this->SetX(35);
                $this->SetFont('Arial', '', 9);
                $this->Cell(0, 5, $school_address, 0, 1, 'L');
            }
            $this->SetDrawColor(13, 110, 253);
            $this->SetLineWidth(0.8);
            $this->Line(10, $this->GetY() + 3, 200, $this->GetY() + 3);
            $this->Ln(8);

            $this->SetFillColor(200, 200, 200);
            $this->SetFont('Arial', 'B', 12);
            $this->SetTextColor(33, 37, 41);
            $this->Cell(0, 8, strtoupper($this->report_title), 0, 1, 'C', true);
            $this->Ln(5);

            // Table Header
            $this->SetFont('Arial', 'B', 9);
            $this->SetFillColor(230, 230, 230);
            $this->Cell(25, 7, 'Meeting', 1, 0, 'C', true);
            $this->Cell(35, 7, 'Visitor Name', 1, 0, 'C', true);
            $this->Cell(35, 7, 'Student Name', 1, 0, 'C', true);
            $this->Cell(30, 7, 'Meeting With', 1, 0, 'C', true);
            $this->Cell(25, 7, 'Contact', 1, 0, 'C', true);
            $this->Cell(28, 7, 'Purpose', 1, 0, 'C', true);
            $this->Cell(12, 7, 'Status', 1, 1, 'C', true);
        }

        function Footer()
        {
            $this->SetY(-22);
            $this->SetFont('Arial', 'B', 8);
            $this->SetFillColor(255, 215, 0); // Gold
            $this->SetTextColor(0, 0, 0);

            $text = 'Designed and maintained by WebNoor';
            $w = $this->GetStringWidth($text) + 10;
            $this->SetX((210 - $w) / 2);
            $this->Cell($w, 6, $text, 0, 1, 'C', true, 'https://webnoor.in');

            $this->SetY(-13);
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, 'Page ' . $this->PageNo() . ' / {nb} | Generated on ' . date('d M Y H:i'), 0, 0, 'C');
        }
    }

    $pdf = new PDF('P', 'mm', 'A4');
    $pdf->settings = $settings;
    $pdf->report_title = "Appointments Report";

    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Arial', '', 9);

    if (empty($appointments)) {
        $pdf->Cell(0, 10, 'No appointments found.', 1, 1, 'C');
    } else {
        foreach ($appointments as $apt) {
            $meet_date = substr(($apt['date'] ?? ''), 0, 10);
            $visitor = substr($apt['visitor_name'] ?? 'N/A', 0, 20);
            $student = substr($apt['student_name'] ?? 'N/A', 0, 20);
            $meet_with = substr($apt['meeting_with'] ?? '-', 0, 17);
            $contact = substr($apt['contact'] ?? '-', 0, 12);
            $purpose = substr($apt['purpose'] ?? '-', 0, 15);
            $status = substr($apt['status'] ?? 'New', 0, 3); // N, P, A

            $pdf->Cell(25, 6, $meet_date, 1, 0, 'C');
            $pdf->Cell(35, 6, $visitor, 1, 0, 'L');
            $pdf->Cell(35, 6, $student, 1, 0, 'L');
            $pdf->Cell(30, 6, $meet_with, 1, 0, 'L');
            $pdf->Cell(25, 6, $contact, 1, 0, 'C');
            $pdf->Cell(28, 6, $purpose, 1, 0, 'L');
            $pdf->Cell(12, 6, strtoupper($status), 1, 1, 'C');
        }
    }

    $date_str = date('Ymd_His');
    $filename = "appointments_export_{$date_str}.pdf";
    $pdf->Output('I', $filename);
    exit();
}

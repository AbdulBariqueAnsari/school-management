<?php
$module_key = 'materials';
$module_title = 'Class Materials';
$module_icon = 'fa-book-open';
require_once __DIR__ . '/includes/class_module.php';
?>

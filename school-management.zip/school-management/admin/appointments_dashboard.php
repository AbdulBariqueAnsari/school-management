<?php
require_once '../includes/auth.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../dashboard.php");
    exit();
}

$appointments_file = '../data/appointments.json';
$appointments = [];
if (file_exists($appointments_file)) {
    $appointments = json_decode(file_get_contents($appointments_file), true);
    if (!is_array($appointments)) $appointments = [];
}

// Handle Single/Bulk Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'delete_single' && isset($_POST['appointment_id'])) {
        $idx = intval($_POST['appointment_id']);
        if (isset($appointments[$idx])) {
            unset($appointments[$idx]);
            $appointments = array_values($appointments); // Reindex
            file_put_contents($appointments_file, json_encode($appointments, JSON_PRETTY_PRINT));
            $_SESSION['success'] = "Appointment deleted successfully!";
            header("Location: appointments_dashboard.php");
            exit();
        }
    } elseif ($_POST['action'] === 'delete_multiple' && isset($_POST['selected_ids'])) {
        $ids = $_POST['selected_ids'];
        foreach ($ids as $id) {
            $idx = intval($id);
            if (isset($appointments[$idx])) {
                unset($appointments[$idx]);
            }
        }
        $appointments = array_values($appointments); // Reindex
        file_put_contents($appointments_file, json_encode($appointments, JSON_PRETTY_PRINT));
        $_SESSION['success'] = count($ids) . " appointments deleted successfully!";
        header("Location: appointments_dashboard.php");
        exit();
    }
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $idx = intval($_POST['appointment_id']);
    $new_status = $_POST['new_status'];
    if (isset($appointments[$idx])) {
        $appointments[$idx]['status'] = $new_status;
        file_put_contents($appointments_file, json_encode($appointments, JSON_PRETTY_PRINT));
        $_SESSION['success'] = "Lead status updated successfully!";
        header("Location: appointments_dashboard.php");
        exit();
    }
}

// Filtering & Sorting Logic
$appointments_display = [];
foreach ($appointments as $idx => $apt) {
    $apt['original_id'] = $idx; // Preserve key for updates/deletes
    $appointments_display[] = $apt;
}

// Filters
$f_visitor = trim($_GET['visitor'] ?? '');
$f_student = trim($_GET['student'] ?? '');
$f_meeting_with = trim($_GET['meeting_with'] ?? '');
$f_status = trim($_GET['status'] ?? '');
$f_sort = trim($_GET['sort'] ?? 'newest');

if ($f_visitor !== '') {
    $appointments_display = array_filter($appointments_display, function($a) use ($f_visitor) {
        return stripos($a['visitor_name'] ?? '', $f_visitor) !== false;
    });
}
if ($f_student !== '') {
    $appointments_display = array_filter($appointments_display, function($a) use ($f_student) {
        return stripos($a['student_name'] ?? '', $f_student) !== false;
    });
}
if ($f_meeting_with !== '') {
    $appointments_display = array_filter($appointments_display, function($a) use ($f_meeting_with) {
        return stripos($a['meeting_with'] ?? '', $f_meeting_with) !== false;
    });
}
if ($f_status !== '') {
    $appointments_display = array_filter($appointments_display, function($a) use ($f_status) {
        return ($a['status'] ?? 'New') === $f_status;
    });
}

// Sorting
usort($appointments_display, function($a, $b) use ($f_sort) {
    if ($f_sort === 'oldest') {
        return strtotime($a['created_at'] ?? '0') - strtotime($b['created_at'] ?? '0');
    } elseif ($f_sort === 'name_asc') {
        return strcasecmp($a['visitor_name'] ?? '', $b['visitor_name'] ?? '');
    } elseif ($f_sort === 'name_desc') {
        return strcasecmp($b['visitor_name'] ?? '', $a['visitor_name'] ?? '');
    }
    // default: newest
    return strtotime($b['created_at'] ?? '0') - strtotime($a['created_at'] ?? '0');
});

$message = '';
if (isset($_SESSION['success'])) {
    $message = "<div class='alert alert-success alert-dismissible'><button type='button' class='btn-close' data-bs-dismiss='alert'></button>" . $_SESSION['success'] . "</div>";
    unset($_SESSION['success']);
}

require_once '../includes/header.php';
?>

<style>
.adm-hub-header {
    background: linear-gradient(135deg, #0f3460 0%, #16213e 60%, #1a1a2e 100%);
    border-radius: 20px;
    padding: 30px 36px;
    margin-bottom: 24px;
    position: relative;
    overflow: hidden;
}
.adm-hub-header h2 { color: #fff; font-weight: 800; font-size: 1.8rem; margin: 0; position: relative; z-index: 1; }
.adm-hub-header p { color: rgba(255,255,255,0.6); margin: 4px 0 0; font-size: 0.95rem; position: relative; z-index: 1; }
.hub-btn {
    background: rgba(255,255,255,0.12); backdrop-filter: blur(8px);
    border: 1px solid rgba(255,255,255,0.2); color: #fff !important;
    border-radius: 10px; padding: 9px 18px; font-weight: 600; font-size: 0.88rem;
    text-decoration: none; display: inline-flex; align-items: center; gap: 7px;
    transition: all 0.25s ease; cursor: pointer;
}
.hub-btn:hover {
    background: rgba(255,255,255,0.22); transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.25);
}
.hub-btn-export { background: rgba(59, 130, 246, 0.2); border-color: rgba(59, 130, 246, 0.4); }
.hub-btn-export:hover { background: rgba(59, 130, 246, 0.4); }

.filter-wrapper {
    background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.03);
    padding: 20px; margin-bottom: 24px; border: 1px solid #f1f3f5;
}

.card-table-wrapper {
    background: #fff; border-radius: 16px; box-shadow: 0 5px 25px rgba(0,0,0,0.05);
    padding: 24px;
}
.status-dropdown { padding: 4px 8px; font-size: 0.85rem; border-radius: 6px; font-weight: bold; border: 1px solid #ccc; }
.status-New { background: #fee2e2; color: #b91c1c; border-color: #fca5a5; }

.btn-delete-icon {
    color: #dc3545; background: #fff0f0; border: none; padding: 6px 10px;
    border-radius: 6px; transition: 0.2s; cursor: pointer;
}
.btn-delete-icon:hover { background: #dc3545; color: #fff; }
</style>

<div class="container-fluid py-4">
    <?php echo $message; ?>

    <div class="adm-hub-header d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h2><i class="fa fa-calendar-check me-2"></i> Appointments Dashboard</h2>
            <p>Manage and review all parent and visitor appointments</p>
        </div>
        <div class="d-flex gap-2 flex-wrap" style="position:relative;z-index:1;">
            <a href="export_appointments.php?type=excel" class="hub-btn hub-btn-export"><i class="fa fa-file-excel"></i> Excel</a>
            <a href="export_appointments.php?type=pdf" class="hub-btn hub-btn-export" target="_blank"><i class="fa fa-file-pdf"></i> PDF</a>
            <a href="../appointment.php" class="hub-btn"><i class="fa fa-plus"></i> New Appointment</a>
            <a href="inquiry_dashboard.php" class="hub-btn"><i class="fa fa-circle-question"></i> View Inquiries</a>
            <a href="index.php" class="hub-btn"><i class="fa fa-arrow-left"></i> Dashboard</a>
        </div>
    </div>

    <!-- FILTER SECTION -->
    <div class="filter-wrapper">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-2">
                <label class="form-label text-muted small fw-bold mb-1">Visitor Name</label>
                <input type="text" name="visitor" class="form-control form-control-sm" value="<?php echo htmlspecialchars($f_visitor); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label text-muted small fw-bold mb-1">Student Name</label>
                <input type="text" name="student" class="form-control form-control-sm" value="<?php echo htmlspecialchars($f_student); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label text-muted small fw-bold mb-1">Meeting With</label>
                <input type="text" name="meeting_with" class="form-control form-control-sm" value="<?php echo htmlspecialchars($f_meeting_with); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label text-muted small fw-bold mb-1">Status</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Statuses</option>
                    <option value="New" <?php echo $f_status==='New'?'selected':'';?>>New</option>
                    <option value="Contacted" <?php echo $f_status==='Contacted'?'selected':'';?>>Contacted</option>
                    <option value="Converted" <?php echo $f_status==='Converted'?'selected':'';?>>Converted</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label text-muted small fw-bold mb-1">Sort By</label>
                <select name="sort" class="form-select form-select-sm">
                    <option value="newest" <?php echo $f_sort==='newest'?'selected':'';?>>Newest First</option>
                    <option value="oldest" <?php echo $f_sort==='oldest'?'selected':'';?>>Oldest First</option>
                    <option value="name_asc" <?php echo $f_sort==='name_asc'?'selected':'';?>>Visitor Name (A-Z)</option>
                    <option value="name_desc" <?php echo $f_sort==='name_desc'?'selected':'';?>>Visitor Name (Z-A)</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-sm w-100 mb-1"><i class="fa fa-filter"></i> Apply Filters</button>
                <a href="appointments_dashboard.php" class="btn btn-outline-secondary btn-sm w-100">Clear</a>
            </div>
        </form>
    </div>

    <!-- MAIN TABLE -->
    <div class="card-table-wrapper table-responsive">
        <form method="POST" id="bulkForm" onsubmit="return confirm('Are you sure you want to delete selected records?');">
            <input type="hidden" name="action" value="delete_multiple">
            
            <div class="d-flex justify-content-between mb-3 align-items-center">
                <h5 class="mb-0 text-dark fw-bold">Records</h5>
                <button type="submit" class="btn btn-danger btn-sm" id="btnBulkDelete" disabled>
                    <i class="fa fa-trash"></i> Delete Selected
                </button>
            </div>

            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th style="width: 40px;"><input type="checkbox" id="selectAll" class="form-check-input"></th>
                        <th>Date & Time</th>
                        <th>Visitor Name</th>
                        <th>Student Name</th>
                        <th>Meeting With</th>
                        <th>Purpose</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($appointments_display) > 0): ?>
                        <?php foreach($appointments_display as $apt): 
                            $idx = $apt['original_id'];
                            $status = $apt['status'] ?? 'New';
                        ?>
                        <tr>
                            <td><input type="checkbox" name="selected_ids[]" value="<?php echo $idx; ?>" class="form-check-input row-checkbox"></td>
                            <td><strong><?php echo htmlspecialchars($apt['date'] ?? ''); ?></strong><br><small class="text-muted"><?php echo htmlspecialchars($apt['time'] ?? ''); ?></small></td>
                            <td><?php echo htmlspecialchars($apt['visitor_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($apt['student_name'] ?? ''); ?></td>
                            <td><span class="badge bg-primary"><?php echo htmlspecialchars($apt['meeting_with'] ?? ''); ?></span></td>
                            <td><?php echo htmlspecialchars($apt['purpose'] ?? ''); ?></td>
                            <td>
                                <!-- Status Update Form (Separate from Bulk Form) -->
                                <select class="status-dropdown <?php echo $status === 'New' ? 'status-New' : ''; ?>" onchange="updateStatus(<?php echo $idx; ?>, this.value)">
                                    <option value="New" <?php echo $status === 'New' ? 'selected' : ''; ?>>New</option>
                                    <option value="Contacted" <?php echo $status === 'Contacted' ? 'selected' : ''; ?>>Contacted</option>
                                    <option value="Converted" <?php echo $status === 'Converted' ? 'selected' : ''; ?>>Converted</option>
                                </select>
                            </td>
                            <td>
                                <button type="button" class="btn-delete-icon" onclick="deleteSingle(<?php echo $idx; ?>)" title="Delete">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No appointments found matching your criteria.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </form>
    </div>
</div>

<!-- Hidden forms for POST actions -->
<form id="statusForm" method="POST" style="display:none;">
    <input type="hidden" name="update_status" value="1">
    <input type="hidden" name="appointment_id" id="statusAppId">
    <input type="hidden" name="new_status" id="statusNewVal">
</form>

<form id="deleteSingleForm" method="POST" style="display:none;">
    <input type="hidden" name="action" value="delete_single">
    <input type="hidden" name="appointment_id" id="deleteAppId">
</form>

<script>
// Select All Logic
document.getElementById('selectAll').addEventListener('change', function() {
    let checkboxes = document.querySelectorAll('.row-checkbox');
    checkboxes.forEach(cb => cb.checked = this.checked);
    toggleBulkDeleteBtn();
});

document.querySelectorAll('.row-checkbox').forEach(cb => {
    cb.addEventListener('change', toggleBulkDeleteBtn);
});

function toggleBulkDeleteBtn() {
    let checkedCount = document.querySelectorAll('.row-checkbox:checked').length;
    document.getElementById('btnBulkDelete').disabled = checkedCount === 0;
}

// Single Delete Action
function deleteSingle(id) {
    if(confirm('Are you sure you want to delete this appointment?')) {
        document.getElementById('deleteAppId').value = id;
        document.getElementById('deleteSingleForm').submit();
    }
}

// Update Status Action
function updateStatus(id, val) {
    document.getElementById('statusAppId').value = id;
    document.getElementById('statusNewVal').value = val;
    document.getElementById('statusForm').submit();
}
</script>

<?php require_once '../includes/footer.php'; ?>

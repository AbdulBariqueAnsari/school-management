<?php
require_once '../includes/auth.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../dashboard.php");
    exit();
}

require_once '../includes/header.php';
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Student Data Export</h1>
    <a href="admissions.php" class="btn btn-outline-secondary">
        <i class="fa fa-arrow-left"></i> Back to Admissions
    </a>
</div>

<div class="row">
    <!-- Export All Students -->
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-primary text-white py-3">
                <h5 class="mb-0"><i class="fa fa-users"></i> Export All Students</h5>
            </div>
            <div class="card-body">
                <p class="text-muted">Export all admission requests and students in the system.</p>
                <div class="d-flex gap-2 mt-4">
                    <a href="actions/export_students.php?type=all&format=pdf" class="btn btn-danger w-50" target="_blank">
                        <i class="fa fa-file-pdf"></i> Export PDF
                    </a>
                    <a href="actions/export_students.php?type=all&format=excel" class="btn btn-success w-50">
                        <i class="fa fa-file-excel"></i> Export Excel
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Export Approved Students -->
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-success text-white py-3">
                <h5 class="mb-0"><i class="fa fa-check-circle"></i> Export Approved Students</h5>
            </div>
            <div class="card-body">
                <p class="text-muted">Export only students who have been fully approved and admitted.</p>
                <div class="d-flex gap-2 mt-4">
                    <a href="actions/export_students.php?type=approved&format=pdf" class="btn btn-danger w-50" target="_blank">
                        <i class="fa fa-file-pdf"></i> Export PDF
                    </a>
                    <a href="actions/export_students.php?type=approved&format=excel" class="btn btn-success w-50">
                        <i class="fa fa-file-excel"></i> Export Excel
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Export Pending Admissions -->
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-warning text-dark py-3">
                <h5 class="mb-0"><i class="fa fa-clock"></i> Export Pending Admissions</h5>
            </div>
            <div class="card-body">
                <p class="text-muted">Export applications that are currently pending review.</p>
                <div class="d-flex gap-2 mt-4">
                    <a href="actions/export_students.php?type=pending&format=pdf" class="btn btn-danger w-50" target="_blank">
                        <i class="fa fa-file-pdf"></i> Export PDF
                    </a>
                    <a href="actions/export_students.php?type=pending&format=excel" class="btn btn-success w-50">
                        <i class="fa fa-file-excel"></i> Export Excel
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Export Rejected Admissions -->
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-danger text-white py-3">
                <h5 class="mb-0"><i class="fa fa-times-circle"></i> Export Rejected Admissions</h5>
            </div>
            <div class="card-body">
                <p class="text-muted">Export applications that have been rejected.</p>
                <div class="d-flex gap-2 mt-4">
                    <a href="actions/export_students.php?type=rejected&format=pdf" class="btn btn-danger w-50" target="_blank">
                        <i class="fa fa-file-pdf"></i> Export PDF
                    </a>
                    <a href="actions/export_students.php?type=rejected&format=excel" class="btn btn-success w-50">
                        <i class="fa fa-file-excel"></i> Export Excel
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

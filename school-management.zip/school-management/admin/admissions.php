<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../dashboard.php");
    exit();
}

// Count from students table only
$total_count = (int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$pending_count = (int)$pdo->query("SELECT COUNT(*) FROM students WHERE status='Pending'")->fetchColumn();
$approved_count = (int)$pdo->query("SELECT COUNT(*) FROM students WHERE status='Approved'")->fetchColumn();
$rejected_count = (int)$pdo->query("SELECT COUNT(*) FROM students WHERE status='Rejected'")->fetchColumn();
$deleted_count = (int)$pdo->query("SELECT COUNT(*) FROM students WHERE status='Deleted'")->fetchColumn();

$message = '';
if (isset($_SESSION['success'])) {
    $message = "<div class='alert alert-success alert-dismissible'><button type='button' class='btn-close' data-bs-dismiss='alert'></button>" . $_SESSION['success'] . "</div>";
    unset($_SESSION['success']);
}
if (isset($_SESSION['error'])) {
    $message = "<div class='alert alert-danger alert-dismissible'><button type='button' class='btn-close' data-bs-dismiss='alert'></button>" . $_SESSION['error'] . "</div>";
    unset($_SESSION['error']);
}

require_once '../includes/header.php';
?>

<style>
/* ============================================================
   ADMISSIONS CARD HUB — identical to teachers.php card grid
   ============================================================ */

.adm-hub-header {
    background: linear-gradient(135deg, #0f3460 0%, #16213e 60%, #1a1a2e 100%);
    border-radius: 20px;
    padding: 30px 36px;
    margin-bottom: 32px;
    position: relative;
    overflow: hidden;
}
.adm-hub-header::before {
    content: ''; position: absolute; top: -60px; right: -60px;
    width: 200px; height: 200px;
    background: rgba(255,255,255,0.05); border-radius: 50%;
}
.adm-hub-header::after {
    content: ''; position: absolute; bottom: -80px; left: 40px;
    width: 160px; height: 160px;
    background: rgba(255,255,255,0.03); border-radius: 50%;
}
.adm-hub-header h2 {
    color: #fff; font-weight: 800; font-size: 1.8rem;
    margin: 0; position: relative; z-index: 1;
}
.adm-hub-header p {
    color: rgba(255,255,255,0.6); margin: 4px 0 0; font-size: 0.95rem;
    position: relative; z-index: 1;
}

.hub-btn {
    background: rgba(255,255,255,0.12);
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255,255,255,0.2);
    color: #fff !important;
    border-radius: 10px;
    padding: 9px 18px;
    font-weight: 600; font-size: 0.88rem;
    text-decoration: none;
    display: inline-flex; align-items: center; gap: 7px;
    transition: all 0.25s ease;
    cursor: pointer;
}
.hub-btn:hover {
    background: rgba(255,255,255,0.22);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.25);
}

/* ---- Card Grid (identical to teachers.php) ---- */
.erp-card-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
}
@media (max-width: 992px) { .erp-card-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 576px) { .erp-card-grid { grid-template-columns: 1fr; } }

.erp-card-link { text-decoration: none; display: block; }

.erp-card {
    background: rgba(255,255,255,0.13);
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border: 1px solid rgba(255,255,255,0.22);
    border-radius: 20px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.13);
    padding: 32px 24px;
    text-align: center;
    position: relative;
    overflow: hidden;
    cursor: pointer;
    transition: transform 0.35s cubic-bezier(0.34,1.56,0.64,1),
                box-shadow 0.35s ease, background 0.25s ease;
    opacity: 0;
    transform: translateY(15px);
}
.erp-card.animated { opacity: 1; transform: translateY(0); }
.erp-card:hover {
    transform: translateY(-8px) scale(1.025);
    box-shadow: 0 20px 50px rgba(0,0,0,0.2);
    background: rgba(255,255,255,0.2);
    border-color: rgba(255,255,255,0.35);
}
.erp-card::before {
    content: ''; position: absolute; top: -40px; right: -40px;
    width: 120px; height: 120px; border-radius: 50%; opacity: 0.15;
    transition: opacity 0.3s;
}
.erp-card:hover::before { opacity: 0.25; }

.erp-card--teal   { background: linear-gradient(135deg, rgba(13,110,253,0.18), rgba(255,255,255,0.08)); }
.erp-card--teal::before   { background: #0d6efd; }
.erp-card--yellow { background: linear-gradient(135deg, rgba(255,193,7,0.22),  rgba(255,255,255,0.08)); }
.erp-card--yellow::before { background: #ffc107; }
.erp-card--green  { background: linear-gradient(135deg, rgba(25,135,84,0.18),  rgba(255,255,255,0.08)); }
.erp-card--green::before  { background: #198754; }
.erp-card--red    { background: linear-gradient(135deg, rgba(220,53,69,0.18),  rgba(255,255,255,0.08)); }
.erp-card--red::before    { background: #dc3545; }
.erp-card--grey   { background: linear-gradient(135deg, rgba(108,117,125,0.18),rgba(255,255,255,0.08)); }
.erp-card--grey::before   { background: #6c757d; }
.erp-card--indigo { background: linear-gradient(135deg, rgba(99,102,241,0.18), rgba(255,255,255,0.08)); }
.erp-card--indigo::before { background: #6366f1; }

.erp-card-icon {
    width: 72px; height: 72px; border-radius: 18px;
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 18px; font-size: 1.8rem;
    position: relative; z-index: 1;
}
.erp-card-icon--teal   { background: linear-gradient(135deg, #0d6efd, #6610f2); color: #fff; }
.erp-card-icon--yellow { background: linear-gradient(135deg, #fd7e14, #ffc107); color: #fff; }
.erp-card-icon--green  { background: linear-gradient(135deg, #198754, #20c997); color: #fff; }
.erp-card-icon--red    { background: linear-gradient(135deg, #dc3545, #e83e8c); color: #fff; }
.erp-card-icon--grey   { background: linear-gradient(135deg, #495057, #6c757d); color: #fff; }

.erp-card-title { font-size: 1.05rem; font-weight: 700; color: #1a1a2e; margin-bottom: 4px; position: relative; z-index: 1; }
.erp-card-sub   { font-size: 0.82rem; color: #666; margin-bottom: 16px; position: relative; z-index: 1; }
.erp-card-count {
    display: inline-flex; align-items: center; justify-content: center;
    font-size: 2rem; font-weight: 800; line-height: 1; position: relative; z-index: 1;
}
.erp-card-count--teal   { color: #0d6efd; }
.erp-card-count--yellow { color: #fd7e14; }
.erp-card-count--green  { color: #198754; }
.erp-card-count--red    { color: #dc3545; }
.erp-card-count--grey   { color: #6c757d; }

.erp-card-arrow {
    position: absolute; bottom: 18px; right: 20px; font-size: 0.9rem;
    color: rgba(0,0,0,0.25); transition: transform 0.25s ease, color 0.25s ease; z-index: 1;
}
.erp-card:hover .erp-card-arrow { transform: translateX(4px); color: rgba(0,0,0,0.5); }

/* Sidebar */
.sidebar, #sidebar { background: #212529 !important; border-right: 1px solid rgba(255,255,255,0.1); }
.sidebar .nav-link, #sidebar .nav-link { color: rgba(255,255,255,0.7) !important; }
.sidebar .nav-link:hover, #sidebar .nav-link:hover { color: #fff !important; background: rgba(255,255,255,0.1); }
.sidebar .nav-link.active, #sidebar .nav-link.active { color: #fff !important; background: #0d6efd !important; }
</style>

<div class="container-fluid py-4">

    <?php echo $message; ?>

    <!-- ===== HEADER ===== -->
    <div class="adm-hub-header d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h2><i class="fa fa-users me-2"></i> Admissions Management</h2>
            <p>Overview of all student applications — click a card to manage</p>
        </div>
        <div class="d-flex gap-2 flex-wrap" style="position:relative;z-index:1;">
            <button type="button" class="hub-btn" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                <i class="fa fa-user-plus"></i> Add Student
            </button>
            <a href="export.php" class="hub-btn">
                <i class="fa fa-download"></i> Export
            </a>
            <a href="students.php" class="hub-btn">
                <i class="fa fa-arrow-left"></i> Back
            </a>
        </div>
    </div>

    <!-- ===== CARD GRID ===== -->
    <div class="erp-card-grid">

        <!-- 1. Total Applications -->
        <a href="all_admissions.php" class="erp-card-link">
            <div class="erp-card erp-card--teal" data-delay="0">
                <div class="erp-card-icon erp-card-icon--teal">
                    <i class="fa fa-folder-open"></i>
                </div>
                <div class="erp-card-title">Total Applications</div>
                <div class="erp-card-sub">All student records</div>
                <div class="erp-card-count erp-card-count--teal"><?php echo $total_count; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 2. Pending Admissions -->
        <a href="pending_admissions.php" class="erp-card-link">
            <div class="erp-card erp-card--yellow" data-delay="100">
                <div class="erp-card-icon erp-card-icon--yellow">
                    <i class="fa fa-clock"></i>
                </div>
                <div class="erp-card-title">Pending Admissions</div>
                <div class="erp-card-sub">Awaiting admin review</div>
                <div class="erp-card-count erp-card-count--yellow"><?php echo $pending_count; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 3. Approved Students -->
        <a href="approved_students.php" class="erp-card-link">
            <div class="erp-card erp-card--green" data-delay="200">
                <div class="erp-card-icon erp-card-icon--green">
                    <i class="fa fa-user-graduate"></i>
                </div>
                <div class="erp-card-title">Approved Students</div>
                <div class="erp-card-sub">Enrolled & active</div>
                <div class="erp-card-count erp-card-count--green"><?php echo $approved_count; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 4. Rejected Students -->
        <a href="rejected_students.php" class="erp-card-link">
            <div class="erp-card erp-card--red" data-delay="300">
                <div class="erp-card-icon erp-card-icon--red">
                    <i class="fa fa-user-xmark"></i>
                </div>
                <div class="erp-card-title">Rejected Students</div>
                <div class="erp-card-sub">Declined applications</div>
                <div class="erp-card-count erp-card-count--red"><?php echo $rejected_count; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 5. Deleted Students -->
        <a href="deleted_students.php" class="erp-card-link">
            <div class="erp-card erp-card--grey" data-delay="400">
                <div class="erp-card-icon erp-card-icon--grey">
                    <i class="fa fa-trash-can"></i>
                </div>
                <div class="erp-card-title">Deleted Students</div>
                <div class="erp-card-sub">Soft-deleted records</div>
                <div class="erp-card-count erp-card-count--grey"><?php echo $deleted_count; ?></div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 6. Import Students -->
        <a href="import_students.php" class="erp-card-link">
            <div class="erp-card erp-card--indigo" data-delay="500">
                <div class="erp-card-icon erp-card-icon--indigo">
                    <i class="fa fa-file-import"></i>
                </div>
                <div class="erp-card-title">Import Students</div>
                <div class="erp-card-sub">Bulk CSV upload</div>
                <div class="erp-card-count erp-card-count--indigo">
                    <i class="fa fa-upload" style="font-size:1.6rem;"></i>
                </div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

    </div><!-- /.erp-card-grid -->
</div>

<!-- Keep the Add Student Modal (preserving existing functionality) -->
<?php
$modal_file = __DIR__ . '/includes/add_student_modal.php';
if (file_exists($modal_file)) {
    include $modal_file;
}
?>

<!-- Import Modal (preserved) -->
<div class="modal fade" id="importModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Import Students from CSV</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form action="actions/import_students.php" method="POST" enctype="multipart/form-data">
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Select CSV File</label>
            <input type="file" name="import_file" class="form-control" accept=".csv" required>
            <div class="form-text">Use the template from "Bulk Import" button above.</div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Start Import</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const cards = document.querySelectorAll('.erp-card');
    cards.forEach(function (card) {
        const delay = parseInt(card.getAttribute('data-delay')) || 0;
        setTimeout(function () {
            card.style.transition = 'opacity 0.45s ease, transform 0.45s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.35s ease, background 0.25s ease';
            card.classList.add('animated');
        }, delay);
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>

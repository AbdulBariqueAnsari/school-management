<?php
require_once '../../includes/db.php';
require_once '../../includes/auth.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    http_response_code(403);
    exit;
}

$q = isset($_GET['q']) ? trim($_GET['q']) : '';

if ($q === '') {
    exit;
}

// Search students in `students` (approved) and `admission_applications` (pending/rejected)
// For simplicity, we search in students table since most searches will be for active students by admission_no or student_name
// BUT the prompt explicitly mentions: "Search fields: admission_no, student_name"

$stmt = $pdo->prepare("
    SELECT s.id as student_id, s.user_id, s.admission_number, u.name as student_name, c.name as class_name, 
           p_u.name as parent_name, u.email, u.is_active, u.profile_photo
    FROM students s
    JOIN users u ON s.user_id = u.id
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN users p_u ON s.parent_id = p_u.id
    WHERE s.admission_number LIKE ? OR u.name LIKE ?
    ORDER BY u.name ASC
    LIMIT 20
");
$search_term = "%{$q}%";
$stmt->execute([$search_term, $search_term]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($results)) {
    echo '<tr><td colspan="7" class="text-center text-muted py-4">No students found matching your search.</td></tr>';
    exit;
}

foreach ($results as $stu) {
?>
    <tr class="table-row-hover">
        <td>
            <?php if ($stu['profile_photo']): ?>
                <img src="../uploads/students/<?php echo htmlspecialchars($stu['profile_photo']); ?>" class="rounded-circle" width="40" height="40" alt="Photo">
            <?php
    else: ?>
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($stu['student_name']); ?>&background=random" class="rounded-circle" width="40" height="40" alt="Photo">
            <?php
    endif; ?>
        </td>
        <td><strong><?php echo htmlspecialchars($stu['admission_number'] ?: 'N/A'); ?></strong></td>
        <td><strong><?php echo htmlspecialchars($stu['student_name']); ?></strong></td>
        <td><?php echo htmlspecialchars($stu['class_name'] ?: 'N/A'); ?></td>
        <td>
            <?php echo htmlspecialchars($stu['parent_name'] ?: 'N/A'); ?><br>
            <small><a href="mailto:<?php echo htmlspecialchars($stu['email']); ?>" class="text-decoration-none"><?php echo htmlspecialchars($stu['email']); ?></a></small>
        </td>
        <td>
            <span class='badge <?php echo $stu['is_active'] ? 'bg-success' : 'bg-warning text-dark'; ?>'><?php echo $stu['is_active'] ? 'Active' : 'Inactive'; ?></span>
        </td>
        <td class="text-end">
            <a href="student_profile.php?id=<?php echo $stu['student_id']; ?>" class="btn btn-sm btn-primary text-white" title="View Profile"><i class="fa fa-eye"></i> View</a>
        </td>
    </tr>
    <?php
}

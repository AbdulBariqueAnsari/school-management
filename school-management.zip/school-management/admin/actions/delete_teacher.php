<?php
require_once __DIR__ . '/../../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        $pdo->beginTransaction();

        // Get teacher info
        $stmt = $pdo->prepare("SELECT email FROM teachers WHERE id = ?");
        $stmt->execute([$id]);
        $teacher = $stmt->fetch();

        if ($teacher) {
            // SOFT DELETE: Update status to 'Deleted'
            $stmtTeacher = $pdo->prepare("UPDATE teachers SET status = 'Deleted' WHERE id = ?");
            $stmtTeacher->execute([$id]);

            // Deactivate user account
            $stmtUser = $pdo->prepare("UPDATE users SET is_active = 0 WHERE email = ?");
            $stmtUser->execute([$teacher['email']]);

            $pdo->commit();
            $_SESSION['success'] = "Teacher record moved to 'Deleted' section.";
        }
    }
    catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
}

header("Location: " . BASE_URL . "/admin/teachers.php");
exit();

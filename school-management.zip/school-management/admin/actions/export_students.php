<?php
require_once '../../includes/auth.php';
require_once '../../config/database_init.php';

// Ensure Super Admin
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    die("Unauthorized access.");
}

$type = isset($_GET['type']) ? $_GET['type'] : '';
$format = isset($_GET['format']) ? $_GET['format'] : 'pdf';
$single_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($single_id === 0 && (!in_array($type, ['all', 'approved', 'pending', 'rejected']) || !in_array($format, ['pdf', 'excel']))) {
    die("Invalid export parameters.");
}

// 0. INDIVIDUAL STUDENT EXPORT LOGIC
if ($single_id > 0) {
    require_once '../../includes/fpdf/fpdf.php';

    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$single_id]);
    $stu = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$stu)
        die("Student not found.");

    // Fetch Settings
    $settings_query = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings");
    $settings = $settings_query->fetchAll(PDO::FETCH_KEY_PAIR);

    class SinglePDF extends FPDF
    {
        public $settings;
        function Header()
        {
            $school_logo = $this->settings['school_logo'] ?? '';
            $school_name = $this->settings['school_name'] ?? 'School Management System';
            $school_tagline = $this->settings['school_tagline'] ?? '';
            $school_code = $this->settings['school_code'] ?? '';
            $school_board = $this->settings['school_board'] ?? '';
            $school_registration_number = $this->settings['school_registration_number'] ?? '';
            $school_phone = $this->settings['school_phone'] ?? '';
            $school_email = $this->settings['school_email'] ?? '';
            $school_website = $this->settings['school_website'] ?? '';
            $school_address = $this->settings['school_address'] ?? '';

            if (!empty($school_logo)) {
                $logo_path1 = __DIR__ . '/../../uploads/branding/' . $school_logo;
                $logo_path2 = __DIR__ . '/../../uploads/logos/' . $school_logo;
                $logo_path3 = __DIR__ . '/../../assets/images/' . $school_logo;

                if (file_exists($logo_path1)) {
                    $this->Image($logo_path1, 10, 6, 20);
                }
                elseif (file_exists($logo_path2)) {
                    $this->Image($logo_path2, 10, 6, 20);
                }
                elseif (file_exists($logo_path3)) {
                    $this->Image($logo_path3, 10, 6, 20);
                }
            }
            else {
                $logo = __DIR__ . '/../../assets/images/logo.png';
                if (file_exists($logo)) {
                    $this->Image($logo, 10, 6, 20);
                }
            }
            $this->SetX(35);
            $this->SetFont('Arial', 'B', 16);
            $this->SetTextColor(13, 110, 253);
            $this->Cell(0, 8, $school_name, 0, 1, 'L');

            if (!empty($school_tagline)) {
                $this->SetX(35);
                $this->SetFont('Arial', 'I', 10);
                $this->SetTextColor(100, 100, 100);
                $this->Cell(0, 5, $school_tagline, 0, 1, 'L');
            }
            $code_info = [];
            if (!empty($school_code))
                $code_info[] = "Code: " . $school_code;
            if (!empty($school_board))
                $code_info[] = "Board: " . $school_board;
            if (!empty($school_registration_number))
                $code_info[] = "Reg No: " . $school_registration_number;
            if (!empty($code_info)) {
                $this->SetX(35);
                $this->SetFont('Arial', '', 9);
                $this->SetTextColor(50, 50, 50);
                $this->Cell(0, 5, implode(' | ', $code_info), 0, 1, 'L');
            }
            $contact_info = [];
            if (!empty($school_phone))
                $contact_info[] = "Phone: " . $school_phone;
            if (!empty($school_email))
                $contact_info[] = "Email: " . $school_email;
            if (!empty($school_website))
                $contact_info[] = "Website: " . $school_website;
            if (!empty($contact_info)) {
                $this->SetX(35);
                $this->SetFont('Arial', '', 9);
                $this->SetTextColor(80, 80, 80);
                $this->Cell(0, 5, implode(' | ', $contact_info), 0, 1, 'L');
            }
            if (!empty($school_address)) {
                $this->SetX(35);
                $this->SetFont('Arial', '', 9);
                $this->Cell(0, 5, $school_address, 0, 1, 'L');
            }
            $this->SetDrawColor(13, 110, 253);
            $this->SetLineWidth(0.8);
            $this->Line(10, $this->GetY() + 3, 200, $this->GetY() + 3);
            $this->Ln(8);

            $this->SetFillColor(0, 102, 204);
            $this->SetTextColor(255, 255, 255);
            $this->SetFont('Arial', 'B', 14);
            $this->Cell(0, 10, 'STUDENT ADMISSION REPORT', 0, 1, 'C', true);
            $this->SetTextColor(0, 0, 0);
            $this->Ln(5);
        }
        function Footer()
        {
            $this->SetY(-22);
            // Developer Branding Highlighted
            $this->SetFont('Arial', 'B', 8);
            $this->SetFillColor(255, 215, 0); // Gold
            $this->SetTextColor(0, 0, 0);

            $text = 'Designed and maintained by WebNoor';
            $w = $this->GetStringWidth($text) + 10;
            $this->SetX((210 - $w) / 2);
            $this->Cell($w, 6, $text, 0, 1, 'C', true, 'https://webnoor.in');

            $this->SetY(-13);
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, 'Page ' . $this->PageNo() . ' / {nb} | Generated on ' . date('d M Y H:i'), 0, 0, 'C');
        }
    }

    $pdf = new SinglePDF('P', 'mm', 'A4');
    $pdf->settings = $settings;
    $pdf->AliasNbPages();
    $pdf->AddPage();

    $fieldsToExport = [
        'Personal Details' => [
            'Student Name' => $stu['student_name'] ?? '',
            'Gender' => $stu['gender'] ?? '',
            'Date of Birth' => $stu['dob'] ?? '',
            'Blood Group' => $stu['blood_group'] ?? '',
            'Aadhaar Number' => $stu['aadhaar_number'] ?? '',
            'Class Applied' => $stu['class_applied'] ?? ($stu['class'] ?? ''),
        ],
        'Contact Details' => [
            'Mobile Number' => $stu['mobile_number'] ?? '',
            'Present Address' => $stu['address'] ?? '',
        ],
        'Family Details' => [
            'Father Name' => $stu['father_name'] ?? '',
            'Father Mobile' => $stu['father_mobile'] ?? '',
            'Mother Name' => $stu['mother_name'] ?? '',
            'Mother Mobile' => $stu['mother_mobile'] ?? '',
            'Parent Address' => $stu['parents_address'] ?? '',
            'Guardian Name' => $stu['guardian_name'] ?? '',
            'Guardian Relation' => $stu['relation'] ?? '',
            'Guardian Mobile' => $stu['guardian_mobile'] ?? '',
            'Guardian Address' => $stu['guardian_address'] ?? '',
        ],
        'Identity & Category' => [
            'Religion' => $stu['religion'] ?? '',
            'Caste Category' => $stu['caste_category'] ?? '',
            'Mother Tongue' => $stu['mother_tongue'] ?? '',
        ],
        'Health Information' => [
            'Medical Condition' => ($stu['has_medical_condition'] ?? 0) ? 'Yes: ' . ($stu['medical_condition_desc'] ?? '') : 'No',
            'Disability' => ($stu['has_disability'] ?? 0) ? 'Yes: ' . ($stu['disability_desc'] ?? '') : 'No',
            'Allergies' => ($stu['has_allergies'] ?? 0) ? 'Yes: ' . ($stu['allergies_desc'] ?? '') : 'No',
        ],
        'Academic Background' => [
            'Previous Schooling' => $stu['previous_schooling_status'] ?? '',
            'Previous Class' => $stu['previous_class'] ?? '',
            'Previous School' => $stu['previous_school_name'] ?? ($stu['previous_school'] ?? ''),
            'Previous Board' => $stu['previous_board'] ?? '',
            'Year of Passing' => $stu['year_of_passing'] ?? '',
        ]
    ];

    $pdf->SetFont('Arial', '', 10);
    foreach ($fieldsToExport as $section => $fields) {
        $pdf->SetFillColor(230, 230, 230);
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 8, strtoupper($section), 1, 1, 'L', true);

        $pdf->SetFont('Arial', '', 10);
        foreach ($fields as $lbl => $val) {
            $pdf->Cell(60, 7, '  ' . $lbl, 1, 0, 'L');
            $pdf->Cell(0, 7, '  ' . htmlspecialchars($val), 1, 1, 'L');
        }
        $pdf->Ln(3);
    }

    $adm = $stu['admission_no'] ?? ($stu['application_id'] ?? $stu['id']);
    $filename = "student_export_{$adm}.pdf";
    $pdf->Output('I', $filename);
    exit();
}

// 1. Fetch Data based on Type
$records = [];
$report_title = "Student Export Report";

try {
    if ($type === 'approved') {
        $stmt = $pdo->query("SELECT * FROM students WHERE status = 'Approved' ORDER BY student_name ASC");
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $report_title = "Approved Students Report";
    }
    elseif ($type === 'pending') {
        $stmt = $pdo->query("SELECT * FROM students WHERE status = 'Pending' ORDER BY created_at DESC");
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $report_title = "Pending Admissions Report";
    }
    elseif ($type === 'rejected') {
        $stmt = $pdo->query("SELECT * FROM students WHERE status = 'Rejected' ORDER BY created_at DESC");
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $report_title = "Rejected Admissions Report";
    }
    else { // 'all'
        $stmt_stu = $pdo->query("SELECT * FROM students ORDER BY created_at DESC");
        $records = $stmt_stu->fetchAll(PDO::FETCH_ASSOC);
        $report_title = "All Students & Applications Report";
    }
}
catch (PDOException $e) {
    die("Database error during export: " . $e->getMessage());
}

if (empty($records)) {
    die("No records found to export.");
}

$date_str = date('Ymd_His');

// 2. EXCEL EXPORT (CSV format)
if ($format === 'excel') {
    $filename = "students_{$type}_export_{$date_str}.csv";

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    $output = fopen('php://output', 'w');

    // Output BOM for Excel UTF-8 compatibility
    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

    // Headers
    fputcsv($output, [
        'Admission No / App ID',
        'Student Name',
        'Class',
        'Gender',
        'DOB',
        'Parent Name',
        'Parent Email',
        'Parent Phone',
        'Status',
        'Date'
    ]);

    foreach ($records as $row) {
        $adm_no = $row['admission_no'] ?? ($row['id'] ? 'APP-' . $row['id'] : 'N/A');
        $class_val = $row['class'] ?? ($row['class_applied'] ?? 'N/A');
        $parent_name = $row['parent_name'] ?? ($row['father_name'] ?? 'N/A');
        $parent_phone = $row['parent_phone'] ?? ($row['father_mobile'] ?? ($row['mobile_number'] ?? 'N/A'));
        $parent_email = $row['parent_email'] ?? 'N/A';
        $status = $row['export_status'] ?? ($row['status'] ?? 'Approved');
        $date_val = $row['admission_date'] ?? ($row['created_at'] ?? 'N/A');
        if ($date_val !== 'N/A') {
            $date_val = date('Y-m-d', strtotime($date_val));
        }

        fputcsv($output, [
            $adm_no,
            $row['student_name'] ?? 'N/A',
            $class_val,
            $row['gender'] ?? 'N/A',
            $row['dob'] ?? 'N/A',
            $parent_name,
            $parent_email,
            $parent_phone,
            $status,
            $date_val
        ]);
    }

    fclose($output);
    exit();
}

// 3. PDF EXPORT Using FPDF
if ($format === 'pdf') {
    require_once '../../includes/fpdf/fpdf.php';

    // Fetch School Settings
    $settings_query = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings");
    $settings = $settings_query->fetchAll(PDO::FETCH_KEY_PAIR);

    class PDF extends FPDF
    {
        public $settings, $report_title;

        function Header()
        {
            $school_logo = $this->settings['school_logo'] ?? '';
            $school_name = $this->settings['school_name'] ?? 'School Management System';
            $school_tagline = $this->settings['school_tagline'] ?? '';
            $school_code = $this->settings['school_code'] ?? '';
            $school_board = $this->settings['school_board'] ?? '';
            $school_registration_number = $this->settings['school_registration_number'] ?? '';
            $school_phone = $this->settings['school_phone'] ?? '';
            $school_email = $this->settings['school_email'] ?? '';
            $school_website = $this->settings['school_website'] ?? '';
            $school_address = $this->settings['school_address'] ?? '';

            if (!empty($school_logo)) {
                $logo_path1 = __DIR__ . '/../../uploads/branding/' . $school_logo;
                $logo_path2 = __DIR__ . '/../../uploads/logos/' . $school_logo;
                $logo_path3 = __DIR__ . '/../../assets/images/' . $school_logo;

                if (file_exists($logo_path1)) {
                    $this->Image($logo_path1, 10, 6, 20);
                }
                elseif (file_exists($logo_path2)) {
                    $this->Image($logo_path2, 10, 6, 20);
                }
                elseif (file_exists($logo_path3)) {
                    $this->Image($logo_path3, 10, 6, 20);
                }
            }
            else {
                $logo = __DIR__ . '/../../assets/images/logo.png';
                if (file_exists($logo)) {
                    $this->Image($logo, 10, 6, 20);
                }
            }
            $this->SetX(35);
            $this->SetFont('Arial', 'B', 16);
            $this->SetTextColor(13, 110, 253);
            $this->Cell(0, 8, $school_name, 0, 1, 'L');

            if (!empty($school_tagline)) {
                $this->SetX(35);
                $this->SetFont('Arial', 'I', 10);
                $this->SetTextColor(100, 100, 100);
                $this->Cell(0, 5, $school_tagline, 0, 1, 'L');
            }
            $code_info = [];
            if (!empty($school_code))
                $code_info[] = "Code: " . $school_code;
            if (!empty($school_board))
                $code_info[] = "Board: " . $school_board;
            if (!empty($school_registration_number))
                $code_info[] = "Reg No: " . $school_registration_number;
            if (!empty($code_info)) {
                $this->SetX(35);
                $this->SetFont('Arial', '', 9);
                $this->SetTextColor(50, 50, 50);
                $this->Cell(0, 5, implode(' | ', $code_info), 0, 1, 'L');
            }
            $contact_info = [];
            if (!empty($school_phone))
                $contact_info[] = "Phone: " . $school_phone;
            if (!empty($school_email))
                $contact_info[] = "Email: " . $school_email;
            if (!empty($school_website))
                $contact_info[] = "Website: " . $school_website;
            if (!empty($contact_info)) {
                $this->SetX(35);
                $this->SetFont('Arial', '', 9);
                $this->SetTextColor(80, 80, 80);
                $this->Cell(0, 5, implode(' | ', $contact_info), 0, 1, 'L');
            }
            if (!empty($school_address)) {
                $this->SetX(35);
                $this->SetFont('Arial', '', 9);
                $this->Cell(0, 5, $school_address, 0, 1, 'L');
            }
            $this->SetDrawColor(13, 110, 253);
            $this->SetLineWidth(0.8);
            $this->Line(10, $this->GetY() + 3, 200, $this->GetY() + 3);
            $this->Ln(8);

            $this->SetFillColor(200, 200, 200);
            $this->SetFont('Arial', 'B', 12);
            $this->SetTextColor(33, 37, 41);
            $this->Cell(0, 8, strtoupper($this->report_title), 0, 1, 'C', true);
            $this->Ln(5);

            // Table Header
            $this->SetFont('Arial', 'B', 9);
            $this->SetFillColor(230, 230, 230);
            $this->Cell(25, 7, 'Adm/App No', 1, 0, 'C', true);
            $this->Cell(45, 7, 'Student Name', 1, 0, 'C', true);
            $this->Cell(15, 7, 'Class', 1, 0, 'C', true);
            $this->Cell(15, 7, 'Gender', 1, 0, 'C', true);
            $this->Cell(45, 7, 'Parent Name', 1, 0, 'C', true);
            $this->Cell(25, 7, 'Phone', 1, 0, 'C', true);
            $this->Cell(20, 7, 'Status', 1, 1, 'C', true);
        }

        function Footer()
        {
            $this->SetY(-22);
            // Developer Branding Highlighted
            $this->SetFont('Arial', 'B', 8);
            $this->SetFillColor(255, 215, 0); // Gold
            $this->SetTextColor(0, 0, 0);

            $text = 'Designed and maintained by WebNoor';
            $w = $this->GetStringWidth($text) + 10;
            $this->SetX((210 - $w) / 2);
            $this->Cell($w, 6, $text, 0, 1, 'C', true, 'https://webnoor.in');

            $this->SetY(-13);
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, 'Page ' . $this->PageNo() . ' / {nb} | Generated on ' . date('d M Y H:i'), 0, 0, 'C');
        }
    }

    $pdf = new PDF('P', 'mm', 'A4');
    $pdf->settings = $settings;
    $pdf->report_title = $report_title;

    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Arial', '', 9);

    foreach ($records as $row) {
        $adm_no = $row['admission_no'] ?? ($row['id'] ? 'APP-' . $row['id'] : 'N/A');

        // Truncate long strings to fit cells
        $name = substr($row['student_name'] ?? 'N/A', 0, 25);
        $class_val = substr($row['class'] ?? ($row['class_applied'] ?? 'N/A'), 0, 10);
        $gender = substr($row['gender'] ?? 'N/A', 0, 1); // just M/F/O is usually enough

        $parent_name = substr($row['parent_name'] ?? ($row['father_name'] ?? 'N/A'), 0, 25);
        $phone = substr($row['parent_phone'] ?? ($row['father_mobile'] ?? ($row['mobile_number'] ?? 'N/A')), 0, 12);

        $status = $row['export_status'] ?? ($row['status'] ?? 'Approved');

        $pdf->Cell(25, 6, $adm_no, 1, 0, 'C');
        $pdf->Cell(45, 6, $name, 1, 0, 'L');
        $pdf->Cell(15, 6, $class_val, 1, 0, 'C');
        $pdf->Cell(15, 6, $gender, 1, 0, 'C');
        $pdf->Cell(45, 6, $parent_name, 1, 0, 'L');
        $pdf->Cell(25, 6, $phone, 1, 0, 'C');
        $pdf->Cell(20, 6, $status, 1, 1, 'C');
    }

    $filename = "students_{$type}_export_{$date_str}.pdf";
    $pdf->Output('I', $filename);
    exit();
}

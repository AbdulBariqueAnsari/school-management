<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';

// Ensure Super Admin access
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    die("Access Denied");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['import_file'])) {
    $file = $_FILES['import_file'];

    if ($file['error'] !== 0) {
        $_SESSION['error'] = "File upload error.";
        header("Location: ../admissions.php");
        exit();
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($ext !== 'csv') {
        $_SESSION['error'] = "Please upload a valid CSV file.";
        header("Location: ../admissions.php");
        exit();
    }

    try {
        $pdo->beginTransaction();

        $handle = fopen($file['tmp_name'], "r");
        $headers = fgetcsv($handle); // First row is headers

        $import_count = 0;
        $error_rows = [];
        $row_num = 1;

        // Fetch classes to map name to ID if needed, though template should ideally use names if we want it user-friendly.
        // For now, we assume the user fills the template correctly.

        while (($data = fgetcsv($handle)) !== FALSE) {
            $row_num++;
            if (empty(array_filter($data)))
                continue; // Skip empty rows

            $row = array_combine($headers, $data);

            // Map CSV data to students table fields
            $full_name = trim($row['full_name'] ?? '');
            $username = trim($row['username'] ?? '');
            $email = trim($row['email'] ?? '');
            $password = trim($row['password'] ?? 'Pass@123');

            if (empty($full_name) || empty($username) || empty($email)) {
                $error_rows[] = "Row $row_num: Missing required fields (Name, Username, or Email).";
                continue;
            }

            // Check if username or email exists
            $stmt_check = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt_check->execute([$username, $email]);
            if ($stmt_check->fetch()) {
                $error_rows[] = "Row $row_num: Username or Email already exists.";
                continue;
            }

            // 1. Create User
            $stmt_user = $pdo->prepare("INSERT INTO users (name, username, email, password, role_id, is_active) VALUES (?, ?, ?, ?, 6, 1)");
            $stmt_user->execute([$full_name, $username, $email, password_hash($password, PASSWORD_DEFAULT)]);
            $user_id = $pdo->lastInsertId();

            // 2. Insert into students table (simplified based on provided schema)
            $stmt_student = $pdo->prepare("INSERT INTO students (
                user_id, student_name, dob, gender, blood_group, aadhaar_number, 
                present_address, student_mobile, religion, caste_category, mother_tongue,
                father_name, father_mobile, mother_name, mother_mobile, parents_address,
                guardian_name, relation, guardian_mobile, guardian_address,
                has_medical_condition, medical_condition_desc, has_disability, disability_desc,
                has_allergies, allergies_desc, previous_schooling_status, previous_class,
                previous_school_name, previous_board, year_of_passing, status, class_applied
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?)");

            $stmt_student->execute([
                $user_id,
                $full_name,
                $row['dob'] ?: null,
                $row['gender'] ?: 'Other',
                $row['blood_group'] ?: null,
                $row['aadhaar_number'] ?: null,
                $row['present_address'] ?: null,
                $row['mobile_number'] ?: null,
                $row['religion'] ?: null,
                $row['caste_category'] ?: 'General',
                $row['mother_tongue'] ?: null,
                $row['father_name'] ?: null,
                $row['father_mobile'] ?: null,
                $row['mother_name'] ?: null,
                $row['mother_mobile'] ?: null,
                $row['parents_address'] ?: null,
                $row['guardian_name'] ?: null,
                $row['relation'] ?: null,
                $row['guardian_mobile'] ?: null,
                $row['guardian_address'] ?: null,
                $row['has_medical_condition'] == 'Yes' ? 1 : 0,
                $row['medical_condition_desc'] ?: null,
                $row['has_disability'] == 'Yes' ? 1 : 0,
                $row['disability_desc'] ?: null,
                $row['has_allergies'] == 'Yes' ? 1 : 0,
                $row['allergies_desc'] ?: null,
                $row['previous_schooling_status'] ?: null,
                $row['previous_class'] ?: null,
                $row['previous_school_name'] ?: null,
                $row['previous_board'] ?: null,
                $row['year_of_passing'] ?: null,
                $row['class_applying_for'] ?: 'Unspecified'
            ]);

            $student_id = $pdo->lastInsertId();

            // Generate Admission Number
            $admission_no = 'ADM-' . date('Y') . '-' . str_pad($student_id, 4, '0', STR_PAD_LEFT);
            $pdo->prepare("UPDATE students SET admission_no = ? WHERE id = ?")->execute([$admission_no, $student_id]);

            $import_count++;
        }

        fclose($handle);
        $pdo->commit();

        $success_msg = "$import_count students imported successfully to Pending list.";
        if (!empty($error_rows)) {
            $_SESSION['error'] = $success_msg . " Errors in some rows: " . implode("<br>", $error_rows);
        }
        else {
            $_SESSION['success'] = $success_msg;
        }

    }
    catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Import failed: " . $e->getMessage();
    }

    header("Location: ../admissions.php");
    exit();
}
?>

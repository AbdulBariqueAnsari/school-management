<?php
require_once __DIR__ . '/../../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        $pdo->beginTransaction();

        // Get teacher info
        $stmt = $pdo->prepare("SELECT email FROM teachers WHERE id = ?");
        $stmt->execute([$id]);
        $teacher = $stmt->fetch();

        if ($teacher) {
            // Update teachers table
            $stmt1 = $pdo->prepare("UPDATE teachers SET status = 'Rejected' WHERE id = ?");
            $stmt1->execute([$id]);

            // Deactivate user account
            $stmt2 = $pdo->prepare("UPDATE users SET is_active = 0 WHERE email = ?");
            $stmt2->execute([$teacher['email']]);

            $pdo->commit();
            $_SESSION['success'] = "Teacher application rejected.";
        }
    }
    catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
}

header("Location: " . BASE_URL . "/admin/teachers.php");
exit();

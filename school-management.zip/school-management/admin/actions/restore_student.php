<?php
require_once __DIR__ . '/../../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        // Restore status to 'Pending' to allow review
        $stmt = $pdo->prepare("UPDATE students SET status = 'Pending' WHERE id = ?");
        $stmt->execute([$id]);

        if ($stmt->rowCount() > 0) {
            $_SESSION['success'] = "Student record restored successfully to Pending status.";
        }
        else {
            $_SESSION['error'] = "Student not found or already restored.";
        }
    }
    catch (Exception $e) {
        $_SESSION['error'] = "Error restoring student: " . $e->getMessage();
    }
}

header("Location: " . BASE_URL . "/admin/admissions.php");
exit();

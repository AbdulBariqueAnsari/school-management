<?php
require_once '../../includes/auth.php';
require_once '../../config/database_init.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../../dashboard.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    if ($id > 0) {
        try {
            $stmt = $pdo->prepare("UPDATE students SET status = 'Deleted' WHERE id = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $_SESSION['success'] = "Student record moved to 'Deleted' section.";
            }
            else {
                $_SESSION['error'] = "Student not found or already deleted.";
            }
        }
        catch (PDOException $e) {
            $_SESSION['error'] = "Could not delete student: " . $e->getMessage();
        }
    }
    else {
        $_SESSION['error'] = "Invalid Student ID.";
    }
}

if (isset($_SERVER['HTTP_REFERER'])) {
    header("Location: " . $_SERVER['HTTP_REFERER']);
} else {
    header("Location: ../admissions.php");
}
exit();

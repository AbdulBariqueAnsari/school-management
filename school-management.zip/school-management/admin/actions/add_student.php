<?php
session_start();
require_once '../../includes/db.php';

// Ensure Super Admin access
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    die("Access Denied");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $pdo->beginTransaction();

        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        $upload_dir = '../../uploads/students/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $profile_photo = null;
        if (isset($_FILES['student_photo']) && $_FILES['student_photo']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            $file_info = pathinfo($_FILES['student_photo']['name']);
            if (in_array(strtolower($file_info['extension']), $allowed)) {
                $profile_photo = time() . '_' . $_FILES['student_photo']['name'];
                move_uploaded_file($_FILES['student_photo']['tmp_name'], $upload_dir . $profile_photo);
            }
        }

        // 1. Create User for Student
        $stmt_user = $pdo->prepare("INSERT INTO users (name, role_id, email, password, profile_photo, is_active, phone) VALUES (?, 6, ?, ?, ?, 1, ?)");
        $stmt_user->execute([trim($_POST['full_name']), $email, $password, $profile_photo, trim($_POST['student_mobile'])]);
        $user_id = $pdo->lastInsertId();

        // 2. Create User for Parent
        $parent_name = trim($_POST['father_name']) ?: 'Parent';
        $parent_phone = trim($_POST['father_mobile']) ?: null;
        $stmt_puser = $pdo->prepare("INSERT INTO users (role_id, name, password, is_active, phone) VALUES (7, ?, ?, 1, ?)");
        $stmt_puser->execute([$parent_name, $password, $parent_phone]);
        $parent_user_id = $pdo->lastInsertId();

        // Insert Parent Details
        $stmt_parent = $pdo->prepare("INSERT INTO parents (user_id, occupation, alt_phone) VALUES (?, ?, ?)");
        $stmt_parent->execute([$parent_user_id, 'Not specified', trim($_POST['mother_mobile']) ?: null]);
        $parent_id = $pdo->lastInsertId();

        // Generate Admission Number
        // Format: ADM-YYYY-XXXX
        $stmt_count = $pdo->query("SELECT COUNT(*) FROM students WHERE admission_number LIKE 'ADM-" . date('Y') . "-%'");
        $count = $stmt_count->fetchColumn() + 1;
        $admission_id = "ADM-" . date('Y') . "-" . str_pad($count, 4, "0", STR_PAD_LEFT);

        // 3. Insert Student
        $stmt_student = $pdo->prepare("INSERT INTO students (
            user_id, admission_number, class_id, section_id, parent_id, dob, age, gender, blood_group, address, admission_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE())");

        $stmt_student->execute([
            $user_id,
            $admission_id,
            $_POST['class_applying_for'],
            1, // default section
            $parent_user_id,
            $_POST['dob'],
            (int)$_POST['age'] ?: null,
            $_POST['gender'],
            $_POST['blood_group'],
            $_POST['present_address']
        ]);
        $student_id = $pdo->lastInsertId();

        // Ensure accessory tables exist
        $pdo->exec("CREATE TABLE IF NOT EXISTS guardians (id INT AUTO_INCREMENT PRIMARY KEY, student_id INT, guardian_name VARCHAR(150), relation VARCHAR(100), guardian_mobile VARCHAR(20), guardian_address TEXT)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS health_details (id INT AUTO_INCREMENT PRIMARY KEY, student_id INT, has_medical_condition TINYINT, medical_condition_desc TEXT, has_disability TINYINT, disability_desc TEXT, has_allergies TINYINT, allergies_desc TEXT)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS academic_details (id INT AUTO_INCREMENT PRIMARY KEY, student_id INT, previous_schooling_status VARCHAR(100), previous_class VARCHAR(50), previous_school_name VARCHAR(150), previous_board VARCHAR(100), year_of_passing INT)");

        // 4. Guardian (if applicable)
        if (!empty(trim($_POST['guardian_name']))) {
            $stmt_guardian = $pdo->prepare("INSERT INTO guardians (student_id, guardian_name, relation, guardian_mobile, guardian_address) VALUES (?, ?, ?, ?, ?)");
            $stmt_guardian->execute([$student_id, $_POST['guardian_name'], $_POST['guardian_relation'] ?? null, $_POST['guardian_mobile'] ?? null, $_POST['guardian_address'] ?? null]);
        }

        // 5. Health Details
        $stmt_health = $pdo->prepare("INSERT INTO health_details (student_id, has_medical_condition, medical_condition_desc, has_disability, disability_desc, has_allergies, allergies_desc) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt_health->execute([$student_id, $_POST['has_medical_condition'] == 'Yes' ? 1 : 0, $_POST['medical_details'] ?? null, $_POST['has_disability'] == 'Yes' ? 1 : 0, $_POST['disability_details'] ?? null, $_POST['has_allergies'] == 'Yes' ? 1 : 0, $_POST['allergy_details'] ?? null]);

        // 6. Academic Details
        $stmt_academic = $pdo->prepare("INSERT INTO academic_details (student_id, previous_schooling_status, previous_class, previous_school_name, previous_board, year_of_passing) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt_academic->execute([$student_id, $_POST['previous_schooling_status'], $_POST['previous_class'], $_POST['previous_school_name'], $_POST['previous_board'], !empty($_POST['year_of_passing']) ? $_POST['year_of_passing'] : null]);

        $pdo->commit();
        $_SESSION['success'] = "Student admitted successfully. Admission No: " . $admission_id;
    }
    catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Admission failed: " . $e->getMessage();
    }

    header("Location: ../admissions.php");
    exit();
}

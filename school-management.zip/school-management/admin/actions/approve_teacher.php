<?php
require_once __DIR__ . '/../../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        $pdo->beginTransaction();

        // Get teacher info to find user_id
        $stmt = $pdo->prepare("SELECT email FROM teachers WHERE id = ?");
        $stmt->execute([$id]);
        $teacher = $stmt->fetch();

        if ($teacher) {
            // Update teachers table
            $stmt1 = $pdo->prepare("UPDATE teachers SET status = 'Approved' WHERE id = ?");
            $stmt1->execute([$id]);

            // Update users table (match by email)
            $stmt2 = $pdo->prepare("UPDATE users SET is_active = 1 WHERE email = ?");
            $stmt2->execute([$teacher['email']]);

            $pdo->commit();
            error_log("APPROVE_TEACHER: Commited successfully for id=$id");
            $_SESSION['success'] = "Teacher application approved successfully!";
        }
        else {
            error_log("APPROVE_TEACHER: Teacher not found for id=$id");
            throw new Exception("Teacher not found.");
        }

    }
    catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("APPROVE_TEACHER ERROR: " . $e->getMessage());
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
}
else {
    error_log("APPROVE_TEACHER: ID is less than 0 or invalid: $id");
}

error_log("APPROVE_TEACHER: Redirecting to: " . BASE_URL . "/admin/teachers.php");
header("Location: " . BASE_URL . "/admin/teachers.php");
exit();

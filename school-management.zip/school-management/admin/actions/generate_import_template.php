<?php
error_reporting(0);
require_once __DIR__ . '/../../includes/auth.php';

// Ensure Super Admin access
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    die("Access Denied");
}

$filename = "student_import_template_" . date('Ymd') . ".csv";

// Headers based on admission.php fields and students table schema
$headers = [
    'full_name',
    'gender',
    'dob',
    'blood_group',
    'aadhaar_number',
    'present_address',
    'mobile_number',
    'has_medical_condition',
    'medical_condition_desc',
    'has_disability',
    'disability_desc',
    'has_allergies',
    'allergies_desc',
    'religion',
    'caste_category',
    'mother_tongue',
    'previous_schooling_status',
    'class_applying_for',
    'previous_class',
    'previous_school_name',
    'previous_board',
    'year_of_passing',
    'father_name',
    'father_mobile',
    'mother_name',
    'mother_mobile',
    'parents_address',
    'guardian_name',
    'relation',
    'guardian_mobile',
    'guardian_address',
    'username',
    'email',
    'password'
];

// Sample data row
$sample_data = [
    'John Doe',
    'Male',
    '2015-05-15',
    'O+',
    '123456789012',
    '123 Street, City',
    '9876543210',
    'No',
    '',
    'No',
    '',
    'No',
    '',
    'Hindu',
    'General',
    'Bengali',
    'Passed from Previous School',
    'Class 1',
    'KG 2',
    'Sample School',
    'CBSE',
    '2023',
    'Robert Doe',
    '9988776655',
    'Jane Doe',
    '9988776644',
    '123 Street, City',
    'Richard Smith',
    'Uncle',
    '1122334455',
    '456 Avenue, City',
    'johndoe2026',
    'john.doe@example.com',
    'Pass@123'
];

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename);

$output = fopen('php://output', 'w');
fputcsv($output, $headers);
fputcsv($output, $sample_data);
fclose($output);
exit();
?>

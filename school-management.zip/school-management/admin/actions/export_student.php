<?php
/**
 * export_student.php — Upgraded PDF design
 * Status badge • Centered logo • Page border • Modern layout
 */
ob_start();

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../config/database_init.php';
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);

if (!isset($_SESSION['role_id'])) {
    ob_end_clean();
    header("Location: ../../login.php");
    exit();
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$type = isset($_GET['type']) ? $_GET['type'] : 'student';

// Permission check
if ($_SESSION['role_id'] == 1) {
    // Admin can see all
} elseif ($_SESSION['role_id'] == 6) {
    // Student can only see their own record
    // We need to fetch the student_id linked to the user_id if not in session
    if (!isset($_SESSION['student_id'])) {
        $checkStmt = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
        $checkStmt->execute([$_SESSION['user_id']]);
        $_SESSION['student_id'] = $checkStmt->fetchColumn();
    }
    
    if ($id != $_SESSION['student_id']) {
        ob_end_clean();
        die("Unauthorized: You can only export your own profile.");
    }
} else {
    ob_end_clean();
    header("Location: ../../dashboard.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$stu = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$stu) {
    ob_end_clean();
    die('<div class="container mt-5"><div class="alert alert-danger">Record not found. <a href="javascript:history.back()">Back</a></div></div>');
}

// Normalise field names
$stu['full_name'] = $stu['student_name'] ?? ($stu['full_name'] ?? 'N/A');
$stu['admission_no'] = $stu['admission_no'] ?? $stu['id'];
$stu['class_display'] = $stu['class_applied'] ?? ($stu['class'] ?? 'N/A');
$stu['photo_file'] = $stu['student_photo'] ?? ($stu['photo'] ?? '');
$stu['mobile'] = $stu['student_mobile'] ?? ($stu['mobile_number'] ?? ($stu['parent_phone'] ?? 'N/A'));
$stu['address_display'] = $stu['present_address'] ?? ($stu['address'] ?? 'N/A');

// Fetch school settings
$settings = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings")
    ->fetchAll(PDO::FETCH_KEY_PAIR);

function safe_str($val, $default = 'N/A')
{
    return ($val === null || $val === '') ? $default : (string)$val;
}

ob_end_clean();
require_once __DIR__ . '/../../includes/fpdf/fpdf.php';

// ────────────────────────────────────────────────────────────
class StudentPDF extends FPDF
{
    var $school_name, $school_address, $school_logo;
    var $school_email, $school_phone, $school_website;
    var $school_reg, $school_board;
    var $report_title, $status_text;

    // Status badge colours
    private function statusColour()
    {
        switch (strtolower($this->status_text)) {
            case 'approved':
                return [34, 139, 34]; // green
            case 'pending':
                return [200, 140, 0]; // amber
            case 'rejected':
                return [180, 30, 30]; // red
            default:
                return [120, 120, 120]; // grey
        }
    }

    function Header()
    {
        // ── Page border ──
        $this->SetDrawColor(160, 160, 160);
        $this->SetLineWidth(0.6);
        $this->Rect(8, 8, 194, 281);

        // ONLY print Header on Page 1
        if ($this->PageNo() == 1) {
            // ── Logo (centred) ──
            $logoY = 14;
            if (!empty($this->school_logo)) {
                $paths = [
                    __DIR__ . '/../../uploads/' . $this->school_logo,
                    __DIR__ . '/../../uploads/branding/' . $this->school_logo,
                    __DIR__ . '/../../assets/images/' . $this->school_logo,
                ];
                foreach ($paths as $p) {
                    if (file_exists($p)) {
                        $logoW = 30;
                        $this->Image($p, (210 - $logoW) / 2, $logoY, $logoW);
                        $logoY += 34;
                        break;
                    }
                }
            }

            $this->SetY($logoY);

            // School name
            $this->SetFont('Arial', 'B', 16);
            $this->SetTextColor(13, 71, 161);
            $this->Cell(0, 8, strtoupper($this->school_name ?: 'School Management System'), 0, 1, 'C');

            // Address & contact
            $this->SetFont('Arial', '', 8);
            $this->SetTextColor(80, 80, 80);
            if ($this->school_address)
                $this->Cell(0, 5, $this->school_address, 0, 1, 'C');

            $info = [];
            if ($this->school_phone)
                $info[] = 'Ph: ' . $this->school_phone;
            if ($this->school_email)
                $info[] = $this->school_email;
            if ($this->school_website)
                $info[] = $this->school_website;
            if ($this->school_board)
                $info[] = 'Board: ' . $this->school_board;
            if ($this->school_reg)
                $info[] = 'Reg: ' . $this->school_reg;
            if ($info)
                $this->Cell(0, 4, implode('  |  ', $info), 0, 1, 'C');

            // Blue separator line
            $this->SetDrawColor(13, 71, 161);
            $this->SetLineWidth(0.8);
            $y = $this->GetY() + 3;
            $this->Line(14, $y, 196, $y);
            $this->SetLineWidth(0.3);
            $this->Line(14, $y + 1.5, 196, $y + 1.5);
            $this->Ln(8);

            // Report title
            $this->SetFont('Arial', 'B', 13);
            $this->SetTextColor(30, 30, 30);
            $this->Cell(0, 8, $this->report_title, 0, 1, 'C');
            $this->Ln(3);

            // ── Status badge ──
            if (!empty($this->status_text)) {
                [$r, $g, $b] = $this->statusColour();
                $label = 'STATUS: ' . strtoupper($this->status_text);
                $bw = 60;
                $bx = (210 - $bw) / 2;
                // background
                $this->SetFillColor($r, $g, $b);
                $this->SetTextColor(255, 255, 255);
                $this->SetFont('Arial', 'B', 10);
                $this->SetXY($bx, $this->GetY());
                $this->Cell($bw, 8, $label, 0, 1, 'C', true);
                // border glow
                $this->SetDrawColor($r, $g, $b);
                $this->SetLineWidth(0.5);
                $this->Rect($bx, $this->GetY() - 8, $bw, 8);
                $this->Ln(6);
            }
        }
        // Reset draw colour for rest of page
        $this->SetDrawColor(200, 200, 200);
        $this->SetLineWidth(0.3);
    }

    function Footer()
    {
        // Re-draw page border (FPDF Header called once at top, border must be on every page)
        $this->SetDrawColor(160, 160, 160);
        $this->SetLineWidth(0.6);
        $this->Rect(8, 8, 194, 281);

        // Footer text
        $this->SetY(-20);
        $this->SetFont('Arial', 'B', 8);
        $this->SetFillColor(255, 215, 0);
        $this->SetTextColor(0, 0, 0);
        $label = 'Maintained and Developed by WebNoor';
        $fw = $this->GetStringWidth($label) + 12;
        $this->SetX((210 - $fw) / 2);
        $this->Cell($fw, 6, $label, 0, 1, 'C', true, 'https://webnoor.in');

        $this->SetFont('Arial', 'I', 7);
        $this->SetTextColor(130, 130, 130);
        $this->Cell(0, 5, 'Page ' . $this->PageNo() . '/{nb}  |  Generated: ' . date('d M Y, h:i A'), 0, 0, 'C');
    }

    function SectionTitle($title)
    {
        $this->SetFont('Arial', 'B', 9);
        $this->SetFillColor(13, 71, 161);
        $this->SetTextColor(255, 255, 255);
        $this->SetDrawColor(13, 71, 161);
        $this->Cell(0, 7, '  ' . strtoupper($title), 'LRB', 1, 'L', true);
        $this->SetDrawColor(200, 200, 200);
        $this->Ln(1);
    }

    // Two-column table row
    function FieldRow($label, $value, $colW = 55)
    {
        $this->SetFont('Arial', 'B', 8.5);
        $this->SetTextColor(60, 60, 60);
        $this->SetFillColor(247, 247, 247);
        $this->Cell($colW, 6.5, $label . ':', 'LB', 0, 'L', true);
        $this->SetFont('Arial', '', 8.5);
        $this->SetTextColor(0, 0, 0);
        $this->SetFillColor(255, 255, 255);
        $this->Cell(0, 6.5, $value, 'RB', 1, 'L', true);
    }

    // Two fields side by side (4-column row)
    function DoubleFieldRow($l1, $v1, $l2, $v2)
    {
        $lw = 42;
        $vw = 50;
        $this->SetFont('Arial', 'B', 8.5);
        $this->SetFillColor(247, 247, 247);
        $this->SetTextColor(60, 60, 60);
        $this->Cell($lw, 6.5, $l1 . ':', 'LB', 0, 'L', true);
        $this->SetFont('Arial', '', 8.5);
        $this->SetFillColor(255, 255, 255);
        $this->SetTextColor(0, 0, 0);
        $this->Cell($vw, 6.5, $v1, 'B', 0, 'L', true);
        $this->SetFont('Arial', 'B', 8.5);
        $this->SetFillColor(247, 247, 247);
        $this->SetTextColor(60, 60, 60);
        $this->Cell($lw, 6.5, $l2 . ':', 'LB', 0, 'L', true);
        $this->SetFont('Arial', '', 8.5);
        $this->SetFillColor(255, 255, 255);
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 6.5, $v2, 'RB', 1, 'L', true);
    }
}

// ────────────────────────────────────────────────────────────
// Build PDF
$report_title = ($type === 'student') ? 'STUDENT ADMISSION REPORT' : 'ADMISSION APPLICATION REPORT';

$pdf = new StudentPDF();
$pdf->school_name = $settings['school_name'] ?? '';
$pdf->school_address = $settings['school_address'] ?? '';
$pdf->school_logo = $settings['school_logo'] ?? '';
$pdf->school_email = $settings['school_email'] ?? '';
$pdf->school_phone = $settings['school_phone'] ?? '';
$pdf->school_website = $settings['school_website'] ?? '';
$pdf->school_board = $settings['school_board'] ?? '';
$pdf->school_reg = $settings['school_reg_no'] ?? ($settings['school_registration_number'] ?? '');
$pdf->report_title = $report_title;
$pdf->status_text = $stu['status'] ?? '';

$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetMargins(14, 10, 14);

// ── Admission No banner ──
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(232, 240, 254);
$pdf->SetTextColor(13, 71, 161);
$pdf->Cell(0, 7, '  Admission No:  ' . safe_str($stu['admission_no'] ?: $stu['admission_number'] ?: 'ADM-'.$stu['id']) . '    |    Application ID: ' . safe_str($stu['application_id'] ?: 'Internal'), 'LRTB', 1, 'L', true);
$pdf->Ln(2);

// ── Section 1: Student Details ──
$pdf->SectionTitle('1. Student Personal Details');
$pdf->DoubleFieldRow('Full Name', safe_str($stu['student_name']), 'Gender', safe_str($stu['gender']));
$pdf->DoubleFieldRow('Date of Birth', safe_str($stu['dob']), 'Age (Years)', safe_str($stu['age']));
$pdf->DoubleFieldRow('Blood Group', safe_str($stu['blood_group']), 'Aadhaar No', safe_str($stu['aadhaar_number']));
$pdf->DoubleFieldRow('Religion', safe_str($stu['religion']), 'Caste Category', safe_str($stu['caste_category']));
$pdf->DoubleFieldRow('Mother Tongue', safe_str($stu['mother_tongue']), 'Mobile', safe_str($stu['mobile_number'] ?: $stu['student_mobile']));
$pdf->FieldRow('Email Address', safe_str($stu['email'] ?: $stu['parent_email']));
$pdf->FieldRow('Present Address', safe_str($stu['present_address'] ?: $stu['address']));
$pdf->Ln(3);

// ── Section 2: Parent & Family Details ──
$pdf->SectionTitle('2. Family & Guardian Information');
$pdf->DoubleFieldRow("Father's Name", safe_str($stu['father_name'] ?: $stu['parent_name']), "Father's Mobile", safe_str($stu['father_mobile'] ?: $stu['parent_phone']));
$pdf->DoubleFieldRow("Mother's Name", safe_str($stu['mother_name']), "Mother's Mobile", safe_str($stu['mother_mobile']));
$pdf->FieldRow('Parent Email', safe_str($stu['parent_email']));
if (!empty($stu['guardian_name'])) {
    $pdf->DoubleFieldRow('Guardian Name', safe_str($stu['guardian_name']), 'Relation', safe_str($stu['relation']));
    $pdf->DoubleFieldRow('Guardian Mobile', safe_str($stu['guardian_mobile']), 'Guardian Address', safe_str($stu['guardian_address'] ?: $stu['guardian_details']));
}
$pdf->FieldRow('Permanent Address', safe_str($stu['parents_address'] ?: 'Same as Present Address'));
$pdf->Ln(3);

// ── Section 3: Health Information ──
$pdf->SectionTitle('3. Medical & Health Information');
$med = ($stu['has_medical_condition'] ?? 0) ? ('YES - ' . safe_str($stu['medical_condition_desc'])) : 'NONE REPORTED';
$dis = ($stu['has_disability'] ?? 0) ? ('YES - ' . safe_str($stu['disability_desc'])) : 'NONE REPORTED';
$alg = ($stu['has_allergies'] ?? 0) ? ('YES - ' . safe_str($stu['allergies_desc'])) : 'NONE REPORTED';
$pdf->FieldRow('Medical Condition', $med);
$pdf->FieldRow('Disability Status', $dis);
$pdf->FieldRow('Known Allergies', $alg);
$pdf->Ln(3);

// ==========================================
// PAGE 2: ACADEMIC, ACCOUNT & SIGNATURES
// ==========================================
$pdf->AddPage();
$pdf->SetY(15); // Adjust top space on Page 2

// ── Section 4: Academic History ──
$pdf->SectionTitle('4. Academic History & Admission');
$pdf->DoubleFieldRow('Class Applied', safe_str($stu['class_applied'] ?: $stu['class']), 'Admission Date', safe_str($stu['admission_date']));
$pdf->DoubleFieldRow('Year of Passing', safe_str($stu['year_of_passing']), 'Schooling Status', safe_str($stu['previous_schooling_status']));
$pdf->FieldRow('Previous School', safe_str($stu['previous_school_name'] ?: $stu['previous_school']));
$pdf->DoubleFieldRow('Last Class', safe_str($stu['previous_class']), 'Previous Board', safe_str($stu['previous_board']));
$pdf->Ln(3);

$pdf->SectionTitle('5. Portal Account Information');
$pdf->DoubleFieldRow('Username', safe_str($stu['username']), 'Official Email', safe_str($stu['email']));
$pdf->DoubleFieldRow('Initial Password', '********', 'Account Status', strtoupper(safe_str($stu['status'], 'ACTIVE')));
$pdf->Ln(5);

// ── Section 6: Declaration ──
$pdf->SectionTitle('DECLARATION');
$pdf->SetFont('Arial', '', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(0, 5, "I hereby declare that all information provided in this admission report is correct and complete to the best of my knowledge. I understand that any false statement may result in the cancellation of this admission. I agree to abide by the disciplinary rules and regulations of the institution.");
$pdf->Ln(2);
$pdf->Rect(14, $pdf->GetY(), 4, 4);
$pdf->SetX($pdf->GetX() + 6);
$pdf->Cell(0, 4, "I confirm that I have verified the details above.");
$pdf->Ln(15);

// ── Signatures Grid ──
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetTextColor(80, 80, 80);

// Row 1: Student & Parent
$y_sig = $pdf->GetY();
$pdf->Cell(90, 6, "STUDENT SIGNATURE", 0, 0);
$pdf->Cell(90, 6, "PARENT / GUARDIAN SIGNATURE", 0, 1);
$pdf->Ln(10);
$pdf->Line(14, $pdf->GetY(), 80, $pdf->GetY());
$pdf->Line(110, $pdf->GetY(), 180, $pdf->GetY());
$pdf->Ln(15);

// Row 2: Clerk & Principal
$y_sig2 = $pdf->GetY();
$pdf->Cell(90, 6, "OFFICE CLERK SIGNATURE", 0, 0);
$pdf->Cell(90, 6, "PRINCIPAL'S SIGNATURE & STAMP", 0, 1);
$pdf->Ln(10);
$pdf->Line(14, $pdf->GetY(), 80, $pdf->GetY());
$pdf->Line(110, $pdf->GetY(), 180, $pdf->GetY());

// Principal Stamp area (Border removed as requested)
$pdf->SetXY(125, $y_sig2 + 10);
$pdf->SetFont('Arial', 'I', 7);
$pdf->Cell(45, 5, "[ OFFICIAL STAMP SPACE ]", 0, 0, 'C');

// Output
$pdf->Output('I', 'Student_' . safe_str($stu['admission_no'], $id) . '.pdf');
exit();

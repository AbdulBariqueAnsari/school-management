<?php
require_once __DIR__ . '/../../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        $pdo->beginTransaction();

        // Get teacher info
        $stmt = $pdo->prepare("SELECT email FROM teachers WHERE id = ?");
        $stmt->execute([$id]);
        $teacher = $stmt->fetch();

        if ($teacher) {
            // Restore to 'Pending' by default or 'Approved' if logic dictates
            $stmt1 = $pdo->prepare("UPDATE teachers SET status = 'Pending' WHERE id = ?");
            $stmt1->execute([$id]);

            // Keep user deactivated until manual approval? 
            // Or activate if restoring? Let's keep it 0 to force review.
            $stmt2 = $pdo->prepare("UPDATE users SET is_active = 0 WHERE email = ?");
            $stmt2->execute([$teacher['email']]);

            $pdo->commit();
            $_SESSION['success'] = "Teacher record restored successfully to Pending status.";
        }
    }
    catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
}

header("Location: " . BASE_URL . "/admin/teachers.php");
exit();

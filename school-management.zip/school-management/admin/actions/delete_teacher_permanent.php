<?php
require_once __DIR__ . '/../../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        $pdo->beginTransaction();

        // Get teacher info to delete associated user
        $stmt = $pdo->prepare("SELECT email FROM teachers WHERE id = ?");
        $stmt->execute([$id]);
        $teacher = $stmt->fetch();

        if ($teacher) {
            // Delete from users
            $stmtUser = $pdo->prepare("DELETE FROM users WHERE email = ?");
            $stmtUser->execute([$teacher['email']]);

            // Delete from teachers
            $stmtTeacher = $pdo->prepare("DELETE FROM teachers WHERE id = ?");
            $stmtTeacher->execute([$id]);

            $pdo->commit();
            $_SESSION['success'] = "Teacher record permanently deleted from the system.";
        }
    }
    catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
}

header("Location: " . BASE_URL . "/admin/teachers.php");
exit();

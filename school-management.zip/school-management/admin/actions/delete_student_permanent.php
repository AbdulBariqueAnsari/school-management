<?php
require_once __DIR__ . '/../../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        $pdo->beginTransaction();

        // 1. Delete the student record permanently
        $stmtStudent = $pdo->prepare("DELETE FROM students WHERE id = ?");
        $stmtStudent->execute([$id]);

        $pdo->commit();
        $_SESSION['success'] = "Student record was permanently deleted.";
    }
    catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['error'] = "Error permanently deleting student: " . $e->getMessage();
    }
}

header("Location: " . BASE_URL . "/admin/admissions.php");
exit();

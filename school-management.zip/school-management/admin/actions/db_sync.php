<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../config/database_init.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    die("Unauthorized.");
}

$columns_to_add = [
    'admission_no' => 'VARCHAR(50)',
    'student_name' => 'VARCHAR(150)',
    'gender' => 'VARCHAR(10)',
    'dob' => 'DATE',
    'blood_group' => 'VARCHAR(10)',
    'aadhaar' => 'VARCHAR(20)',
    'class_applied' => 'VARCHAR(50)',
    'father_name' => 'VARCHAR(150)',
    'mother_name' => 'VARCHAR(150)',
    'parent_email' => 'VARCHAR(150)',
    'parent_phone' => 'VARCHAR(20)',
    'present_address' => 'TEXT',
    'medical_condition' => 'VARCHAR(20)',
    'medical_details' => 'TEXT',
    'disability' => 'VARCHAR(20)',
    'disability_details' => 'TEXT',
    'allergies' => 'VARCHAR(20)',
    'allergy_details' => 'TEXT',
    'religion' => 'VARCHAR(50)',
    'caste_category' => 'VARCHAR(50)',
    'mother_tongue' => 'VARCHAR(50)',
    'previous_school_status' => 'VARCHAR(50)',
    'previous_class' => 'VARCHAR(50)',
    'previous_school_name' => 'VARCHAR(150)',
    'previous_board' => 'VARCHAR(100)',
    'year_of_passing' => 'VARCHAR(10)',
    'student_photo' => 'VARCHAR(255)',
    'username' => 'VARCHAR(100)',
    'email' => 'VARCHAR(150)',
    'password' => 'VARCHAR(255)',
    'status' => 'VARCHAR(20) DEFAULT \'Pending\'',
];

// Ensure table exists safely (it must exist already, but just to be sure we don't drop fields)
$pdo->exec("CREATE TABLE IF NOT EXISTS students (id INT AUTO_INCREMENT PRIMARY KEY, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

// Get existing columns
$stmt = $pdo->query("SHOW COLUMNS FROM students");
$existing_columns = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $existing_columns[] = $row['Field'];
}

// Add missing columns safely
foreach ($columns_to_add as $col => $def) {
    if (!in_array($col, $existing_columns)) {
        try {
            $pdo->exec("ALTER TABLE students ADD COLUMN $col $def");
            echo "Added column: $col <br>";
        }
        catch (Exception $e) {
            echo "Error adding $col: " . $e->getMessage() . "<br>";
        }
    }
}

echo "Database sync completed successfully.";

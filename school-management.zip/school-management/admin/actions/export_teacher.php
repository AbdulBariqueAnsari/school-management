<?php
/**
 * export_teacher.php — Upgraded PDF design
 * Status badge • Centred logo • Page border • Modern layout
 */
ob_start();

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../config/db.php';
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    ob_end_clean();
    header("Location: ../../dashboard.php");
    exit();
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
$stmt->execute([$id]);
$t = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$t) {
    ob_end_clean();
    die('<div class="container mt-5"><div class="alert alert-danger">Teacher not found. <a href="javascript:history.back()">Back</a></div></div>');
}

$settings = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings")
    ->fetchAll(PDO::FETCH_KEY_PAIR);

function safe_str($val, $default = 'N/A')
{
    return (empty($val) && $val !== '0') ? $default : (string)$val;
}

ob_end_clean();
require_once __DIR__ . '/../../includes/fpdf/fpdf.php';

// ────────────────────────────────────────────────────────────
class TeacherPDF extends FPDF
{
    var $school_name, $school_address, $school_logo;
    var $school_email, $school_phone, $school_website;
    var $school_reg, $school_board;
    var $status_text;

    private function statusColour()
    {
        switch (strtolower($this->status_text)) {
            case 'approved':
                return [34, 139, 34];
            case 'pending':
                return [200, 140, 0];
            case 'rejected':
                return [180, 30, 30];
            default:
                return [120, 120, 120];
        }
    }

    function Header()
    {
        // ── Page border ──
        $this->SetDrawColor(160, 160, 160);
        $this->SetLineWidth(0.6);
        $this->Rect(8, 8, 194, 281);

        if ($this->PageNo() == 1) {
            // ── Logo centred ──
            $logoY = 14;
            if (!empty($this->school_logo)) {
                $paths = [
                    __DIR__ . '/../../uploads/branding/' . $this->school_logo,
                    __DIR__ . '/../../uploads/' . $this->school_logo,
                    __DIR__ . '/../../assets/images/' . $this->school_logo,
                ];
                foreach ($paths as $p) {
                    if (file_exists($p)) {
                        $logoW = 30;
                        $this->Image($p, (210 - $logoW) / 2, $logoY, $logoW);
                        $logoY += 34;
                        break;
                    }
                }
            }

            $this->SetY($logoY);

            // School name
            $this->SetFont('Arial', 'B', 16);
            $this->SetTextColor(13, 71, 161);
            $this->Cell(0, 8, strtoupper($this->school_name ?: 'School Management System'), 0, 1, 'C');

            // Contact line
            $this->SetFont('Arial', '', 8);
            $this->SetTextColor(80, 80, 80);
            if ($this->school_address)
                $this->Cell(0, 4, $this->school_address, 0, 1, 'C');

            $info = [];
            if ($this->school_phone)
                $info[] = 'Ph: ' . $this->school_phone;
            if ($this->school_email)
                $info[] = $this->school_email;
            if ($this->school_website)
                $info[] = $this->school_website;
            if ($this->school_board)
                $info[] = 'Board: ' . $this->school_board;
            if ($this->school_reg)
                $info[] = 'Reg: ' . $this->school_reg;
            if ($info)
                $this->Cell(0, 4, implode('  |  ', $info), 0, 1, 'C');

            // Double rule
            $this->SetDrawColor(13, 71, 161);
            $this->SetLineWidth(0.8);
            $y = $this->GetY() + 3;
            $this->Line(14, $y, 196, $y);
            $this->SetLineWidth(0.3);
            $this->Line(14, $y + 1.5, 196, $y + 1.5);
            $this->Ln(8);

            // Title
            $this->SetFont('Arial', 'B', 13);
            $this->SetTextColor(30, 30, 30);
            $this->Cell(0, 8, 'TEACHER PROFILE REPORT', 0, 1, 'C');
            $this->Ln(3);

            // ── Status badge ──
            if (!empty($this->status_text)) {
                [$r, $g, $b] = $this->statusColour();
                $bw = 60;
                $bx = (210 - $bw) / 2;
                $this->SetFillColor($r, $g, $b);
                $this->SetTextColor(255, 255, 255);
                $this->SetFont('Arial', 'B', 10);
                $this->SetXY($bx, $this->GetY());
                $this->Cell($bw, 8, 'STATUS: ' . strtoupper($this->status_text), 0, 1, 'C', true);
                $this->SetDrawColor($r, $g, $b);
                $this->SetLineWidth(0.5);
                $this->Rect($bx, $this->GetY() - 8, $bw, 8);
                $this->Ln(6);
            }
        }

        $this->SetDrawColor(200, 200, 200);
        $this->SetLineWidth(0.3);
    }

    function Footer()
    {
        $this->SetDrawColor(160, 160, 160);
        $this->SetLineWidth(0.6);
        $this->Rect(8, 8, 194, 281);

        $this->SetY(-20);
        $this->SetFont('Arial', 'B', 8);
        $this->SetFillColor(255, 215, 0);
        $this->SetTextColor(0, 0, 0);
        $label = 'Maintained and Developed by WebNoor';
        $fw = $this->GetStringWidth($label) + 12;
        $this->SetX((210 - $fw) / 2);
        $this->Cell($fw, 6, $label, 1, 1, 'C', true, 'https://webnoor.in');

        $this->SetFont('Arial', 'I', 7);
        $this->SetTextColor(130, 130, 130);
        $this->Cell(0, 5, 'Page ' . $this->PageNo() . '/{nb}  |  Generated: ' . date('d M Y, h:i A'), 0, 0, 'C');
    }

    function SectionTitle($title)
    {
        $this->SetFont('Arial', 'B', 9);
        $this->SetFillColor(13, 71, 161);
        $this->SetTextColor(255, 255, 255);
        $this->Cell(0, 7, '  ' . strtoupper($title), 'LRB', 1, 'L', true);
        $this->SetDrawColor(200, 200, 200);
        $this->Ln(1);
    }

    function FieldRow($label, $value, $colW = 55)
    {
        $this->SetFont('Arial', 'B', 8.5);
        $this->SetTextColor(60, 60, 60);
        $this->SetFillColor(247, 247, 247);
        $this->Cell($colW, 6.5, $label . ':', 'LB', 0, 'L', true);
        $this->SetFont('Arial', '', 8.5);
        $this->SetTextColor(0, 0, 0);
        $this->SetFillColor(255, 255, 255);
        $this->Cell(0, 6.5, $value, 'RB', 1, 'L', true);
    }

    function DoubleFieldRow($l1, $v1, $l2, $v2)
    {
        $lw = 42;
        $vw = 50;
        $this->SetFont('Arial', 'B', 8.5);
        $this->SetFillColor(247, 247, 247);
        $this->SetTextColor(60, 60, 60);
        $this->Cell($lw, 6.5, $l1 . ':', 'LB', 0, 'L', true);
        $this->SetFont('Arial', '', 8.5);
        $this->SetFillColor(255, 255, 255);
        $this->SetTextColor(0, 0, 0);
        $this->Cell($vw, 6.5, $v1, 'B', 0, 'L', true);
        $this->SetFont('Arial', 'B', 8.5);
        $this->SetFillColor(247, 247, 247);
        $this->SetTextColor(60, 60, 60);
        $this->Cell($lw, 6.5, $l2 . ':', 'LB', 0, 'L', true);
        $this->SetFont('Arial', '', 8.5);
        $this->SetFillColor(255, 255, 255);
        $this->SetTextColor(0, 0, 0);
        $this->Cell(0, 6.5, $v2, 'RB', 1, 'L', true);
    }
}

// ────────────────────────────────────────────────────────────
// Build PDF
$pdf = new TeacherPDF();
$pdf->school_name = $settings['school_name'] ?? '';
$pdf->school_address = $settings['school_address'] ?? '';
$pdf->school_logo = $settings['school_logo'] ?? '';
$pdf->school_email = $settings['school_email'] ?? '';
$pdf->school_phone = $settings['school_phone'] ?? '';
$pdf->school_website = $settings['school_website'] ?? '';
$pdf->school_board = $settings['school_board'] ?? '';
$pdf->school_reg = $settings['school_reg_no'] ?? ($settings['school_registration_number'] ?? '');
$pdf->status_text = $t['status'] ?? '';

$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetMargins(14, 10, 14);


// ── Teacher ID banner ──
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(232, 240, 254);
$pdf->SetTextColor(13, 71, 161);
$pdf->Cell(0, 7, ' Teacher ID:  ' . safe_str($t['teacher_id']), 'LRTB', 1, 'L', true);
$pdf->Ln(3);

// ── Section 1: Personal Details ──
$pdf->SectionTitle('1. Personal Details');
$pdf->DoubleFieldRow('Full Name', safe_str($t['full_name']), 'Gender', safe_str($t['gender']));
$pdf->DoubleFieldRow('Date of Birth', safe_str($t['dob']), 'Blood Group', safe_str($t['blood_group']));
$pdf->DoubleFieldRow('Age', safe_str($t['age']), 'Aadhaar No', safe_str($t['aadhaar']));
$pdf->Ln(5);

// ── Section 2: Contact Details ──
$pdf->SectionTitle('2. Contact Details');
$pdf->DoubleFieldRow('Phone', safe_str($t['phone']), 'Email', safe_str($t['email']));
$pdf->FieldRow('Present Address', safe_str($t['present_address']));
$pdf->FieldRow('Permanent Address', safe_str($t['permanent_address']));
$pdf->Ln(5);

// ── Section 3: Professional Details ──
$pdf->SectionTitle('3. Professional Background');
$pdf->DoubleFieldRow('Qualification', safe_str($t['qualification']), 'Specialization', safe_str($t['specialization']));
$pdf->DoubleFieldRow('Experience', safe_str($t['experience_years']) . ' Yrs', 'Designation', safe_str($t['designation']));
$pdf->DoubleFieldRow('Employment Type', safe_str($t['employment_type']), 'Year of Joining', safe_str($t['year_of_joining']));
$pdf->FieldRow('Previous School', safe_str($t['previous_school']));
$pdf->Ln(5);

// ── Section 4: Assignments ──
$pdf->SectionTitle('4. Class & Subject Assignments');
$pdf->DoubleFieldRow('Assigned Subject', safe_str($t['assigned_subject']), 'Teaching Class', safe_str($t['assigned_class']));
$role_display = str_replace('_', ' ', $t['role']);
$role_display = ucfirst($role_display);
if($t['role'] === 'class_teacher') {
    $role_display .= ' (' . $t['class_teacher_of'] . ')';
}
$pdf->FieldRow('Primary Role', $role_display);
$pdf->Ln(5);

// ── Section 5: Account Info ──
$pdf->SectionTitle('5. Portal Account Information');
$pdf->DoubleFieldRow('Login Username', safe_str($t['username']), 'Portal Email', safe_str($t['email']));
$pdf->FieldRow('Account Status', strtoupper(safe_str($t['status'])));

// ==========================================
// PAGE 2: DECLARATION & SIGNATURES
// ==========================================
$pdf->AddPage();
$pdf->SetY(20);

// Declarations section
$pdf->SectionTitle('DECLARATION');
$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(0, 6, "I hereby declare that the information provided above is accurate and I agree to perform my duties according to the policies and regulations of the institution.");
$pdf->Ln(4);
$pdf->SetFont('ZapfDingbats', '', 12);
$pdf->Rect($pdf->GetX(), $pdf->GetY() + 1, 4, 4);
$pdf->SetX($pdf->GetX() + 6);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 6, "I agree to the declaration.");
$pdf->Ln(25);

// ── Signatures Area ──
// Teacher Signature
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetTextColor(80, 80, 80);
$pdf->Cell(0, 6, "Teacher Signature", 0, 1);
$pdf->Ln(4);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(20, 6, "Signature:");
$pdf->Line($pdf->GetX() + 2, $pdf->GetY() + 5, $pdf->GetX() + 50, $pdf->GetY() + 5);
$pdf->Ln(8);
$pdf->Cell(15, 6, "Name:");
$pdf->Line($pdf->GetX() + 2, $pdf->GetY() + 5, $pdf->GetX() + 45, $pdf->GetY() + 5);
$pdf->SetX(90);
$pdf->Cell(12, 6, "Date:");
$pdf->Line($pdf->GetX() + 2, $pdf->GetY() + 5, $pdf->GetX() + 40, $pdf->GetY() + 5);
$pdf->Ln(20);

// Principal Signature & Stamp Box side-by-side
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 6, "Principal Signature", 0, 1);
$pdf->Ln(4);
$currY = $pdf->GetY();

$pdf->SetFont('Arial', '', 10);
$pdf->Cell(20, 6, "Signature:");
$pdf->Line($pdf->GetX() + 2, $pdf->GetY() + 5, $pdf->GetX() + 50, $pdf->GetY() + 5);
$pdf->Ln(8);
$pdf->Cell(15, 6, "Name:");
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(45, 6, "Principal", "B", 0, "C");
$pdf->SetFont('Arial', '', 10);
$pdf->Ln(8);
$pdf->Cell(12, 6, "Date:");
$pdf->Line($pdf->GetX() + 2, $pdf->GetY() + 5, $pdf->GetX() + 40, $pdf->GetY() + 5);

// Stamp text (No box)
$boxW = 60;
$boxH = 26;
$pdf->SetXY(140, $currY - 2 + ($boxH / 2) - 3);
$pdf->SetFont('Arial', 'I', 9);
$pdf->SetTextColor(150, 150, 150);
$pdf->Cell($boxW, 6, "Official School Stamp & Seal", 0, 0, 'C');

$fname = 'Teacher_' . str_replace(' ', '_', safe_str($t['full_name'], 'Profile')) . '.pdf';
$pdf->Output('I', $fname);
exit();

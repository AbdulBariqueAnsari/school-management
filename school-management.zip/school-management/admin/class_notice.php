<?php
$module_key = 'notice';
$module_title = 'Class Notice';
$module_icon = 'fa-bullhorn';
require_once __DIR__ . '/includes/class_module.php';
?>

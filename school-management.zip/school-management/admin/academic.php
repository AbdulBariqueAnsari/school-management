<?php
require_once '../includes/auth.php';
require_once '../config/db.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$success = '';
$error = '';

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 1. Add New Class
    if (isset($_POST['add_class'])) {
        $class_name = trim($_POST['class_name']);
        if (empty($class_name)) {
            $error = "Class name cannot be empty.";
        } else {
            // Check if class exists
            $check = $pdo->prepare("SELECT id FROM classes WHERE LOWER(name) = LOWER(?)");
            $check->execute([$class_name]);
            if ($check->fetch()) {
                $error = "Class '$class_name' already exists.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO classes (name) VALUES (?)");
                if ($stmt->execute([$class_name])) {
                    $success = "Class '$class_name' added successfully!";
                } else {
                    $error = "Failed to add class.";
                }
            }
        }
    }
    
    // 2. Add/Map Subject to Class
    if (isset($_POST['add_subject'])) {
        $class_id = (int)$_POST['class_id'];
        $subject_select = trim($_POST['subject_select'] ?? '');
        $subject_custom = trim($_POST['subject_custom'] ?? '');
        
        $subject_name = !empty($subject_custom) ? $subject_custom : $subject_select;
        
        if (empty($class_id)) {
            $error = "Please select a class.";
        } elseif (empty($subject_name)) {
            $error = "Please enter or select a subject name.";
        } else {
            // Check if class exists
            $cls_check = $pdo->prepare("SELECT name FROM classes WHERE id = ?");
            $cls_check->execute([$class_id]);
            $class = $cls_check->fetch();
            
            if (!$class) {
                $error = "Selected class does not exist.";
            } else {
                // Check if subject is already mapped to this class
                $sub_check = $pdo->prepare("SELECT id FROM subjects WHERE class_id = ? AND LOWER(TRIM(name)) = LOWER(TRIM(?))");
                $sub_check->execute([$class_id, $subject_name]);
                if ($sub_check->fetch()) {
                    $error = "Subject '$subject_name' is already mapped to " . htmlspecialchars($class['name']) . ".";
                } else {
                    $stmt = $pdo->prepare("INSERT INTO subjects (name, class_id) VALUES (?, ?)");
                    if ($stmt->execute([$subject_name, $class_id])) {
                        $success = "Subject '$subject_name' mapped to " . htmlspecialchars($class['name']) . " successfully!";
                    } else {
                        $error = "Failed to map subject.";
                    }
                }
            }
        }
    }
}

// Handle GET Actions (Deletions)
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    
    // Delete Subject Mapping
    if ($action === 'delete_subject' && isset($_GET['id'])) {
        $subject_id = (int)$_GET['id'];
        // Get details for success msg
        $stmt_detail = $pdo->prepare("SELECT s.name as sub_name, c.name as class_name FROM subjects s JOIN classes c ON s.class_id = c.id WHERE s.id = ?");
        $stmt_detail->execute([$subject_id]);
        $detail = $stmt_detail->fetch();
        
        if ($detail) {
            try {
                $del = $pdo->prepare("DELETE FROM subjects WHERE id = ?");
                if ($del->execute([$subject_id])) {
                    $_SESSION['success_msg'] = "Subject '" . htmlspecialchars($detail['sub_name']) . "' removed from '" . htmlspecialchars($detail['class_name']) . "' successfully!";
                } else {
                    $_SESSION['error_msg'] = "Failed to delete subject mapping.";
                }
            } catch (PDOException $e) {
                if ($e->getCode() == '23000') {
                    $_SESSION['error_msg'] = "Cannot remove subject '" . htmlspecialchars($detail['sub_name']) . "' from '" . htmlspecialchars($detail['class_name']) . "' because it is currently linked to student marks, assignments, or exam results. Please delete those references first.";
                } else {
                    $_SESSION['error_msg'] = "Database error: " . $e->getMessage();
                }
            }
        }
        header("Location: academic.php");
        exit();
    }
    
    // Delete Class
    if ($action === 'delete_class' && isset($_GET['id'])) {
        $class_id = (int)$_GET['id'];
        // Get details
        $stmt_detail = $pdo->prepare("SELECT name FROM classes WHERE id = ?");
        $stmt_detail->execute([$class_id]);
        $class_name = $stmt_detail->fetchColumn();
        
        if ($class_name) {
            try {
                $pdo->beginTransaction();
                // 1. Delete associated subjects first
                $del_subs = $pdo->prepare("DELETE FROM subjects WHERE class_id = ?");
                $del_subs->execute([$class_id]);
                
                // 2. Delete class
                $del_cls = $pdo->prepare("DELETE FROM classes WHERE id = ?");
                $del_cls->execute([$class_id]);
                
                $pdo->commit();
                $_SESSION['success_msg'] = "Class '" . htmlspecialchars($class_name) . "' and all its mapped subjects deleted successfully!";
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                if ($e->getCode() == '23000') {
                    $_SESSION['error_msg'] = "Cannot delete class '" . htmlspecialchars($class_name) . "' because some of its subjects or the class itself are linked to active student marks, assignments, exam results, or timetables. Please delete those references first.";
                } else {
                    $_SESSION['error_msg'] = "Database error deleting class: " . $e->getMessage();
                }
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $_SESSION['error_msg'] = "Error deleting class: " . $e->getMessage();
            }
        }
        header("Location: academic.php");
        exit();
    }
}

// Session messages handler
if (isset($_SESSION['success_msg'])) {
    $success = $_SESSION['success_msg'];
    unset($_SESSION['success_msg']);
}
if (isset($_SESSION['error_msg'])) {
    $error = $_SESSION['error_msg'];
    unset($_SESSION['error_msg']);
}

// Fetch all classes & their subject counts
$stmt_classes = $pdo->query("SELECT c.*, COUNT(s.id) as subject_count FROM classes c LEFT JOIN subjects s ON c.id = s.class_id GROUP BY c.id ORDER BY c.id ASC");
$classes_list = $stmt_classes->fetchAll(PDO::FETCH_ASSOC);

// Fetch all mapped subjects grouped by class
$stmt_subjects = $pdo->query("SELECT s.*, c.name as class_name FROM subjects s JOIN classes c ON s.class_id = c.id ORDER BY c.id ASC, s.name ASC");
$subjects_list = $stmt_subjects->fetchAll(PDO::FETCH_ASSOC);

// Unique subject names for dropdown suggestions
$stmt_unique_subs = $pdo->query("SELECT DISTINCT name FROM subjects ORDER BY name ASC");
$unique_subjects = $stmt_unique_subs->fetchAll(PDO::FETCH_COLUMN);

// Group subjects by class_id for listing
$subjects_by_class = [];
foreach ($subjects_list as $sub) {
    $subjects_by_class[$sub['class_id']][] = $sub;
}

// Totals counts
$total_classes = count($classes_list);
$total_subjects = count($subjects_list);

require_once '../includes/header.php';
?>

<style>
/* ============================================================
   ACADEMIC MANAGEMENT — SUPREME GLASSMORPHISM DESIGN
   ============================================================ */

.academic-header {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%);
    border-radius: 20px;
    padding: 30px 36px;
    margin-bottom: 32px;
    position: relative;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(15,23,42,0.15);
}

.academic-header::before {
    content: '';
    position: absolute;
    top: -50px; right: -50px;
    width: 180px; height: 180px;
    background: rgba(255,255,255,0.03);
    border-radius: 50%;
}

.academic-header h2 {
    color: #fff;
    font-weight: 800;
    font-size: 1.80rem;
    margin: 0;
    position: relative;
    z-index: 1;
}

.academic-header p {
    color: rgba(255,255,255,0.6);
    margin: 6px 0 0;
    font-size: 0.95rem;
    position: relative;
    z-index: 1;
}

/* Glassmorphic Metrics Card */
.metric-card {
    background: rgba(255, 255, 255, 0.45);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.25);
    border-radius: 18px;
    padding: 24px;
    display: flex;
    align-items: center;
    gap: 20px;
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.05);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.metric-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 40px rgba(31, 38, 135, 0.1);
}
.metric-icon {
    width: 60px; height: 60px;
    border-radius: 14px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.6rem; color: #fff;
}
.metric-icon--blue {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
    box-shadow: 0 4px 14px rgba(59, 130, 246, 0.3);
}
.metric-icon--purple {
    background: linear-gradient(135deg, #8b5cf6, #6d28d9);
    box-shadow: 0 4px 14px rgba(139, 92, 246, 0.3);
}
.metric-details h3 {
    font-size: 1.8rem; font-weight: 800; margin: 0; color: #1e293b;
}
.metric-details p {
    font-size: 0.88rem; color: #64748b; margin: 0; font-weight: 500;
}

/* Premium Form Card Styles */
.premium-card {
    background: #ffffff;
    border-radius: 18px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.03);
    transition: all 0.3s ease;
}
.premium-card:hover {
    box-shadow: 0 8px 30px rgba(0,0,0,0.06);
}
.premium-card-header {
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
    padding: 18px 24px;
    border-top-left-radius: 18px;
    border-top-right-radius: 18px;
}
.premium-card-title {
    font-size: 1.05rem; font-weight: 700; color: #0f172a; margin: 0;
    display: flex; align-items: center; gap: 8px;
}
.premium-card-body {
    padding: 24px;
}

/* Custom Accordion Tree View */
.class-accordion .accordion-item {
    border: 1px solid #e2e8f0;
    border-radius: 12px !important;
    overflow: hidden;
    margin-bottom: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.01);
    transition: all 0.25s ease;
}
.class-accordion .accordion-item:hover {
    border-color: #cbd5e1;
    box-shadow: 0 4px 15px rgba(0,0,0,0.03);
}
.class-accordion .accordion-button {
    background: #ffffff;
    font-weight: 700;
    color: #1e293b;
    padding: 16px 20px;
    font-size: 0.98rem;
    box-shadow: none !important;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.class-accordion .accordion-button:not(.collapsed) {
    background: #f8fafc;
    color: #4f46e5;
}
.class-accordion .accordion-button::after {
    margin-left: auto;
}
.class-subject-badge {
    background: #f1f5f9;
    color: #334155;
    border: 1px solid #e2e8f0;
    padding: 8px 12px;
    border-radius: 8px;
    font-size: 0.82rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin: 4px;
    transition: all 0.2s ease;
}
.class-subject-badge:hover {
    background: #fee2e2;
    color: #ef4444;
    border-color: #fca5a5;
    transform: translateY(-1px);
}
.class-subject-badge .btn-delete-subject {
    border: none;
    background: none;
    padding: 0;
    color: #94a3b8;
    cursor: pointer;
    font-size: 0.8rem;
    display: flex;
    align-items: center;
    transition: color 0.2s ease;
}
.class-subject-badge:hover .btn-delete-subject {
    color: #ef4444;
}

.empty-state {
    padding: 40px;
    text-align: center;
    color: #94a3b8;
}
.empty-state i {
    font-size: 2.5rem;
    margin-bottom: 12px;
    color: #cbd5e1;
}

.text-indigo { color: #4f46e5 !important; }
.bg-indigo-light { background-color: rgba(79, 70, 229, 0.08) !important; color: #4f46e5 !important; }
.btn-indigo {
    background: linear-gradient(135deg, #4f46e5, #4338ca);
    color: #fff;
    font-weight: 600;
    border: none;
    transition: all 0.25s ease;
}
.btn-indigo:hover {
    background: linear-gradient(135deg, #4338ca, #3730a3);
    color: #fff;
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(79, 70, 229, 0.25);
}
</style>

<div class="container-fluid py-4">

    <!-- ===== NOTIFICATIONS ===== -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm border-0" style="border-radius: 12px; background: #ecfdf5; color: #065f46;">
            <div class="d-flex align-items-center">
                <i class="fa fa-check-circle me-3 fs-5" style="color: #10b981;"></i>
                <div>
                    <strong>Success!</strong> <?php echo $success; ?>
                </div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0" style="border-radius: 12px; background: #fef2f2; color: #991b1b;">
            <div class="d-flex align-items-center">
                <i class="fa fa-exclamation-triangle me-3 fs-5" style="color: #ef4444;"></i>
                <div>
                    <strong>Error!</strong> <?php echo $error; ?>
                </div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- ===== HEADER ===== -->
    <div class="academic-header d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h2><i class="fa fa-graduation-cap me-2 text-warning"></i> Academic Setup</h2>
            <p>Define classes, organize subject lists, and map class-subject combinations across the portal.</p>
        </div>
        <div>
            <a href="index.php" class="btn btn-light shadow-sm fw-bold px-4" style="border-radius: 10px; border: 1px solid #cbd5e1;">
                <i class="fa fa-arrow-left me-1"></i> Dashboard
            </a>
        </div>
    </div>

    <!-- ===== METRICS ORBS ===== -->
    <div class="row g-4 mb-4">
        <div class="col-md-6 col-xl-4">
            <div class="metric-card">
                <div class="metric-icon metric-icon--blue">
                    <i class="fa fa-school"></i>
                </div>
                <div class="metric-details">
                    <h3><?php echo $total_classes; ?></h3>
                    <p>Total Configured Classes</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-4">
            <div class="metric-card">
                <div class="metric-icon metric-icon--purple">
                    <i class="fa fa-book-open"></i>
                </div>
                <div class="metric-details">
                    <h3><?php echo $total_subjects; ?></h3>
                    <p>Total Mapped Subjects</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== MAIN CONTENT ROW ===== -->
    <div class="row g-4">
        
        <!-- Left Side: Interactive Add Actions -->
        <div class="col-lg-5">
            
            <!-- 1. Add Class Card -->
            <div class="premium-card mb-4">
                <div class="premium-card-header">
                    <h5 class="premium-card-title"><i class="fa fa-plus-circle text-primary"></i> Add Class</h5>
                </div>
                <div class="premium-card-body">
                    <form action="academic.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Class Name</label>
                            <input type="text" name="class_name" class="form-control" required placeholder="e.g. Class 1, Class 11-Science, Pre-Nursery">
                            <small class="text-muted">Enter the name of the new academic class group.</small>
                        </div>
                        <button type="submit" name="add_class" class="btn btn-primary w-100 fw-bold shadow-sm" style="border-radius: 10px; padding: 10px;">
                            <i class="fa fa-save me-1"></i> Create Class
                        </button>
                    </form>
                </div>
            </div>

            <!-- 2. Add/Map Subject Card -->
            <div class="premium-card">
                <div class="premium-card-header">
                    <h5 class="premium-card-title"><i class="fa fa-link text-indigo"></i> Map Subject to Class</h5>
                </div>
                <div class="premium-card-body">
                    <form action="academic.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Select Class</label>
                            <select name="class_id" class="form-select" required>
                                <option value="">-- Choose Class --</option>
                                <?php foreach ($classes_list as $cls): ?>
                                    <option value="<?php echo $cls['id']; ?>"><?php echo htmlspecialchars($cls['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Select Existing Subject</label>
                            <select name="subject_select" id="subject_select" class="form-select">
                                <option value="">-- Choose Existing Subject (or type custom below) --</option>
                                <?php foreach ($unique_subjects as $sub_name): ?>
                                    <option value="<?php echo htmlspecialchars($sub_name); ?>"><?php echo htmlspecialchars($sub_name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">OR Type Custom Subject Name</label>
                            <input type="text" name="subject_custom" id="subject_custom" class="form-control" placeholder="e.g. Sanskrit, German, Social Studies">
                            <small class="text-muted">Type here to add a completely new subject name to the system.</small>
                        </div>
                        <button type="submit" name="add_subject" class="btn btn-indigo w-100 fw-bold shadow-sm" style="border-radius: 10px; padding: 10px;">
                            <i class="fa fa-plus me-1"></i> Map Subject
                        </button>
                    </form>
                </div>
            </div>

        </div>

        <!-- Right Side: Class Accordion & Subjects Mapping List -->
        <div class="col-lg-7">
            
            <div class="premium-card h-100">
                <div class="premium-card-header d-flex justify-content-between align-items-center">
                    <h5 class="premium-card-title"><i class="fa fa-sitemap text-indigo"></i> Classes &amp; Subjects Matrix</h5>
                    <span class="badge bg-indigo-light px-3 py-2 fw-bold" style="border-radius: 8px;">
                        Interactive Tree View
                    </span>
                </div>
                <div class="premium-card-body">
                    <?php if (empty($classes_list)): ?>
                        <div class="empty-state">
                            <i class="fa fa-school"></i>
                            <h5>No Classes Defined Yet</h5>
                            <p>Get started by adding a new academic class in the form on the left.</p>
                        </div>
                    <?php else: ?>
                        <div class="accordion class-accordion" id="academicAccordion">
                            <?php foreach ($classes_list as $idx => $cls): ?>
                                <?php 
                                $classId = $cls['id'];
                                $mapped_subs = $subjects_by_class[$classId] ?? [];
                                $hasSubjects = !empty($mapped_subs);
                                ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading-<?php echo $classId; ?>">
                                        <div class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo $classId; ?>" aria-expanded="false" aria-controls="collapse-<?php echo $classId; ?>">
                                            <div class="d-flex align-items-center justify-content-between w-100 pe-3">
                                                <span>
                                                    <i class="fa fa-chalkboard text-muted me-2"></i>
                                                    <strong><?php echo htmlspecialchars($cls['name']); ?></strong>
                                                    <span class="badge bg-light text-secondary border ms-2">
                                                        <?php echo count($mapped_subs); ?> Subjects
                                                    </span>
                                                </span>
                                                <!-- Delete Class Trigger -->
                                                <button class="btn btn-sm btn-outline-danger border-0 btn-delete-class-trigger ms-auto"
                                                        data-id="<?php echo $classId; ?>"
                                                        data-name="<?php echo htmlspecialchars($cls['name']); ?>"
                                                        title="Delete class and all its subjects"
                                                        style="border-radius: 8px;">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </h2>
                                    <div id="collapse-<?php echo $classId; ?>" class="accordion-collapse collapse" aria-labelledby="heading-<?php echo $classId; ?>" data-bs-parent="#academicAccordion">
                                        <div class="accordion-body bg-light bg-opacity-25 p-3">
                                            <h6 class="text-secondary fw-bold small mb-2"><i class="fa fa-book me-1"></i> Mapped Subjects:</h6>
                                            <?php if (!$hasSubjects): ?>
                                                <p class="text-muted small mb-0"><i class="fa fa-info-circle me-1"></i> No subjects mapped to this class yet. Use the mapping form to assign subjects.</p>
                                            <?php else: ?>
                                                <div class="d-flex flex-wrap">
                                                    <?php foreach ($mapped_subs as $s): ?>
                                                        <span class="class-subject-badge">
                                                            <?php echo htmlspecialchars($s['name']); ?>
                                                            <button type="button" class="btn-delete-subject btn-delete-subject-trigger"
                                                                    data-id="<?php echo $s['id']; ?>"
                                                                    data-name="<?php echo htmlspecialchars($s['name']); ?>"
                                                                    data-class="<?php echo htmlspecialchars($cls['name']); ?>"
                                                                    title="Remove subject mapping">
                                                                <i class="fa fa-times-circle"></i>
                                                            </button>
                                                        </span>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

    </div>

</div>

<!-- SweetAlert2 Scripts -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {

    // 1. Delete Subject Mapping Handler
    const deleteSubjectButtons = document.querySelectorAll('.btn-delete-subject-trigger');
    deleteSubjectButtons.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation(); // Avoid accordion toggle
            const subjectId = this.getAttribute('data-id');
            const subjectName = this.getAttribute('data-name');
            const className = this.getAttribute('data-class');

            Swal.fire({
                title: 'Remove Subject Mapping?',
                text: `Are you sure you want to unmap '${subjectName}' from '${className}'?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Yes, Remove It!',
                cancelButtonText: 'Cancel'
            }).then(function (result) {
                if (result.isConfirmed) {
                    window.location.href = `academic.php?action=delete_subject&id=${subjectId}`;
                }
            });
        });
    });

    // 2. Delete Class Handler
    const deleteClassButtons = document.querySelectorAll('.btn-delete-class-trigger');
    deleteClassButtons.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation(); // Avoid accordion toggle
            const classId = this.getAttribute('data-id');
            const className = this.getAttribute('data-name');

            Swal.fire({
                title: 'Delete Entire Class?',
                text: `This will permanently delete '${className}' AND ALL associated subject mappings. This cannot be undone!`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Yes, Delete Everything!',
                cancelButtonText: 'Cancel'
            }).then(function (result) {
                if (result.isConfirmed) {
                    window.location.href = `academic.php?action=delete_class&id=${classId}`;
                }
            });
        });
    });

    // Sync select and custom subject inputs helper
    const subjectSelect = document.getElementById('subject_select');
    const subjectCustom = document.getElementById('subject_custom');
    if (subjectSelect && subjectCustom) {
        subjectSelect.addEventListener('change', function () {
            if (this.value !== '') {
                subjectCustom.value = ''; // Clear custom if select is picked
            }
        });
        subjectCustom.addEventListener('input', function () {
            if (this.value !== '') {
                subjectSelect.value = ''; // Clear select if typing custom
            }
        });
    }

});
</script>

<?php require_once '../includes/footer.php'; ?>

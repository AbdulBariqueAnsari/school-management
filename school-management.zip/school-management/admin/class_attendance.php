<?php
$module_key = 'attendance';
$module_title = 'Class Attendance';
$module_icon = 'fa-calendar-check';
require_once __DIR__ . '/includes/class_module.php';
?>

<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

// Pagination
$limit = 20;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Filters
$where = "WHERE 1=1";
$params = [];

if (!empty($_GET['user_id'])) {
    $where .= " AND a.user_id = ?";
    $params[] = $_GET['user_id'];
}

if (!empty($_GET['action'])) {
    $where .= " AND a.action LIKE ?";
    $params[] = '%' . $_GET['action'] . '%';
}

// Total Count
$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM audit_logs a $where");
$total_stmt->execute($params);
$total_logs = $total_stmt->fetchColumn();
$total_pages = ceil($total_logs / $limit);

// Fetch Logs
$stmt = $pdo->prepare("
    SELECT a.*, u.name as user_name, u.email as user_email, r.name as role_name 
    FROM audit_logs a 
    LEFT JOIN users u ON a.user_id = u.id 
    LEFT JOIN roles r ON u.role_id = r.id 
    $where 
    ORDER BY a.created_at DESC 
    LIMIT $limit OFFSET $offset
");
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch Users for Filter
$users = $pdo->query("SELECT id, name FROM users WHERE role_id != 6 ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 mb-0 fw-bold"><i class="fa fa-list-check text-primary me-2"></i> System Audit Logs</h2>
        <div class="d-flex align-items-center gap-3">
            <div class="text-muted small">Total Records: <?php echo number_format($total_logs); ?></div>
            <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="fa fa-arrow-left me-1"></i> Dashboard</a>
        </div>
    </div>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4" style="border-radius:12px;">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Filter by User</label>
                    <select name="user_id" class="form-select form-select-sm">
                        <option value="">All Users</option>
                        <?php foreach ($users as $u): ?>
                            <option value="<?php echo $u['id']; ?>" <?php echo (isset($_GET['user_id']) && $_GET['user_id'] == $u['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($u['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold">Search Action</label>
                    <input type="text" name="action" class="form-control form-select-sm" placeholder="e.g. login, update" value="<?php echo htmlspecialchars($_GET['action'] ?? ''); ?>">
                </div>
                <div class="col-md-4 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary btn-sm px-4">Apply Filters</button>
                    <a href="audit_logs.php" class="btn btn-outline-secondary btn-sm">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Logs Table -->
    <div class="card border-0 shadow-sm" style="border-radius:12px; overflow:hidden;">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4">Timestamp</th>
                        <th>User</th>
                        <th>Role</th>
                        <th>Action</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($logs) > 0): ?>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td class="ps-4 text-nowrap">
                                    <div class="fw-bold"><?php echo date('d M Y', strtotime($log['created_at'])); ?></div>
                                    <small class="text-muted"><?php echo date('H:i:s', strtotime($log['created_at'])); ?></small>
                                </td>
                                <td>
                                    <div class="fw-bold"><?php echo htmlspecialchars($log['user_name'] ?? 'System / Deleted'); ?></div>
                                    <small class="text-muted"><?php echo htmlspecialchars($log['user_email'] ?? ''); ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-secondary opacity-75 small">
                                        <?php echo htmlspecialchars($log['role_name'] ?? 'N/A'); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="text-dark py-2" style="max-width:300px;"><?php echo htmlspecialchars($log['action']); ?></div>
                                </td>
                                <td>
                                    <code class="text-muted small"><?php echo htmlspecialchars($log['ip_address'] ?: 'Internal'); ?></code>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">No logs found matching your criteria.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="card-footer bg-white border-0 py-3">
                <nav>
                    <ul class="pagination pagination-sm justify-content-center mb-0">
                        <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo isset($_GET['user_id']) ? '&user_id='.$_GET['user_id'] : ''; ?>">Previous</a>
                        </li>
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?php echo $page == $i ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?><?php echo isset($_GET['user_id']) ? '&user_id='.$_GET['user_id'] : ''; ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo isset($_GET['user_id']) ? '&user_id='.$_GET['user_id'] : ''; ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../dashboard.php");
    exit();
}

require_once '../includes/header.php';
?>

<style>
/* ============================================================
   MODULE HUB — identical card system to teachers.php
   ============================================================ */
.module-hub-header {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 55%, #0f3460 100%);
    border-radius: 20px;
    padding: 30px 36px;
    margin-bottom: 32px;
    position: relative;
    overflow: hidden;
}
.module-hub-header::before {
    content:''; position:absolute; top:-60px; right:-60px;
    width:200px; height:200px; background:rgba(255,255,255,0.05); border-radius:50%;
}
.module-hub-header::after {
    content:''; position:absolute; bottom:-80px; left:40px;
    width:160px; height:160px; background:rgba(255,255,255,0.03); border-radius:50%;
}
.module-hub-header h2 { color:#fff; font-weight:800; font-size:1.8rem; margin:0; position:relative; z-index:1; }
.module-hub-header p  { color:rgba(255,255,255,0.6); margin:4px 0 0; font-size:0.95rem; position:relative; z-index:1; }

.hub-btn {
    background:rgba(255,255,255,0.12);
    backdrop-filter:blur(8px);
    border:1px solid rgba(255,255,255,0.2);
    color:#fff !important;
    border-radius:10px;
    padding:9px 18px;
    font-weight:600; font-size:0.88rem;
    text-decoration:none;
    display:inline-flex; align-items:center; gap:7px;
    transition:all 0.25s ease;
}
.hub-btn:hover {
    background:rgba(255,255,255,0.22);
    transform:translateY(-2px);
    box-shadow:0 6px 20px rgba(0,0,0,0.25);
}

/* ---- Card Grid ---- */
.erp-card-grid {
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:24px;
}
@media (max-width:992px) { .erp-card-grid { grid-template-columns:repeat(2,1fr); } }
@media (max-width:576px) { .erp-card-grid { grid-template-columns:1fr; } }

.erp-card-link { text-decoration:none; display:block; }

.erp-card {
    background:rgba(255,255,255,0.15);
    backdrop-filter:blur(12px);
    -webkit-backdrop-filter:blur(12px);
    border:1px solid rgba(255,255,255,0.22);
    border-radius:16px;
    box-shadow:0 8px 30px rgba(0,0,0,0.12);
    padding:28px 22px;
    text-align:center;
    position:relative;
    overflow:hidden;
    cursor:pointer;
    transition:transform 0.35s cubic-bezier(0.34,1.56,0.64,1),
                box-shadow 0.35s ease, background 0.25s ease;
    opacity:0;
    transform:translateY(15px);
}
.erp-card.animated { opacity:1; transform:translateY(0); }
.erp-card:hover {
    transform:translateY(-8px) scale(1.025);
    box-shadow:0 20px 50px rgba(0,0,0,0.2);
    background:rgba(255,255,255,0.2);
    border-color:rgba(255,255,255,0.35);
}
.erp-card::before {
    content:''; position:absolute; top:-40px; right:-40px;
    width:110px; height:110px; border-radius:50%; opacity:0.15;
    transition:opacity 0.3s;
}
.erp-card:hover::before { opacity:0.25; }

/* Colour themes */
.erp-card--blue   { background:linear-gradient(135deg,rgba(13,110,253,0.18),rgba(255,255,255,0.08)); } .erp-card--blue::before   { background:#0d6efd; }
.erp-card--teal   { background:linear-gradient(135deg,rgba(20,184,166,0.18),rgba(255,255,255,0.08)); } .erp-card--teal::before   { background:#14b8a6; }
.erp-card--green  { background:linear-gradient(135deg,rgba(25,135,84,0.18),rgba(255,255,255,0.08));  } .erp-card--green::before  { background:#198754; }
.erp-card--yellow { background:linear-gradient(135deg,rgba(245,158,11,0.18),rgba(255,255,255,0.08));} .erp-card--yellow::before { background:#f59e0b; }
.erp-card--purple { background:linear-gradient(135deg,rgba(124,58,237,0.18),rgba(255,255,255,0.08));} .erp-card--purple::before { background:#7c3aed; }
.erp-card--red    { background:linear-gradient(135deg,rgba(220,53,69,0.18),rgba(255,255,255,0.08)); } .erp-card--red::before    { background:#dc3545; }
.erp-card--pink   { background:linear-gradient(135deg,rgba(236,72,153,0.18),rgba(255,255,255,0.08));} .erp-card--pink::before   { background:#ec4899; }
.erp-card--cyan   { background:linear-gradient(135deg,rgba(6,182,212,0.18),rgba(255,255,255,0.08)); } .erp-card--cyan::before   { background:#06b6d4; }
.erp-card--orange { background:linear-gradient(135deg,rgba(234,88,12,0.18),rgba(255,255,255,0.08)); } .erp-card--orange::before { background:#ea580c; }
.erp-card--indigo { background:linear-gradient(135deg,rgba(99,102,241,0.18),rgba(255,255,255,0.08));} .erp-card--indigo::before { background:#6366f1; }
.erp-card--grey   { background:linear-gradient(135deg,rgba(100,116,139,0.18),rgba(255,255,255,0.08));} .erp-card--grey::before  { background:#64748b; }
.erp-card--lime   { background:linear-gradient(135deg,rgba(101,163,13,0.18),rgba(255,255,255,0.08));} .erp-card--lime::before   { background:#65a30d; }

/* Icon */
.erp-card-icon {
    width:68px; height:68px; border-radius:16px;
    display:flex; align-items:center; justify-content:center;
    margin:0 auto 16px; font-size:1.7rem;
    position:relative; z-index:1;
    transition:transform 0.3s ease;
}
.erp-card:hover .erp-card-icon { transform:scale(1.1) rotate(-3deg); }

.i--blue   { background:linear-gradient(135deg,#0d6efd,#6610f2); color:#fff; }
.i--teal   { background:linear-gradient(135deg,#0d9488,#14b8a6); color:#fff; }
.i--green  { background:linear-gradient(135deg,#198754,#20c997); color:#fff; }
.i--yellow { background:linear-gradient(135deg,#f59e0b,#fcd34d); color:#fff; }
.i--purple { background:linear-gradient(135deg,#7c3aed,#a855f7); color:#fff; }
.i--red    { background:linear-gradient(135deg,#dc3545,#f43f5e); color:#fff; }
.i--pink   { background:linear-gradient(135deg,#db2777,#ec4899); color:#fff; }
.i--cyan   { background:linear-gradient(135deg,#0891b2,#06b6d4); color:#fff; }
.i--orange { background:linear-gradient(135deg,#ea580c,#f97316); color:#fff; }
.i--indigo { background:linear-gradient(135deg,#4f46e5,#6366f1); color:#fff; }
.i--grey   { background:linear-gradient(135deg,#475569,#64748b); color:#fff; }
.i--lime   { background:linear-gradient(135deg,#4d7c0f,#65a30d); color:#fff; }

.erp-card-title { font-size:1rem; font-weight:700; color:#1a1a2e; margin-bottom:4px; position:relative; z-index:1; }
.erp-card-sub   { font-size:0.8rem; color:#666; margin-bottom:14px; position:relative; z-index:1; line-height:1.4; }

.erp-card-arrow {
    position:absolute; bottom:16px; right:18px; font-size:0.88rem;
    color:rgba(0,0,0,0.22); transition:transform 0.25s ease, color 0.25s ease; z-index:1;
}
.erp-card:hover .erp-card-arrow { transform:translateX(4px); color:rgba(0,0,0,0.5); }

/* Sidebar match */
.sidebar, #sidebar { background:#212529 !important; border-right:1px solid rgba(255,255,255,0.1); }
.sidebar .nav-link, #sidebar .nav-link { color:rgba(255,255,255,0.7) !important; }
.sidebar .nav-link:hover, #sidebar .nav-link:hover { color:#fff !important; background:rgba(255,255,255,0.1); }
.sidebar .nav-link.active, #sidebar .nav-link.active { color:#fff !important; background:#0d6efd !important; }
</style>

<div class="container-fluid py-4">

    <!-- ===== HEADER ===== -->
    <div class="module-hub-header d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h2><i class="fa fa-certificate me-2"></i> Certificates Management</h2>
            <p>Generate and manage official certificates</p>
        </div>
        <div class="d-flex gap-2 flex-wrap" style="position:relative;z-index:1;">
            <a href="students.php" class="hub-btn"><i class="fa fa-arrow-left"></i> Back to Students</a>
        </div>
    </div>

    <!-- ===== CARD GRID ===== -->
    <div class="erp-card-grid">

        <!-- 1. Generate Certificates -->
        <a href="generate_certificates.php" class="erp-card-link">
            <div class="erp-card erp-card--yellow" data-delay="0">
                <div class="erp-card-icon i--yellow"><i class="fa fa-award"></i></div>
                <div class="erp-card-title">Generate Certificates</div>
                <div class="erp-card-sub">Issue achievement and completion certificates</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 2. Certificate Templates -->
        <a href="certificate_templates.php" class="erp-card-link">
            <div class="erp-card erp-card--purple" data-delay="80">
                <div class="erp-card-icon i--purple"><i class="fa fa-pen-ruler"></i></div>
                <div class="erp-card-title">Certificate Templates</div>
                <div class="erp-card-sub">Manage default layouts and configurations</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 3. Download Certificates -->
        <a href="download_certificates.php" class="erp-card-link">
            <div class="erp-card erp-card--teal" data-delay="160">
                <div class="erp-card-icon i--teal"><i class="fa fa-download"></i></div>
                <div class="erp-card-title">Download Certificates</div>
                <div class="erp-card-sub">Export batch certificates to PDF</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

        <!-- 4. Certificate Records -->
        <a href="certificate_records.php" class="erp-card-link">
            <div class="erp-card erp-card--indigo" data-delay="240">
                <div class="erp-card-icon i--indigo"><i class="fa fa-box-archive"></i></div>
                <div class="erp-card-title">Certificate Records</div>
                <div class="erp-card-sub">View history of issued certificates</div>
                <span class="erp-card-arrow"><i class="fa fa-arrow-right"></i></span>
            </div>
        </a>

    </div><!-- /.erp-card-grid -->
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const cards = document.querySelectorAll('.erp-card');
    cards.forEach(function (card) {
        const delay = parseInt(card.getAttribute('data-delay')) || 0;
        setTimeout(function () {
            card.style.transition = 'opacity 0.45s ease, transform 0.45s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.35s ease, background 0.25s ease';
            card.classList.add('animated');
        }, delay);
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>

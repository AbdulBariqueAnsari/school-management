<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$classes = ['Pre-Nursery', 'Nursery', 'LKG', 'UKG'];
for ($i = 1; $i <= 12; $i++) {
    $classes[] = "Class " . $i;
}

// Fetch Teachers grouped by class
$stmt = $pdo->query("SELECT * FROM teachers WHERE status = 'Approved' ORDER BY assigned_class, full_name");
$teachers_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

$class_map = [];
foreach ($teachers_raw as $t) {
    $class_map[$t['assigned_class']][] = $t;
}

require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="fa fa-layer-group text-info me-2"></i> Subject Teachers (Class-wise)</h2>
        <a href="teachers.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-1"></i> Back to Directory</a>
    </div>

    <div class="accordion shadow-sm border-0" id="classTeacherAccordion">
        <?php foreach ($classes as $index => $className): ?>
        <div class="accordion-item mb-2 border-0 rounded overflow-hidden">
            <h2 class="accordion-header" id="headingClass<?php echo $index; ?>">
                <button class="accordion-button collapsed fw-bold <?php echo isset($class_map[$className]) ? 'bg-white text-primary' : 'bg-light text-muted'; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapseClass<?php echo $index; ?>" aria-expanded="false" aria-controls="collapseClass<?php echo $index; ?>">
                    <i class="fa fa-chalkboard text-secondary me-2"></i> <?php echo htmlspecialchars($className); ?>
                    <?php if (isset($class_map[$className])): ?>
                        <span class="badge bg-primary ms-2"><?php echo count($class_map[$className]); ?> Assigned</span>
                    <?php
    else: ?>
                        <span class="badge bg-secondary ms-2">No Teachers</span>
                    <?php
    endif; ?>
                </button>
            </h2>
            <div id="collapseClass<?php echo $index; ?>" class="accordion-collapse collapse" aria-labelledby="headingClass<?php echo $index; ?>" data-bs-parent="#classTeacherAccordion">
                <div class="accordion-body bg-white p-0">
                    <?php if (isset($class_map[$className])): ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Subject</th>
                                        <th>Teacher Name</th>
                                        <th>ID</th>
                                        <th>Phone</th>
                                        <th class="text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($class_map[$className] as $teacher): ?>
                                    <tr>
                                        <td><span class="fw-bold text-dark"><?php echo htmlspecialchars($teacher['assigned_subject']); ?></span></td>
                                        <td>
                                            <a href="teacher_profile.php?id=<?php echo $teacher['id']; ?>" class="text-decoration-none">
                                                <img src="../uploads/profile/<?php echo $teacher['photo'] ?: 'default-teacher.png'; ?>" class="rounded-circle me-2" width="30" height="30" style="object-fit:cover;">
                                                <?php echo htmlspecialchars($teacher['full_name']); ?>
                                            </a>
                                        </td>
                                        <td><small class="text-muted"><?php echo htmlspecialchars($teacher['teacher_id']); ?></small></td>
                                        <td><?php echo htmlspecialchars($teacher['phone']); ?></td>
                                        <td class="text-end">
                                            <a href="teacher_profile.php?id=<?php echo $teacher['id']; ?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-eye"></i> Profile</a>
                                        </td>
                                    </tr>
                                    <?php
        endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php
    else: ?>
                        <div class="p-4 text-center text-muted italic">
                            No subject teachers assigned to <?php echo htmlspecialchars($className); ?> yet.
                        </div>
                    <?php
    endif; ?>
                </div>
            </div>
        </div>
        <?php
endforeach; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

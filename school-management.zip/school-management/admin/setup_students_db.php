<?php
/**
 * setup_students_db.php
 * Run this ONCE via browser: http://localhost/school-management/admin/setup_students_db.php
 * Resets/creates the students table and inserts 10 test records.
 */
require_once '../includes/auth.php';
require_once '../config/database_init.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    die('Access denied. Super Admin only.');
}

$log = [];

try {
    // STEP 1: Backup existing students data
    $pdo->exec("CREATE TABLE IF NOT EXISTS students_backup AS SELECT * FROM students");
    $log[] = "✅ Backup created: students_backup (old data preserved)";
}
catch (Exception $e) {
    $log[] = "⚠️  Backup note: " . $e->getMessage();
}

// STEP 2: Drop and recreate students table with FULL schema
try {
    $pdo->exec("DROP TABLE IF EXISTS students");
    $pdo->exec("CREATE TABLE students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        admission_no VARCHAR(50),
        student_name VARCHAR(150),
        gender VARCHAR(10),
        dob DATE,
        age INT,
        blood_group VARCHAR(10),
        aadhaar_number VARCHAR(20),
        student_photo VARCHAR(255),
        present_address TEXT,
        address TEXT,
        student_mobile VARCHAR(20),
        mobile_number VARCHAR(20),
        father_name VARCHAR(150),
        father_mobile VARCHAR(20),
        mother_name VARCHAR(150),
        mother_mobile VARCHAR(20),
        parent_name VARCHAR(150),
        parent_email VARCHAR(150),
        parent_phone VARCHAR(20),
        parents_address TEXT,
        guardian_name VARCHAR(150),
        relation VARCHAR(100),
        guardian_mobile VARCHAR(20),
        guardian_address TEXT,
        guardian_details TEXT,
        has_medical_condition TINYINT(1) DEFAULT 0,
        medical_condition_desc TEXT,
        has_disability TINYINT(1) DEFAULT 0,
        disability_desc TEXT,
        has_allergies TINYINT(1) DEFAULT 0,
        allergies_desc TEXT,
        religion VARCHAR(50),
        caste_category VARCHAR(50),
        mother_tongue VARCHAR(100),
        previous_schooling_status VARCHAR(100),
        class_applied VARCHAR(50),
        previous_class VARCHAR(50),
        previous_school_name VARCHAR(150),
        previous_school VARCHAR(150),
        previous_board VARCHAR(100),
        year_of_passing INT,
        username VARCHAR(100),
        email VARCHAR(150),
        password VARCHAR(255),
        status VARCHAR(20) DEFAULT 'Pending',
        admission_date DATE DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $log[] = "✅ students table recreated with full schema";
}
catch (Exception $e) {
    $log[] = "❌ Error recreating table: " . $e->getMessage();
    die(implode('<br>', $log));
}

// STEP 3: Insert 10 test students
$hash = password_hash('password123', PASSWORD_BCRYPT);

$students = [
    // 5 Approved
    [
        'ADM-2026-0001', 'Arjun Sharma', 'Male', '2010-05-15', 15, 'O+', '123456789012',
        null, '12 MG Road, Delhi', '9876543201', 'Ramesh Sharma', '9876543200',
        'Sunita Sharma', '9876543202', 'ramesh@example.com', '12 MG Road, Delhi',
        'Uncle Suresh', 'Uncle', '9876543203', '14 MG Road, Delhi',
        0, null, 0, null, 0, null,
        'Hindu', 'General', 'Hindi', 'Passed from Previous School',
        'Class 10', 'Class 9', 'Delhi Public School', 'Delhi Public School', 'CBSE', 2025,
        'student1', 'student1@school.com', $hash, 'Approved'
    ],
    [
        'ADM-2026-0002', 'Priya Patel', 'Female', '2011-03-22', 14, 'A+', '234567890123',
        null, '45 Nehru Nagar, Mumbai', '9876543211', 'Vikram Patel', '9876543210',
        'Meena Patel', '9876543212', 'vikram@example.com', '45 Nehru Nagar, Mumbai',
        '', '', '', '',
        0, null, 0, null, 0, null,
        'Hindu', 'OBC-A', 'Gujarati', 'Passed from Previous School',
        'Class 9', 'Class 8', 'Mumbai Vidyalay', 'Mumbai Vidyalay', 'SSC', 2024,
        'student2', 'student2@school.com', $hash, 'Approved'
    ],
    [
        'ADM-2026-0003', 'Mohammed Raza', 'Male', '2009-11-08', 16, 'B+', '345678901234',
        null, '78 Station Road, Hyderabad', '9876543221', 'Abdul Raza', '9876543220',
        'Fatima Raza', '9876543222', 'abdul@example.com', '78 Station Road, Hyderabad',
        '', '', '', '',
        1, 'Mild Asthma', 0, null, 1, 'Dust allergy',
        'Islam', 'OBC-B', 'Urdu', 'Transfer Certificate',
        'Class 11', 'Class 10', 'Hyderabad Govt School', 'Hyderabad Govt School', 'SSC', 2024,
        'student3', 'student3@school.com', $hash, 'Approved'
    ],
    [
        'ADM-2026-0004', 'Sneha Reddy', 'Female', '2012-07-19', 13, 'AB+', '456789012345',
        null, '23 Jubilee Hills, Bangalore', '9876543231', 'Ravi Reddy', '9876543230',
        'Lakshmi Reddy', '9876543232', 'ravi@example.com', '23 Jubilee Hills, Bangalore',
        'Aunt Kamala', 'Aunt', '9876543233', '25 Jubilee Hills, Bangalore',
        0, null, 1, 'Hearing impaired (mild)', 0, null,
        'Hindu', 'SC', 'Telugu', 'Currently Studying',
        'Class 8', 'Class 7', 'Bangalore Public School', 'Bangalore Public School', 'CBSE', 2024,
        'student4', 'student4@school.com', $hash, 'Approved'
    ],
    [
        'ADM-2026-0005', 'Rohan Gupta', 'Male', '2010-09-30', 15, 'O-', '567890123456',
        null, '56 Civil Lines, Kolkata', '9876543241', 'Sunil Gupta', '9876543240',
        'Anita Gupta', '9876543242', 'sunil@example.com', '56 Civil Lines, Kolkata',
        '', '', '', '',
        0, null, 0, null, 0, null,
        'Hindu', 'General', 'Bengali', 'Passed from Previous School',
        'Class 10', 'Class 9', 'Kolkata DAV School', 'Kolkata DAV School', 'CBSE', 2025,
        'student5', 'student5@school.com', $hash, 'Approved'
    ],
    // 5 Pending
    [
        'ADM-2026-0006', 'Anjali Singh', 'Female', '2011-02-14', 14, 'A-', '678901234567',
        null, '34 Awadh Nagar, Lucknow', '9876543251', 'Rajesh Singh', '9876543250',
        'Kavita Singh', '9876543252', 'rajesh@example.com', '34 Awadh Nagar, Lucknow',
        '', '', '', '',
        0, null, 0, null, 0, null,
        'Hindu', 'General', 'Hindi', 'Passed from Previous School',
        'Class 9', 'Class 8', 'Lucknow Public School', 'Lucknow Public School', 'CBSE', 2024,
        'student6', 'student6@school.com', $hash, 'Pending'
    ],
    [
        'ADM-2026-0007', 'Kiran Kumar', 'Male', '2012-06-25', 13, 'B-', '789012345678',
        null, '67 Gandhi Nagar, Chennai', '9876543261', 'Anil Kumar', '9876543260',
        'Usha Kumar', '9876543262', 'anil@example.com', '67 Gandhi Nagar, Chennai',
        '', '', '', '',
        0, null, 0, null, 1, 'Seasonal allergy',
        'Hindu', 'OBC-B', 'Tamil', 'Currently Studying',
        'Class 8', 'Class 7', 'Chennai Higher Sec School', 'Chennai Higher Sec School', 'State Board', 2024,
        'student7', 'student7@school.com', $hash, 'Pending'
    ],
    [
        'ADM-2026-0008', 'Fatima Ansari', 'Female', '2010-12-05', 15, 'O+', '890123456789',
        null, '89 HB Colony, Pune', '9876543271', 'Iqbal Ansari', '9876543270',
        'Zainab Ansari', '9876543272', 'iqbal@example.com', '89 HB Colony, Pune',
        'Uncle Salim', 'Uncle', '9876543273', '91 HB Colony, Pune',
        0, null, 0, null, 0, null,
        'Islam', 'OBC-A', 'Marathi', 'Passed from Previous School',
        'Class 10', 'Class 9', 'Pune Urdu School', 'Pune Urdu School', 'SSC', 2025,
        'student8', 'student8@school.com', $hash, 'Pending'
    ],
    [
        'ADM-2026-0009', 'Deepak Verma', 'Male', '2011-08-18', 14, 'AB-', '901234567890',
        null, '12 Shastri Nagar, Jaipur', '9876543281', 'Mukesh Verma', '9876543280',
        'Geeta Verma', '9876543282', 'mukesh@example.com', '12 Shastri Nagar, Jaipur',
        '', '', '', '',
        1, 'Diabetes Type 1', 0, null, 0, null,
        'Hindu', 'ST', 'Hindi', 'Transfer Certificate',
        'Class 9', 'Class 8', 'Jaipur Govt School', 'Jaipur Govt School', 'RBSE', 2024,
        'student9', 'student9@school.com', $hash, 'Pending'
    ],
    [
        'ADM-2026-0010', 'Pooja Nair', 'Female', '2009-04-10', 16, 'A+', '012345678901',
        null, '45 Kozhikode Lane, Kochi', '9876543291', 'Suresh Nair', '9876543290',
        'Sujatha Nair', '9876543292', 'suresh@example.com', '45 Kozhikode Lane, Kochi',
        '', '', '', '',
        0, null, 0, null, 0, null,
        'Hindu', 'General', 'Malayalam', 'Passed from Previous School',
        'Class 11', 'Class 10', 'Kerala Central School', 'Kerala Central School', 'CBSE', 2025,
        'student10', 'student10@school.com', $hash, 'Pending'
    ],
];

$sql = "INSERT INTO students 
    (admission_no, student_name, gender, dob, age, blood_group, aadhaar_number,
     student_photo, present_address, mobile_number, father_name, father_mobile,
     mother_name, mother_mobile, parent_email, parents_address,
     guardian_name, relation, guardian_mobile, guardian_address,
     has_medical_condition, medical_condition_desc, has_disability, disability_desc,
     has_allergies, allergies_desc,
     religion, caste_category, mother_tongue, previous_schooling_status,
     class_applied, previous_class, previous_school_name, previous_school, previous_board, year_of_passing,
     username, email, password, status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

$stmt = $pdo->prepare($sql);

foreach ($students as $i => $s) {
    try {
        $stmt->execute($s);
        $log[] = "✅ Inserted: {$s[0]} — {$s[1]} ({$s[39]})";
    }
    catch (Exception $e) {
        $log[] = "❌ Error inserting student " . ($i + 1) . ": " . $e->getMessage();
    }
}

// Set parent_name = father_name for display
$pdo->exec("UPDATE students SET parent_name = father_name WHERE parent_name IS NULL OR parent_name = ''");
$pdo->exec("UPDATE students SET parent_phone = father_mobile WHERE parent_phone IS NULL OR parent_phone = ''");
$pdo->exec("UPDATE students SET address = present_address WHERE address IS NULL OR address = ''");
$pdo->exec("UPDATE students SET student_mobile = mobile_number WHERE student_mobile IS NULL OR student_mobile = ''");

// Verify counts
$total = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$pending = $pdo->query("SELECT COUNT(*) FROM students WHERE status='Pending'")->fetchColumn();
$approved = $pdo->query("SELECT COUNT(*) FROM students WHERE status='Approved'")->fetchColumn();

$log[] = "-----";
$log[] = "📊 Total Students: $total";
$log[] = "📊 Pending: $pending";
$log[] = "📊 Approved: $approved";

?><!DOCTYPE html>
<html>
<head>
    <title>DB Setup Result</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">
<h2>🛠️ Database Setup Complete</h2>
<div class="card p-3 mt-3">
<?php foreach ($log as $line): ?>
    <p class="mb-1"><?php echo $line; ?></p>
<?php
endforeach; ?>
</div>
<div class="mt-4">
    <a href="admissions.php" class="btn btn-primary">→ Go to Admissions</a>
    <a href="students.php" class="btn btn-secondary ms-2">→ Go to Students</a>
</div>
<div class="mt-3 alert alert-warning">
    ⚠️ <strong>Security Note:</strong> Delete this file after running: <code>admin/setup_students_db.php</code>
</div>
</body>
</html>

<?php
require_once '../includes/auth.php';
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$classes = ['Pre-Nursery', 'Nursery', 'LKG', 'UKG'];
for ($i = 1; $i <= 12; $i++) {
    $classes[] = "Class " . $i;
}

// Fetch all approved teachers, group by class
$stmt = $pdo->query("SELECT * FROM teachers WHERE status = 'Approved' ORDER BY assigned_class, full_name");
$teachers_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

$class_map = [];
foreach ($teachers_raw as $t) {
    $class_map[$t['assigned_class']][] = $t;
}

$total = count($teachers_raw);

require_once '../includes/header.php';
?>
<?php include 'includes/teacher_page_styles.php'; ?>

<style>
.class-section {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.07);
    margin-bottom: 20px;
    overflow: hidden;
    border: 1px solid #eef0f2;
}

.class-section-header {
    background: linear-gradient(135deg, #6f42c1, #6610f2);
    color: #fff;
    padding: 14px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-weight: 700;
    font-size: 1rem;
    cursor: pointer;
    user-select: none;
    transition: background 0.25s;
}

.class-section-header:hover {
    background: linear-gradient(135deg, #5a32a3, #520dc2);
}

.class-section-header .toggle-icon {
    transition: transform 0.3s ease;
}

.class-section-header.open .toggle-icon {
    transform: rotate(180deg);
}

.class-section-body {
    display: none;
}
.class-section-body.open {
    display: block;
}

.cs-empty {
    padding: 20px;
    text-align: center;
    color: #aaa;
    font-size: 0.9rem;
}
</style>

<div class="container-fluid py-4">
    <div class="tp-header tp-header--purple">
        <div>
            <h2><i class="fa fa-layer-group me-2"></i> Subject Teachers</h2>
            <p>Teachers grouped by class assignment — <strong><?php echo $total; ?></strong> active teachers</p>
        </div>
        <div>
            <a href="teachers.php" class="tp-back-btn"><i class="fa fa-arrow-left me-1"></i> Back</a>
        </div>
    </div>

    <?php foreach ($classes as $className): ?>
    <?php $hasTeachers = !empty($class_map[$className]); ?>
    <div class="class-section">
        <div class="class-section-header <?php echo $hasTeachers ? '' : ''; ?>"
             onclick="toggleClass(this)">
            <span>
                <i class="fa fa-chalkboard me-2"></i>
                <?php echo htmlspecialchars($className); ?>
                <?php if ($hasTeachers): ?>
                    <span class="badge bg-white text-purple ms-2" style="color:#6f42c1;">
                        <?php echo count($class_map[$className]); ?> Teachers
                    </span>
                <?php
    else: ?>
                    <span class="badge bg-white bg-opacity-25 ms-2">No Teachers</span>
                <?php
    endif; ?>
            </span>
            <i class="fa fa-chevron-down toggle-icon"></i>
        </div>
        <div class="class-section-body">
            <?php if ($hasTeachers): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 tp-table">
                    <thead class="table-light">
                        <tr>
                            <th>Teacher</th>
                            <th>Subject</th>
                            <th>Designation</th>
                            <th>Experience</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($class_map[$className] as $t): ?>
                        <tr class="tp-row" data-id="<?php echo $t['id']; ?>">
                            <td>
                                <a href="teacher_profile.php?id=<?php echo $t['id']; ?>" class="d-flex align-items-center gap-2 text-decoration-none">
                                    <img src="../uploads/profile/<?php echo $t['photo'] ?: 'default-teacher.png'; ?>"
                                         class="rounded-circle border shadow-sm"
                                         width="38" height="38" style="object-fit:cover;"
                                         onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($t['full_name']); ?>&background=random'">
                                    <div>
                                        <span class="fw-bold text-dark d-block"><?php echo htmlspecialchars($t['full_name']); ?></span>
                                        <small class="text-muted"><?php echo htmlspecialchars($t['teacher_id']); ?></small>
                                    </div>
                                </a>
                            </td>
                            <td><span class="badge bg-purple bg-opacity-10 text-purple border" style="background:rgba(111,66,193,0.1);color:#6f42c1;border-color:rgba(111,66,193,0.3)!important;"><?php echo htmlspecialchars($t['assigned_subject']); ?></span></td>
                            <td><small><?php echo htmlspecialchars($t['designation']); ?></small></td>
                            <td><span class="fw-bold"><?php echo htmlspecialchars($t['experience_years']); ?></span> <small class="text-muted">yrs</small></td>
                            <td><small><?php echo htmlspecialchars($t['phone']); ?></small></td>
                        </tr>
                        <!-- Action Panel -->
                        <tr class="tp-action-row" id="panel-<?php echo $t['id']; ?>" style="display:none;">
                            <td colspan="5">
                                <div class="tp-action-panel">
                                    <a href="teacher_profile.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-view"><i class="fa fa-eye"></i> View</a>
                                    <a href="edit_teacher.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-edit"><i class="fa fa-edit"></i> Edit</a>
                                    <a href="actions/export_teacher.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-pdf" target="_blank"><i class="fa fa-file-pdf"></i> Export PDF</a>
                                    <button class="tp-btn tp-btn-delete btn-confirm"
                                            data-url="actions/delete_teacher.php?id=<?php echo $t['id']; ?>"
                                            data-title="Move to Trash?" data-text="Move this teacher to deleted records?" data-icon="warning" data-confirm="Yes, Delete">
                                        <i class="fa fa-trash"></i> Delete
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php
        endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php
    else: ?>
            <div class="cs-empty">
                <i class="fa fa-info-circle me-1"></i> No subject teachers assigned to <?php echo htmlspecialchars($className); ?> yet.
            </div>
            <?php
    endif; ?>
        </div>
    </div>
    <?php
endforeach; ?>

</div>

<script>
function toggleClass(header) {
    header.classList.toggle('open');
    const body = header.nextElementSibling;
    body.classList.toggle('open');
}
</script>

<?php include 'includes/teacher_page_scripts.php'; ?>
<?php require_once '../includes/footer.php'; ?>

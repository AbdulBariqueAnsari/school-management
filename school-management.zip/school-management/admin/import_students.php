<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../dashboard.php");
    exit();
}

// Handle CSV import POST
$import_result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    $imported = 0;
    $skipped = 0;
    $invalid = 0;
    $errors = [];

    if ($file['error'] !== 0) {
        $import_result = ['status' => 'error', 'msg' => 'File upload error. Please try again.'];
    }
    elseif (strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) !== 'csv') {
        $import_result = ['status' => 'error', 'msg' => 'Please upload a valid .csv file.'];
    }
    else {
        try {
            $pdo->beginTransaction();

            $handle = fopen($file['tmp_name'], 'r');
            $headers = fgetcsv($handle);
            $row_num = 1;

            while (($data = fgetcsv($handle)) !== false) {
                $row_num++;
                if (empty(array_filter($data)))
                    continue; // skip blank rows

                if (count($data) < count($headers)) {
                    $errors[] = "Row $row_num: Column mismatch — skipped.";
                    $invalid++;
                    continue;
                }

                $row = array_combine($headers, $data);

                // --- Required field check ---
                $full_name = trim($row['full_name'] ?? '');
                $father_name = trim($row['father_name'] ?? '');
                $phone = trim($row['mobile_number'] ?? $row['father_mobile'] ?? '');
                $username = trim($row['username'] ?? '');
                $email = trim($row['email'] ?? '');
                $class = trim($row['class_applying_for'] ?? '');

                if (empty($full_name) || empty($class) || empty($father_name) || empty($phone)) {
                    $errors[] = "Row $row_num: Missing required fields (Name, Class, Father Name, Phone) — skipped.";
                    $invalid++;
                    continue;
                }

                // Auto-generate username/email if missing
                if (empty($username))
                    $username = strtolower(str_replace(' ', '', $full_name)) . rand(100, 999);
                if (empty($email))
                    $email = $username . '@school.local';
                $password = trim($row['password'] ?? 'Pass@123');

                // --- Duplicate check (phone or email) ---
                $dup = $pdo->prepare("SELECT id FROM students WHERE student_mobile = ? OR (user_id IN (SELECT id FROM users WHERE email = ?)) LIMIT 1");
                $dup->execute([$phone, $email]);
                if ($dup->fetch()) {
                    $errors[] = "Row $row_num: Duplicate entry (phone/email) — skipped.";
                    $skipped++;
                    continue;
                }

                // Also check users table
                $dup2 = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
                $dup2->execute([$username, $email]);
                if ($dup2->fetch()) {
                    // Auto-fix: make unique username
                    $username = $username . rand(100, 999);
                }

                // 1. Create user account
                $usr = $pdo->prepare("INSERT INTO users (name, username, email, password, role_id, is_active) VALUES (?, ?, ?, ?, 6, 1)");
                $usr->execute([$full_name, $username, $email, password_hash($password, PASSWORD_DEFAULT)]);
                $user_id = $pdo->lastInsertId();

                // 2. Insert student record
                $ins = $pdo->prepare("INSERT INTO students (
                    user_id, student_name, dob, gender, blood_group, aadhaar_number,
                    present_address, student_mobile, religion, caste_category, mother_tongue,
                    father_name, father_mobile, mother_name, mother_mobile, parents_address,
                    guardian_name, relation, guardian_mobile, guardian_address,
                    has_medical_condition, medical_condition_desc, has_disability, disability_desc,
                    has_allergies, allergies_desc, previous_schooling_status, previous_class,
                    previous_school_name, previous_board, year_of_passing,
                    class_applied, status
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'Pending')");

                $ins->execute([
                    $user_id, $full_name,
                    $row['dob'] ?: null, $row['gender'] ?: 'Other', $row['blood_group'] ?: null, $row['aadhaar_number'] ?: null,
                    $row['present_address'] ?: null, $phone, $row['religion'] ?: null,
                    $row['caste_category'] ?: 'General', $row['mother_tongue'] ?: null,
                    $father_name, $row['father_mobile'] ?: null, $row['mother_name'] ?: null, $row['mother_mobile'] ?: null,
                    $row['parents_address'] ?: null, $row['guardian_name'] ?: null, $row['relation'] ?: null,
                    $row['guardian_mobile'] ?: null, $row['guardian_address'] ?: null,
                    $row['has_medical_condition'] === 'Yes' ? 1 : 0, $row['medical_condition_desc'] ?: null,
                    $row['has_disability'] === 'Yes' ? 1 : 0, $row['disability_desc'] ?: null,
                    $row['has_allergies'] === 'Yes' ? 1 : 0, $row['allergies_desc'] ?: null,
                    $row['previous_schooling_status'] ?: null, $row['previous_class'] ?: null,
                    $row['previous_school_name'] ?: null, $row['previous_board'] ?: null, $row['year_of_passing'] ?: null,
                    $class
                ]);

                $sid = $pdo->lastInsertId();
                $adm_no = 'ADM-' . date('Y') . '-' . str_pad($sid, 4, '0', STR_PAD_LEFT);
                $pdo->prepare("UPDATE students SET admission_no = ? WHERE id = ?")->execute([$adm_no, $sid]);

                $imported++;
            }
            fclose($handle);
            $pdo->commit();

            $import_result = [
                'status' => 'success',
                'imported' => $imported,
                'skipped' => $skipped,
                'invalid' => $invalid,
                'errors' => $errors
            ];

        }
        catch (Exception $e) {
            $pdo->rollBack();
            $import_result = ['status' => 'error', 'msg' => 'Import failed: ' . $e->getMessage()];
        }
    }
}

require_once '../includes/header.php';
?>
<?php include 'includes/student_page_styles.php'; ?>

<style>
/* Import page styles */
.import-hero {
    background: linear-gradient(135deg, #6366f1 0%, #4f46e5 50%, #4338ca 100%);
    border-radius: 20px;
    padding: 30px 36px;
    margin-bottom: 32px;
    position: relative;
    overflow: hidden;
}
.import-hero::before {
    content: ''; position: absolute; top: -50px; right: -50px;
    width: 180px; height: 180px; background: rgba(255,255,255,0.06); border-radius: 50%;
}
.import-hero h2 { color: #fff; font-weight: 800; margin: 0; position: relative; z-index: 1; }
.import-hero p  { color: rgba(255,255,255,0.65); margin: 4px 0 0; position: relative; z-index: 1; }

.import-glasscard {
    background: rgba(255,255,255,0.92);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(99,102,241,0.15);
    border-radius: 18px;
    box-shadow: 0 8px 32px rgba(99,102,241,0.1);
    padding: 36px 40px;
    margin-bottom: 24px;
}

.csv-dropzone {
    border: 2px dashed #a5b4fc;
    border-radius: 16px;
    background: linear-gradient(135deg, #eef2ff, #f5f3ff);
    padding: 50px 20px;
    text-align: center;
    transition: all 0.3s ease;
    cursor: pointer;
    position: relative;
}
.csv-dropzone:hover, .csv-dropzone.drag-over {
    border-color: #6366f1;
    background: linear-gradient(135deg, #e0e7ff, #ede9fe);
}
.csv-dropzone input[type=file] {
    position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%;
}
.csv-dropzone .dz-icon { font-size: 3rem; color: #6366f1; margin-bottom: 12px; }
.csv-dropzone .dz-text { color: #4f46e5; font-weight: 600; font-size: 1.05rem; }
.csv-dropzone .dz-sub  { color: #7c3aed; font-size: 0.85rem; margin-top: 6px; }
.csv-dropzone .dz-file-name { color: #312e81; font-weight: 700; margin-top: 10px; font-size: 0.95rem; display: none; }

.import-submit-btn {
    background: linear-gradient(135deg, #6366f1, #4f46e5);
    color: #fff;
    border: none;
    border-radius: 12px;
    padding: 14px 36px;
    font-weight: 700;
    font-size: 1rem;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    transition: all 0.25s ease;
    box-shadow: 0 4px 16px rgba(99,102,241,0.4);
}
.import-submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(99,102,241,0.5);
}

.template-btn {
    background: #f0fdf4;
    color: #166534 !important;
    border: 2px solid #86efac;
    border-radius: 12px;
    padding: 12px 28px;
    font-weight: 700;
    font-size: 0.9rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.25s ease;
}
.template-btn:hover {
    background: #dcfce7;
    border-color: #4ade80;
    transform: translateY(-1px);
}

.field-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: #f5f3ff;
    color: #6366f1;
    border: 1px solid #c7d2fe;
    border-radius: 8px;
    padding: 4px 10px;
    font-size: 0.78rem;
    font-weight: 600;
    margin: 3px;
}
.field-badge.required { background: #fff1f2; color: #be123c; border-color: #fecdd3; }

.result-card {
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 24px;
    animation: spSlide 0.4s ease;
}
.result-card.success { background: linear-gradient(135deg, #dcfce7, #f0fdf4); border: 1px solid #86efac; }
.result-card.error   { background: linear-gradient(135deg, #fff1f2, #fff5f5); border: 1px solid #fca5a5; }
.result-stat { text-align: center; }
.result-stat .num { font-size: 2.2rem; font-weight: 900; line-height: 1; }
.result-stat .lbl { font-size: 0.8rem; color: #666; font-weight: 600; margin-top: 4px; }
</style>

<div class="container-fluid py-4">

    <!-- HEADER -->
    <div class="import-hero d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h2><i class="fa fa-file-import me-2"></i> Bulk Student Import</h2>
            <p>Upload a CSV file to import multiple students at once — all go to Pending</p>
        </div>
        <a href="admissions.php" class="sp-back-btn"><i class="fa fa-arrow-left me-1"></i> Back to Admissions</a>
    </div>

    <!-- IMPORT RESULT DISPLAY -->
    <?php if ($import_result): ?>
    <?php if ($import_result['status'] === 'success'): ?>
    <div class="result-card success">
        <h5 class="fw-bold mb-3"><i class="fa fa-circle-check text-success me-2"></i> Import Complete</h5>
        <div class="row text-center">
            <div class="col-4 result-stat">
                <div class="num text-success"><?php echo $import_result['imported']; ?></div>
                <div class="lbl">Imported Successfully</div>
            </div>
            <div class="col-4 result-stat">
                <div class="num text-warning"><?php echo $import_result['skipped']; ?></div>
                <div class="lbl">Duplicates Skipped</div>
            </div>
            <div class="col-4 result-stat">
                <div class="num text-danger"><?php echo $import_result['invalid']; ?></div>
                <div class="lbl">Invalid Rows</div>
            </div>
        </div>
        <?php if (!empty($import_result['errors'])): ?>
        <div class="mt-3 p-3 bg-white rounded border">
            <p class="fw-bold text-muted small mb-2"><i class="fa fa-triangle-exclamation text-warning"></i> Row Warnings:</p>
            <?php foreach ($import_result['errors'] as $err): ?>
            <div class="small text-danger"><i class="fa fa-xmark me-1"></i><?php echo htmlspecialchars($err); ?></div>
            <?php
            endforeach; ?>
        </div>
        <?php
        endif; ?>
        <?php if ($import_result['imported'] > 0): ?>
        <div class="mt-3">
            <a href="pending_admissions.php" class="sp-btn sp-btn-approve" style="text-decoration:none;">
                <i class="fa fa-clock"></i> View Pending Admissions
            </a>
        </div>
        <?php
        endif; ?>
    </div>
    <?php
    elseif ($import_result['status'] === 'error'): ?>
    <div class="result-card error">
        <h5 class="fw-bold text-danger"><i class="fa fa-circle-xmark me-2"></i> Import Failed</h5>
        <p class="mb-0"><?php echo htmlspecialchars($import_result['msg']); ?></p>
    </div>
    <?php
    endif; ?>
    <?php
endif; ?>

    <div class="row g-4">
        <!-- LEFT: Upload form -->
        <div class="col-lg-7">
            <div class="import-glasscard">
                <h5 class="fw-bold mb-1"><i class="fa fa-upload me-2 text-indigo" style="color:#6366f1"></i> Upload CSV File</h5>
                <p class="text-muted small mb-4">Select a properly formatted CSV file. All students will be added as <strong>Pending</strong>.</p>

                <form method="POST" enctype="multipart/form-data" id="importForm">
                    <div class="csv-dropzone mb-4" id="dropzone">
                        <i class="fa fa-file-csv dz-icon"></i>
                        <div class="dz-text">Click or drag CSV file here</div>
                        <div class="dz-sub">Only .csv files accepted — max 5MB</div>
                        <div class="dz-file-name" id="fileName"></div>
                        <input type="file" name="csv_file" id="csvInput" accept=".csv" required>
                    </div>

                    <div class="d-flex gap-3 flex-wrap align-items-center">
                        <button type="submit" class="import-submit-btn" id="submitBtn">
                            <i class="fa fa-cloud-arrow-up"></i> Import Students
                        </button>
                        <a href="actions/generate_import_template.php" class="template-btn">
                            <i class="fa fa-file-excel"></i> Download CSV Template
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- RIGHT: CSV format guide -->
        <div class="col-lg-5">
            <div class="import-glasscard" style="height:100%;">
                <h5 class="fw-bold mb-1"><i class="fa fa-circle-info me-2" style="color:#6366f1"></i> CSV Format Guide</h5>
                <p class="text-muted small mb-3">Download the template above for the correct column order.</p>

                <p class="text-xs fw-bold text-danger mb-2"><i class="fa fa-asterisk"></i> Required Fields</p>
                <div class="mb-3">
                    <span class="field-badge required"><i class="fa fa-asterisk"></i> full_name</span>
                    <span class="field-badge required"><i class="fa fa-asterisk"></i> class_applying_for</span>
                    <span class="field-badge required"><i class="fa fa-asterisk"></i> father_name</span>
                    <span class="field-badge required"><i class="fa fa-asterisk"></i> mobile_number</span>
                </div>

                <p class="text-xs fw-bold text-muted mb-2">Optional Fields</p>
                <div class="mb-3">
                    <span class="field-badge">gender</span>
                    <span class="field-badge">dob</span>
                    <span class="field-badge">blood_group</span>
                    <span class="field-badge">mother_name</span>
                    <span class="field-badge">email</span>
                    <span class="field-badge">present_address</span>
                    <span class="field-badge">religion</span>
                    <span class="field-badge">caste_category</span>
                    <span class="field-badge">aadhaar_number</span>
                    <span class="field-badge">previous_school_name</span>
                    <span class="field-badge">previous_class</span>
                    <span class="field-badge">year_of_passing</span>
                </div>

                <div class="alert alert-info border-0 rounded-3 small" style="background:#eef2ff;">
                    <i class="fa fa-lightbulb me-1 text-indigo"></i>
                    <strong>Note:</strong> Duplicate entries (matching phone/email) are automatically skipped. Import auto-generates admission numbers and sets status to <em>Pending</em>.
                </div>

                <div class="alert border-0 rounded-3 small" style="background:#fef9c3;">
                    <i class="fa fa-triangle-exclamation me-1 text-warning"></i>
                    <strong>Date format:</strong> Use <code>YYYY-MM-DD</code> for <code>dob</code> and admission dates.
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// File picker UX
const input    = document.getElementById('csvInput');
const dropzone = document.getElementById('dropzone');
const fileName = document.getElementById('fileName');

input.addEventListener('change', function () {
    if (this.files.length > 0) {
        fileName.textContent = '✓ ' + this.files[0].name;
        fileName.style.display = 'block';
        dropzone.style.borderColor = '#6366f1';
        dropzone.style.background = 'linear-gradient(135deg, #e0e7ff, #ede9fe)';
    }
});

['dragover','dragenter'].forEach(e => {
    dropzone.addEventListener(e, function(ev) {
        ev.preventDefault();
        this.classList.add('drag-over');
    });
});
['dragleave','drop'].forEach(e => {
    dropzone.addEventListener(e, function(ev) { this.classList.remove('drag-over'); });
});

// Spinner on submit
document.getElementById('importForm').addEventListener('submit', function() {
    const btn = document.getElementById('submitBtn');
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Importing...';
    btn.disabled = true;
});
</script>

<?php require_once '../includes/footer.php'; ?>

<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../dashboard.php");
    exit();
}

$stmt = $pdo->query("SELECT * FROM students WHERE status='Deleted' ORDER BY created_at DESC");
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>
<?php include 'includes/student_page_styles.php'; ?>

<div class="container-fluid py-4">
    <div class="sp-header sp-header--grey">
        <div>
            <h2><i class="fa fa-trash-can me-2"></i> Deleted Students</h2>
            <p>Soft-deleted records — <strong><?php echo count($students); ?></strong> records</p>
        </div>
        <a href="admissions.php" class="sp-back-btn"><i class="fa fa-arrow-left me-1"></i> Back</a>
    </div>

    <?php if (empty($students)): ?>
        <div class="sp-empty"><i class="fa fa-trash-can fa-3x text-secondary mb-3"></i><p class="text-muted">No deleted student records found.</p></div>
    <?php
else: ?>
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 bg-white sp-table">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Admission No</th>
                        <th>Student Name</th>
                        <th>Parent Name</th>
                        <th>Class</th>
                        <th>Admission Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $i => $s): ?>
                    <tr class="sp-row" data-id="<?php echo $s['id']; ?>">
                        <td><span class="text-muted small"><?php echo $i + 1; ?></span></td>
                        <td><strong class="text-muted"><?php echo htmlspecialchars($s['admission_no'] ?? 'N/A'); ?></strong></td>
                        <td><span class="text-muted"><?php echo htmlspecialchars($s['student_name']); ?></span></td>
                        <td><small class="text-muted"><?php echo htmlspecialchars($s['parent_name'] ?? $s['father_name'] ?? 'N/A'); ?></small></td>
                        <td><small class="text-muted"><?php echo htmlspecialchars($s['class_applied'] ?? 'N/A'); ?></small></td>
                        <td><small class="text-muted"><?php echo date('d M Y', strtotime($s['created_at'])); ?></small></td>
                        <td><span class="badge bg-secondary">Deleted</span></td>
                    </tr>
                    <tr class="sp-action-row" id="sp-panel-<?php echo $s['id']; ?>" style="display:none;">
                        <td colspan="7">
                            <div class="sp-action-panel">
                                <button class="sp-btn sp-btn-restore sp-confirm"
                                    data-url="actions/restore_student.php?id=<?php echo $s['id']; ?>"
                                    data-title="Restore Student?" data-text="Restore this student to Pending status?" data-icon="info" data-confirm="Yes, Restore">
                                    <i class="fa fa-undo"></i> Restore
                                </button>
                                <button class="sp-btn sp-btn-purge sp-confirm"
                                    data-url="actions/delete_student_permanent.php?id=<?php echo $s['id']; ?>"
                                    data-title="Delete Permanently?" data-text="WARNING: This will permanently delete all records and logs. This cannot be undone!" data-icon="error" data-confirm="Yes, Purge">
                                    <i class="fa fa-fire"></i> Purge Permanently
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
    endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
endif; ?>
</div>

<?php include 'includes/student_page_scripts.php'; ?>
<?php require_once '../includes/footer.php'; ?>

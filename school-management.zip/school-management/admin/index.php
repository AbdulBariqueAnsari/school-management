<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

// --- Core Academic Metrics ---
$total_students_count = $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$total_teachers_count = $pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
$total_classes_count = $pdo->query("SELECT COUNT(*) FROM classes")->fetchColumn();
$total_sections_count = $pdo->query("SELECT COUNT(*) FROM sections")->fetchColumn();

// --- Student Specific Metrics ---
$student_active_count = $pdo->query("SELECT COUNT(*) FROM students WHERE status = 'Approved'")->fetchColumn();
$inactive_student_count = $pdo->query("SELECT COUNT(*) FROM students WHERE status = 'Rejected'")->fetchColumn();
$promoted_student_count = '0';

// Isolated Data System integration
$total_inquiries_count = '0';
$inquiries_file = '../data/inquiries.json';
if (file_exists($inquiries_file)) {
    $inq_data = json_decode(file_get_contents($inquiries_file), true);
    if (is_array($inq_data)) $total_inquiries_count = count($inq_data);
}

$appointments_file = '../data/appointments.json';
$total_appointments_count = 0;
if (file_exists($appointments_file)) {
    $apt_data = json_decode(file_get_contents($appointments_file), true);
    if (is_array($apt_data)) $total_appointments_count = count($apt_data);
}

$total_boys_count = $pdo->query("SELECT COUNT(*) FROM students WHERE gender = 'Male'")->fetchColumn();
$total_girls_count = $pdo->query("SELECT COUNT(*) FROM students WHERE gender = 'Female'")->fetchColumn();

// --- Finance Metrics (Placeholders) ---
$total_invoices_count = '0';
$paid_invoices_count = '0';
$unpaid_invoices_count = '0';
$partially_paid_invoices_count = '0';
$total_payments_count = '0';
$payment_received_count = '$0';
$amount_pending_count = '$0';
$expenses_count = '$0';
$donation_count = '$0';

// --- Exam Metrics (Placeholders) ---
$exam_published_timetables_count = '0';
$exams_published_admit_cards_count = '0';
$exams_published_results_count = '0';

// --- Staff & Admin Metrics ---
$total_admins_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role_id = 1")->fetchColumn();
$total_roles_count = $pdo->query("SELECT COUNT(*) FROM roles")->fetchColumn();
$total_staff_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role_id != 6 AND role_id != 7")->fetchColumn();
$staff_active_count = $total_staff_count;

// --- Library Metrics (Placeholders) ---
$total_books_count = '0';
$total_library_cards_count = '0';

// Fetch pending admissions
$pending_admissions_count = $pdo->query("SELECT COUNT(*) FROM students WHERE status = 'Pending'")->fetchColumn();
$recent_admissions = $pdo->query("SELECT * FROM students WHERE status = 'Pending' ORDER BY created_at DESC LIMIT 5")->fetchAll();

// Fetch recent audit logs
$recent_logs = $pdo->query("SELECT a.*, u.name as user_name FROM audit_logs a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT 5")->fetchAll();

require_once '../includes/header.php';
?>

<style>
/* ═══════════════════════════════════════════════════
   SUPER ADMIN DASHBOARD — Vivid Animated Cards v2
   ═══════════════════════════════════════════════════ */

@keyframes shimmer {
    0%   { background-position: -200% 0; }
    100% { background-position:  200% 0; }
}
@keyframes floatOrb {
    0%,100% { transform: translateY(0) scale(1); }
    50%     { transform: translateY(-8px) scale(1.05); }
}

/* Welcome bar */
.dash-welcome {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 60%, #0f3460 100%);
    border-radius: 18px;
    padding: 24px 30px;
    margin-bottom: 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
}
.dash-welcome h1 { color: #fff; font-size: 1.6rem; font-weight: 800; margin: 0; }
.dash-welcome p  { color: rgba(255,255,255,0.55); margin: 4px 0 0; font-size: 0.9rem; }
.dash-badge {
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.2);
    color: #fff; font-size: 0.8rem; font-weight: 700;
    padding: 6px 16px; border-radius: 20px; letter-spacing: 0.5px;
}

/* Section headings */
.dash-section-title {
    font-size: 0.78rem; font-weight: 800; letter-spacing: 1.4px;
    text-transform: uppercase; color: #64748b;
    margin: 30px 0 14px; padding-bottom: 9px;
    border-bottom: 1px solid #e2e8f0;
    display: flex; align-items: center; gap: 7px;
}

/* Grid */
.dash-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-bottom: 6px;
}
@media (max-width: 1200px) { .dash-grid { grid-template-columns: repeat(3, 1fr); } }
@media (max-width: 800px)  { .dash-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 480px)  { .dash-grid { grid-template-columns: 1fr; } }

/* ── STAT CARD ── */
.stat-card {
    border-radius: 18px;
    padding: 26px 18px 20px;
    position: relative;
    overflow: hidden;
    cursor: pointer;
    text-decoration: none !important;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    transition: transform 0.32s cubic-bezier(0.34,1.56,0.64,1),
                box-shadow 0.32s ease;
    border: none;
}
.stat-card:hover {
    transform: translateY(-8px) scale(1.02);
    text-decoration: none;
}

/* Animated shimmer overlay */
.stat-card::before {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(
        105deg,
        rgba(255,255,255,0)   30%,
        rgba(255,255,255,0.22) 50%,
        rgba(255,255,255,0)   70%
    );
    background-size: 200% 100%;
    animation: shimmer 3.5s linear infinite;
    pointer-events: none;
}

/* Decorative orb */
.stat-card::after {
    content: '';
    position: absolute;
    bottom: -28px; right: -28px;
    width: 100px; height: 100px;
    border-radius: 50%;
    background: rgba(255,255,255,0.12);
    animation: floatOrb 5s ease-in-out infinite;
}

/* ── Gradient backgrounds per colour ── */
.sc--blue   { background: linear-gradient(135deg,#2563eb,#3b82f6,#60a5fa); box-shadow: 0 10px 30px rgba(59,130,246,0.35); }
.sc--green  { background: linear-gradient(135deg,#16a34a,#22c55e,#4ade80); box-shadow: 0 10px 30px rgba(34,197,94,0.35);  }
.sc--teal   { background: linear-gradient(135deg,#0d9488,#14b8a6,#2dd4bf); box-shadow: 0 10px 30px rgba(20,184,166,0.35); }
.sc--purple { background: linear-gradient(135deg,#7c3aed,#a855f7,#c084fc); box-shadow: 0 10px 30px rgba(168,85,247,0.35); }
.sc--indigo { background: linear-gradient(135deg,#4338ca,#6366f1,#818cf8); box-shadow: 0 10px 30px rgba(99,102,241,0.35); }
.sc--orange { background: linear-gradient(135deg,#c2410c,#f97316,#fb923c); box-shadow: 0 10px 30px rgba(249,115,22,0.35); }
.sc--red    { background: linear-gradient(135deg,#b91c1c,#ef4444,#f87171); box-shadow: 0 10px 30px rgba(239,68,68,0.35);  }
.sc--yellow { background: linear-gradient(135deg,#b45309,#d97706,#fbbf24); box-shadow: 0 10px 30px rgba(234,179,8,0.35);  }
.sc--pink   { background: linear-gradient(135deg,#be185d,#ec4899,#f472b6); box-shadow: 0 10px 30px rgba(236,72,153,0.35); }
.sc--cyan   { background: linear-gradient(135deg,#0e7490,#06b6d4,#22d3ee); box-shadow: 0 10px 30px rgba(6,182,212,0.35);  }
.sc--grey   { background: linear-gradient(135deg,#334155,#64748b,#94a3b8); box-shadow: 0 10px 30px rgba(100,116,139,0.35);}
.sc--dark   { background: linear-gradient(135deg,#0f172a,#1e293b,#334155); box-shadow: 0 10px 30px rgba(30,41,59,0.35);   }
.sc--lime   { background: linear-gradient(135deg,#3f6212,#65a30d,#84cc16); box-shadow: 0 10px 30px rgba(132,204,22,0.35); }
.sc--rose   { background: linear-gradient(135deg,#be123c,#f43f5e,#fb7185); box-shadow: 0 10px 30px rgba(244,63,94,0.35);  }

/* Hover shadow boost */
.sc--blue:hover   { box-shadow: 0 18px 50px rgba(59,130,246,0.5);  }
.sc--green:hover  { box-shadow: 0 18px 50px rgba(34,197,94,0.5);   }
.sc--teal:hover   { box-shadow: 0 18px 50px rgba(20,184,166,0.5);  }
.sc--purple:hover { box-shadow: 0 18px 50px rgba(168,85,247,0.5);  }
.sc--indigo:hover { box-shadow: 0 18px 50px rgba(99,102,241,0.5);  }
.sc--orange:hover { box-shadow: 0 18px 50px rgba(249,115,22,0.5);  }
.sc--red:hover    { box-shadow: 0 18px 50px rgba(239,68,68,0.5);   }
.sc--yellow:hover { box-shadow: 0 18px 50px rgba(234,179,8,0.5);   }
.sc--pink:hover   { box-shadow: 0 18px 50px rgba(236,72,153,0.5);  }
.sc--cyan:hover   { box-shadow: 0 18px 50px rgba(6,182,212,0.5);   }
.sb--grey:hover   { box-shadow: 0 18px 50px rgba(100,116,139,0.5); }
.sc--dark:hover   { box-shadow: 0 18px 50px rgba(30,41,59,0.5);    }
.sc--lime:hover   { box-shadow: 0 18px 50px rgba(132,204,22,0.5);  }
.sc--rose:hover   { box-shadow: 0 18px 50px rgba(244,63,94,0.5);   }

/* Icon bubble — white frosted */
.stat-icon {
    width: 62px; height: 62px;
    border-radius: 16px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.65rem;
    margin-bottom: 16px;
    background: rgba(255,255,255,0.22);
    color: #fff;
    backdrop-filter: blur(4px);
    transition: transform 0.28s ease, background 0.28s ease;
    position: relative; z-index: 1;
}
.stat-card:hover .stat-icon {
    transform: scale(1.12) rotate(-5deg);
    background: rgba(255,255,255,0.32);
}

/* Overwrite all si-- colours — everything is white-on-colour now */
[class*="si--"] { background: rgba(255,255,255,0.22) !important; color: #fff !important; }

/* Number */
.stat-num {
    font-size: 2.6rem;
    font-weight: 900;
    color: #fff;
    line-height: 1;
    margin-bottom: 5px;
    position: relative; z-index: 1;
    transition: transform 0.22s ease;
    text-shadow: 0 2px 8px rgba(0,0,0,0.15);
}
.stat-card:hover .stat-num { transform: scale(1.08); }

/* Labels */
.stat-label {
    font-size: 0.95rem; font-weight: 700;
    color: rgba(255,255,255,0.95);
    margin-bottom: 3px; position: relative; z-index: 1;
}
.stat-sub {
    font-size: 0.78rem;
    color: rgba(255,255,255,0.65);
    position: relative; z-index: 1;
}

/* View link */
.stat-link {
    display: inline-flex; align-items: center; gap: 5px;
    font-size: 0.78rem; font-weight: 700; margin-top: 14px;
    color: rgba(255,255,255,0.8) !important;
    text-decoration: none;
    background: rgba(255,255,255,0.15);
    padding: 5px 14px; border-radius: 20px;
    transition: background 0.22s ease, color 0.22s ease;
    position: relative; z-index: 1;
}
.stat-card:hover .stat-link {
    background: rgba(255,255,255,0.28);
    color: #fff !important;
}

/* Bottom panels */
.dash-panel {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 14px rgba(0,0,0,0.06);
    overflow: hidden;
}
.dash-panel-header {
    padding: 16px 20px;
    border-bottom: 1px solid #f1f5f9;
    display: flex; align-items: center; justify-content: space-between;
}
.dash-panel-header h6 { margin: 0; font-weight: 700; font-size: 0.9rem; }

/* Sidebar compatibility */
.sidebar, #sidebar { background: #1e293b !important; }
.sidebar .nav-link, #sidebar .nav-link { color: rgba(255,255,255,0.65) !important; }
.sidebar .nav-link:hover, #sidebar .nav-link:hover { color: #fff !important; background: rgba(255,255,255,0.08); }
.sidebar .nav-link.active, #sidebar .nav-link.active { color: #fff !important; background: #3b82f6 !important; }
</style>

<!-- ── Welcome bar ── -->
<div class="dash-welcome">
    <div>
        <h1><i class="fa fa-gauge-high me-2 opacity-75"></i> Super Admin Dashboard</h1>
        <p>Welcome back — here's what's happening in your school today</p>
    </div>
    <span class="dash-badge"><i class="fa fa-circle text-success me-1" style="font-size:0.5rem;vertical-align:middle;"></i> System Online</span>
</div>

<!-- ════════════════════════════════
     SECTION 1 — Academic Core
═════════════════════════════════ -->
<div class="dash-section-title"><i class="fa fa-building-columns"></i> Academic Overview</div>
<div class="dash-grid">

    <a href="<?php echo BASE_URL; ?>/admin/students.php" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-users"></i></div>
        <div class="stat-num"><?php echo $total_students_count; ?></div>
        <div class="stat-label">Total Students</div>
        <div class="stat-sub">All registered students</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/teachers.php" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-chalkboard-user"></i></div>
        <div class="stat-num"><?php echo $total_teachers_count; ?></div>
        <div class="stat-label">Total Teachers</div>
        <div class="stat-sub">Teaching staff</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/class_teachers.php" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-school"></i></div>
        <div class="stat-num"><?php echo $total_classes_count; ?></div>
        <div class="stat-label">Total Classes</div>
        <div class="stat-sub">Active class groups</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>


</div>

<!-- ════════════════════════════════
     SECTION 2 — Student Metrics
═════════════════════════════════ -->
<div class="dash-section-title"><i class="fa fa-user-graduate"></i> Student Metrics</div>
<div class="dash-grid">

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=active_students" class="stat-card sc--green">
        <div class="stat-icon si--green"><i class="fa fa-user-check"></i></div>
        <div class="stat-num"><?php echo $student_active_count; ?></div>
        <div class="stat-label">Active Students</div>
        <div class="stat-sub">Currently enrolled</div>
        <span class="stat-link" style="color:#22c55e;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=inactive_students" class="stat-card sc--yellow">
        <div class="stat-icon si--yellow"><i class="fa fa-user-xmark"></i></div>
        <div class="stat-num"><?php echo $inactive_student_count; ?></div>
        <div class="stat-label">Inactive Students</div>
        <div class="stat-sub">Rejected / inactive</div>
        <span class="stat-link" style="color:#ca8a04;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>


    <a href="<?php echo BASE_URL; ?>/admin/admissions.php" class="stat-card sc--yellow">
        <div class="stat-icon si--yellow"><i class="fa fa-user-plus"></i></div>
        <div class="stat-num"><?php echo $pending_admissions_count; ?></div>
        <div class="stat-label">Pending Admissions</div>
        <div class="stat-sub">Awaiting approval</div>
        <span class="stat-link" style="color:#ca8a04;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/inquiry_dashboard.php" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-circle-question"></i></div>
        <div class="stat-num"><?php echo $total_inquiries_count; ?></div>
        <div class="stat-label">Total Inquiries</div>
        <div class="stat-sub">Student inquiries</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=boys" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-mars"></i></div>
        <div class="stat-num"><?php echo $total_boys_count; ?></div>
        <div class="stat-label">Total Boys</div>
        <div class="stat-sub">Male students</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=girls" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-venus"></i></div>
        <div class="stat-num"><?php echo $total_girls_count; ?></div>
        <div class="stat-label">Total Girls</div>
        <div class="stat-sub">Female students</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/appointments_dashboard.php" class="stat-card sc--purple">
        <div class="stat-icon si--purple"><i class="fa fa-calendar-check"></i></div>
        <div class="stat-num"><?php echo $total_appointments_count; ?></div>
        <div class="stat-label">Appointments</div>
        <div class="stat-sub">Visitor & Parent Meetings</div>
        <span class="stat-link" style="color:#a855f7;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

</div>

<!-- ════════════════════════════════
     SECTION 3 — Financial Records
═════════════════════════════════ -->
<div class="dash-section-title"><i class="fa fa-coins"></i> Financial Records</div>
<div class="dash-grid">

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=invoices" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-file-invoice"></i></div>
        <div class="stat-num"><?php echo $total_invoices_count; ?></div>
        <div class="stat-label">Total Invoices</div>
        <div class="stat-sub">All billing records</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=paid_invoices" class="stat-card sc--green">
        <div class="stat-icon si--green"><i class="fa fa-check-double"></i></div>
        <div class="stat-num"><?php echo $paid_invoices_count; ?></div>
        <div class="stat-label">Paid Invoices</div>
        <div class="stat-sub">Cleared payments</div>
        <span class="stat-link" style="color:#22c55e;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=unpaid_invoices" class="stat-card sc--red">
        <div class="stat-icon si--red"><i class="fa fa-file-invoice-dollar"></i></div>
        <div class="stat-num"><?php echo $unpaid_invoices_count; ?></div>
        <div class="stat-label">Unpaid Invoices</div>
        <div class="stat-sub">Pending dues</div>
        <span class="stat-link" style="color:#ef4444;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=partial_invoices" class="stat-card sc--yellow">
        <div class="stat-icon si--yellow"><i class="fa fa-circle-half-stroke"></i></div>
        <div class="stat-num"><?php echo $partially_paid_invoices_count; ?></div>
        <div class="stat-label">Partial Invoices</div>
        <div class="stat-sub">Partially cleared</div>
        <span class="stat-link" style="color:#ca8a04;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=payments" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-money-check-dollar"></i></div>
        <div class="stat-num"><?php echo(defined('APP_CURRENCY') ? APP_CURRENCY : '₹') . ' ' . $total_payments_count; ?></div>
        <div class="stat-label">Total Payments</div>
        <div class="stat-sub">All transactions</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=revenue" class="stat-card sc--green">
        <div class="stat-icon si--green"><i class="fa fa-hand-holding-dollar"></i></div>
        <div class="stat-num"><?php echo $payment_received_count; ?></div>
        <div class="stat-label">Amount Received</div>
        <div class="stat-sub">Revenue collected</div>
        <span class="stat-link" style="color:#22c55e;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=pending" class="stat-card sc--red">
        <div class="stat-icon si--red"><i class="fa fa-hourglass-half"></i></div>
        <div class="stat-num"><?php echo $amount_pending_count; ?></div>
        <div class="stat-label">Amount Pending</div>
        <div class="stat-sub">Dues outstanding</div>
        <span class="stat-link" style="color:#ef4444;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=expenses" class="stat-card sc--red">
        <div class="stat-icon si--red"><i class="fa fa-receipt"></i></div>
        <div class="stat-num"><?php echo $expenses_count; ?></div>
        <div class="stat-label">Expenses</div>
        <div class="stat-sub">Total expenditure</div>
        <span class="stat-link" style="color:#ef4444;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>


</div>

<!-- ════════════════════════════════
     SECTION 4 — Exams & Library
═════════════════════════════════ -->
<div class="dash-section-title"><i class="fa fa-book-open"></i> Exams &amp; Library</div>
<div class="dash-grid">

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=timetables" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-calendar-days"></i></div>
        <div class="stat-num"><?php echo $exam_published_timetables_count; ?></div>
        <div class="stat-label">Exams w/ Timetables</div>
        <div class="stat-sub">Published schedules</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=admit_cards" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-address-card"></i></div>
        <div class="stat-num"><?php echo $exams_published_admit_cards_count; ?></div>
        <div class="stat-label">Exams w/ Admit Cards</div>
        <div class="stat-sub">Issued admit cards</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=results" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-graduation-cap"></i></div>
        <div class="stat-num"><?php echo $exams_published_results_count; ?></div>
        <div class="stat-label">Exams w/ Results</div>
        <div class="stat-sub">Published results</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>



</div>

<!-- ════════════════════════════════
     SECTION 5 — Staff & Admin
═════════════════════════════════ -->
<div class="dash-section-title"><i class="fa fa-user-shield"></i> Staff &amp; Administration</div>
<div class="dash-grid">

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=admins" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-user-tie"></i></div>
        <div class="stat-num"><?php echo $total_admins_count; ?></div>
        <div class="stat-label">Total Admins</div>
        <div class="stat-sub">Super administrators</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=roles" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-users-gear"></i></div>
        <div class="stat-num"><?php echo $total_roles_count; ?></div>
        <div class="stat-label">Total Roles</div>
        <div class="stat-sub">Permission groups</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=staff" class="stat-card sc--blue">
        <div class="stat-icon si--blue"><i class="fa fa-user-group"></i></div>
        <div class="stat-num"><?php echo $total_staff_count; ?></div>
        <div class="stat-label">Total Staff</div>
        <div class="stat-sub">All non-student users</div>
        <span class="stat-link" style="color:#3b82f6;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

    <a href="<?php echo BASE_URL; ?>/admin/placeholder.php?type=active_staff" class="stat-card sc--green">
        <div class="stat-icon si--green"><i class="fa fa-user-nurse"></i></div>
        <div class="stat-num"><?php echo $staff_active_count; ?></div>
        <div class="stat-label">Active Staff</div>
        <div class="stat-sub">Currently working</div>
        <span class="stat-link" style="color:#22c55e;">View All <i class="fa fa-arrow-right" style="font-size:0.65rem;"></i></span>
    </a>

</div>

<!-- ════════════════════════════════
     BOTTOM PANELS
═════════════════════════════════ -->
<div class="row mt-4 g-4">
    <!-- Recent Pending Admissions -->
    <div class="col-md-8">
        <div class="dash-panel">
            <div class="dash-panel-header">
                <h6><i class="fa fa-clock text-warning me-2"></i> Recent Pending Admissions</h6>
                <a href="<?php echo BASE_URL; ?>/admin/admissions.php" class="btn btn-sm btn-primary" style="border-radius:8px;font-size:0.78rem;">Manage All</a>
            </div>
            <div class="p-3">
                <?php if (count($recent_admissions) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size:0.85rem;">
                        <thead class="table-light">
                            <tr>
                                <th>Date</th>
                                <th>Student Name</th>
                                <th>Parent Name</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_admissions as $app): ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($app['created_at'])); ?></td>
                                <td><strong><?php echo htmlspecialchars($app['student_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($app['parent_name']); ?></td>
                                <td><span class="badge bg-warning text-dark"><?php echo htmlspecialchars($app['status']); ?></span></td>
                            </tr>
                            <?php
    endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php
else: ?>
                <p class="text-muted mb-0 py-3">No pending admissions at the moment.</p>
                <?php
endif; ?>
            </div>
        </div>
    </div>

    <!-- Audit Logs -->
    <div class="col-md-4">
        <div class="dash-panel" style="height:100%;">
            <div class="dash-panel-header">
                <h6><i class="fa fa-list-check text-primary me-2"></i> Recent Audit Logs</h6>
                <a href="<?php echo BASE_URL; ?>/admin/audit_logs.php" class="btn btn-sm btn-outline-secondary" style="border-radius:8px;font-size:0.78rem;">View All</a>
            </div>
            <?php if (count($recent_logs) > 0): ?>
            <ul class="list-group list-group-flush">
                <?php foreach ($recent_logs as $log): ?>
                <li class="list-group-item d-flex justify-content-between align-items-start py-3">
                    <div>
                        <div class="fw-bold" style="font-size:0.82rem;"><?php echo htmlspecialchars($log['user_name'] ?? 'System'); ?></div>
                        <small class="text-muted"><?php echo htmlspecialchars($log['action']); ?></small>
                    </div>
                    <small class="text-muted ms-2 text-nowrap"><?php echo date('M d, H:i', strtotime($log['created_at'])); ?></small>
                </li>
                <?php
    endforeach; ?>
            </ul>
            <?php
else: ?>
            <p class="text-muted p-3 mb-0">No recent activity.</p>
            <?php
endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

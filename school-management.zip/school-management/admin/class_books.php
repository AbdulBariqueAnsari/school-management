<?php
$module_key = 'books';
$module_title = 'Class Books';
$module_icon = 'fa-book';
require_once __DIR__ . '/includes/class_module.php';
?>

<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

// Fetch all classes and their assigned Class Teachers
$classes = ['Pre-Nursery', 'Nursery', 'LKG', 'UKG'];
for ($i = 1; $i <= 12; $i++) {
    $classes[] = "Class " . $i;
}

// Map Class Teachers
$stmt = $pdo->query("SELECT * FROM teachers WHERE role='class_teacher' AND status='Approved'");
$teachers_db = $stmt->fetchAll(PDO::FETCH_ASSOC);

$class_teachers = [];
foreach ($teachers_db as $t) {
    if (!empty($t['class_teacher_of'])) {
        $classes_array = array_filter(array_map('trim', explode(',', $t['class_teacher_of'])));
        foreach ($classes_array as $cls_name) {
            $class_teachers[$cls_name] = $t;
        }
    }
}

require_once '../includes/header.php';
?>

<style>
/* Modern ERP UI Upgrades (Imported from teachers Dashboard) */
.glass-card {
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    border-radius: 16px;
    border: 1px solid rgba(255,255,255,0.2);
    box-shadow: 0 8px 30px rgba(0,0,0,0.12);
    cursor: pointer;
    text-align: center;
}

.widget-animate {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    animation: slideUp 0.5s ease-out forwards;
    opacity: 0;
}

@keyframes slideUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

.widget-animate:hover {
    transform: translateY(-5px) scale(1.03);
    box-shadow: 0 15px 35px rgba(0,0,0,0.2) !important;
}

.widget-animate:hover i {
    text-shadow: 0 0 10px rgba(255,255,255,0.8);
}

.neumorphic-btn {
    background: #f0f0f0;
    border-radius: 10px;
    box-shadow: 6px 6px 12px #cfcfcf, -6px -6px 12px #ffffff;
    border: none;
    color: #333;
    font-weight: 600;
    padding: 10px 20px;
    transition: all 0.2s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
}

.neumorphic-btn:hover {
    box-shadow: inset 6px 6px 12px #cfcfcf, inset -6px -6px 12px #ffffff;
    color: #000;
}

.neumorphic-btn i {
    margin-right: 8px;
}

/* Professional Dark Sidebar */
.sidebar, #sidebar {
    background: #212529 !important; /* Dark charcoal */
    border-right: 1px solid rgba(255,255,255,0.1);
}

/* Ensure menu items have good contrast */
.sidebar .nav-link, #sidebar .nav-link {
    color: rgba(255,255,255,0.7) !important;
}

.sidebar .nav-link:hover, #sidebar .nav-link:hover {
    color: #fff !important;
    background: rgba(255,255,255,0.1);
}

.sidebar .nav-link.active, #sidebar .nav-link.active {
    color: #fff !important;
    background: #0d6efd !important;
}

/* Specific Class Card Colors - Repeating pattern */
.bg-gradient-1 { background: linear-gradient(135deg, #a1c4fd 0%, #c2e9fb 100%); }
.bg-gradient-2 { background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%); }
.bg-gradient-3 { background: linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%); }
.bg-gradient-4 { background: linear-gradient(135deg, #f6d365 0%, #fda085 100%); text-white; }
</style>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="fa fa-chalkboard text-primary me-2"></i> Class Teachers Management</h2>
        <div class="d-flex gap-2">
            <a href="teachers.php" class="neumorphic-btn"><i class="fa fa-arrow-left text-secondary"></i> Back to Teachers</a>
        </div>
    </div>

    <div class="row g-4 mb-5">
        <?php
$delay = 0;
$color_idx = 1;
foreach ($classes as $class_name):
    $has_teacher = isset($class_teachers[$class_name]);
    $teacher = $has_teacher ? $class_teachers[$class_name] : null;

    // Optional gradient coloring pattern
    $gradient_class = "bg-gradient-" . $color_idx;
    $color_idx = $color_idx >= 4 ? 1 : $color_idx + 1;
?>
            <div class="col-6 col-md-4 col-lg-3">
                <div class="glass-card widget-animate p-4 <?php echo $gradient_class; ?>" style="animation-delay: <?php echo $delay; ?>s;"
                    onclick="openTeacherModal('<?php echo htmlspecialchars($class_name); ?>', 
                                            '<?php echo $has_teacher ? addslashes($teacher['full_name']) : 'Not Assigned'; ?>', 
                                            '<?php echo $has_teacher ? addslashes($teacher['photo']) : 'default-teacher.png'; ?>', 
                                            '<?php echo $has_teacher ? addslashes($teacher['assigned_subject']) : 'N/A'; ?>', 
                                            '<?php echo $has_teacher ? addslashes($teacher['experience_years']) . ' Years' : 'N/A'; ?>')">
                    
                    <div class="mb-3">
                        <?php if ($has_teacher): ?>
                            <img src="../uploads/profile/<?php echo htmlspecialchars($teacher['photo']); ?>" alt="Teacher" class="rounded-circle shadow" style="width: 80px; height: 80px; object-fit: cover; border: 3px solid white;">
                        <?php
    else: ?>
                            <div class="rounded-circle d-inline-flex align-items-center justify-content-center bg-white shadow-sm" style="width: 80px; height: 80px; border: 3px solid #eee;">
                                <i class="fa fa-user-slash fa-2x text-muted"></i>
                            </div>
                        <?php
    endif; ?>
                    </div>
                    
                    <h4 class="fw-bold mb-1 text-dark"><?php echo $class_name; ?></h4>
                    
                    <?php if ($has_teacher): ?>
                        <p class="text-success small mb-0 fw-bold"><i class="fa fa-check-circle me-1"></i> <?php echo $teacher['full_name']; ?></p>
                    <?php
    else: ?>
                        <p class="text-danger small mb-0"><i class="fa fa-exclamation-triangle me-1"></i> Not Assigned</p>
                    <?php
    endif; ?>
                </div>
            </div>
        <?php
    $delay += 0.05;
endforeach;
?>
    </div>
</div>

<!-- Teacher Details Modal -->
<div class="modal fade" id="teacherModal" tabindex="-1" aria-labelledby="teacherModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content glass-card border-0" style="background: rgba(255,255,255,0.95);">
      <div class="modal-header border-bottom-0 pb-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center pt-0">
        <h3 class="fw-bold mb-4" id="modalClassName">Class Name</h3>
        
        <div class="mb-3">
             <img src="" id="modalTeacherPhoto" alt="Teacher" class="rounded-circle shadow-lg" style="width: 120px; height: 120px; object-fit: cover; border: 5px solid white;">
        </div>
        
        <h4 class="fw-bold text-primary mb-1" id="modalTeacherName">Teacher Name</h4>
        <p class="text-muted mb-4">Class Teacher</p>
        
        <div class="row text-start bg-light rounded-3 p-3 mb-4 mx-2 shadow-sm">
            <div class="col-6 mb-2">
                <small class="text-muted d-block">Subject</small>
                <strong id="modalTeacherSubject">Subject Name</strong>
            </div>
            <div class="col-6 mb-2">
                <small class="text-muted d-block">Experience</small>
                <strong id="modalTeacherExperience">X Years</strong>
            </div>
        </div>
        
        <a href="#" id="modalViewClassBtn" class="neumorphic-btn w-100 justify-content-center mb-2">
            <i class="fa fa-door-open text-primary"></i> View Class Dashboard
        </a>
      </div>
    </div>
  </div>
</div>

<script>
function openTeacherModal(className, teacherName, photo, subject, experience) {
    document.getElementById('modalClassName').innerText = className;
    
    // Fallback logic if needed, but relative path should work
    let photoPath = photo === 'default-teacher.png' ? '../assets/images/default-user.png' : '../uploads/profile/' + photo;
    document.getElementById('modalTeacherPhoto').src = photoPath;
    
    document.getElementById('modalTeacherName').innerText = teacherName;
    document.getElementById('modalTeacherSubject').innerText = subject;
    document.getElementById('modalTeacherExperience').innerText = experience;
    
    // Set dynamic link to Class View Dashboard
    let classUrl = "class_view.php?class=" + encodeURIComponent(className);
    document.getElementById('modalViewClassBtn').href = classUrl;
    
    let modalEl = document.getElementById('teacherModal');
    // Move modal to body to prevent stacking context (blur/unclickable) issues
    if (modalEl.parentNode !== document.body) {
        document.body.appendChild(modalEl);
    }
    
    // Use getOrCreateInstance instead of instantiating manually each time to prevent duplicate backdrops
    var myModal = bootstrap.Modal.getOrCreateInstance(modalEl);
    myModal.show();
}
</script>

<?php require_once '../includes/footer.php'; ?>

<?php
$module_key = 'marks';
$module_title = 'Class Marks';
$module_icon = 'fa-chart-line';
require_once __DIR__ . '/includes/class_module.php';
?>

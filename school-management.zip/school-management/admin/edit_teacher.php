<?php
require_once '../includes/auth.php';

// Super Admin Check
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
$stmt->execute([$id]);
$teacher = $stmt->fetch();

if (!$teacher) {
    die("Teacher not found.");
}

$success = '';
$error = '';

$cbse_subjects = $pdo->query("SELECT DISTINCT name FROM subjects ORDER BY name ASC")->fetchAll(PDO::FETCH_COLUMN);
if (empty($cbse_subjects)) {
    $cbse_subjects = [
        'English', 'Hindi', 'Mathematics', 'EVS', 'Science', 'Social Science', 'Computer Science',
        'General Knowledge', 'Moral Science', 'Drawing', 'Music', 'Physical Education',
        'Physics', 'Chemistry', 'Biology', 'Economics', 'Accountancy', 'Business Studies',
        'Political Science', 'History', 'Geography', 'Informatics Practices'
    ];
}

$classes = $pdo->query("SELECT name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_COLUMN);
if (empty($classes)) {
    $classes = ['Pre-Nursery', 'Nursery', 'LKG', 'UKG'];
    for ($i = 1; $i <= 12; $i++) {
        $classes[] = "Class " . $i;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    try {
        $pdo->beginTransaction();

        $full_name = trim($_POST['full_name']);
        $gender = $_POST['gender'];
        $dob = $_POST['dob'];
        $age = (int)$_POST['age'];
        $blood_group = $_POST['blood_group'];
        $aadhaar = trim($_POST['aadhaar']);

        // Photo Upload Handling
        $photo = $teacher['photo'];
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
            $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $filename = time() . '_' . uniqid() . '.' . $ext;
            if (move_uploaded_file($_FILES['photo']['tmp_name'], '../uploads/profile/' . $filename)) {
                $photo = $filename;
            }
        }

        $phone = trim($_POST['phone']);
        $email = trim($_POST['email']);
        $present_address = trim($_POST['present_address']);
        $permanent_address = trim($_POST['permanent_address']);

        $qualification = trim($_POST['qualification']);
        $specialization = trim($_POST['specialization']);
        $experience_years = (int)$_POST['experience_years'];
        $previous_school = trim($_POST['previous_school']);
        $year_of_joining = $_POST['year_of_joining'];
        $designation = $_POST['designation'];
        $employment_type = $_POST['employment_type'];

        $assigned_subject_ids_arr = isset($_POST['assigned_subject']) ? (array)$_POST['assigned_subject'] : [];
        $assigned_subject_ids = implode(',', $assigned_subject_ids_arr);
        
        $assigned_class_names = [];
        $assigned_subject_names = [];
        if (!empty($assigned_subject_ids_arr)) {
            $in_placeholder = implode(',', array_fill(0, count($assigned_subject_ids_arr), '?'));
            $stmt_mapped = $pdo->prepare("SELECT s.name as sub_name, c.name as class_name FROM subjects s JOIN classes c ON s.class_id = c.id WHERE s.id IN ($in_placeholder)");
            $stmt_mapped->execute($assigned_subject_ids_arr);
            $mapped_records = $stmt_mapped->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($mapped_records as $rec) {
                $assigned_class_names[] = $rec['class_name'];
                $assigned_subject_names[] = $rec['sub_name'];
            }
            $assigned_class_names = array_unique($assigned_class_names);
            $assigned_subject_names = array_unique($assigned_subject_names);
        }
        
        $assigned_subject = implode(',', $assigned_subject_names);
        $assigned_class = implode(',', $assigned_class_names);
        
        $role = $_POST['role'];
        $class_teacher_of = NULL;
        if ($role === 'class_teacher' && isset($_POST['class_teacher_of'])) {
            $class_teacher_of_array = (array)$_POST['class_teacher_of'];
            $class_teacher_of = implode(',', $class_teacher_of_array);
            
            // --- EXCLUSIVITY RULE FOR CLASS TEACHERS ---
            foreach ($class_teacher_of_array as $target_class) {
                // Find any teacher who has this class in their list
                $stmt_others = $pdo->prepare("SELECT id, class_teacher_of, email FROM teachers WHERE role = 'class_teacher' AND id != ?");
                $stmt_others->execute([$id]);
                $others = $stmt_others->fetchAll();
                
                foreach ($others as $other) {
                    $other_classes = array_map('trim', explode(',', $other['class_teacher_of'] ?? ''));
                    if (in_array($target_class, $other_classes)) {
                        // Remove target class from their list
                        $updated_classes = array_diff($other_classes, [$target_class]);
                        if (empty($updated_classes)) {
                            // Demote them if they no longer have any classes
                            $stmt_demote_t = $pdo->prepare("UPDATE teachers SET role = 'subject_teacher', class_teacher_of = NULL WHERE id = ?");
                            $stmt_demote_t->execute([$other['id']]);
                            
                            $stmt_demote_u = $pdo->prepare("UPDATE users SET role_id = 5 WHERE email = ?");
                            $stmt_demote_u->execute([$other['email']]);
                        } else {
                            // Update their list
                            $new_list = implode(',', $updated_classes);
                            $stmt_update_other = $pdo->prepare("UPDATE teachers SET class_teacher_of = ? WHERE id = ?");
                            $stmt_update_other->execute([$new_list, $other['id']]);
                        }
                    }
                }
            }
        }

        $teacher_id_val = trim($_POST['teacher_id']);
        $status = $_POST['status'];
        $username = trim($_POST['username']);

        // Password handling
        $password_sql = "";
        $password_params = [];
        if (!empty($_POST['new_password'])) {
            $hashed_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $password_sql = ", password = ?";
            $password_params[] = $hashed_password;
        }

        // UPDATE TEACHERS TABLE
        $update_teacher_sql = "UPDATE teachers SET 
            full_name = ?, gender = ?, dob = ?, age = ?, blood_group = ?, aadhaar = ?, 
            phone = ?, email = ?, present_address = ?, permanent_address = ?, photo = ?, 
            qualification = ?, specialization = ?, experience_years = ?, previous_school = ?, 
            year_of_joining = ?, designation = ?, employment_type = ?, 
            assigned_subject = ?, assigned_class = ?, role = ?, class_teacher_of = ?, 
            teacher_id = ?, status = ?, username = ?, assigned_subject_ids = ? $password_sql
            WHERE id = ?";
        
        $stmt_teacher_update = $pdo->prepare($update_teacher_sql);
        $teacher_params = [
            $full_name, $gender, $dob, $age, $blood_group, $aadhaar, $phone, $email,
            $present_address, $permanent_address, $photo, $qualification, $specialization,
            $experience_years, $previous_school, $year_of_joining, $designation, $employment_type,
            $assigned_subject, $assigned_class, $role, $class_teacher_of, $teacher_id_val, $status, $username, $assigned_subject_ids
        ];
        $teacher_params = array_merge($teacher_params, $password_params, [$id]);
        $stmt_teacher_update->execute($teacher_params);

        // Sync with Users table
        $is_active = ($status === 'Approved') ? 1 : 0;
        $user_password_sql = "";
        $user_password_params = [];
        if (!empty($_POST['new_password'])) {
            $user_password_sql = ", password = ?";
            $user_password_params[] = $hashed_password;
        }

        $target_role_id = ($role === 'class_teacher') ? 4 : 5;
        $stmt_user = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ?, is_active = ?, username = ?, role_id = ? $user_password_sql WHERE email = ?");
        $user_sync_params = array_merge([$full_name, $email, $phone, $is_active, $username, $target_role_id], $user_password_params, [$teacher['email']]);
        $stmt_user->execute($user_sync_params);

        $pdo->commit();
        $success = "Teacher profile and account updated successfully!";

        // Refresh data
        $stmt->execute([$id]);
        $teacher = $stmt->fetch();

    }
    catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = "Error: " . $e->getMessage();
    }
}

require_once '../includes/header.php';
?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-11">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold"><i class="fa fa-user-edit text-warning me-2"></i> Edit Teacher Profile</h3>
                <a href="teacher_profile.php?id=<?php echo $id; ?>" class="btn btn-outline-secondary shadow-sm px-4"><i class="fa fa-arrow-left me-1"></i> Back to Profile</a>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show shadow-sm" style="border-radius: 10px;">
                    <i class="fa fa-check-circle me-2"></i> <?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show shadow-sm" style="border-radius: 10px;">
                    <i class="fa fa-exclamation-triangle me-2"></i> <?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form action="" method="POST" enctype="multipart/form-data">
                <div class="row g-4">
                    <!-- Column 1: Personal & Account -->
                    <div class="col-lg-7">
                        <!-- Section 1: Basic Info -->
                        <div class="card mb-4 shadow-sm border-0" style="border-radius: 15px;">
                            <div class="card-body p-4">
                                <h5 class="fw-bold mb-4 border-bottom pb-2 text-primary"><i class="fa fa-id-card me-2"></i> 1. Personal Details</h5>
                                <div class="row g-3">
                                    <div class="col-md-8">
                                        <label class="form-label fw-bold">Full Name</label>
                                        <input type="text" name="full_name" class="form-control" required value="<?php echo htmlspecialchars($teacher['full_name']); ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label fw-bold">Gender</label>
                                        <select name="gender" class="form-select" required>
                                            <option value="Male" <?php echo($teacher['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                                            <option value="Female" <?php echo($teacher['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                                            <option value="Other" <?php echo($teacher['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                    <div class="col-md-5">
                                        <label class="form-label fw-bold">Date of Birth</label>
                                        <input type="date" name="dob" class="form-control" required value="<?php echo $teacher['dob']; ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label fw-bold">Age</label>
                                        <input type="number" name="age" class="form-control" required value="<?php echo $teacher['age']; ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label fw-bold">Blood Group</label>
                                        <input type="text" name="blood_group" class="form-control" value="<?php echo htmlspecialchars($teacher['blood_group']); ?>" placeholder="e.g. O+">
                                    </div>
                                    <div class="col-md-7">
                                        <label class="form-label fw-bold">Aadhaar Number</label>
                                        <input type="text" name="aadhaar" class="form-control" required maxlength="12" value="<?php echo htmlspecialchars($teacher['aadhaar']); ?>">
                                    </div>
                                    <div class="col-md-5">
                                        <label class="form-label fw-bold">Phone Number</label>
                                        <input type="text" name="phone" class="form-control" required value="<?php echo htmlspecialchars($teacher['phone']); ?>">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label fw-bold">Present Address</label>
                                        <textarea name="present_address" class="form-control" rows="3" required><?php echo htmlspecialchars($teacher['present_address']); ?></textarea>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label fw-bold">Permanent Address</label>
                                        <textarea name="permanent_address" class="form-control" rows="3" required><?php echo htmlspecialchars($teacher['permanent_address']); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Section 2: Account Access -->
                        <div class="card mb-4 shadow-sm border-0 border-top border-4 border-danger" style="border-radius: 15px;">
                            <div class="card-body p-4">
                                <h5 class="fw-bold mb-4 border-bottom pb-2 text-danger"><i class="fa fa-key me-2"></i> 2. Portal Access & Security</h5>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label fw-bold text-danger">Portal Username</label>
                                        <input type="text" name="username" class="form-control border-danger" required value="<?php echo htmlspecialchars($teacher['username'] ?: ''); ?>">
                                        <small class="text-muted">Used for teacher portal login.</small>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-bold">Email Address</label>
                                        <input type="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($teacher['email']); ?>">
                                    </div>
                                    <div class="col-md-12">
                                        <div class="bg-light p-3 rounded">
                                            <label class="form-label fw-bold text-dark"><i class="fa fa-lock me-1"></i> Reset Password</label>
                                            <input type="password" name="new_password" class="form-control" placeholder="Leave blank to keep current password">
                                            <small class="text-muted">Enter a new password ONLY if you wish to change it.</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Column 2: Professional & Assignment -->
                    <div class="col-lg-5">
                        <!-- Section 3: Professional Info -->
                        <div class="card mb-4 shadow-sm border-0" style="border-radius: 15px;">
                            <div class="card-body p-4">
                                <h5 class="fw-bold mb-4 border-bottom pb-2 text-warning"><i class="fa fa-briefcase me-2"></i> 3. Professional Details</h5>
                                <div class="row g-3">
                                    <div class="col-12 text-center mb-3">
                                        <img src="../uploads/profile/<?php echo $teacher['photo'] ?: 'default-teacher.png'; ?>" class="rounded-circle border mb-3" width="100" height="100" style="object-fit:cover;">
                                        <input type="file" name="photo" class="form-control form-control-sm" accept="image/*">
                                        <small class="text-muted">Change profile picture</small>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-bold">Highest Qualification</label>
                                        <input type="text" name="qualification" class="form-control" required value="<?php echo htmlspecialchars($teacher['qualification']); ?>">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-bold">Specialization</label>
                                        <input type="text" name="specialization" class="form-control" required value="<?php echo htmlspecialchars($teacher['specialization']); ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-bold">Exp. (Years)</label>
                                        <input type="number" name="experience_years" class="form-control" required value="<?php echo $teacher['experience_years']; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-bold">Year of Joining</label>
                                        <input type="text" name="year_of_joining" class="form-control" maxlength="4" value="<?php echo htmlspecialchars($teacher['year_of_joining']); ?>">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-bold">Previous School</label>
                                        <input type="text" name="previous_school" class="form-control" value="<?php echo htmlspecialchars($teacher['previous_school'] ?: ''); ?>">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-bold">Employment Type</label>
                                        <select name="employment_type" class="form-select" required>
                                            <option value="Full Time" <?php echo($teacher['employment_type'] == 'Full Time') ? 'selected' : ''; ?>>Full Time</option>
                                            <option value="Part Time" <?php echo($teacher['employment_type'] == 'Part Time') ? 'selected' : ''; ?>>Part Time</option>
                                            <option value="Contract" <?php echo($teacher['employment_type'] == 'Contract') ? 'selected' : ''; ?>>Contract</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Section 4: Assignment -->
                        <div class="card mb-4 shadow-sm border-0" style="border-radius: 15px;">
                            <div class="card-body p-4">
                                <h5 class="fw-bold mb-4 border-bottom pb-2 text-info"><i class="fa fa-chalkboard-teacher me-2"></i> 4. System & Assignment</h5>
                                <div class="row g-3">
                                    <div class="col-md-12">
                                        <label class="form-label fw-bold">Teacher ID</label>
                                        <input type="text" name="teacher_id" class="form-control bg-light" required value="<?php echo htmlspecialchars($teacher['teacher_id']); ?>">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-bold">Designation</label>
                                        <select name="designation" class="form-select" required>
                                            <option value="Assistant Teacher" <?php echo($teacher['designation'] == 'Assistant Teacher') ? 'selected' : ''; ?>>Assistant Teacher</option>
                                            <option value="Senior Teacher" <?php echo($teacher['designation'] == 'Senior Teacher') ? 'selected' : ''; ?>>Senior Teacher</option>
                                            <option value="Head Teacher" <?php echo($teacher['designation'] == 'Head Teacher') ? 'selected' : ''; ?>>Head Teacher</option>
                                            <option value="Subject Teacher" <?php echo($teacher['designation'] == 'Subject Teacher') ? 'selected' : ''; ?>>Subject Teacher</option>
                                        </select>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-bold">Primary Role</label>
                                        <select name="role" id="role_select" class="form-select" required onchange="toggleClassTeacherField()">
                                            <option value="subject_teacher" <?php echo($teacher['role'] == 'subject_teacher') ? 'selected' : ''; ?>>Regular Subject Teacher</option>
                                            <option value="class_teacher" <?php echo($teacher['role'] == 'class_teacher') ? 'selected' : ''; ?>>Class Teacher</option>
                                        </select>
                                    </div>
                                    <div class="col-md-12" id="class_teacher_container" style="<?php echo ($teacher['role'] !== 'class_teacher') ? 'display: none;' : ''; ?>">
                                        <label class="form-label fw-bold text-success d-block mb-2"><i class="fa fa-chalkboard-teacher me-1"></i> Class Teacher Of (Select one or more)</label>
                                        <div class="row g-2 bg-light p-3 rounded" style="max-height: 180px; overflow-y: auto; border: 1px solid #ced4da;">
                                            <?php 
                                            $selected_class_teacher_classes = array_map('trim', explode(',', $teacher['class_teacher_of'] ?? ''));
                                            foreach ($classes as $c): 
                                            ?>
                                                <div class="col-md-4 col-sm-6">
                                                    <div class="form-check">
                                                        <input class="form-check-input class-teacher-checkbox" type="checkbox" name="class_teacher_of[]" value="<?php echo htmlspecialchars($c); ?>" id="ct_<?php echo md5($c); ?>" <?php echo in_array($c, $selected_class_teacher_classes) ? 'checked' : ''; ?>>
                                                        <label class="form-check-label small" for="ct_<?php echo md5($c); ?>">
                                                            <?php echo htmlspecialchars($c); ?>
                                                        </label>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-bold d-block text-secondary mb-2"><i class="fa fa-school me-1"></i> Class &amp; Subject Assignments Matrix</label>
                                        <div class="bg-white p-3 rounded shadow-sm" style="max-height: 350px; overflow-y: auto; border: 1px solid #ced4da;">
                                            <?php 
                                            // Fetch all classes and their mapped subjects
                                            $all_classes_stmt = $pdo->query("SELECT * FROM classes ORDER BY id ASC");
                                            $all_classes_res = $all_classes_stmt->fetchAll(PDO::FETCH_ASSOC);
                                            
                                            $all_subjects_stmt = $pdo->query("SELECT * FROM subjects ORDER BY class_id ASC, name ASC");
                                            $all_subjects_res = $all_subjects_stmt->fetchAll(PDO::FETCH_ASSOC);
                                            
                                            $subjects_by_class_map = [];
                                            foreach ($all_subjects_res as $sub) {
                                                $subjects_by_class_map[$sub['class_id']][] = [
                                                    'id' => $sub['id'],
                                                    'name' => $sub['name']
                                                ];
                                            }
                                            
                                            $selected_subject_ids = array_map('trim', explode(',', $teacher['assigned_subject_ids'] ?? ''));
                                            $selected_subjects = array_map('trim', explode(',', $teacher['assigned_subject'] ?? ''));
                                            $selected_classes = array_map('trim', explode(',', $teacher['assigned_class'] ?? ''));
                                            
                                            if (empty($all_classes_res)): 
                                            ?>
                                                <p class="text-muted small mb-0"><i class="fa fa-info-circle me-1"></i> No classes or subjects configured yet. Setup classes in Academic Setup first.</p>
                                            <?php 
                                            else:
                                                foreach ($all_classes_res as $cls):
                                                    $clsId = $cls['id'];
                                                    $clsName = $cls['name'];
                                                    $clsSubjects = $subjects_by_class_map[$clsId] ?? [];
                                                    $hasSubjects = !empty($clsSubjects);
                                            ?>
                                                <div class="mb-3 pb-3 border-bottom" style="border-color: #f1f5f9 !important;">
                                                    <div class="d-flex align-items-center mb-2">
                                                        <div class="form-check">
                                                            <input class="form-check-input class-checkbox" type="checkbox" name="assigned_class[]" value="<?php echo htmlspecialchars($clsName); ?>" id="cls_<?php echo md5($clsName); ?>" <?php echo in_array($clsName, $selected_classes) ? 'checked' : ''; ?>>
                                                            <label class="form-check-label fw-bold text-dark" for="cls_<?php echo md5($clsName); ?>">
                                                                <i class="fa fa-graduation-cap text-muted me-1"></i> <?php echo htmlspecialchars($clsName); ?>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="ps-4 row g-2">
                                                        <?php if (!$hasSubjects): ?>
                                                            <div class="col-12"><small class="text-muted italic"><i class="fa fa-exclamation-circle me-1"></i> No subjects mapped to this class.</small></div>
                                                        <?php else: ?>
                                                            <?php foreach ($clsSubjects as $sub): 
                                                                $isChecked = false;
                                                                if (!empty($teacher['assigned_subject_ids'])) {
                                                                    $isChecked = in_array($sub['id'], $selected_subject_ids);
                                                                } else {
                                                                    $isChecked = (in_array($sub['name'], $selected_subjects) && in_array($clsName, $selected_classes));
                                                                }
                                                            ?>
                                                                <div class="col-6 col-md-4">
                                                                    <div class="form-check">
                                                                        <input class="form-check-input subject-checkbox" type="checkbox" name="assigned_subject[]" value="<?php echo htmlspecialchars($sub['id']); ?>" data-class="<?php echo htmlspecialchars($clsName); ?>" id="sub_<?php echo md5($clsName . '_' . $sub['id']); ?>" <?php echo $isChecked ? 'checked' : ''; ?>>
                                                                        <label class="form-check-label small" for="sub_<?php echo md5($clsName . '_' . $sub['id']); ?>">
                                                                            <?php echo htmlspecialchars($sub['name']); ?>
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php 
                                                endforeach;
                                            endif; 
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-bold">Approval Status</label>
                                        <select name="status" class="form-select" required>
                                            <option value="Pending" <?php echo($teacher['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                            <option value="Approved" <?php echo($teacher['status'] == 'Approved') ? 'selected' : ''; ?>>Approved</option>
                                            <option value="Rejected" <?php echo($teacher['status'] == 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-2 mb-5">
                    <button type="submit" name="update" class="btn btn-warning px-5 py-3 fw-bold shadow rounded-pill">
                        <i class="fa fa-save me-2"></i> Update Teacher Profile
                    </button>
                    <a href="teacher_profile.php?id=<?php echo $id; ?>" class="btn btn-link link-secondary text-decoration-none d-block mt-3">Cancel and return to profile</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleClassTeacherField() {
    const role = document.getElementById('role_select').value;
    const container = document.getElementById('class_teacher_container');
    
    if (role === 'class_teacher') {
        container.style.display = 'block';
    } else {
        container.style.display = 'none';
        const checkboxes = container.querySelectorAll('.class-teacher-checkbox');
        checkboxes.forEach(function (chk) {
            chk.checked = false;
        });
    }
}

document.addEventListener('DOMContentLoaded', function () {
    // When a subject checkbox is checked, ensure its parent class checkbox is checked
    const subjectCheckboxes = document.querySelectorAll('.subject-checkbox');
    subjectCheckboxes.forEach(function (chk) {
        chk.addEventListener('change', function () {
            if (this.checked) {
                const className = this.getAttribute('data-class');
                const classCheckbox = document.querySelector(`.class-checkbox[value="${className}"]`);
                if (classCheckbox) {
                    classCheckbox.checked = true;
                }
            }
        });
    });

    // When a class checkbox is changed
    const classCheckboxes = document.querySelectorAll('.class-checkbox');
    classCheckboxes.forEach(function (chk) {
        chk.addEventListener('change', function () {
            const className = this.value;
            const relatedSubjects = document.querySelectorAll(`.subject-checkbox[data-class="${className}"]`);
            
            // If class checkbox is unchecked, uncheck all its subjects
            if (!this.checked) {
                relatedSubjects.forEach(function (subChk) {
                    subChk.checked = false;
                });
            } else {
                // If checked, check all its subjects
                relatedSubjects.forEach(function (subChk) {
                    subChk.checked = true;
                });
            }
        });
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>

<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    header("Location: ../dashboard.php");
    exit();
}

$stmt = $pdo->query("SELECT * FROM students ORDER BY created_at DESC");
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>
<?php include 'includes/student_page_styles.php'; ?>

<div class="container-fluid py-4">
    <div class="sp-header sp-header--teal">
        <div>
            <h2><i class="fa fa-folder-open me-2"></i> All Applications</h2>
            <p>Every student record — <strong><?php echo count($students); ?></strong> total</p>
        </div>
        <a href="admissions.php" class="sp-back-btn"><i class="fa fa-arrow-left me-1"></i> Back</a>
    </div>

    <?php if (empty($students)): ?>
        <div class="sp-empty"><i class="fa fa-folder-open fa-3x text-primary mb-3"></i><p class="text-muted">No records found.</p></div>
    <?php
else: ?>
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 bg-white sp-table">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Admission No</th>
                        <th>Student Name</th>
                        <th>Parent Name</th>
                        <th>Class</th>
                        <th>Admission Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $i => $s): ?>
                    <?php
        $badge = 'bg-secondary';
        if ($s['status'] == 'Approved')
            $badge = 'bg-success';
        elseif ($s['status'] == 'Pending')
            $badge = 'bg-warning text-dark';
        elseif ($s['status'] == 'Rejected')
            $badge = 'bg-danger';
?>
                    <tr class="sp-row" data-id="<?php echo $s['id']; ?>">
                        <td><span class="text-muted small"><?php echo $i + 1; ?></span></td>
                        <td><strong class="text-primary"><?php echo htmlspecialchars($s['admission_no'] ?? 'N/A'); ?></strong></td>
                        <td><strong><?php echo htmlspecialchars($s['student_name']); ?></strong></td>
                        <td><small><?php echo htmlspecialchars($s['parent_name'] ?? $s['father_name'] ?? 'N/A'); ?></small></td>
                        <td><small class="fw-semibold"><?php echo htmlspecialchars($s['class_applied'] ?? 'N/A'); ?></small></td>
                        <td><small><?php echo $s['admission_date'] ? date('d M Y', strtotime($s['admission_date'])) : date('d M Y', strtotime($s['created_at'])); ?></small></td>
                        <td><span class="badge <?php echo $badge; ?>"><?php echo htmlspecialchars($s['status']); ?></span></td>
                    </tr>
                    <tr class="sp-action-row" id="sp-panel-<?php echo $s['id']; ?>" style="display:none;">
                        <td colspan="7">
                            <div class="sp-action-panel">
                                <a href="student_profile.php?id=<?php echo $s['id']; ?>&type=app" class="sp-btn sp-btn-view"><i class="fa fa-eye"></i> View</a>
                                <a href="edit_student.php?id=<?php echo $s['id']; ?>&type=app" class="sp-btn sp-btn-edit"><i class="fa fa-edit"></i> Edit</a>
                                <a href="actions/export_student.php?id=<?php echo $s['id']; ?>&type=student" class="sp-btn sp-btn-pdf" target="_blank"><i class="fa fa-file-pdf"></i> Export PDF</a>
                                <?php if ($s['status'] !== 'Approved'): ?>
                                <button class="sp-btn sp-btn-approve sp-confirm"
                                    data-url="actions/approve_student.php?id=<?php echo $s['id']; ?>"
                                    data-title="Approve Student?" data-text="Approve this student application?" data-icon="question" data-confirm="Yes, Approve">
                                    <i class="fa fa-check"></i> Approve
                                </button>
                                <?php
        endif; ?>
                                <?php if ($s['status'] !== 'Rejected'): ?>
                                <button class="sp-btn sp-btn-reject sp-confirm"
                                    data-url="actions/reject_student.php?id=<?php echo $s['id']; ?>&type=app"
                                    data-title="Reject Student?" data-text="Reject this student application?" data-icon="warning" data-confirm="Yes, Reject">
                                    <i class="fa fa-times"></i> Reject
                                </button>
                                <?php
        endif; ?>
                                <button class="sp-btn sp-btn-delete sp-confirm"
                                    data-url="actions/delete_student.php?id=<?php echo $s['id']; ?>&type=app"
                                    data-title="Delete Record?" data-text="Move this student to deleted records?" data-icon="warning" data-confirm="Yes, Delete">
                                    <i class="fa fa-trash"></i> Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
    endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
endif; ?>
</div>

<?php include 'includes/student_page_scripts.php'; ?>
<?php require_once '../includes/footer.php'; ?>

<?php
require_once '../includes/auth.php';
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$stmt = $pdo->query("SELECT * FROM teachers WHERE role = 'class_teacher' AND status = 'Approved' ORDER BY class_teacher_of, full_name");
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once '../includes/header.php';
?>
<?php include 'includes/teacher_page_styles.php'; ?>

<div class="container-fluid py-4">
    <div class="tp-header tp-header--blue">
        <div>
            <h2><i class="fa fa-chalkboard me-2"></i> Class Teachers</h2>
            <p>Teachers assigned as class in-charge — <strong><?php echo count($teachers); ?></strong> records</p>
        </div>
        <div>
            <a href="teachers.php" class="tp-back-btn"><i class="fa fa-arrow-left me-1"></i> Back</a>
        </div>
    </div>

    <?php if (empty($teachers)): ?>
        <div class="tp-empty">
            <i class="fa fa-chalkboard fa-3x text-primary mb-3"></i>
            <p class="text-muted">No class teachers found. Assign teachers the "class_teacher" role to see them here.</p>
        </div>
    <?php
else: ?>
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 bg-white tp-table">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Teacher</th>
                        <th>Class In-Charge</th>
                        <th>Experience</th>
                        <th>Phone</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($teachers as $i => $t): ?>
                    <tr class="tp-row" data-id="<?php echo $t['id']; ?>">
                        <td><span class="text-muted small"><?php echo $i + 1; ?></span></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <img src="../uploads/profile/<?php echo $t['photo'] ?: 'default-teacher.png'; ?>"
                                     class="rounded-circle border border-2 border-white shadow-sm"
                                     width="42" height="42" style="object-fit:cover;"
                                     onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($t['full_name']); ?>&background=random'">
                                <div>
                                    <span class="fw-bold d-block"><?php echo htmlspecialchars($t['full_name']); ?></span>
                                    <small class="text-muted"><?php echo htmlspecialchars($t['teacher_id']); ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge bg-primary px-3 py-2 fs-6">
                                <i class="fa fa-chalkboard me-1"></i>
                                <?php echo htmlspecialchars($t['class_teacher_of'] ?: $t['assigned_class']); ?>
                            </span>
                        </td>
                        <td><span class="fw-bold"><?php echo htmlspecialchars($t['experience_years']); ?></span> <small class="text-muted">yrs</small></td>
                        <td><small><?php echo htmlspecialchars($t['phone']); ?></small></td>
                        <td><span class="badge bg-success">Approved</span></td>
                    </tr>
                    <!-- Action Panel -->
                    <tr class="tp-action-row" id="panel-<?php echo $t['id']; ?>" style="display:none;">
                        <td colspan="6">
                            <div class="tp-action-panel">
                                <a href="teacher_profile.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-view"><i class="fa fa-eye"></i> View</a>
                                <a href="edit_teacher.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-edit"><i class="fa fa-edit"></i> Edit</a>
                                <a href="actions/export_teacher.php?id=<?php echo $t['id']; ?>" class="tp-btn tp-btn-pdf" target="_blank"><i class="fa fa-file-pdf"></i> Export PDF</a>
                                <button class="tp-btn tp-btn-delete btn-confirm"
                                        data-url="actions/delete_teacher.php?id=<?php echo $t['id']; ?>"
                                        data-title="Move to Trash?" data-text="Move this class teacher to deleted records?" data-icon="warning" data-confirm="Yes, Delete">
                                    <i class="fa fa-trash"></i> Delete
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
    endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
endif; ?>
</div>

<?php include 'includes/teacher_page_scripts.php'; ?>
<?php require_once '../includes/footer.php'; ?>

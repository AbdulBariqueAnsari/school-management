<?php
require_once '../includes/auth.php';
require_once '../config/database_init.php';

if (!isset($_SESSION['role_id'])) {
    die("Unauthorized access.");
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$type = isset($_GET['type']) ? $_GET['type'] : 'app';

if ($_SESSION['role_id'] == 1) {
    // Admin authorized
} elseif ($_SESSION['role_id'] == 6) {
    // Student authorized for own record
    if (!isset($_SESSION['student_id'])) {
        require_once '../config/db.php'; // ensure $pdo is available if init didn't load it
        $checkStmt = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
        $checkStmt->execute([$_SESSION['user_id']]);
        $_SESSION['student_id'] = $checkStmt->fetchColumn();
    }
    if ($id != $_SESSION['student_id']) {
        die("Unauthorized: You can only view your own record.");
    }
} else {
    die("Unauthorized access.");
}

if ($id <= 0)
    die("Invalid ID");

// Fetch student/application record
if ($type === 'student') {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    $title = "Approved Student Record";
}
else {
    $stmt = $pdo->prepare("SELECT * FROM admission_requests WHERE id = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    $title = "Admission Application Record";
}

if (!$data)
    die("Record not found.");

// Fetch school settings
$settings_query = $pdo->query("SELECT setting_key, setting_value FROM super_admin_settings");
$settings = $settings_query->fetchAll(PDO::FETCH_KEY_PAIR);
$school_name = $settings['school_name'] ?? 'School Management System';
$school_address = $settings['school_address'] ?? '';
$school_phone = $settings['school_phone'] ?? '';
$school_email = $settings['school_email'] ?? '';
$school_logo = $settings['school_logo'] ?? '';

// Determine photo field
$photo = $data['student_photo'] ?? ($data['photo'] ?? '');
$admission_no = $data['admission_no'] ?? ($data['id'] ?? '');

// Field label map — human-readable names for each db column
$labels = [
    'student_name' => 'Student Name',
    'gender' => 'Gender',
    'dob' => 'Date of Birth',
    'blood_group' => 'Blood Group',
    'aadhaar_number' => 'Aadhaar Number',
    'class_applied' => 'Class Applied',
    'mobile_number' => 'Mobile Number',
    'address' => 'Present Address',
    'religion' => 'Religion',
    'caste_category' => 'Caste Category',
    'mother_tongue' => 'Mother Tongue',
    'previous_schooling_status' => 'Previous Schooling',
    'parent_name' => 'Parent Name',
    'parent_email' => 'Parent Email',
    'parent_phone' => 'Parent Phone',
    'father_name' => "Father's Name",
    'father_mobile' => "Father's Mobile",
    'mother_name' => "Mother's Name",
    'mother_mobile' => "Mother's Mobile",
    'parents_address' => 'Parents Address',
    'guardian_name' => 'Guardian Name',
    'relation' => 'Guardian Relation',
    'guardian_mobile' => 'Guardian Mobile',
    'guardian_address' => 'Guardian Address',
    'guardian_details' => 'Guardian Details',
    'previous_class' => 'Previous Class',
    'previous_school_name' => 'Previous School',
    'previous_school' => 'Previous School',
    'previous_board' => 'Previous Board',
    'year_of_passing' => 'Year of Passing',
    'admission_no' => 'Admission Number',
    'admission_number' => 'Admission Number',
    'status' => 'Application Status',
    'is_active' => 'Account Status',
    'admission_date' => 'Admission Date',
    'created_at' => 'Application Date',
];

// Columns to skip in the auto-generated table (handled manually or not needed)
$skip = ['id', 'student_photo', 'photo', 'user_id', 'class_id', 'section_id', 'parent_id', 'password',
    'has_medical_condition', 'medical_condition_desc',
    'has_disability', 'disability_desc',
    'has_allergies', 'allergies_desc'];

// Pre-format health summary
$health_summary = [];
$health_summary['Medical Condition'] = ($data['has_medical_condition'] ?? 0) ? ('Yes — ' . ($data['medical_condition_desc'] ?: 'N/A')) : 'None';
$health_summary['Disability'] = ($data['has_disability'] ?? 0) ? ('Yes — ' . ($data['disability_desc'] ?: 'N/A')) : 'None';
$health_summary['Allergies'] = ($data['has_allergies'] ?? 0) ? ('Yes — ' . ($data['allergies_desc'] ?: 'N/A')) : 'None';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Export — <?php echo htmlspecialchars($school_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #fff; padding: 30px; font-family: Arial, sans-serif; color: #1a1a2e; }

        .school-header {
            display: flex;
            align-items: center;
            gap: 20px;
            border-bottom: 3px double #003087;
            padding-bottom: 18px;
            margin-bottom: 24px;
        }
        .school-logo-img { width: 80px; height: 80px; object-fit: contain; border-radius: 8px; }
        .school-logo-placeholder {
            width: 80px; height: 80px; border-radius: 8px;
            background: linear-gradient(135deg, #003087, #0055cc);
            display: flex; align-items: center; justify-content: center;
            color: #fff; font-size: 2rem;
        }
        .school-info { flex: 1; text-align: center; }
        .school-info h2 { margin: 0; font-size: 1.5rem; font-weight: 800; color: #003087; letter-spacing: 0.5px; }
        .school-info .sub { font-size: 0.82rem; color: #555; margin-top: 3px; }

        .doc-title {
            text-align: center;
            background: #003087;
            color: #fff;
            padding: 10px 20px;
            border-radius: 6px;
            font-size: 1.1rem;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 22px;
        }

        .student-photo-box { text-align: center; margin-bottom: 20px; }
        .student-photo-box img { width: 120px; height: 140px; object-fit: cover; border: 3px solid #003087; border-radius: 6px; }
        .student-photo-box .no-photo {
            width: 120px; height: 140px; background: #e8edf5; border: 2px dashed #ccc;
            border-radius: 6px; display: inline-flex; align-items: center; justify-content: center;
            color: #aaa; font-size: 2.5rem;
        }

        .section-head {
            background: #003087; color: #fff; padding: 6px 14px;
            font-weight: 700; font-size: 0.85rem; letter-spacing: 0.8px;
            border-radius: 4px; margin: 18px 0 8px 0;
            text-transform: uppercase;
        }

        .info-table { width: 100%; border-collapse: collapse; margin-bottom: 6px; }
        .info-table tr { border-bottom: 1px solid #e9ecef; }
        .info-table td { padding: 7px 12px; font-size: 0.9rem; vertical-align: top; }
        .info-table td:first-child { width: 38%; color: #555; font-weight: 600; background: #f8f9fa; }
        .info-table td:last-child { font-weight: 500; }

        .footer-signature { text-align: right; margin-top: 40px; padding-right: 40px; }
        .footer-signature p { margin: 0; }
        .generated-on { text-align: center; font-size: 0.78rem; color: #888; margin-top: 14px; }

        /* Developer Footer Styling */
        .dev-footer-branding {
            margin-top: 30px;
            text-align: center;
            font-size: 0.85em;
        }
        .dev-footer-branding span {
            background-color: #ffd700;
            padding: 3px 10px;
            border-radius: 4px;
            color: #333;
            font-weight: 600;
            display: inline-block;
        }
        .dev-footer-branding a {
            color: #000;
            text-decoration: none;
            font-weight: bold;
        }

        @media print {
            .no-print { display: none !important; }
            body { padding: 15px; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .school-header { border-bottom: 2px solid #003087; }
            .info-table td:first-child { background: #f0f4ff !important; }
            .dev-footer-branding span { background-color: #ffd700 !important; -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body>
    <!-- TOP BUTTONS (screen only) -->
    <div class="no-print d-flex justify-content-between mb-4">
        <a href="javascript:history.back()" class="btn btn-outline-secondary btn-sm"><i class="fa fa-arrow-left"></i> Back</a>
        <div>
            <button onclick="window.print()" class="btn btn-primary btn-sm me-2"><i class="fa fa-print"></i> Print / Save as PDF</button>
            <button onclick="window.close()" class="btn btn-outline-secondary btn-sm"><i class="fa fa-times"></i> Close</button>
        </div>
    </div>

    <div class="container" style="max-width:820px;">

        <!-- SCHOOL HEADER -->
        <div class="school-header">
            <div>
                <?php if ($school_logo && file_exists('../uploads/' . $school_logo)): ?>
                    <img src="../uploads/<?php echo htmlspecialchars($school_logo); ?>" class="school-logo-img" alt="Logo">
                <?php
else: ?>
                    <div class="school-logo-placeholder"><i class="fa fa-graduation-cap"></i></div>
                <?php
endif; ?>
            </div>
            <div class="school-info">
                <h2><?php echo htmlspecialchars($school_name); ?></h2>
                <?php if ($school_address): ?>
                    <div class="sub"><i class="fa fa-map-marker-alt"></i> <?php echo htmlspecialchars($school_address); ?></div>
                <?php
endif; ?>
                <?php if ($school_phone || $school_email): ?>
                    <div class="sub">
                        <?php if ($school_phone): ?><i class="fa fa-phone"></i> <?php echo htmlspecialchars($school_phone); ?><?php
    endif; ?>
                        <?php if ($school_phone && $school_email): ?> &nbsp;|&nbsp; <?php
    endif; ?>
                        <?php if ($school_email): ?><i class="fa fa-envelope"></i> <?php echo htmlspecialchars($school_email); ?><?php
    endif; ?>
                    </div>
                <?php
endif; ?>
            </div>
        </div>

        <!-- DOCUMENT TITLE -->
        <div class="doc-title">STUDENT ADMISSION RECORD</div>

        <div class="row align-items-start">

            <!-- PERSONAL INFO QUICK SUMMARY -->
            <div class="col-sm-12">
                <div class="section-head">Personal Information</div>
                <table class="info-table">
                    <?php
$personal_fields = ['admission_no', 'student_name', 'gender', 'dob', 'class_applied', 'class', 'blood_group', 'status', 'admission_date'];
foreach ($personal_fields as $field):
    if (!array_key_exists($field, $data) || $data[$field] === null || $data[$field] === '')
        continue;
    $label = $labels[$field] ?? ucwords(str_replace('_', ' ', $field));
    $val = $data[$field];
    if ($field === 'is_active')
        $val = $val ? 'Active' : 'Inactive';
?>
                    <tr>
                        <td><?php echo htmlspecialchars($label); ?></td>
                        <td><?php echo htmlspecialchars($val); ?></td>
                    </tr>
                    <?php
endforeach; ?>
                </table>
            </div>
        </div>


        <!-- PARENT / GUARDIAN DETAILS -->
        <div class="section-head">Parent / Guardian Information</div>
        <table class="info-table">
            <?php
$parent_fields = ['parent_name', 'father_name', 'father_mobile', 'mother_name', 'mother_mobile', 'parent_email', 'parent_phone', 'parents_address', 'guardian_name', 'relation', 'guardian_mobile', 'guardian_address', 'guardian_details'];
foreach ($parent_fields as $field):
    if (!array_key_exists($field, $data))
        continue;
    $val = $data[$field];
    if ($val === null || $val === '')
        continue;
    $label = $labels[$field] ?? ucwords(str_replace('_', ' ', $field));
?>
            <tr>
                <td><?php echo htmlspecialchars($label); ?></td>
                <td><?php echo nl2br(htmlspecialchars($val)); ?></td>
            </tr>
            <?php
endforeach; ?>
        </table>

        <!-- HEALTH INFORMATION -->
        <div class="section-head">Health Information</div>
        <table class="info-table">
            <?php foreach ($health_summary as $hlbl => $hval): ?>
            <tr>
                <td><?php echo htmlspecialchars($hlbl); ?></td>
                <td><?php echo htmlspecialchars($hval); ?></td>
            </tr>
            <?php
endforeach; ?>
        </table>


        <!-- ALL REMAINING FIELDS (any not yet shown) -->
        <?php
$shown = array_merge($personal_fields, $parent_fields, $skip);
$remaining = [];
foreach ($data as $key => $val) {
    if (!in_array($key, $shown) && $val !== null && $val !== '') {
        $remaining[$key] = $val;
    }
}
if (!empty($remaining)):
?>
        <div class="section-head">Additional Details</div>
        <table class="info-table">
            <?php foreach ($remaining as $key => $val):
        $label = $labels[$key] ?? ucwords(str_replace('_', ' ', $key));
?>
            <tr>
                <td><?php echo htmlspecialchars($label); ?></td>
                <td><?php echo nl2br(htmlspecialchars((string)$val)); ?></td>
            </tr>
            <?php
    endforeach; ?>
        </table>
        <?php
endif; ?>

        <!-- SIGNATURE FOOTER -->
        <div class="footer-signature">
            <br><br>
            <p>___________________________</p>
            <p><strong>Authorized Signature</strong></p>
        </div>

        <div class="generated-on">Document generated on <?php echo date('d F Y, h:i A'); ?> &nbsp;|&nbsp; <?php echo htmlspecialchars($school_name); ?></div>

        <div class="dev-footer-branding">
            <span>Designed and maintained by <a href="https://webnoor.in/" target="_blank">WebNoor</a></span>
        </div>

    </div>
</body>
</html>

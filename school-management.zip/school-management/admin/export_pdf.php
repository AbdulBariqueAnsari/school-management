<?php
session_start();
require_once '../includes/auth.php';
require_once '../config/database_init.php';

if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    die("Unauthorized access.");
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$type = isset($_GET['type']) ? $_GET['type'] : 'app';

if ($id <= 0)
    die("Invalid ID");

// Fetch record
if ($type === 'student') {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    $title = "Student Profile Record";
}
else {
    $stmt = $pdo->prepare("SELECT * FROM admission_requests WHERE id = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    $title = "Admission Application Record";
}

if (!$data)
    die("Record not found.");

// Fetch school settings
$settings = $pdo->query("SELECT * FROM system_settings WHERE id = 1")->fetch(PDO::FETCH_ASSOC);
$school_name = $settings['school_name'] ?? 'School Management System';
$school_address = $settings['school_address'] ?? '';
$school_phone = $settings['school_phone'] ?? '';
$school_email = $settings['school_email'] ?? '';
$school_logo = $settings['school_logo'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($title); ?> — <?php echo htmlspecialchars($school_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #fff; padding: 20px; font-family: Arial, sans-serif; color: #000; }
        .print-header { border-bottom: 3px double #003087; padding-bottom: 15px; margin-bottom: 25px; }
        .school-logo-placeholder {
            width: 70px; height: 70px; background: #003087;
            border-radius: 50%; display: inline-flex; align-items: center;
            justify-content: center; color: #fff; font-size: 1.8rem;
        }
        .data-table th { width: 35%; background-color: #f8f9fa !important; color: #000 !important; }
        .data-table td, .data-table th { border-color: #dee2e6 !important; }
        @media print {
            .no-print { display: none !important; }
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .data-table th { background-color: #f8f9fa !important; }
        }
    </style>
</head>
<body onload="window.print()">
    <div class="container mt-3">
        <div class="text-end mb-3 no-print">
            <button onclick="window.print()" class="btn btn-primary btn-sm">&#128438; Print / Save as PDF</button>
            <button onclick="window.close()" class="btn btn-secondary btn-sm">&#10005; Close</button>
        </div>

        <div class="print-header d-flex align-items-center gap-3">
            <?php if ($school_logo && file_exists('../uploads/' . $school_logo)): ?>
                <img src="../uploads/<?php echo htmlspecialchars($school_logo); ?>" style="width:70px;height:70px;object-fit:contain;border-radius:8px;" alt="Logo">
            <?php
else: ?>
                <div class="school-logo-placeholder">&#127891;</div>
            <?php
endif; ?>
            <div class="flex-grow-1 text-center">
                <h3 class="mb-0 fw-bold" style="color:#003087;"><?php echo htmlspecialchars($school_name); ?></h3>
                <?php if ($school_address): ?><p class="mb-0 small text-muted"><?php echo htmlspecialchars($school_address); ?></p><?php
endif; ?>
                <?php if ($school_phone): ?><p class="mb-0 small text-muted">&#128222; <?php echo htmlspecialchars($school_phone); ?><?php if ($school_email): ?> &nbsp;|&nbsp; &#9993; <?php echo htmlspecialchars($school_email); ?><?php
    endif; ?></p><?php
endif; ?>
                <h5 class="mt-2 mb-0 text-uppercase" style="letter-spacing:1.5px;color:#555;"><?php echo htmlspecialchars($title); ?></h5>
                <small class="text-muted">Generated: <?php echo date('d M Y, h:i A'); ?></small>
            </div>
        </div>

        <div class="card border-dark shadow-none">
            <div class="card-body p-0">
                <table class="table table-bordered mb-0 data-table">
                    <tbody>
                        <?php
$skip = ['id', 'photo', 'student_photo', 'user_id', 'class_id', 'section_id', 'parent_id', 'password'];
$labels = [
    'student_name' => 'Student Name',
    'gender' => 'Gender',
    'dob' => 'Date of Birth',
    'class_applied' => 'Class Applied',
    'class' => 'Class',
    'blood_group' => 'Blood Group',
    'address' => 'Address',
    'parent_name' => 'Parent Name',
    'parent_email' => 'Parent Email',
    'parent_phone' => 'Parent Phone',
    'guardian_details' => 'Guardian Details',
    'admission_no' => 'Admission Number',
    'admission_number' => 'Admission Number',
    'status' => 'Application Status',
    'is_active' => 'Account Status',
    'admission_date' => 'Admission Date',
    'created_at' => 'Application Date',
];
foreach ($data as $key => $value):
    if (in_array($key, $skip))
        continue;
    $label = $labels[$key] ?? ucwords(str_replace('_', ' ', $key));
    if ($key === 'is_active')
        $value = $value ? 'Active' : 'Inactive';
?>
                        <tr>
                            <th><?php echo htmlspecialchars($label); ?></th>
                            <td><?php echo nl2br(htmlspecialchars((string)$value !== '' ? $value : 'N/A')); ?></td>
                        </tr>
                        <?php
endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-5 text-end pe-5">
            <br><br>
            <p>___________________________</p>
            <p><strong>Authorized Signature</strong></p>
        </div>
        <p class="text-center text-muted no-print small mt-3">To export to PDF, change printer destination to <strong>"Save as PDF"</strong></p>
    </div>
</body>
</html>

<?php
require_once '../includes/init.php';
header('Content-Type: application/json');

// Super Admin Check
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
    exit;
}

$action = $_POST['action'] ?? '';

try {
    if ($action === 'update_personal') {
        $name = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $dob = $_POST['dob'] ?? null;
        $gender = $_POST['gender'] ?? null;
        $address = trim($_POST['address'] ?? '');

        if (empty($name) || empty($email)) {
            echo json_encode(['status' => 'error', 'message' => 'Name and Email are required.']);
            exit;
        }

        // Handle profile photo upload
        $photo_query = "";
        $params = [
            ':name' => $name,
            ':username' => !empty($username) ? $username : null,
            ':email' => $email,
            ':phone' => !empty($phone) ? $phone : null,
            ':dob' => !empty($dob) ? $dob : null,
            ':gender' => !empty($gender) ? $gender : null,
            ':address' => !empty($address) ? $address : null,
            ':id' => $_SESSION['user_id']
        ];

        if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] == UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            if (!in_array($_FILES['profile_photo']['type'], $allowed_types)) {
                echo json_encode(['status' => 'error', 'message' => 'Invalid image format.']);
                exit;
            }
            if ($_FILES['profile_photo']['size'] > 2 * 1024 * 1024) {
                echo json_encode(['status' => 'error', 'message' => 'Image size cannot exceed 2MB.']);
                exit;
            }

            $ext = pathinfo($_FILES['profile_photo']['name'], PATHINFO_EXTENSION);
            $filename = uniqid('profile_') . '.' . $ext;
            $upload_dir = '../uploads/profile/';

            if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $upload_dir . $filename)) {
                $photo_query = ", profile_photo = :photo";
                $params[':photo'] = $filename;
            }
        }

        $sql = "UPDATE users SET name = :name, username = :username, email = :email, phone = :phone, dob = :dob, gender = :gender, address = :address $photo_query WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        $_SESSION['user_name'] = $name; // Update session

        echo json_encode(['status' => 'success', 'message' => 'Personal information updated successfully.']);
        exit;

    }
    elseif ($action === 'update_branding') {
        $fields = [
            'school_name', 'school_tagline', 'school_code', 'school_board',
            'school_registration_number', 'school_email', 'school_phone',
            'school_website', 'school_address'
        ];

        $stmt = $pdo->prepare("INSERT INTO super_admin_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");

        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                $val = trim($_POST[$field]);
                $stmt->execute([$field, $val]);

                // Sync school_email with the super admin's login email
                if ($field === 'school_email' && !empty($val)) {
                    $stmt_u = $pdo->prepare("UPDATE users SET email = ? WHERE id = ?");
                    $stmt_u->execute([$val, $_SESSION['user_id']]);
                }
            }
        }

        // Handle image uploads
        $upload_dir = '../uploads/branding/';

        if (isset($_FILES['school_logo']) && $_FILES['school_logo']['error'] == UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['school_logo']['name'], PATHINFO_EXTENSION);
            $filename = 'logo_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['school_logo']['tmp_name'], $upload_dir . $filename)) {
                $stmt->execute(['school_logo', $filename]);
            }
        }

        if (isset($_FILES['school_favicon']) && $_FILES['school_favicon']['error'] == UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['school_favicon']['name'], PATHINFO_EXTENSION);
            $filename = 'favicon_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['school_favicon']['tmp_name'], $upload_dir . $filename)) {
                $stmt->execute(['school_favicon', $filename]);
            }
        }

        echo json_encode(['status' => 'success', 'message' => 'Branding settings updated successfully.']);
        exit;

    }
    elseif ($action === 'update_academic') {
        $fields = ['academic_year', 'academic_start_date', 'academic_end_date', 'grade_system', 'passing_percentage', 'attendance_type'];
        $stmt = $pdo->prepare("INSERT INTO super_admin_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        foreach ($fields as $field) {
            $val = isset($_POST[$field]) ? trim($_POST[$field]) : '';
            $stmt->execute([$field, $val]);
        }
        echo json_encode(['status' => 'success', 'message' => 'Academic settings updated.']);
        exit;

    }
    elseif ($action === 'update_system') {
        $fields = ['timezone', 'currency', 'date_format', 'language', 'theme'];
        $stmt = $pdo->prepare("INSERT INTO super_admin_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        foreach ($fields as $field) {
            $val = isset($_POST[$field]) ? trim($_POST[$field]) : '';
            $stmt->execute([$field, $val]);
        }

        // Checkboxes check
        if (!isset($_SESSION['true_role_id']) || $_SESSION['true_role_id'] != 2) {
            $maint = isset($_POST['maintenance_mode']) ? '1' : '0';
            $stmt->execute(['maintenance_mode', $maint]);
        }

        echo json_encode(['status' => 'success', 'message' => 'System settings updated.']);
        exit;

    }
    elseif ($action === 'update_security') {
        $stmt = $pdo->prepare("INSERT INTO super_admin_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");

        $two_fac = isset($_POST['two_factor_auth']) ? '1' : '0';
        $stmt->execute(['two_factor_auth', $two_fac]);

        $timeout = isset($_POST['session_timeout']) ? (int)$_POST['session_timeout'] : 120;
        $stmt->execute(['session_timeout', (string)$timeout]);

        echo json_encode(['status' => 'success', 'message' => 'Security settings updated.']);
        exit;

    }
    elseif ($action === 'update_password') {
        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        if (strlen($new_pass) < 6) {
            echo json_encode(['status' => 'error', 'message' => 'Password must be at least 6 characters.']);
            exit;
        }

        if ($new_pass !== $confirm_pass) {
            echo json_encode(['status' => 'error', 'message' => 'Passwords do not match.']);
            exit;
        }

        $hash = password_hash($new_pass, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hash, $_SESSION['user_id']]);

        echo json_encode(['status' => 'success', 'message' => 'Password successfully updated.']);
        exit;
    }

    echo json_encode(['status' => 'error', 'message' => 'Invalid action request.']);
}
catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}

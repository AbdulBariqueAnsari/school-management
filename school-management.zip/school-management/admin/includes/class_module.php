<?php
require_once __DIR__ . '/../../includes/auth.php';

if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

if (!isset($_GET['class']) || trim($_GET['class']) === '') {
    redirect('class_teachers.php');
}

$class_name = trim($_GET['class']);
$module_key = $module_key ?? 'overview';
$module_title = $module_title ?? 'Class Module';
$module_icon = $module_icon ?? 'fa-layer-group';

function class_module_count($sql, $params = [])
{
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

function class_module_rows($sql, $params = [], $limit = 100)
{
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql . " LIMIT " . (int)$limit);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

$class_id = class_module_count("SELECT id FROM classes WHERE name = ?", [$class_name]);
$students = class_module_rows(
    "SELECT id, admission_no, student_name, gender, parent_name, status
     FROM students
     WHERE class_applied = ? OR class = ?
     ORDER BY student_name",
    [$class_name, $class_name],
    300
);

$cards = [
    ['Students', count($students)],
    ['Approved', class_module_count("SELECT COUNT(*) FROM students WHERE (class_applied = ? OR class = ?) AND status='Approved'", [$class_name, $class_name])],
    ['Pending', class_module_count("SELECT COUNT(*) FROM students WHERE (class_applied = ? OR class = ?) AND status='Pending'", [$class_name, $class_name])],
];

$columns = ['Admission No', 'Student', 'Gender', 'Parent', 'Status'];
$rows = $students;
$empty = 'No records are available for this class yet.';
$summary = 'Class-wise operational view.';

switch ($module_key) {
    case 'attendance':
        $summary = 'Attendance records for students in this class.';
        $columns = ['Date', 'Student ID', 'Status', 'Marked By'];
        $rows = class_module_rows(
            "SELECT a.date, a.student_id, a.status, a.marked_by
             FROM attendance a
             INNER JOIN students s ON a.student_id = s.id
             WHERE s.class_applied = ? OR s.class = ?
             ORDER BY a.date DESC",
            [$class_name, $class_name]
        );
        $cards[] = ['Attendance Rows', count($rows)];
        break;

    case 'assignments':
    case 'homework':
        $summary = 'Assignments and homework posted for this class.';
        $columns = ['Title', 'Subject ID', 'Deadline', 'Teacher ID', 'Created'];
        $rows = $class_id ? class_module_rows(
            "SELECT title, subject_id, deadline, teacher_id, created_at FROM assignments WHERE class_id = ? ORDER BY deadline DESC",
            [$class_id]
        ) : [];
        $cards[] = ['Assignments', count($rows)];
        break;

    case 'marks':
    case 'tests':
    case 'reports':
        $summary = 'Marks and exam records connected to students in this class.';
        $columns = ['Exam ID', 'Student ID', 'Subject ID', 'Marks', 'Grade'];
        $rows = class_module_rows(
            "SELECT m.exam_id, m.student_id, m.subject_id, CONCAT(m.marks_obtained, '/', m.total_marks) AS marks, m.grade
             FROM marks m
             INNER JOIN students s ON m.student_id = s.id
             WHERE s.class_applied = ? OR s.class = ?
             ORDER BY m.id DESC",
            [$class_name, $class_name]
        );
        $cards[] = ['Result Rows', count($rows)];
        break;

    case 'messages':
        $summary = 'Recent message activity for students in this class.';
        $columns = ['Sender', 'Receiver', 'Message', 'Role', 'Created'];
        $rows = class_module_rows(
            "SELECT m.sender_id, m.receiver_id, COALESCE(m.message, m.content) AS message, m.sender_role, m.created_at
             FROM messages m
             WHERE m.sender_id IN (SELECT id FROM students WHERE class_applied = ? OR class = ?)
                OR m.receiver_id IN (SELECT id FROM students WHERE class_applied = ? OR class = ?)
             ORDER BY m.created_at DESC",
            [$class_name, $class_name, $class_name, $class_name]
        );
        $cards[] = ['Messages', count($rows)];
        break;

    case 'materials':
    case 'books':
    case 'notice':
    case 'routine':
    case 'syllabus':
    case 'events':
        $summary = 'This class workspace is ready. Dedicated storage for this module is not configured yet, so the roster is shown as the working base.';
        break;
}

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
.class-hero{background:linear-gradient(135deg,#172554,#0f766e);color:#fff;border-radius:16px;padding:26px;margin-bottom:22px;box-shadow:0 16px 36px rgba(15,23,42,.16)}
.class-kpi{border:0;border-radius:14px;box-shadow:0 10px 28px rgba(15,23,42,.07)}
.class-table th{font-size:.74rem;text-transform:uppercase;letter-spacing:.5px;color:#64748b}
</style>

<div class="container-fluid py-4">
    <div class="class-hero d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <div class="small text-white-50 fw-bold text-uppercase mb-2"><?php echo htmlspecialchars($class_name); ?></div>
            <h1 class="h3 fw-bold mb-1"><i class="fa <?php echo htmlspecialchars($module_icon); ?> me-2"></i><?php echo htmlspecialchars($module_title); ?></h1>
            <p class="mb-0 text-white-50"><?php echo htmlspecialchars($summary); ?></p>
        </div>
        <a href="class_view.php?class=<?php echo urlencode($class_name); ?>" class="btn btn-light text-primary fw-bold"><i class="fa fa-arrow-left me-2"></i>Class View</a>
    </div>

    <div class="row g-3 mb-4">
        <?php foreach ($cards as $card): ?>
            <div class="col-md-4 col-xl-3">
                <div class="card class-kpi"><div class="card-body">
                    <div class="text-muted small fw-bold"><?php echo htmlspecialchars($card[0]); ?></div>
                    <div class="h3 fw-bold mb-0"><?php echo htmlspecialchars((string)$card[1]); ?></div>
                </div></div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h2 class="h5 fw-bold mb-0">Records</h2>
            <span class="badge text-bg-primary"><?php echo count($rows); ?> shown</span>
        </div>
        <?php if (!$rows): ?>
            <div class="text-center py-5 text-muted">
                <i class="fa <?php echo htmlspecialchars($module_icon); ?> fa-3x mb-3 opacity-25"></i>
                <p class="mb-0"><?php echo htmlspecialchars($empty); ?></p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 class-table">
                    <thead class="table-light"><tr>
                        <?php foreach ($columns as $column): ?><th><?php echo htmlspecialchars($column); ?></th><?php endforeach; ?>
                    </tr></thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <?php foreach ($row as $value): ?><td><?php echo htmlspecialchars((string)($value ?? 'N/A')); ?></td><?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<style>
/* === Shared Teacher Page Styles === */
/* === Page Header === */
.tp-header {
    border-radius: 18px;
    padding: 28px 32px;
    margin-bottom: 28px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}

.tp-header h2 {
    color: #fff;
    font-weight: 800;
    font-size: 1.6rem;
    margin: 0;
}

.tp-header p {
    color: rgba(255,255,255,0.7);
    margin: 4px 0 0;
    font-size: 0.9rem;
}

.tp-header--blue   { background: linear-gradient(135deg, #0d6efd, #6610f2); }
.tp-header--green  { background: linear-gradient(135deg, #198754, #20c997); }
.tp-header--yellow { background: linear-gradient(135deg, #fd7e14, #ffc107); }
.tp-header--red    { background: linear-gradient(135deg, #dc3545, #e83e8c); }
.tp-header--purple { background: linear-gradient(135deg, #6f42c1, #6610f2); }
.tp-header--grey   { background: linear-gradient(135deg, #495057, #6c757d); }

.tp-back-btn {
    background: rgba(255,255,255,0.18);
    border: 1px solid rgba(255,255,255,0.3);
    color: #fff !important;
    border-radius: 10px;
    padding: 8px 18px;
    font-weight: 600;
    font-size: 0.88rem;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    transition: all 0.2s ease;
    backdrop-filter: blur(6px);
}

.tp-back-btn:hover {
    background: rgba(255,255,255,0.28);
    transform: translateX(-3px);
}

/* === Empty State === */
.tp-empty {
    text-align: center;
    padding: 70px 20px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

/* === Table === */
.tp-table {
    font-size: 0.9rem;
}

.tp-row {
    cursor: pointer;
    transition: background 0.2s ease;
}

.tp-row:hover {
    background-color: rgba(13, 110, 253, 0.04) !important;
}

.tp-row.active-row {
    background-color: rgba(13, 110, 253, 0.07) !important;
    border-left: 3px solid #0d6efd;
}

/* === Action Panel === */
.tp-action-row td {
    padding: 0 !important;
}

.tp-action-panel {
    background: #f8f9fa;
    border-radius: 10px;
    margin: 6px 12px 10px;
    padding: 14px 18px;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
    border: 1px solid #e9ecef;
    animation: panelSlide 0.25s ease;
}

@keyframes panelSlide {
    from { opacity: 0; transform: translateY(-6px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* === Neumorphic Action Buttons === */
.tp-btn {
    background: #f0f2f5;
    box-shadow: 5px 5px 10px #d4d6d9, -5px -5px 10px #ffffff;
    border: none;
    border-radius: 10px;
    color: #333 !important;
    font-weight: 700;
    font-size: 0.82rem;
    padding: 9px 18px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
}

.tp-btn:hover {
    box-shadow: inset 4px 4px 8px #d4d6d9, inset -4px -4px 8px #ffffff;
    transform: translateY(-1px);
}

.tp-btn i { font-size: 0.85rem; }

.tp-btn-view   { color: #4a0bdb !important; }
.tp-btn-view i { color: #4a0bdb; }

.tp-btn-edit   { color: #0f766e !important; }
.tp-btn-edit i { color: #0f766e; }

.tp-btn-pdf    { color: #9b1c1c !important; }
.tp-btn-pdf i  { color: #9b1c1c; }

.tp-btn-dash   { color: #854d0e !important; }
.tp-btn-dash i { color: #854d0e; }

.tp-btn-approve   { color: #166534 !important; }
.tp-btn-approve i { color: #166534; }

.tp-btn-reject   { color: #b91c1c !important; }
.tp-btn-reject i { color: #b91c1c; }

.tp-btn-delete   { color: #991b1b !important; }
.tp-btn-delete i { color: #991b1b; }

.tp-btn-restore   { color: #1e5a3a !important; }
.tp-btn-restore i { color: #1e5a3a; }

.tp-btn-purge   { color: #1f2937 !important; }
.tp-btn-purge i { color: #1f2937; }

/* Sidebar fixes */
.sidebar, #sidebar { background: #212529 !important; border-right: 1px solid rgba(255,255,255,0.1); }
.sidebar .nav-link, #sidebar .nav-link { color: rgba(255,255,255,0.7) !important; }
.sidebar .nav-link:hover, #sidebar .nav-link:hover { color: #fff !important; background: rgba(255,255,255,0.1); }
.sidebar .nav-link.active, #sidebar .nav-link.active { color: #fff !important; background: #0d6efd !important; }
</style>

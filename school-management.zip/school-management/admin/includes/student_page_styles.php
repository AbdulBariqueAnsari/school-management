<style>
/* === Shared Student/Admissions Page Styles === */

/* === Page Header === */
.sp-header {
    border-radius: 18px;
    padding: 28px 32px;
    margin-bottom: 28px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
}
.sp-header h2 { color: #fff; font-weight: 800; font-size: 1.6rem; margin: 0; }
.sp-header p  { color: rgba(255,255,255,0.7); margin: 4px 0 0; font-size: 0.9rem; }

.sp-header--blue   { background: linear-gradient(135deg, #0d6efd, #6610f2); }
.sp-header--green  { background: linear-gradient(135deg, #198754, #20c997); }
.sp-header--yellow { background: linear-gradient(135deg, #fd7e14, #ffc107); }
.sp-header--red    { background: linear-gradient(135deg, #dc3545, #e83e8c); }
.sp-header--grey   { background: linear-gradient(135deg, #495057, #6c757d); }
.sp-header--teal   { background: linear-gradient(135deg, #0f766e, #06b6d4); }

.sp-back-btn {
    background: rgba(255,255,255,0.18);
    border: 1px solid rgba(255,255,255,0.3);
    color: #fff !important;
    border-radius: 10px;
    padding: 8px 18px;
    font-weight: 600;
    font-size: 0.88rem;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    transition: all 0.2s ease;
    backdrop-filter: blur(6px);
}
.sp-back-btn:hover { background: rgba(255,255,255,0.28); transform: translateX(-3px); }

/* === Empty State === */
.sp-empty {
    text-align: center;
    padding: 70px 20px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.06);
}

/* === Table === */
.sp-table { font-size: 0.9rem; }

.sp-row {
    cursor: pointer;
    transition: background 0.2s ease;
}
.sp-row:hover { background-color: rgba(13,110,253,0.04) !important; }
.sp-row.active-row {
    background-color: rgba(13,110,253,0.07) !important;
    border-left: 3px solid #0d6efd;
}

/* === Action Panel === */
.sp-action-row td { padding: 0 !important; }
.sp-action-panel {
    background: #f8f9fa;
    border-radius: 10px;
    margin: 6px 12px 10px;
    padding: 14px 18px;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
    border: 1px solid #e9ecef;
    animation: spSlide 0.25s ease;
}
@keyframes spSlide {
    from { opacity: 0; transform: translateY(-6px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* === Neumorphic Action Buttons === */
.sp-btn {
    background: #f0f2f5;
    box-shadow: 5px 5px 10px #d4d6d9, -5px -5px 10px #ffffff;
    border: none;
    border-radius: 10px;
    color: #333 !important;
    font-weight: 700;
    font-size: 0.82rem;
    padding: 9px 18px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
}
.sp-btn:hover {
    box-shadow: inset 4px 4px 8px #d4d6d9, inset -4px -4px 8px #ffffff;
    transform: translateY(-1px);
}
.sp-btn i { font-size: 0.85rem; }

.sp-btn-view    { color: #4a0bdb !important; } .sp-btn-view i    { color: #4a0bdb; }
.sp-btn-edit    { color: #0f766e !important; } .sp-btn-edit i    { color: #0f766e; }
.sp-btn-pdf     { color: #9b1c1c !important; } .sp-btn-pdf i     { color: #9b1c1c; }
.sp-btn-approve { color: #166534 !important; } .sp-btn-approve i { color: #166534; }
.sp-btn-reject  { color: #b91c1c !important; } .sp-btn-reject i  { color: #b91c1c; }
.sp-btn-delete  { color: #991b1b !important; } .sp-btn-delete i  { color: #991b1b; }
.sp-btn-restore { color: #1e5a3a !important; } .sp-btn-restore i { color: #1e5a3a; }
.sp-btn-purge   { color: #1f2937 !important; } .sp-btn-purge i   { color: #1f2937; }

/* Sidebar */
.sidebar, #sidebar { background: #212529 !important; border-right: 1px solid rgba(255,255,255,0.1); }
.sidebar .nav-link, #sidebar .nav-link { color: rgba(255,255,255,0.7) !important; }
.sidebar .nav-link:hover, #sidebar .nav-link:hover { color: #fff !important; background: rgba(255,255,255,0.1); }
.sidebar .nav-link.active, #sidebar .nav-link.active { color: #fff !important; background: #0d6efd !important; }
</style>

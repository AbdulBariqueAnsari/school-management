<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {

    // ---- Row Click Toggle (Event Delegation) ----
    document.addEventListener('click', function (e) {
        const row = e.target.closest('.sp-row');
        if (!row) return;
        if (e.target.closest('a') || e.target.closest('button')) return;
        
        const id = row.getAttribute('data-id');
        const panelRow = document.getElementById('sp-panel-' + id);
        if (!panelRow) return;

        const isOpen = panelRow.style.display !== 'none';

        // Close all first
        document.querySelectorAll('.sp-action-row').forEach(function (p) { p.style.display = 'none'; });
        document.querySelectorAll('.sp-row.active-row').forEach(function (r) { r.classList.remove('active-row'); });

        if (!isOpen) {
            panelRow.style.display = 'table-row';
            row.classList.add('active-row');
        }
    });

    // ---- Confirmation Buttons ----
    const confirmBtns = document.querySelectorAll('.sp-confirm');
    confirmBtns.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            const url     = this.getAttribute('data-url');
            const title   = this.getAttribute('data-title');
            const text    = this.getAttribute('data-text');
            const icon    = this.getAttribute('data-icon') || 'warning';
            const confirm = this.getAttribute('data-confirm') || 'Yes, proceed';

            Swal.fire({
                title: title,
                text: text,
                icon: icon,
                showCancelButton: true,
                confirmButtonColor: icon === 'error' ? '#dc3545' : (icon === 'question' ? '#198754' : '#fd7e14'),
                cancelButtonColor: '#6c757d',
                confirmButtonText: confirm,
                cancelButtonText: 'Cancel'
            }).then(function (result) {
                if (result.isConfirmed) { window.location.href = url; }
            });
        });
    });

});
</script>

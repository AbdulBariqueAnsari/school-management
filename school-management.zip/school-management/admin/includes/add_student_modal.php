<!-- Manual Student Admission Modal -->
<div class="modal fade" id="addStudentModal" tabindex="-1" aria-labelledby="addStudentModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <div class="modal-content shadow-lg border-0 rounded-3">
      <div class="modal-header bg-primary text-white border-0 py-3">
        <h5 class="modal-title fw-bold" id="addStudentModalLabel"><i class="fa fa-user-plus me-2"></i> Add Student Manually</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="actions/add_student.php" method="POST" enctype="multipart/form-data">
        <div class="modal-body p-4 bg-light">
            <!-- STUDENT DETAILS -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-0 pt-4 pb-0">
                    <h5 class="text-primary mb-0"><i class="fa fa-info-circle me-1"></i> Student Details</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold text-muted small uppercase">Full Name <span class="text-danger">*</span></label>
                            <input type="text" name="full_name" class="form-control form-control-lg bg-light border-0" required>
                        </div>
                <div class="col-md-4">
                    <label class="form-label">Gender <span class="text-danger">*</span></label>
                    <select name="gender" class="form-control" required>
                        <option value="">Select</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Date of Birth <span class="text-danger">*</span></label>
                    <input type="date" name="dob" id="manual_dob" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Age</label>
                    <input type="number" name="age" id="manual_age" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Blood Group</label>
                    <input type="text" name="blood_group" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Aadhaar Number</label>
                    <input type="text" name="aadhaar_number" class="form-control">
                </div>
                <div class="col-md-12">
                            <label class="form-label fw-semibold text-muted small uppercase">Student Photo Upload</label>
                            <input type="file" name="student_photo" class="form-control form-control-lg bg-light border-0" accept="image/*">
                        </div>
                    </div>
                </div>
            </div>

            <!-- CONTACT DETAILS -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-0 pt-4 pb-0">
                    <h5 class="text-primary mb-0"><i class="fa fa-address-book me-1"></i> Contact Details</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Present Address <span class="text-danger">*</span></label>
                    <textarea name="present_address" class="form-control" rows="2" required></textarea>
                </div>
                <div class="col-md-4">
                            <label class="form-label fw-semibold text-muted small uppercase">Student Mobile Number</label>
                            <input type="text" name="student_mobile" class="form-control form-control-lg bg-light border-0">
                        </div>
                    </div>
                </div>
            </div>

            <!-- HEALTH INFORMATION -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white border-0 pt-4 pb-0">
                    <h5 class="text-primary mb-0"><i class="fa fa-heartbeat me-1"></i> Health Information</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Medical Condition <span class="text-danger">*</span></label>
                    <select name="has_medical_condition" class="form-control" required onchange="toggleField(this, 'medical_details_div')">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
                <div class="col-md-8" id="medical_details_div" style="display:none;">
                    <label class="form-label">Medical Details</label>
                    <textarea name="medical_details" class="form-control" rows="1"></textarea>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Disability <span class="text-danger">*</span></label>
                    <select name="has_disability" class="form-control" required onchange="toggleField(this, 'disability_details_div')">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
                <div class="col-md-8" id="disability_details_div" style="display:none;">
                    <label class="form-label">Disability Details</label>
                    <textarea name="disability_details" class="form-control" rows="1"></textarea>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Allergies <span class="text-danger">*</span></label>
                    <select name="has_allergies" class="form-control" required onchange="toggleField(this, 'allergy_details_div')">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
                <div class="col-md-8" id="allergy_details_div" style="display:none;">
                    <label class="form-label">Allergy Details</label>
                    <textarea name="allergy_details" class="form-control" rows="1"></textarea>
                </div>
            </div>

            <!-- IDENTITY & CATEGORY -->
            <h5 class="text-primary border-bottom pb-2 mb-3 mt-4">Identity & Category</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Religion</label>
                    <select name="religion" class="form-control">
                        <option value="">Select</option>
                        <option value="Islam">Islam</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Christian">Christian</option>
                        <option value="Buddhist">Buddhist</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Caste Category</label>
                    <select name="caste_category" class="form-control">
                        <option value="">Select</option>
                        <option value="OBC-A">OBC-A</option>
                        <option value="OBC-B">OBC-B</option>
                        <option value="ST">ST</option>
                        <option value="SC">SC</option>
                        <option value="General">General</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Mother Tongue</label>
                    <input type="text" name="mother_tongue" class="form-control">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Previous Schooling Status</label>
                    <select name="previous_schooling_status" class="form-control">
                        <option value="">Select</option>
                        <option value="Passed from Previous School">Passed from Previous School</option>
                        <option value="Currently Studying">Currently Studying</option>
                        <option value="Transfer Certificate">Transfer Certificate</option>
                        <option value="Left School">Left School</option>
                        <option value="Never Attended School">Never Attended School</option>
                    </select>
                </div>
            </div>

            <!-- PARENT DETAILS -->
            <h5 class="text-primary border-bottom pb-2 mb-3 mt-4">Parent Details</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Father Name <span class="text-danger">*</span></label>
                    <input type="text" name="father_name" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Father Mobile <span class="text-danger">*</span></label>
                    <input type="text" name="father_mobile" class="form-control" required>
                </div>
                <div class="col-md-4"></div>

                <div class="col-md-4">
                    <label class="form-label">Mother Name <span class="text-danger">*</span></label>
                    <input type="text" name="mother_name" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Mother Mobile <span class="text-danger">*</span></label>
                    <input type="text" name="mother_mobile" class="form-control" required>
                </div>
                <div class="col-md-4"></div>

                <div class="col-md-12">
                    <label class="form-label">Parent Address <span class="text-danger">*</span></label>
                    <textarea name="parent_address" class="form-control" rows="2" required></textarea>
                </div>
            </div>

            <!-- GUARDIAN DETAILS -->
            <h5 class="text-primary border-bottom pb-2 mb-3 mt-4">Guardian Details (Optional)</h5>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Guardian Name</label>
                    <input type="text" name="guardian_name" class="form-control" id="guardian_name_input" onkeyup="toggleGuardianFields()">
                </div>
                <div class="col-md-6 guardian-field" style="display:none;">
                    <label class="form-label">Relation with Student</label>
                    <input type="text" name="guardian_relation" class="form-control">
                </div>
                <div class="col-md-6 guardian-field" style="display:none;">
                    <label class="form-label">Guardian Mobile</label>
                    <input type="text" name="guardian_mobile" class="form-control">
                </div>
                <div class="col-md-6 guardian-field" style="display:none;">
                    <label class="form-label">Guardian Address</label>
                    <input type="text" name="guardian_address" class="form-control">
                </div>
            </div>

            <!-- ACADEMIC BACKGROUND -->
            <h5 class="text-primary border-bottom pb-2 mb-3 mt-4">Academic Background</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Class Applying For <span class="text-danger">*</span></label>
                    <select name="class_applying_for" class="form-control" required>
                        <option value="">Select</option>
                        <option value="Pre-Nursery">Pre-Nursery</option>
                        <option value="Nursery">Nursery</option>
                        <option value="LKG">LKG</option>
                        <option value="UKG">UKG</option>
                        <option value="Class 1">Class 1</option>
                        <option value="Class 2">Class 2</option>
                        <option value="Class 3">Class 3</option>
                        <option value="Class 4">Class 4</option>
                        <option value="Class 5">Class 5</option>
                        <option value="Class 6">Class 6</option>
                        <option value="Class 7">Class 7</option>
                        <option value="Class 8">Class 8</option>
                        <option value="Class 9">Class 9</option>
                        <option value="Class 10">Class 10</option>
                        <option value="Class 11">Class 11</option>
                        <option value="Class 12">Class 12</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Previous Class</label>
                    <input type="text" name="previous_class" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Previous School Name</label>
                    <input type="text" name="previous_school_name" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Previous Board</label>
                    <input type="text" name="previous_board" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Year of Passing</label>
                    <input type="number" name="year_of_passing" class="form-control">
                </div>
            </div>

            <!-- PORTAL LOGIN DETAILS -->
            <h5 class="text-primary border-bottom pb-2 mb-3 mt-4">Portal Login Details</h5>
            <div class="row g-3">
                <div class="col-md-4">
                            <label class="form-label fw-semibold text-muted small">Username <span class="text-danger">*</span></label>
                            <input type="text" name="username" class="form-control form-control-lg bg-light border-0" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold text-muted small">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control form-control-lg bg-light border-0" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold text-muted small">Password <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control form-control-lg bg-light border-0" required>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="modal-footer border-0 bg-white py-3">
          <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success px-4 shadow-sm"><i class="fa fa-check me-2"></i> Add Student & Approve</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="../assets/js/age_calc.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var modalEl = document.getElementById('addStudentModal');
    if (modalEl && modalEl.parentNode !== document.body) {
        document.body.appendChild(modalEl);
    }
    
    // Auto-calculate age in manual admission modal
    const dobInput = document.getElementById('manual_dob');
    const ageInput = document.getElementById('manual_age');
    if (dobInput && ageInput) {
        dobInput.addEventListener('change', function() {
            const dob = new Date(this.value);
            const today = new Date();
            let age = today.getFullYear() - dob.getFullYear();
            const m = today.getMonth() - dob.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
                age--;
            }
            ageInput.value = age >= 0 ? age : 0;
        });
    }
});

function toggleField(selectElem, targetId) {
    var target = document.getElementById(targetId);
    if(selectElem.value === 'Yes') {
        target.style.display = 'block';
    } else {
        target.style.display = 'none';
        target.querySelector('textarea').value = '';
    }
}

function toggleGuardianFields() {
    var input = document.getElementById('guardian_name_input').value;
    var fields = document.querySelectorAll('.guardian-field');
    if(input.trim() !== '') {
        fields.forEach(function(el) { el.style.display = 'block'; });
    } else {
        fields.forEach(function(el) { 
            el.style.display = 'none'; 
            el.querySelector('input').value = '';
        });
    }
}
</script>

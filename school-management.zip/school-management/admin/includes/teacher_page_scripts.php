<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {

    // ---- Row Click Toggle ----
    const rows = document.querySelectorAll('.tp-row');
    rows.forEach(function (row) {
        row.addEventListener('click', function (e) {
            // Don't toggle if clicking a link inside the row
            if (e.target.closest('a')) return;

            const id = this.getAttribute('data-id');
            const panelRow = document.getElementById('panel-' + id);
            if (!panelRow) return;

            const isOpen = panelRow.style.display !== 'none';

            // Close all open panels first
            document.querySelectorAll('.tp-action-row').forEach(function (p) {
                p.style.display = 'none';
            });
            document.querySelectorAll('.tp-row.active-row').forEach(function (r) {
                r.classList.remove('active-row');
            });

            // Toggle this one
            if (!isOpen) {
                panelRow.style.display = 'table-row';
                this.classList.add('active-row');
            }
        });
    });

    // ---- Confirmation Buttons ----
    const confirmBtns = document.querySelectorAll('.btn-confirm');
    confirmBtns.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            const url     = this.getAttribute('data-url');
            const title   = this.getAttribute('data-title');
            const text    = this.getAttribute('data-text');
            const icon    = this.getAttribute('data-icon') || 'warning';
            const confirm = this.getAttribute('data-confirm') || 'Yes, proceed';

            Swal.fire({
                title: title,
                text: text,
                icon: icon,
                showCancelButton: true,
                confirmButtonColor: icon === 'error' ? '#dc3545' : (icon === 'question' ? '#198754' : '#fd7e14'),
                cancelButtonColor: '#6c757d',
                confirmButtonText: confirm,
                cancelButtonText: 'Cancel'
            }).then(function (result) {
                if (result.isConfirmed) {
                    window.location.href = url;
                }
            });
        });
    });

});
</script>

<?php
require_once '../includes/auth.php';

// Super Admin Only
if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

if (!isset($_GET['id'])) {
    redirect('admissions.php');
}

$id = (int)$_GET['id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_application'])) {
    try {
        $stmtUpdate = $pdo->prepare("UPDATE admission_applications SET 
            student_name = ?, dob = ?, gender = ?, blood_group = ?, 
            address = ?, previous_school = ?, aadhaar_number = ?, 
            parent_name = ?, parent_phone = ?, parent_email = ?, 
            class_applying_for = ?, mobile_number = ?, religion = ?, 
            caste_category = ?, mother_tongue = ?, father_name = ?, 
            father_mobile = ?, mother_name = ?, mother_mobile = ?, 
            parents_address = ?, guardian_name = ?, relation = ?, 
            guardian_mobile = ?, guardian_address = ?, has_medical_condition = ?, 
            medical_condition_desc = ?, has_disability = ?, disability_desc = ?, 
            has_allergies = ?, allergies_desc = ?, previous_schooling_status = ?, 
            previous_class = ?, previous_board = ?, year_of_passing = ?
            WHERE id = ?");

        $stmtUpdate->execute([
            trim($_POST['student_name']),
            trim($_POST['dob']),
            trim($_POST['gender']),
            trim($_POST['blood_group']),
            trim($_POST['address']),
            trim($_POST['previous_school']),
            trim($_POST['aadhaar_number']),
            trim($_POST['parent_name']),
            trim($_POST['parent_phone']),
            trim($_POST['parent_email']),
            (int)$_POST['class_applying_for'],
            trim($_POST['mobile_number'] ?? ''),
            trim($_POST['religion'] ?? ''),
            trim($_POST['caste_category'] ?? ''),
            trim($_POST['mother_tongue'] ?? ''),
            trim($_POST['father_name'] ?? ''),
            trim($_POST['father_mobile'] ?? ''),
            trim($_POST['mother_name'] ?? ''),
            trim($_POST['mother_mobile'] ?? ''),
            trim($_POST['parents_address'] ?? ''),
            trim($_POST['guardian_name'] ?? ''),
            trim($_POST['relation'] ?? ''),
            trim($_POST['guardian_mobile'] ?? ''),
            trim($_POST['guardian_address'] ?? ''),
            trim($_POST['has_medical_condition'] ?? ''),
            trim($_POST['medical_condition_desc'] ?? ''),
            trim($_POST['has_disability'] ?? ''),
            trim($_POST['disability_desc'] ?? ''),
            trim($_POST['has_allergies'] ?? ''),
            trim($_POST['allergies_desc'] ?? ''),
            trim($_POST['previous_schooling_status'] ?? ''),
            trim($_POST['previous_class'] ?? ''),
            trim($_POST['previous_board'] ?? ''),
            trim($_POST['year_of_passing'] ?? ''),
            $id
        ]);
        $message = "Application updated successfully!";
    }
    catch (Exception $e) {
        $message = "Error updating application: " . $e->getMessage();
    }
}

$stmt = $pdo->prepare("SELECT * FROM admission_applications WHERE id = ?");
$stmt->execute([$id]);
$app = $stmt->fetch();

if (!$app) {
    redirect('admissions.php');
}

// Fetch classes
$clsStmt = $pdo->query("SELECT id, name FROM classes ORDER BY id");
$classesList = $clsStmt->fetchAll();

require_once '../includes/header.php';
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">View / Edit Application #<?php echo $id; ?></h1>
    <a href="admissions.php" class="btn btn-outline-secondary"><i class="fa fa-arrow-left me-1"></i> Back to Admissions</a>
</div>

<?php if ($message): ?>
    <div class="alert alert-success"><i class="fa fa-check-circle"></i> <?php echo htmlspecialchars($message); ?></div>
<?php
endif; ?>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Full Applicant Details</h5>
        <span class="badge bg-light text-dark">Status: <?php echo htmlspecialchars($app['status']); ?></span>
    </div>
    <div class="card-body">
        <form method="POST">
            <h5 class="border-bottom pb-2 mb-3 text-primary"><i class="fa fa-user"></i> Student Information</h5>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Student Name</label>
                    <input type="text" name="student_name" class="form-control" value="<?php echo htmlspecialchars($app['student_name']); ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Date of Birth</label>
                    <input type="date" name="dob" id="edit_app_dob" class="form-control" value="<?php echo htmlspecialchars($app['dob']); ?>" required>
                </div>
                <div class="col-md-2 mb-3">
                    <label class="form-label fw-bold text-muted">Calculated Age</label>
                    <input type="text" id="edit_app_age" class="form-control bg-light" readonly>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Gender</label>
                    <select name="gender" class="form-select" required>
                        <option value="Male" <?php echo $app['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo $app['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                        <option value="Other" <?php echo $app['gender'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Blood Group</label>
                    <input type="text" name="blood_group" class="form-control" value="<?php echo htmlspecialchars($app['blood_group'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Aadhaar Number</label>
                    <input type="text" name="aadhaar_number" class="form-control" value="<?php echo htmlspecialchars($app['aadhaar_number'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Mobile Number</label>
                    <input type="text" name="mobile_number" class="form-control" value="<?php echo htmlspecialchars($app['mobile_number'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Religion</label>
                    <input type="text" name="religion" class="form-control" value="<?php echo htmlspecialchars($app['religion'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Caste Category</label>
                    <input type="text" name="caste_category" class="form-control" value="<?php echo htmlspecialchars($app['caste_category'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Mother Tongue</label>
                    <input type="text" name="mother_tongue" class="form-control" value="<?php echo htmlspecialchars($app['mother_tongue'] ?? ''); ?>">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label fw-bold">Present Address</label>
                    <textarea name="address" class="form-control" rows="2" required><?php echo htmlspecialchars($app['address']); ?></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Class Applying For</label>
                    <select name="class_applying_for" class="form-select" required>
                        <?php foreach ($classesList as $c): ?>
                            <option value="<?php echo $c['id']; ?>" <?php echo $app['class_applying_for'] == $c['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($c['name']); ?></option>
                        <?php
endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Student Photo (Uploaded Path)</label>
                    <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars($app['student_photo'] ?? 'No Photo Uploaded'); ?>" readonly>
                </div>
            </div>

            <h5 class="border-bottom pb-2 mt-4 mb-3 text-primary"><i class="fa fa-users"></i> Parent / Guardian Information</h5>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Father's Name</label>
                    <input type="text" name="father_name" class="form-control" value="<?php echo htmlspecialchars($app['father_name'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Father's Mobile</label>
                    <input type="text" name="father_mobile" class="form-control" value="<?php echo htmlspecialchars($app['father_mobile'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Mother's Name</label>
                    <input type="text" name="mother_name" class="form-control" value="<?php echo htmlspecialchars($app['mother_name'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Mother's Mobile</label>
                    <input type="text" name="mother_mobile" class="form-control" value="<?php echo htmlspecialchars($app['mother_mobile'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Primary Parent Email</label>
                    <input type="email" name="parent_email" class="form-control" value="<?php echo htmlspecialchars($app['parent_email'] ?? ''); ?>">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label fw-bold">Parents' Address</label>
                    <textarea name="parents_address" class="form-control" rows="2"><?php echo htmlspecialchars($app['parents_address'] ?? ''); ?></textarea>
                </div>
                
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Guardian Name</label>
                    <input type="text" name="guardian_name" class="form-control" value="<?php echo htmlspecialchars($app['guardian_name'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Relation</label>
                    <input type="text" name="relation" class="form-control" value="<?php echo htmlspecialchars($app['relation'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Guardian Mobile</label>
                    <input type="text" name="guardian_mobile" class="form-control" value="<?php echo htmlspecialchars($app['guardian_mobile'] ?? ''); ?>">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label fw-bold">Guardian Address</label>
                    <textarea name="guardian_address" class="form-control" rows="2"><?php echo htmlspecialchars($app['guardian_address'] ?? ''); ?></textarea>
                </div>
                <!-- Hidden compatibility fallbacks for logic -->
                <input type="hidden" name="parent_name" value="<?php echo htmlspecialchars($app['parent_name'] ?? ''); ?>">
                <input type="hidden" name="parent_phone" value="<?php echo htmlspecialchars($app['parent_phone'] ?? ''); ?>">
            </div>

            <h5 class="border-bottom pb-2 mt-4 mb-3 text-primary"><i class="fa fa-heartbeat"></i> Health Details</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Medical Condition?</label>
                    <input type="text" name="has_medical_condition" class="form-control" value="<?php echo htmlspecialchars($app['has_medical_condition'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Condition Description</label>
                    <input type="text" name="medical_condition_desc" class="form-control" value="<?php echo htmlspecialchars($app['medical_condition_desc'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Disability?</label>
                    <input type="text" name="has_disability" class="form-control" value="<?php echo htmlspecialchars($app['has_disability'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Disability Description</label>
                    <input type="text" name="disability_desc" class="form-control" value="<?php echo htmlspecialchars($app['disability_desc'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Allergies?</label>
                    <input type="text" name="has_allergies" class="form-control" value="<?php echo htmlspecialchars($app['has_allergies'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Allergies Description</label>
                    <input type="text" name="allergies_desc" class="form-control" value="<?php echo htmlspecialchars($app['allergies_desc'] ?? ''); ?>">
                </div>
            </div>

            <h5 class="border-bottom pb-2 mt-4 mb-3 text-primary"><i class="fa fa-book"></i> Academic Details</h5>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Previous Schooling</label>
                    <input type="text" name="previous_schooling_status" class="form-control" value="<?php echo htmlspecialchars($app['previous_schooling_status'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Previous School Name</label>
                    <input type="text" name="previous_school" class="form-control" value="<?php echo htmlspecialchars($app['previous_school'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Previous Class</label>
                    <input type="text" name="previous_class" class="form-control" value="<?php echo htmlspecialchars($app['previous_class'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Previous Board</label>
                    <input type="text" name="previous_board" class="form-control" value="<?php echo htmlspecialchars($app['previous_board'] ?? ''); ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label fw-bold">Year of Passing</label>
                    <input type="text" name="year_of_passing" class="form-control" value="<?php echo htmlspecialchars($app['year_of_passing'] ?? ''); ?>">
                </div>
            </div>

            <div class="mt-4 text-end border-top pt-3">
                <button type="submit" name="update_application" class="btn btn-primary px-4 btn-lg"><i class="fa fa-save"></i> Save Application Changes</button>
            </div>
        </form>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

<script src="../assets/js/age_calc.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initial calculation
    const dobInput = document.getElementById('edit_app_dob');
    const ageDisplay = document.getElementById('edit_app_age');
    
    if (dobInput && ageDisplay) {
        function updateAge() {
            const dobValue = dobInput.value;
            if (dobValue) {
                const dob = new Date(dobValue);
                const today = new Date();
                let age = today.getFullYear() - dob.getFullYear();
                const m = today.getMonth() - dob.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
                    age--;
                }
                ageDisplay.value = (age >= 0 ? age : 0) + " yrs";
            } else {
                ageDisplay.value = "";
            }
        }
        
        dobInput.addEventListener('change', updateAge);
        updateAge(); // Run on load
    }
});
</script>

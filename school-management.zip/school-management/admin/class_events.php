<?php
$module_key = 'events';
$module_title = 'Class Events';
$module_icon = 'fa-calendar-days';
require_once __DIR__ . '/includes/class_module.php';
?>

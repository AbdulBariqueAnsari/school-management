<?php
require_once '../includes/auth.php';

if ($_SESSION['role_id'] != 1) {
    redirect(BASE_URL . '/dashboard.php');
}

$type = $_GET['type'] ?? 'unknown';

function admin_safe_count($sql, $params = [])
{
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

function admin_safe_rows($sql, $params = [], $limit = 100)
{
    global $pdo;
    try {
        $sql .= " LIMIT " . (int)$limit;
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

function admin_table_exists($table)
{
    global $pdo;
    try {
        $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
        $stmt->execute([$table]);
        return (bool)$stmt->fetchColumn();
    } catch (Exception $e) {
        return false;
    }
}

function admin_money($value)
{
    $currency = defined('APP_CURRENCY') ? APP_CURRENCY : 'USD';
    return $currency . ' ' . number_format((float)$value, 2);
}

$module = [
    'title' => 'Module Dashboard',
    'icon' => 'fa-chart-simple',
    'summary' => 'Operational admin view.',
    'cards' => [],
    'columns' => [],
    'rows' => [],
    'empty' => 'No records found for this module yet.',
];

switch ($type) {
    case 'active_students':
        $module['title'] = 'Active Students';
        $module['icon'] = 'fa-user-check';
        $module['summary'] = 'Approved student records currently active in the school.';
        $module['cards'] = [
            ['Approved', admin_safe_count("SELECT COUNT(*) FROM students WHERE status='Approved'")],
            ['Male', admin_safe_count("SELECT COUNT(*) FROM students WHERE status='Approved' AND gender='Male'")],
            ['Female', admin_safe_count("SELECT COUNT(*) FROM students WHERE status='Approved' AND gender='Female'")],
        ];
        $module['columns'] = ['Admission No', 'Student', 'Class', 'Parent', 'Status'];
        $module['rows'] = admin_safe_rows("SELECT admission_no, student_name, class_applied, parent_name, status FROM students WHERE status='Approved' ORDER BY student_name");
        break;

    case 'inactive_students':
        $module['title'] = 'Inactive / Rejected Students';
        $module['icon'] = 'fa-user-slash';
        $module['summary'] = 'Students who are rejected, deleted, or inactive.';
        $module['cards'] = [
            ['Rejected', admin_safe_count("SELECT COUNT(*) FROM students WHERE status='Rejected'")],
            ['Deleted', admin_safe_count("SELECT COUNT(*) FROM students WHERE status='Deleted'")],
        ];
        $module['columns'] = ['Admission No', 'Student', 'Class', 'Parent', 'Status'];
        $module['rows'] = admin_safe_rows("SELECT admission_no, student_name, class_applied, parent_name, status FROM students WHERE status IN ('Rejected','Deleted') ORDER BY created_at DESC");
        break;

    case 'promoted_students':
        $module['title'] = 'Promoted Students';
        $module['icon'] = 'fa-arrow-up-right-dots';
        $module['summary'] = 'Students marked as promoted.';
        $module['cards'] = [['Promoted', admin_safe_count("SELECT COUNT(*) FROM students WHERE status='Promoted'")]];
        $module['columns'] = ['Admission No', 'Student', 'Class', 'Parent', 'Status'];
        $module['rows'] = admin_safe_rows("SELECT admission_no, student_name, class_applied, parent_name, status FROM students WHERE status='Promoted' ORDER BY student_name");
        break;

    case 'boys':
    case 'girls':
        $gender = $type === 'boys' ? 'Male' : 'Female';
        $module['title'] = $gender . ' Students';
        $module['icon'] = 'fa-users';
        $module['summary'] = 'Gender-wise approved student list.';
        $module['cards'] = [[$gender, admin_safe_count("SELECT COUNT(*) FROM students WHERE gender = ?", [$gender])]];
        $module['columns'] = ['Admission No', 'Student', 'Class', 'Parent', 'Status'];
        $module['rows'] = admin_safe_rows("SELECT admission_no, student_name, class_applied, parent_name, status FROM students WHERE gender = ? ORDER BY student_name", [$gender]);
        break;

    case 'invoices':
    case 'paid_invoices':
    case 'unpaid_invoices':
    case 'partial_invoices':
        $titles = [
            'invoices' => 'Fee Invoices',
            'paid_invoices' => 'Paid Fee Records',
            'unpaid_invoices' => 'Unpaid Fee Records',
            'partial_invoices' => 'Partially Paid Fee Records',
        ];
        $module['title'] = $titles[$type];
        $module['icon'] = 'fa-file-invoice-dollar';
        $module['summary'] = 'Finance view based on configured fees and payment records.';
        $totalFees = admin_safe_count("SELECT COUNT(*) FROM fees");
        $totalPayments = admin_safe_count("SELECT COUNT(*) FROM payments");
        $received = admin_safe_count("SELECT COALESCE(SUM(amount_paid),0) FROM payments WHERE status='Completed'");
        $module['cards'] = [
            ['Fee Heads', $totalFees],
            ['Payment Rows', $totalPayments],
            ['Received', admin_money($received)],
        ];
        $module['columns'] = ['Title', 'Class ID', 'Amount', 'Due Date', 'Academic Year'];
        $module['rows'] = admin_safe_rows("SELECT title, class_id, amount, due_date, academic_year_id FROM fees ORDER BY due_date DESC");
        if ($type === 'paid_invoices') {
            $module['columns'] = ['Student ID', 'Fee ID', 'Paid', 'Method', 'Date'];
            $module['rows'] = admin_safe_rows("SELECT student_id, fee_id, amount_paid, payment_method, payment_date FROM payments WHERE status='Completed' ORDER BY payment_date DESC");
        }
        break;

    case 'payments':
    case 'revenue':
    case 'pending':
        $module['title'] = $type === 'pending' ? 'Pending Revenue' : ($type === 'revenue' ? 'Revenue Received' : 'Payments');
        $module['icon'] = 'fa-money-check-dollar';
        $module['summary'] = 'Payment records captured in the fees/payment module.';
        $received = admin_safe_count("SELECT COALESCE(SUM(amount_paid),0) FROM payments WHERE status='Completed'");
        $pending = admin_safe_count("SELECT COALESCE(SUM(amount_paid),0) FROM payments WHERE status='Pending'");
        $module['cards'] = [
            ['Completed Revenue', admin_money($received)],
            ['Pending Amount', admin_money($pending)],
            ['Total Payments', admin_safe_count("SELECT COUNT(*) FROM payments")],
        ];
        $module['columns'] = ['Student ID', 'Fee ID', 'Paid', 'Method', 'Status', 'Date'];
        $module['rows'] = admin_safe_rows("SELECT student_id, fee_id, amount_paid, payment_method, status, payment_date FROM payments ORDER BY payment_date DESC");
        break;

    case 'expenses':
    case 'donations':
        $module['title'] = $type === 'expenses' ? 'Expenses' : 'Donations';
        $module['icon'] = $type === 'expenses' ? 'fa-receipt' : 'fa-hand-holding-dollar';
        $module['summary'] = 'Register area for future ' . strtolower($module['title']) . ' entries.';
        $module['cards'] = [['Records', 0], ['Total', admin_money(0)]];
        $module['columns'] = ['Date', 'Title', 'Amount', 'Status'];
        $module['rows'] = [];
        $module['empty'] = $module['title'] . ' table is not configured yet. The page shell is ready for entries when that database table is added.';
        break;

    case 'timetables':
    case 'admit_cards':
    case 'results':
        $module['title'] = $type === 'results' ? 'Exam Results' : ($type === 'admit_cards' ? 'Admit Cards' : 'Exam Timetables');
        $module['icon'] = $type === 'results' ? 'fa-graduation-cap' : 'fa-calendar-days';
        $module['summary'] = 'Exam data from exams and marks records.';
        $module['cards'] = [
            ['Exams', admin_safe_count("SELECT COUNT(*) FROM exams")],
            ['Marks', admin_safe_count("SELECT COUNT(*) FROM marks")],
            ['Students', admin_safe_count("SELECT COUNT(*) FROM students WHERE status='Approved'")],
        ];
        if ($type === 'results') {
            $module['columns'] = ['Exam ID', 'Student ID', 'Subject ID', 'Marks', 'Grade'];
            $module['rows'] = admin_safe_rows("SELECT exam_id, student_id, subject_id, CONCAT(marks_obtained, '/', total_marks) AS marks, grade FROM marks ORDER BY id DESC");
        } else {
            $module['columns'] = ['Exam', 'Start Date', 'End Date', 'Academic Year'];
            $module['rows'] = admin_safe_rows("SELECT name, start_date, end_date, academic_year_id FROM exams ORDER BY start_date DESC");
        }
        break;

    case 'books':
    case 'library_cards':
        $module['title'] = $type === 'books' ? 'Library Books' : 'Library Cards';
        $module['icon'] = $type === 'books' ? 'fa-book-open' : 'fa-id-card';
        $module['summary'] = 'Library-ready view using current student records until a dedicated library table is added.';
        $module['cards'] = [
            ['Books Table', admin_table_exists('books') ? 'Ready' : 'Not Added'],
            ['Active Students', admin_safe_count("SELECT COUNT(*) FROM students WHERE status='Approved'")],
        ];
        $module['columns'] = ['Admission No', 'Student', 'Class', 'Status'];
        $module['rows'] = admin_safe_rows("SELECT admission_no, student_name, class_applied, status FROM students WHERE status='Approved' ORDER BY student_name");
        break;

    case 'admins':
    case 'staff':
    case 'active_staff':
        $module['title'] = $type === 'admins' ? 'Administrators' : ($type === 'active_staff' ? 'Active Staff' : 'Total Staff');
        $module['icon'] = 'fa-user-tie';
        $module['summary'] = 'Staff and administrator accounts from the users table.';
        $where = $type === 'admins' ? "role_id = 1" : "role_id NOT IN (6,7)";
        if ($type === 'active_staff') {
            $where .= " AND is_active = 1";
        }
        $module['cards'] = [
            ['Records', admin_safe_count("SELECT COUNT(*) FROM users WHERE $where")],
            ['Active', admin_safe_count("SELECT COUNT(*) FROM users WHERE $where AND is_active=1")],
        ];
        $module['columns'] = ['Name', 'Username', 'Email', 'Role ID', 'Active'];
        $module['rows'] = admin_safe_rows("SELECT name, username, email, role_id, is_active FROM users WHERE $where ORDER BY name");
        break;

    case 'roles':
        $module['title'] = 'User Roles';
        $module['icon'] = 'fa-users-gear';
        $module['summary'] = 'Role records used by login and dashboard routing.';
        $module['cards'] = [['Roles', admin_safe_count("SELECT COUNT(*) FROM roles")]];
        $module['columns'] = ['ID', 'Role Name'];
        $module['rows'] = admin_safe_rows("SELECT id, name FROM roles ORDER BY id");
        break;
}

require_once '../includes/header.php';
?>

<style>
.module-hero{background:linear-gradient(135deg,#0f172a,#1d4ed8);color:#fff;border-radius:16px;padding:26px;margin-bottom:22px;box-shadow:0 16px 36px rgba(15,23,42,.16)}
.module-kpi{border:0;border-radius:14px;box-shadow:0 10px 28px rgba(15,23,42,.07)}
.module-table th{font-size:.74rem;text-transform:uppercase;letter-spacing:.5px;color:#64748b}
</style>

<div class="container-fluid py-4">
    <div class="module-hero d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <div class="small text-white-50 fw-bold text-uppercase mb-2">Admin Module</div>
            <h1 class="h3 fw-bold mb-1"><i class="fa <?php echo htmlspecialchars($module['icon']); ?> me-2"></i><?php echo htmlspecialchars($module['title']); ?></h1>
            <p class="mb-0 text-white-50"><?php echo htmlspecialchars($module['summary']); ?></p>
        </div>
        <a href="index.php" class="btn btn-light text-primary fw-bold"><i class="fa fa-arrow-left me-2"></i>Dashboard</a>
    </div>

    <?php if (!empty($module['cards'])): ?>
        <div class="row g-3 mb-4">
            <?php foreach ($module['cards'] as $card): ?>
                <div class="col-md-4 col-xl-3">
                    <div class="card module-kpi">
                        <div class="card-body">
                            <div class="text-muted small fw-bold"><?php echo htmlspecialchars($card[0]); ?></div>
                            <div class="h3 fw-bold mb-0"><?php echo htmlspecialchars((string)$card[1]); ?></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm" style="border-radius:14px;overflow:hidden;">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h2 class="h5 fw-bold mb-0">Records</h2>
            <span class="badge text-bg-primary"><?php echo count($module['rows']); ?> shown</span>
        </div>
        <?php if (empty($module['rows'])): ?>
            <div class="text-center py-5 text-muted">
                <i class="fa <?php echo htmlspecialchars($module['icon']); ?> fa-3x mb-3 opacity-25"></i>
                <p class="mb-0"><?php echo htmlspecialchars($module['empty']); ?></p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 module-table">
                    <thead class="table-light">
                        <tr>
                            <?php foreach ($module['columns'] as $column): ?>
                                <th><?php echo htmlspecialchars($column); ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($module['rows'] as $row): ?>
                            <tr>
                                <?php foreach ($row as $value): ?>
                                    <td><?php echo htmlspecialchars((string)($value ?? 'N/A')); ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

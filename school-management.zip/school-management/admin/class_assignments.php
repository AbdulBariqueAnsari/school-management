<?php
$module_key = 'assignments';
$module_title = 'Class Assignments';
$module_icon = 'fa-tasks';
require_once __DIR__ . '/includes/class_module.php';
?>

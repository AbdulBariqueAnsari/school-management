<?php
session_start();
require_once '../includes/init.php';

// Check if Super Admin
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    die("Access Denied. You are not authorized to view this page.");
}

// Handle Approve / Reject
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $req_id = (int)$_POST['request_id'];
    $user_id = (int)$_POST['user_id'];
    $action = $_POST['action'];

    if ($action == 'approve') {
        $pdo->query("UPDATE admission_requests SET status = 'Approved' WHERE id = $req_id");
        $pdo->query("UPDATE users SET status = 'Active' WHERE id = $user_id");
        $msg = "Application Approved Successfully.";

        // Optionally generate admission ID
        $adm_id = "ADM-" . date('Y') . "-" . str_pad($user_id, 4, "0", STR_PAD_LEFT);
        $pdo->prepare("UPDATE students SET admission_id = ? WHERE user_id = ?")->execute([$adm_id, $user_id]);

    }
    elseif ($action == 'reject') {
        $pdo->query("UPDATE admission_requests SET status = 'Rejected' WHERE id = $req_id");
        $pdo->query("UPDATE users SET status = 'Rejected' WHERE id = $user_id");
        $msg = "Application Rejected.";
    }
}

// Fetch Applications
$requests = $pdo->query("
    SELECT r.id as req_id, r.status as req_status, r.applied_on, u.id as user_id, u.email, u.profile_photo, s.full_name, s.class_applying_for, s.mobile_number 
    FROM admission_requests r 
    JOIN users u ON r.user_id = u.id 
    JOIN students s ON s.user_id = u.id 
    ORDER BY r.applied_on DESC
")->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admission Requests | Super Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>body { background-color: #f8f9fa; }</style>
</head>
<body>
    <div class="container py-5">
        <h2 class="mb-4 text-primary"><i class="fa-solid fa-users"></i> Admission Requests</h2>
        
        <?php if (isset($msg)): ?>
            <div class="alert alert-info alert-dismissible"><button type="button" class="btn-close" data-bs-dismiss="alert"></button><?php echo $msg; ?></div>
        <?php
endif; ?>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Student Name</th>
                            <th>Class Target</th>
                            <th>Contact</th>
                            <th>Applied On</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$requests): ?>
                            <tr><td colspan="7" class="text-center">No admission requests found.</td></tr>
                        <?php
endif; ?>
                        <?php foreach ($requests as $row): ?>
                        <tr>
                            <td>#<?php echo $row['req_id']; ?></td>
                            <td>
                                <?php if ($row['profile_photo']): ?>
                                    <img src="../uploads/students/<?php echo htmlspecialchars($row['profile_photo']); ?>" width="40" height="40" class="rounded-circle me-2" alt="Photo">
                                <?php
    else: ?>
                                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($row['full_name']); ?>&background=random" width="40" height="40" class="rounded-circle me-2" alt="Photo">
                                <?php
    endif; ?>
                                <strong><?php echo htmlspecialchars($row['full_name']); ?></strong>
                            </td>
                            <td><?php echo htmlspecialchars($row['class_applying_for']); ?></td>
                            <td><?php echo htmlspecialchars($row['mobile_number'] ?? $row['email']); ?></td>
                            <td><?php echo date('d M Y, h:i A', strtotime($row['applied_on'])); ?></td>
                            <td>
                                <?php
    $badge = 'bg-warning text-dark';
    if ($row['req_status'] == 'Approved')
        $badge = 'bg-success';
    if ($row['req_status'] == 'Rejected')
        $badge = 'bg-danger';
?>
                                <span class="badge <?php echo $badge; ?>"><?php echo $row['req_status']; ?></span>
                            </td>
                            <td>
                                <?php if ($row['req_status'] == 'Pending'): ?>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="request_id" value="<?php echo $row['req_id']; ?>">
                                    <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                    <button type="submit" name="action" value="approve" class="btn btn-sm btn-success" onclick="return confirm('Approve this application?');"><i class="fa fa-check"></i></button>
                                    <button type="submit" name="action" value="reject" class="btn btn-sm btn-danger" onclick="return confirm('Reject this application?');"><i class="fa fa-times"></i></button>
                                </form>
                                <?php
    else: ?>
                                    <button class="btn btn-sm btn-secondary" disabled>No Action</button>
                                <?php
    endif; ?>
                            </td>
                        </tr>
                        <?php
endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="mt-3">
            <a href="../dashboard.php" class="btn btn-outline-primary">&larr; Back to Dashboard</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

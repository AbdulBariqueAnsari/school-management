<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=school_management', 'root', '');
    $stmt = $pdo->query('SHOW FULL COLUMNS FROM students');
    $cols = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($cols, JSON_PRETTY_PRINT);
}
catch (Exception $e) {
    echo "DB_ERROR: " . $e->getMessage();
}

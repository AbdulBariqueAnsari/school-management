<?php
require 'config/db.php';
$stmt = $pdo->query("SELECT id, email, username, password FROM users WHERE id = 1");
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
print_r($admin);

// Try to verify the password manually if I know it
$pass = 'SuperPassword123!';
if (password_verify($pass, $admin['password'])) {
    echo "Password 'SuperPassword123!' is CORRECT for superadmin.\n";
} else {
    echo "Password 'SuperPassword123!' is INCORRECT for superadmin.\n";
}

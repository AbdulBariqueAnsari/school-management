<?php
$file = __DIR__ . '/admin/admissions.php';
$content = file_get_contents($file);

// Fix pattern 1: garbled export+reject+delete lines in approved tab
// The mess starts with: <a href="    <a href="actions/export_student.php
$old_pattern = '/<a href="[^"]*<a href="actions\/export_student\.php\?id=<\?php echo \$stu\[.id.\]; \?>" class="btn btn-sm btn-secondary" target="_blank" title="Export PDF"><i class="fa fa-file-pdf"><\/i><\/a>.*?<\/a>\s*<a href="actions\/reject_student\.php[^"]*\?id=<\?php echo \$stu\[.id.\]; \?>" class="btn btn-sm btn-warning" onclick="return confirm[^"]*" title="Reject"><i class="fa fa-times text-dark"><\/i><\/a>\s*<a href="actions\/delete_student\.php[^"]*\?id=<\?php echo \$stu\[.id.\]; \?>" class="btn btn-sm btn-danger" onclick="return confirm[^"]*" title="Delete"><i class="fa fa-trash"><\/i><\/a>/is';

$new_buttons = '                                                           <a href="actions/export_student.php?id=<?php echo $stu[\'id\']; ?>" class="btn btn-sm btn-secondary" target="_blank" title="Export PDF"><i class="fa fa-file-pdf"></i></a>
                                                           <a href="actions/reject_student.php?id=<?php echo $stu[\'id\']; ?>" class="btn btn-sm btn-warning" onclick="return confirm(\'Move to rejected?\')" title="Reject"><i class="fa fa-times text-dark"></i></a>
                                                           <a href="actions/delete_student.php?id=<?php echo $stu[\'id\']; ?>" class="btn btn-sm btn-danger" onclick="return confirm(\'Delete permanently?\')" title="Delete"><i class="fa fa-trash"></i></a>';

$new_content = preg_replace($old_pattern, $new_buttons, $content);

if ($new_content && $new_content !== $content) {
    file_put_contents($file, $new_content);
    echo "SUCCESS: Fixed garbled approved tab buttons\n";
}
else {
    // Try a simpler manual line-by-line replacement
    $lines = explode("\n", $content);
    $fixed = false;
    foreach ($lines as $i => $line) {
        if (strpos($line, '<a href="                                                          <a href="actions/export_student.php') !== false) {
            $lines[$i] = '                                                           <a href="actions/export_student.php?id=<?php echo $stu[\'id\']; ?>" class="btn btn-sm btn-secondary" target="_blank" title="Export PDF"><i class="fa fa-file-pdf"></i></a>';
            $fixed = true;
            echo "Fixed line " . ($i + 1) . "\n";
        }
    }
    if ($fixed) {
        file_put_contents($file, implode("\n", $lines));
        echo "SUCCESS via line replacement\n";
    }
    else {
        echo "FALLBACK: Line not found, showing first 100 chars of problematic lines:\n";
        foreach ($lines as $i => $line) {
            if (strpos($line, 'export_student') !== false || strpos($line, 'export_students') !== false) {
                echo "Line " . ($i + 1) . ": " . substr(trim($line), 0, 120) . "\n";
            }
        }
    }
}
?>
